--
-- PostgreSQL database dump
--

SET client_encoding = 'SQL_ASCII';
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public namespace';


SET search_path = public, pg_catalog;

--
-- Name: plpgsql_call_handler(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION plpgsql_call_handler() RETURNS language_handler
    AS '$libdir/plpgsql', 'plpgsql_call_handler'
    LANGUAGE c;


ALTER FUNCTION public.plpgsql_call_handler() OWNER TO source;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: public; Owner: 
--

CREATE TRUSTED PROCEDURAL LANGUAGE plpgsql HANDLER plpgsql_call_handler;


--
-- Name: allownulls(name, name); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION allownulls(name, name) RETURNS boolean
    AS $_$DECLARE
      tablename ALIAS FOR $1;
      colname ALIAS FOR $2;
      rec_affected int;
    BEGIN
     -- If any params are NULL, return NULL - this means function
     -- can be defined isstrict.
     IF tablename IS NULL OR colname IS NULL THEN
      RETURN NULL;
     END IF;
    
     -- Lock table with standard ALTER TABLE locks
     EXECUTE 'LOCK TABLE ' || quote_ident(tablename) || ' IN ACCESS EXCLUSIVE MODE';
    
     -- Update the system catalogs
     EXECUTE 'UPDATE pg_attribute SET attnotnull = false WHERE attrelid =
    (SELECT oid FROM pg_class WHERE relname = ' || quote_literal(tablename) || ')
    AND attname = ' || quote_literal(colname);
    
     -- Get number of rows modified
     GET DIAGNOSTICS rec_affected = ROW_COUNT;
    
     -- Return number of rows modified
     RETURN (rec_affected = 1);
    
    END;$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.allownulls(name, name) OWNER TO source;

--
-- Name: apst_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION apst_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.apst_code is null ) then
      new.apst_code = new.apst__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.apst_tr_before() OWNER TO source;

--
-- Name: aptp_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION aptp_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( TG_OP = 'INSERT' or TG_OP = 'UPDATE') then
      if ( new.aptp_code is null ) then
        new.aptp_code = new.aptp__sequence::text;
      end if;
    end if;

    -- prevent changing '-'
    if ( TG_OP = 'UPDATE' ) then
      if ( old.aptp_code = '-' ) then
        RAISE EXCEPTION 'You cannot change this code';
        return old;
      end if;
    end if;

    -- prevent deletion of '-'
    if ( TG_OP = 'DELETE' ) then
      if ( old.aptp_code = '-' ) then
        RAISE EXCEPTION 'You cannot remove this code';
        return old;
      end if;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.aptp_tr_before() OWNER TO source;

--
-- Name: bank_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION bank_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.bank_code is null ) then
      new.bank_code = new.bank__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.bank_tr_before() OWNER TO source;

--
-- Name: bkdp_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION bkdp_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_bkdp__sequence bkdp.bkdp__sequence%TYPE;

    BEGIN

         -- get a bkdp__sequence
         select nextval('bkdp_bkdp__sequence_seq')
         into tmp_bkdp__sequence;

         -- add the new row
         insert into bkdp( bkdp__sequence )
                   values( tmp_bkdp__sequence);

         update paym
         set    paym_bkdp__sequence = tmp_bkdp__sequence
         where  paym_bkdp__sequence = 0
         and    (select count(*)
                 from   cred
                 where  cred_paym__sequence = paym.paym__sequence) > 0;

         update bkdp
         set    bkdp_desc = ''
         where  bkdp__sequence = tmp_bkdp__sequence;
         

    return tmp_bkdp__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.bkdp_insert_row() OWNER TO source;

--
-- Name: bkdp_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION bkdp_tr_before() RETURNS "trigger"
    AS $$DECLARE
       tmp_bkdp_amount bkdp.bkdp_amount%TYPE; 
    BEGIN
      if (TG_OP = 'DELETE') then
        RAISE EXCEPTION 'You cannot remove banking batches';
        return null;
      end if;


      select    sum(paym_amount)
      into      tmp_bkdp_amount
      from      paym
      where     paym_bkdp__sequence = new.bkdp__sequence;

    if ( tmp_bkdp_amount is null ) then
      new.bkdp_amount := 0.00::numeric;
    else
      new.bkdp_amount := tmp_bkdp_amount;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.bkdp_tr_before() OWNER TO source;

--
-- Name: byteaparam(bytea, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION byteaparam(bytea, integer) RETURNS text
    AS $_$
    declare
        bparm   alias for $1;  --bytea parameters
        parmIdx alias for $2;

        parmCount  int = 0;
        charCount  int = 0;
        bsize      int;
        c          int;
        parm       text = '';

    begin
        -- length of bytea
        select octet_length(bparm)
        into   bsize;

        -- skip over the leading params
        while parmCount < parmIdx loop
            if (charCount >= bsize) then
               return '';
            end if;
            c := get_byte(bparm, charCount);
            charCount := charCount + 1;
            if c = 0 then
                parmCount := parmCount + 1;
            end if;
        end loop;

        -- extract the parameter.
        while parmCount = parmIdx loop
            if (charCount >= bsize) then
               return '';
            end if;
            c := get_byte(bparm, charCount);
            charCount := charCount + 1;
            if c = 0 then
                parmCount := parmCount + 1;
            else
                parm := parm || chr(c);
            end if;
        end loop;

        return parm;
    end;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.byteaparam(bytea, integer) OWNER TO source;

--
-- Name: cnrt_post_debit(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION cnrt_post_debit(integer) RETURNS integer
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

    arg_patn__sequence ALIAS for $1;
    cnrt_row cnrt%ROWTYPE;
    count_post integer;
    amount_posted svpf.svpf_amount%TYPE;
    tmp_desc text;

    BEGIN

        count_post := 0;

        -- find the due postings
        --

        FOR cnrt_row IN

          select    *
          from      cnrt
          where     cnrt_patn__sequence = arg_patn__sequence
          and       cnrt_balance > 0
          and       ( cnrt_last_date + ctrt_period < 'today'::timestamp
                      or cnrt_last_date is null)

        LOOP

          if (cnrt_row.cnrt_last_date is null ) then
            amount_posted := cnrt_row.cnrt_first_installment;
          else
            amount_posted := cnrt_row.cnrt_other_installment;
          end if;
          tmp_desc := 'Installment - ' || to_char('now'::timestamp, 'Month');

          -- check for overposting
          if ( amount_posted > cnrt_row.cnrt_balance ) then
            amount_posted := cnrt_row.cnrt_balance;
          end if;

          -- post the installment
          -- raise notice '%/%/%/%', cnrt_row.cnrt_patn__sequence, cnrt_row.cnrt_serv_code,tmp_desc, amount_posted;
          insert into svpf(
                svpf_date_service,
                svpf_serv_code,
                svpf_desc,
                svpf_amount,
                svpf_patn__sequence)
            values(
                'now'::timestamp,
                cnrt_row.cnrt_serv_code,
                tmp_desc,
                amount_posted,
                cnrt_row.cnrt_patn__sequence);

          -- update the contract

          update cnrt
          set    cnrt_balance = cnrt_balance - amount_posted,
                 cnrt_last_date = 'today'::timestamp
          where  cnrt__sequence = cnrt_row.cnrt__sequence;
          count_post := count_post + 1;

        END LOOP;

      

    return count_post;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.cnrt_post_debit(integer) OWNER TO source;

--
-- Name: cnrt_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION cnrt_tr_before() RETURNS "trigger"
    AS $$DECLARE
      tmp_serv_code serv.serv_code%TYPE;
      tmp_fept fept%ROWTYPE;
      count_other integer;
      count_remaining integer;

    BEGIN
      --  RAISE NOTICE 'cnrt_tr_before';
      --
      -- if missing service code, then use a default
      -- 

      if (new.cnrt_serv_code is null) then
        new.cnrt_serv_code := '-';
      end if;

      --
      -- load the fee defaults
      -- 

      select fept.*
      into   tmp_fept
      from   fept,patn
      where  patn__sequence = new.cnrt_patn__sequence
      and    fept_serv_code = new.cnrt_serv_code
      and    fept_feet_code = patn_feet_code;

      if not found then
        tmp_fept.fept_amount := 0.00;
      end if;

      --
      -- set some defaults on INSERT
      --

      if ( TG_OP = 'INSERT' ) then
        if (new.cnrt_amount is null) then
          new.cnrt_amount := tmp_fept.fept_amount;
        end if;
      end if;
      
      -- amount cannot be less then already posted amounts
      if ( new.cnrt_last_date is not null ) then
        if ( TG_OP = 'UPDATE' ) then
          if ( new.cnrt_amount < (old.cnrt_amount - old.cnrt_balance) ) then
            new.cnrt_amount := old.cnrt_amount - old.cnrt_balance;
          end if;
          -- balance needs to be adjusted if amount is adjusted
          if ( new.cnrt_amount != old.cnrt_amount ) then
            new.cnrt_balance := new.cnrt_balance + ( new.cnrt_amount - old.cnrt_amount );
          end if;  
        end if;
      end if;

      --
      -- No nulls
      --

      if ( new.cnrt_amount is null ) then
        new.cnrt_amount := 0;
      end if;

      if ( new.cnrt_first_installment is null ) then
        new.cnrt_first_installment := 0;
      end if;

      if ( new.cnrt_other_installment is null ) then
        new.cnrt_other_installment := 0;
      end if;

      if ( new.cnrt_balance is null ) then
        new.cnrt_balance := 0;
      end if;

      if ( new.cnrt_start_date is null ) then
        new.cnrt_start_date := 'now'::timestamp;
      end if;

      if ( new.ctrt_period is null ) then
        new.ctrt_period := '3 months'::interval;
      end if;

      if ( new.cnrt_count is null or new.cnrt_count < 1 ) then
        new.cnrt_count := 1;
      end if;

      --
      -- calculate
      --

      -- other installment count
      count_other := new.cnrt_count - 1;

      -- limit first installment
      if ( new.cnrt_first_installment > new.cnrt_amount ) then
        new.cnrt_first_installment := new.cnrt_amount;
      end if;

      -- if single payment
      if ( new.cnrt_count = 1 ) then
        new.cnrt_first_installment := new.cnrt_amount;
      else
        if ( new.cnrt_first_installment = 0 ) then
          new.cnrt_first_installment = new.cnrt_amount / new.cnrt_count;
        end if;
      end if;

      -- other payments
      new.cnrt_other_installment := new.cnrt_amount - new.cnrt_first_installment;
      if ( count_other > 1 ) then
        new.cnrt_other_installment := new.cnrt_other_installment / count_other;
      end if;

      
      --
      -- If this appears to be a new contract, then setup default values
      --

      if ( new.cnrt_last_date is null ) then
        new.cnrt_balance := new.cnrt_amount;
        count_remaining := new.cnrt_count;
      else
        count_remaining := round(new.cnrt_balance / new.cnrt_other_installment);
      end if;

      -- recalculate the end date
      new.cnrt_end_date := new.cnrt_last_date + ( count_remaining * new.ctrt_period );

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.cnrt_tr_before() OWNER TO source;

--
-- Name: cnrv_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION cnrv_insert_row() RETURNS integer
    AS $$
    DECLARE
                rec_cnrv cnrv%ROWTYPE;
                rec_patn patn%ROWTYPE;
                tmp_cnrt__sequence cnrt.cnrt__sequence%TYPE; 
                
    BEGIN

         -- Do not know invoice yet, so use 0 
         if ( rec_cnrv.cnrv_patn__sequence is null ) then
           -- new invoice = 0 to trigger
           rec_cnrv.cnrv_patn__sequence := 0;
            select  *
            into    rec_patn
            from    patn
            where   patn__sequence = rec_cnrv.cnrv_patn__sequence;
            -- if not found create a dummy to temporarily satisfy constraints
            if ( not found ) then
              insert into patn(patn__sequence) values(0);
            end if;
         end if;

         -- get a cnrt__sequence
         select nextval('cnrt_cnrt__sequence_seq')
         into tmp_cnrt__sequence;
         -- add the cnrt record 
         insert into cnrt(cnrt__sequence)
          values(tmp_cnrt__sequence);

    return tmp_cnrt__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.cnrv_insert_row() OWNER TO source;

--
-- Name: conf_integer(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION conf_integer(text) RETURNS integer
    AS $_$DECLARE
    tmp_conf_code ALIAS for $1;
    period integer;

    BEGIN

    select  conf_value
    into    period
    from    conf
    where   conf_code = tmp_conf_code;

    if ( not found ) then
      period = 0;
    end if;

    return period;
      
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.conf_integer(text) OWNER TO source;

--
-- Name: count_triggers(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION count_triggers() RETURNS text
    AS $$DECLARE
       count integer;
       tmp_rec record;
       output text;

    BEGIN

    count := 0;
    output := '';
    for tmp_rec in 
      EXECUTE '
         SELECT rpad(relname,10) ||
                to_char( reltriggers::integer,99999999) ||
                to_char( count_triggers,99999999) as output
         FROM   pg_class,
                (SELECT tgrelid, count(*) as count_triggers
                 FROM pg_trigger
                 GROUP BY tgrelid) as realtriggers
         WHERE  pg_class.oid = realtriggers.tgrelid 
         AND   relname in (select mtcl_name from mtcl)
         ORDER BY relname;'

      LOOP
        output := output || '
' || tmp_rec.output;
        count := count + 1;
      END LOOP;

    -- GET DIAGNOSTICS count = ROW_COUNT;
    return output;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.count_triggers() OWNER TO source;

--
-- Name: create_fk_links(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION create_fk_links(text) RETURNS integer
    AS $_$DECLARE
   arg_reln alias for $1;
   tmp_record record;
   tmp_count integer := 0;

    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

    BEGIN

        insert into mtfn(mtfn_title,
                         mtfn_master_class,
                         mtfn_key,
                         mtfn_other_class,
                         mtfn_join,
                         mtfn_view)
          select  mtsv_other_class as tmp_title,
                  mtsv_master_class as tmp_master_class,
                  mtsv_key as tmp_key,
                  mtsv_other_class as tmp_other_class,
                  mtsv_join as tmp_join,
                  mtsv_join as tmp_view
          from    mtsv
          where   mtsv_master_class = arg_reln
          except
          select  mtfn_other_class as tmp_title,
                  mtfn_master_class as tmp_master_class,
                  mtfn_key as tmp_key,
                  mtfn_other_class as tmp_other_class,
                  mtfn_join as tmp_join,
                  mtfn_join as tmp_view
          from    mtfn
          where   mtfn_master_class = arg_reln;

          GET DIAGNOSTICS tmp_count = ROW_COUNT;
    return tmp_count;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.create_fk_links(text) OWNER TO source;

--
-- Name: create_metadata(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION create_metadata(text) RETURNS boolean
    AS $_$DECLARE
    classname alias for $1;
    mtcl_row mtcl%ROWTYPE;
    pg_class_oid pg_class.oid%TYPE;
    pg_class_relname pg_class.relname%TYPE;
    mtcl_pk mtcl.mtcl_primary%TYPE;
    mtat_row RECORD;
    x_counter integer;
    -- regexp mtat.mtat_input_method%TYPE;

    BEGIN

        -- get class system metadata
        select oid,
               relname
        into   pg_class_oid,
               pg_class_relname
        from   pg_class
        where  relname = classname;
        if not found then
           RAISE NOTICE 'Unable to locate <%> in system catalogues', classname;
           return false;
        end if;


        -- Check for existing mtcl record
        select into mtcl_row *
        from   mtcl
        where  mtcl_name = classname;
        if (not found) then
          -- No existing MTCL record, so create one.
          
          -- get primary key
          select a.attname
          into   mtcl_pk
          from   pg_index i,
                 pg_attribute a
          where  i.indrelid = pg_class_oid
          and    i.indkey[0] = a.attnum
          and    a.attrelid = pg_class_oid
          and    i.indisprimary = 't';
          if not found then
             mtcl_pk = classname||'__sequence';
          end if;
          
          -- insert a mtcl record
          
          insert into mtcl(
                      mtcl_access,
                      mtcl_name,
                      mtcl_title,
                      mtcl_group,
                      mtcl_matrix_order,
                      mtcl_order_by,
                      mtcl_group_by,
                      mtcl_primary,
                      mtcl_userkey,
                      mtcl_userlabel,
                      mtcl_query_limit,
                      mtcl_query_offset,
                      mtcl_extras)
                  values(
                      '31',
                      classname,
                      classname,
                      NULL,
                      10000,
                      'order by '||classname||'__sequence',
                      NULL,
                      mtcl_pk,
                      mtcl_pk,
                      mtcl_pk,
                      200,
                      0,
                      NULL);
        end if;

        -- insert attribute metadata
        -- regexp := classname||'__';
        x_counter = 0;
        FOR mtat_row IN
          select  a.attnum,
                  a.attname,
                  initcap(translate(substr(a.attname, position('_' in a.attname)+1), '_', ' '))
                                                    as att_title,
                  t.typname,
                  (case when a.atttypmod > 0 then
                              a.atttypmod-4 
                    else 30
                   end) as mtat_length,
                   (case when a.attname ~ '^....__' then
                      'SYSTEM'::text
                    else
                      '10'::text
                    end) as mtat_input_method
          from     pg_attribute a,
                   pg_type t
          where    a.attname not in (select mtat_name from mtat)
          and      a.attrelid = pg_class_oid
          and      a.attnum > 0
          and      a.atttypid = t.oid
          order by attnum
        LOOP
          insert into mtat(
                      mtat_class_name,
                      mtat_access,
                      mtat_name,
                      mtat_type,
                      mtat_length,
                      mtat_operator,
                      mtat_title,
                      mtat_displen,
                      mtat_browse_order,
                      mtat_view_order,
                      mtat_input_method,
                      mtat_default,
                      mtat_htmltagatt)
                  values(
                      classname,
                      '31',
                      mtat_row.attname,
                      mtat_row.typname,
                      mtat_row.mtat_length,
                      '~*',
                      trim(both from mtat_row.att_title),
                      mtat_row.mtat_length,
                      mtat_row.attnum * 10,
                      mtat_row.attnum * 10,
                      mtat_row.mtat_input_method,
                      '',
                      '');
          x_counter := x_counter + 1;
        END LOOP;
        raise notice 'additions = %', x_counter;

        -- cleanup obsolete attributes
        delete from mtat
        where  mtat_class_name = classname
        and    mtat_name not in
               (select attname
                from   pg_attribute
                where  attrelid = pg_class_oid);
        GET DIAGNOSTICS x_counter =  ROW_COUNT;
        raise notice 'deletions = %', x_counter;
--
    return true;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.create_metadata(text) OWNER TO source;

--
-- Name: create_rl_links(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION create_rl_links(text) RETURNS integer
    AS $_$DECLARE
   arg_reln alias for $1;
   tmp_record record;
   tmp_count integer := 0;

    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

    BEGIN

        insert into mtrl(mtrl_title,
                         mtrl_master_class,
                         mtrl_key,
                         mtrl_other_class,
                         mtrl_join)
          select  mtsv_master_class as tmp_title,
                  mtsv_other_class as tmp_master_class,
                  mtsv_join as tmp_key,
                  mtsv_master_class as tmp_other_class,
                  mtsv_key as tmp_join
          from    mtsv
          where   mtsv_other_class = arg_reln
          except
          select  mtrl_other_class as tmp_title,
                  mtrl_master_class as tmp_master_class,
                  mtrl_key as tmp_key,
                  mtrl_other_class as tmp_other_class,
                  mtrl_join as tmp_join
          from    mtrl
          where   mtrl_master_class = arg_reln;

          GET DIAGNOSTICS tmp_count = ROW_COUNT;
    return tmp_count;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.create_rl_links(text) OWNER TO source;

--
-- Name: cred_summary(integer, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION cred_summary(integer, integer) RETURNS text
    AS $_$
    DECLARE
    tmp_invc__sequence ALIAS for $1;
    maxrows ALIAS for $2;
    tmp_rec record;
    eol text;
    count integer;
    desc text;
    other_desc text;
    other_balance numeric;
    pad text;
                
    BEGIN

    eol := '';
    count := 0;
    other_balance := 0;
    other_desc = '';
    desc := '';
    pad := ' ';

    -- collect the credits

    for tmp_rec in EXECUTE '
      select    cred_paym__sequence,
                (cred_amount + cred_gst_amount) as cred_total,
                short_date(cred__timestamp) as cred_date,
                cred__timestamp,
                rpad( (case when paym_drawer is null
                        then tdtp_desc
                        else paym_drawer end),10,chr(32)) as drawer
      from      cred,paym,tdtp
      where     cred_invc__sequence = ' || tmp_invc__sequence || '
      and       cred_paym__sequence = paym__sequence
      and       paym_tdtp_code = tdtp_code
      order by  cred__timestamp desc;'

    LOOP
        count := count + 1;

        if ( count > maxrows ) then
           other_balance := other_balance + tmp_rec.cred_total::numeric;
        else
          desc := desc || eol ||
                  '#'|| tmp_rec.cred_paym__sequence ||
                  ' ' || tmp_rec.cred_date ||
                  ' ' || tmp_rec.drawer ||
                  ' ' || to_char(tmp_rec.cred_total,'9999999999.99');
        end if;
        eol = '<br>';
    END LOOP;

    if ( other_balance > 0 ) then
      desc := desc || eol ||
              rpad('... other payments (',29,chr(28)) ||
              count-maxrows || ')' ||
              to_char(other_balance, 99999.99);
    end if;

    return desc;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.cred_summary(integer, integer) OWNER TO source;

--
-- Name: cred_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION cred_tr_before() RETURNS "trigger"
    AS $$DECLARE
    sum_cred_amount cred.cred_amount%TYPE;
    sum_cred_gst_amount cred.cred_gst_amount%TYPE;
    sum_unpaid cred.cred_amount%TYPE;
    sum_gst_unpaid cred.cred_amount%TYPE;
    rec_invc invc%ROWTYPE;
    rec_paym paym%ROWTYPE;
    sum_other_paym paym.paym_amount%TYPE;
    avail_paym paym.paym_amount%TYPE;

    BEGIN

        -- ----------------------------------------
        -- get credit/debit totals from invoice
        -- ----------------------------------------
        select *
        into   rec_invc
        from   invc
        where  invc__sequence = new.cred_invc__sequence;

        -- ----------------------------------------
        -- THERE MUST BE AN INVOICE!!
        -- ----------------------------------------
        if ( not found ) then
          raise EXCEPTION 'cred_tr_before:invoice # % does not exist', new.cred_invc__sequence;
          return NULL;
        end if;

        -- ----------------------------------------
        -- get the current balances
        -- ----------------------------------------

        sum_unpaid := rec_invc.invc_amount - rec_invc.invc_paid_amount;
        sum_gst_unpaid := rec_invc.invc_gst_amount - rec_invc.invc_paid_gst_amount;
        if ( TG_OP = 'UPDATE' ) then
          sum_unpaid := sum_unpaid + old.cred_amount;
          sum_gst_unpaid := sum_gst_unpaid + old.cred_gst_amount;
        end if;

        -- ----------------------------------------
        -- If no payment record, then create dummy
        -- ----------------------------------------

        if ( new.cred_paym__sequence = 0 or new.cred_paym__sequence is null ) then
          new.cred_paym__sequence := 0;
          select  *
          into    rec_paym
          from    paym
          where   paym__sequence = new.cred_paym__sequence;

          -- if not found create a dummy to temporarily satisfy constraints
          if ( not found ) then
            insert into paym(paym__sequence) values(0);
            -- raise notice 'cred_tr_before:inserting new payment';
          end if;
        end if;

        -- get the paym record

        select  *
        into    rec_paym
        from    paym
        where   paym__sequence = new.cred_paym__sequence;

        -- get the payment already-allocated amount

        select coalesce(sum(cred_amount + cred_gst_amount), '0.00'::numeric)
        into   sum_other_paym
        from   cred
        where  cred_paym__sequence = new.cred_paym__sequence
        and    cred__sequence != new.cred__sequence;

        -- if the payment is zero, then default the payment amount to the outstanding
        -- ( this will be adjusted after credit amounts are finalised)

        if ( rec_paym.paym_amount = 0.00::numeric ) then
          avail_paym := sum_unpaid + sum_gst_unpaid;
        else
          avail_paym := rec_paym.paym_amount - sum_other_paym;
        end if;

        if ( avail_paym < 0 ) then
          avail_paym = 0;
        end if;

        sum_cred_amount := new.cred_amount + new.cred_gst_amount;

        -- if new credit amounts are 0, then look for outstanding amounts
        -- to use as default

        if ( new.cred_amount = 0 and new.cred_gst_amount = 0 ) then
          -- raise notice 'cred_tr_before: adjusting zero amount to %/%', sum_unpaid, sum_gst_unpaid;
          new.cred_amount     := sum_unpaid;
          new.cred_gst_amount := sum_gst_unpaid;

         end if;

        -- ----------------------------------------
        -- sanity checks
        -- ----------------------------------------

        -- No overpayments of GST ----------
        -- ---------------------------------
        if ( new.cred_gst_amount > sum_gst_unpaid ) then
          -- raise notice 'cred_tr_before: adjusting GST overpayment to % from %', new.cred_gst_amount, sum_gst_unpaid;
          new.cred_gst_amount := sum_gst_unpaid;
        end if;

        -- No negatives amounts ----------
        -- -------------------------------
        if ( new.cred_amount  < 0 ) then
          -- raise notice 'cred_tr_before: adjusting negative payment to 0.00 from %', new.cred_amount;
          new.cred_amount := 0;
        end if;
        if ( new.cred_gst_amount < 0) then
          -- raise notice 'cred_tr_before: adjusting negative GST payment to 0.00 from %', new.cred_gst_amount;
          new.cred_gst_amount := 0;
        end if;

        -- No overpayments if GST is unpaid
        -- -------------------------------- 
        if ( (sum_unpaid < new.cred_amount) and (sum_gst_unpaid > new.cred_gst_amount) ) then
          raise exception 'You cannot make an overpayment which ignores outstanding GST'; 
          return null;
        end if;

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.cred_tr_before() OWNER TO source;

--
-- Name: crep_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION crep_insert_row() RETURNS integer
    AS $$
    DECLARE
                rec_crep crep%ROWTYPE;
                tmp_cred__sequence cred.cred__sequence%TYPE; 
                rec_invc invc%ROWTYPE;
                rec_cred cred%ROWTYPE;
                rec_paym paym%ROWTYPE;
                
    BEGIN

         -- Do not know invoice yet, so use 0 
         if ( rec_crep.crep_invc__sequence is null ) then
           -- new invoice = 0 to trigger
           rec_crep.crep_invc__sequence := 0;
            select  *
            into    rec_invc
            from    invc
            where   invc__sequence = rec_crep.crep_invc__sequence;
            -- if not found create a dummy to temporarily satisfy constraints
            if ( not found ) then
              insert into invc(invc__sequence) values(0);
            end if;
         end if;

         -- Do not know payment yet, so use 0 
         if ( rec_crep.crep_paym__sequence is null ) then
           -- new payment = 0 to trigger
           rec_crep.crep_paym__sequence := 0;
            select  *
            into    rec_paym
            from    paym
            where   paym__sequence = rec_crep.crep_paym__sequence;
            -- if not found create a dummy to temporarily satisfy constraints
            if ( not found ) then
              insert into paym(paym__sequence) values(0);
            end if;
         end if;

         -- set to non-null
         if ( rec_crep.crep_cred_amount is null ) then
            rec_crep.crep_cred_amount := 0.0;
         end if;

         -- set to non-null
         if ( rec_crep.crep_cred_gst_amount is null ) then
            rec_crep.crep_cred_gst_amount := 0.0;
         end if;


         -- get a cred__sequence
         select nextval('cred_cred__sequence_seq')
         into tmp_cred__sequence;
         -- add the cred record 
         insert into cred(
                     cred_paym__sequence,
                     cred_invc__sequence,
                     cred_amount,
                     cred_gst_amount,
                     cred__sequence)
               values(
                     rec_crep.crep_paym__sequence,
                     rec_crep.crep_invc__sequence,
                     rec_crep.crep_cred_amount,
                     rec_crep.crep_cred_gst_amount,
                     tmp_cred__sequence);

    return tmp_cred__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.crep_insert_row() OWNER TO source;

--
-- Name: crev_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION crev_insert_row() RETURNS integer
    AS $$
    DECLARE
                rec_crev crev%ROWTYPE;
                tmp_paym__sequence paym.paym__sequence%TYPE; 
                tmp_cred__sequence cred.cred__sequence%TYPE; 
                rec_invc invc%ROWTYPE;
                rec_cred cred%ROWTYPE;
                rec_paym paym%ROWTYPE;
                
    BEGIN

         -- Do not know invoice yet, so use 0 
         if ( rec_crev.crev_invc__sequence is null) then
           -- new invoice = 0 to trigger
           rec_crev.crev_invc__sequence := 0;
           insert into invc(invc__sequence) select 0 except select invc__sequence from invc;
           insert into patn(patn__sequence) select 0 except select patn__sequence from patn;
         end if;

         -- set defaults
         if ( rec_crev.crev_date_entry is null ) then
            rec_crev.crev_date_entry := now();
         end if;

         if ( rec_crev.crev_user_entry is null ) then
            rec_crev.crev_user_entry := getpgusername();
         end if;

         if ( rec_crev.crev_site_entry is null ) then
            rec_crev.crev_site_entry := '-';
         end if;

            -- set to non-null
         if ( rec_crev.crev_paym_amount is null ) then
            rec_crev.crev_paym_amount := 0.0;
         end if;

         if ( rec_crev.crev_tdtp_code is null ) then
            rec_crev.crev_tdtp_code := '-';
         end if;

         -- set to non-null
         if ( rec_crev.crev_cred_amount is null ) then
            rec_crev.crev_cred_amount := 0.0;
         end if;

         -- set to non-null
         if ( rec_crev.crev_cred_gst_amount is null ) then
            rec_crev.crev_cred_gst_amount := 0.0;
         end if;

         -- get a paym__sequence
         select nextval('paym_paym__sequence_seq')
         into tmp_paym__sequence;


        --
        -- Debugging
        --
        -- RAISE NOTICE 'OUT->%/%/%/%/%/%/%/%/%/%/%/%/',
        --              rec_crev.crev_date_entry,
        --              rec_crev.crev_user_entry,
        --              rec_crev.crev_site_entry,
        --              rec_crev.crev_paym_amount,
        --              rec_crev.crev_tdtp_code,
        --              rec_crev.crev_drawer,
        --              rec_crev.crev_bank,
        --              rec_crev.crev_branch,
        --              tmp_paym__sequence,
        --              rec_crev.crev_invc__sequence,
        --              rec_crev.crev_cred_amount,
        --              rec_crev.crev_cred_gst_amount;

         -- add the paym record
         insert into paym(
                     paym_date_entry,
                     paym_user_entry,
                     paym_site_entry,
                     paym_amount,
                     paym_tdtp_code,
                     paym_drawer,
                     paym_bank,
                     paym_branch,
                     paym__sequence)
              values(
                     rec_crev.crev_date_entry,
                     rec_crev.crev_user_entry,
                     rec_crev.crev_site_entry,
                     rec_crev.crev_paym_amount,
                     rec_crev.crev_tdtp_code,
                     rec_crev.crev_drawer,
                     rec_crev.crev_bank,
                     rec_crev.crev_branch,
                     tmp_paym__sequence);

         -- get a cred__sequence
         select nextval('cred_cred__sequence_seq')
         into tmp_cred__sequence;
         -- add the cred record 
         insert into cred(
                     cred_paym__sequence,
                     cred_invc__sequence,
                     cred_amount,
                     cred_gst_amount,
                     cred__sequence)
               values(
                     tmp_paym__sequence,
                     rec_crev.crev_invc__sequence,
                     rec_crev.crev_cred_amount,
                     rec_crev.crev_cred_gst_amount,
                     tmp_cred__sequence);

    return tmp_cred__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.crev_insert_row() OWNER TO source;

--
-- Name: crsm_load(text, text, text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION crsm_load(text, text, text) RETURNS integer
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

    query text;
    from_date text;
    date_attribute text;
    to_date text;
    ctype text;
        
    BEGIN
      from_date := quote_literal($1);
      to_date := quote_literal($2);
      date_attribute := $3;
      ctype := quote_literal('C');

      EXECUTE 'delete from crsm;';

      -- PAYMENTS
      --
      query := '
        insert into crsm(crsm_date_start,
                         crsm_date_end,
                         crsm_type,
                         crsm_prov_code,
                         crsm_prov_name,
                         crsm_count,
                         crsm_tdtp_code,
                         crsm_desc,
                         crsm_amount,
                         crsm_gst_amount)
          select ' || from_date || ',
                 ' || to_date || ',
                 ' || ctype || ',
                 invc_prov_code,
                 prov_name,
                 count(*),
                 paym_tdtp_code,
                 tdtp_desc,
                 sum(cred_amount),
                 sum(cred_gst_amount)
            from cred,invc,paym,prov,tdtp
           where date(' || date_attribute || ') between ' || from_date || '
                                                        and ' || to_date || '
             and cred_invc__sequence = invc__sequence
             and cred_paym__sequence = paym__sequence
             and paym_tdtp_code = tdtp_code
             and invc_prov_code = prov_code
           group by invc_prov_code, prov_name, paym_tdtp_code, tdtp_desc;';

      -- RAISE NOTICE '%', query;
      EXECUTE query;

      -- this should return the number of rows inserted
      return 0;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.crsm_load(text, text, text) OWNER TO source;

--
-- Name: dbtr_address(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_address(text) RETURNS text
    AS $_$DECLARE

    tmp_dbtr_code ALIAS for $1;
    tmp_rec record;
    address text;
    BEGIN


    select      dbtr.*
    into        tmp_rec
    from        dbtr
    where       dbtr_code = tmp_dbtr_code;

    if ( not found ) then
      RAISE EXCEPTION 'Debtor code not found - %', tmp_dbtr_code;
      return null;
    end if;

    address := coalesce(tmp_rec.dbtr_name, '') || '<br>' 
                || coalesce(tmp_rec.dbtr_address, '') || '<br>'
                || coalesce(tmp_rec.dbtr_suburb, '') ||' '
                || coalesce(tmp_rec.dbtr_state, '') ||' '
                || coalesce(tmp_rec.dbtr_postcode, '');

    return address;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_address(text) OWNER TO source;

--
-- Name: dbtr_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_dbtr__sequence dbtr.dbtr__sequence%TYPE;

    BEGIN

         -- get a dbtr__sequence
         select nextval('dbtr_dbtr__sequence_seq')
         into tmp_dbtr__sequence;

         -- add the new row
         insert into dbtr( dbtr_code, dbtr__sequence )
                   values( tmp_dbtr__sequence::text, tmp_dbtr__sequence);

    return tmp_dbtr__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_insert_row() OWNER TO source;

--
-- Name: dbtr_last_invc_printed(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_last_invc_printed(text) RETURNS date
    AS $_$DECLARE

    tmp_dbtr_code ALIAS for $1;  
    tmp_date_printed date; 
    tmp_date_reprint date;

    BEGIN

    select max(invc_date_printed), max(invc_date_reprint)
    into   tmp_date_printed,tmp_date_reprint
    from   invc
    where  invc_dbtr_code = tmp_dbtr_code;

    if ( tmp_date_printed is null ) then
      tmp_date_printed = 'epoch'::date;
    end if;

    if ( tmp_date_reprint is null ) then
      tmp_date_reprint = 'epoch'::date;
    end if;

    if ( tmp_date_reprint > tmp_date_printed ) then
      return tmp_date_reprint;
    else
      return tmp_date_printed;
    end if;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_last_invc_printed(text) OWNER TO source;

--
-- Name: dbtr_patient_key(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_patient_key(text) RETURNS text
    AS $_$DECLARE

    tmp_dbtr_code ALIAS for $1;
    tmp_rec record;
    query text;
    label text;
    count integer;

    BEGIN


--    query := 'select patn_psnam,patn_fsnam,invc_dbtr_code'
--           + 'from   invc,patn'
--           + 'where  invc_dbtr_code = ' + tmp_dbtr_code
--           + 'and    patn__sequence = invc_patn__sequence;';
--
--
--    for tmp_rec in EXECUTE query

    count := 0;

    for tmp_rec in
        select  distinct upper(patn_psnam) as patn_psnam,upper(patn_fsnam) as patn_fsnam,invc_dbtr_code
        from    invc,patn
        where   invc_dbtr_code = tmp_dbtr_code
        and     patn__sequence = invc_patn__sequence
      
    LOOP
        -- if more than one, then skip out
        count := count + 1;
        if (count > 1) then
          exit;
        end if;
        label := tmp_rec.patn_psnam || ',' || tmp_rec.patn_fsnam || ',' || tmp_rec.invc_dbtr_code;
    END LOOP;

    if (count = 1) then
        return label;
    end if;

    select      dbtr_name
    into        label
    from        dbtr
    where       dbtr_code = tmp_dbtr_code;

    if (not found) then
        return 'Unknown: ' || tmp_dbtr_code;
    end if;
    
    return label || ' *(Multiple Patients)';

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_patient_key(text) OWNER TO source;

--
-- Name: dbtr_period_balance(text, integer, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_period_balance(text, integer, integer) RETURNS numeric
    AS $_$DECLARE
    tmp_dbtr_code ALIAS for $1;
    tmp_period ALIAS for $2;
    tmp_daysago ALIAS for $3;
    tmp_rec record;
    sqlexec text;
    str_daysago text;

    BEGIN
    str_daysago := tmp_daysago || ' days';
    sqlexec = '
      select    sum(invc_balance_then(invc__sequence,' || tmp_daysago || ')) as period_total
      from      invc
      where     invc_dbtr_code = ' || quote_literal(tmp_dbtr_code) || '
      and       invc_date_printed is not null
      and       date(invc_date_printed) <= now() - ' || quote_literal(str_daysago) || '::interval 
      and       invc_age_period(invc__sequence,'||tmp_daysago||') = ' || tmp_period || ';';

    -- raise notice 'SQlEXEC: %', sqlexec;

    for tmp_rec in EXECUTE sqlexec
    LOOP
    -- RAISE NOTICE '% % %',tmp_period,tmp_rec.period_total,sqlexec;
        if ( tmp_rec.period_total is null ) then
          return 0.00::numeric;
        else
          return tmp_rec.period_total;
        end if;
    END LOOP;

    return 0.00::numeric;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_period_balance(text, integer, integer) OWNER TO source;

--
-- Name: dbtr_total_balance(text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_total_balance(text) RETURNS numeric
    AS $_$DECLARE

    tmp_rec record;

    BEGIN

    for tmp_rec in EXECUTE '
      select    sum(invc_balance(invc__sequence)) as total_balance
      from      invc
      where     invc_dbtr_code = ' || quote_literal($1) || ';'

    LOOP
        return tmp_rec.total_balance;
    END LOOP;

    return null;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_total_balance(text) OWNER TO source;

--
-- Name: dbtr_total_balance(text, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_total_balance(text, integer) RETURNS numeric
    AS $_$DECLARE
    tmp_dbtr_code ALIAS for $1;
    tmp_daysago ALIAS for $2;
    tmp_rec record;
    tmp_daysago_str text;

    BEGIN

    tmp_daysago_str := tmp_daysago || ' days';
    -- RAISE NOTICE '%', tmp_daysago;
    for tmp_rec in EXECUTE '
      select    sum(invc_balance_then(invc__sequence,' || tmp_daysago || ')) as total_balance
      from      invc
      where     invc_dbtr_code = ' || quote_literal(tmp_dbtr_code) || '
      and       invc_date_printed is not null
      and       date(invc_date_printed) <= now() - ' || quote_literal(tmp_daysago_str) || '::interval;'

    LOOP
        if ( tmp_rec.total_balance is null ) then
          return 0.00::numeric;
        else
          return tmp_rec.total_balance;
        end if;
    END LOOP;

    return 0.00::numeric;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_total_balance(text, integer) OWNER TO source;

--
-- Name: dbtr_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION dbtr_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( TG_OP = 'UPDATE' or TG_OP = 'INSERT' ) then
      if ( new.dbtr_code is null ) then
         new.dbtr_code := new.dbtr__sequence::text;
      end if;
    end if;

    if ( TG_OP = 'UPDATE' ) then
      if ( old.dbtr_code = '-' and new.dbtr_code != '-') then
        new.dbtr_code := old.dbtr_code;
        RAISE EXCEPTION 'This code (-) cannot be altered';
        return old;
      end if;
    end if;
    if ( TG_OP = 'DELETE') then
       if ( old.dbtr_code = '-') then
         RAISE EXCEPTION 'This code (-) cannot be deleted';
         return old;
      end if;
    end if;

    if (TG_OP = 'DELETE') then
      return old;
    else
      return new;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.dbtr_tr_before() OWNER TO source;

--
-- Name: disable_triggers(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION disable_triggers() RETURNS integer
    AS $$DECLARE
       count integer;

    BEGIN

    EXECUTE '
       UPDATE pg_class
       SET    reltriggers = 0
       WHERE  relname in (select mtcl_name from mtcl);';
       GET DIAGNOSTICS count = ROW_COUNT;
       return count;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.disable_triggers() OWNER TO source;

--
-- Name: disallownulls(name, name); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION disallownulls(name, name) RETURNS boolean
    AS $_$DECLARE
     tablename ALIAS FOR $1;
     colname ALIAS FOR $2;
     rec_affected int;
    BEGIN
     -- If any params are NULL, return NULL - this means function
     -- can be defined isstrict.
     IF tablename IS NULL OR colname IS NULL THEN
      RETURN NULL;
     END IF;
    
     -- Lock table with standard ALTER TABLE locks
     EXECUTE 'LOCK TABLE ' || quote_ident(tablename) || ' IN ACCESS EXCLUSIVE MODE';

     -- See if there are any NULLs in the column already
     EXECUTE 'SELECT * FROM ' || quote_ident(tablename) || ' WHERE ' || quote_ident(colname) || ' IS NULL LIMIT 1';
     IF FOUND THEN
      RAISE EXCEPTION 'Column contains NULL values.';
      RETURN FALSE;
     END IF;
    
     -- Update the system catalogs
     EXECUTE 'UPDATE pg_attribute SET attnotnull = true WHERE attrelid =
        (SELECT oid FROM pg_class WHERE relname = ' || quote_literal(tablename) || ')
        AND attname = ' || quote_literal(colname);
    
     -- Get number of rows modified
     GET DIAGNOSTICS rec_affected = ROW_COUNT;
    
     -- Return success if one row affected
     RETURN (rec_affected = 1);
    
    END;$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.disallownulls(name, name) OWNER TO source;

--
-- Name: eftr_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION eftr_tr_before() RETURNS "trigger"
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_eftr__sequence eftr.eftr__sequence%TYPE;
    min_paym integer;
    max_paym integer;

    BEGIN

         select max(paym__sequence)
         into   max_paym
         from   paym;

         select max(eftr_last__sequence) + 1
         into   min_paym
         from   eftr;

         if ( max_paym is null ) then
            max_paym := 0;
         end if;

         if ( min_paym is null ) then
            min_paym := 0;
         end if;

         if ( max_paym <= min_paym ) then
           RAISE EXCEPTION 'There are no unreported payments';
           return null;
         end if;

         -- RAISE NOTICE 'eftr__sequence = %',new.eftr__sequence;
         new.eftr_first__sequence = min_paym;
         new.eftr_last__sequence = max_paym;
         

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.eftr_tr_before() OWNER TO source;

--
-- Name: empl_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION empl_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_empl__sequence empl.empl__sequence%TYPE;

    BEGIN

         -- get a empl__sequence
         select nextval('empl_empl__sequence_seq')
         into tmp_empl__sequence;

         -- add the new row
         insert into empl( empl_code, empl__sequence )
                   values( tmp_empl__sequence::text, tmp_empl__sequence);

    return tmp_empl__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.empl_insert_row() OWNER TO source;

--
-- Name: enable_triggers(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION enable_triggers() RETURNS integer
    AS $$DECLARE
       count integer;

    BEGIN

    EXECUTE '
       UPDATE pg_class
       SET    reltriggers =  (SELECT count(*)
                              FROM   pg_trigger
                              where  pg_class.oid = tgrelid)
       WHERE  relname in (select mtcl_name from mtcl);';
       GET DIAGNOSTICS count = ROW_COUNT;
       return count;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.enable_triggers() OWNER TO source;

--
-- Name: evnv_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION evnv_insert_row() RETURNS integer
    AS $$
    DECLARE
         rec_evnv evnv%ROWTYPE;
         tmp_evnt__sequence evnt.evnt__sequence%TYPE; 
         rec_patn patn%ROWTYPE;
                
    BEGIN

         -- Do not know patient yet, so use 0 
         if ( rec_evnv.evnv_patn__sequence is null ) then
           -- new invoice = 0 to trigger
           rec_evnv.evnv_patn__sequence := 0;
            select  *
            into    rec_patn
            from    patn
            where   patn__sequence = rec_evnv.evnv_patn__sequence;
            -- if not found create a dummy to temporarily satisfy constraints
            if ( not found ) then
              insert into patn(patn__sequence) values(0);
            end if;
         end if;

         -- get a evnt__sequence
         select nextval('evnt_evnt__sequence_seq')
         into tmp_evnt__sequence;
         -- add the evnt record 
         insert into evnt(
                     evnt_patn__sequence,
                     evnt__sequence)
               values(
                     rec_evnv.evnv_patn__sequence,
                     tmp_evnt__sequence);

    return tmp_evnt__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.evnv_insert_row() OWNER TO source;

--
-- Name: feeb_tr_after(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION feeb_tr_after() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- add new feeb rows

    insert into feeb(feeb_serv_code, feeb_feet_code)
    select distinct serv_code, feet_code
    from serv, feet
    except select feeb_serv_code, feeb_feet_code from feeb;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.feeb_tr_after() OWNER TO source;

--
-- Name: feet_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION feet_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.feet_code is null ) then
      new.feet_code = new.feet__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.feet_tr_before() OWNER TO source;

--
-- Name: fn_amountoutstanding(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_amountoutstanding() RETURNS "trigger"
    AS $$DECLARE
        x_patn__sequence patn.patn__sequence%TYPE;
        x_dbtr_code dbtr.dbtr_code%TYPE;

    BEGIN
        
        if (TG_OP = 'INSERT' ) then
          if (  new.invc_amount != 0.00::numeric and 
                new.invc_gst_amount != 0.00::numeric and
                new.invc_paid_amount != 0.00::numeric and
                new.invc_paid_gst_amount::numeric != 0.00::numeric ) then
            return new;
          end if;
          x_patn__sequence = new.invc_patn__sequence;
          x_dbtr_code = new.invc_dbtr_code;          
        end if;

        if (TG_OP = 'UPDATE' ) then
          if(   new.invc_amount = old.invc_amount and
                new.invc_gst_amount = old.invc_gst_amount and
                new.invc_paid_amount = old.invc_paid_amount and
                new.invc_paid_gst_amount = old.invc_paid_gst_amount ) then
            return new;
          end if;
          x_patn__sequence = new.invc_patn__sequence;
          x_dbtr_code = new.invc_dbtr_code;
        end if;

        if (TG_OP = 'DELETE' ) then
          x_patn__sequence = old.invc_patn__sequence;
          x_dbtr_code = old.invc_dbtr_code;
        end if;

        UPDATE  patn
        set     patn_amount_outstanding = (
                        select  sum(invc_balance(invc__sequence))
                        from    invc
                        where   invc_patn__sequence = x_patn__sequence )
        where   patn__sequence = x_patn__sequence;
        -- RAISE NOTICE 'setting patn_amount_outstanding for %', x_patn__sequence;

        UPDATE  dbtr
        set     dbtr_amount_outstanding = (
                        select  sum(invc_balance(invc__sequence))
                        from    invc
                        where   invc_dbtr_code = x_dbtr_code )
        where   dbtr_code = x_dbtr_code;
        -- RAISE NOTICE 'setting dbtr_amount_outstanding for %', x_dbtr_code;

    if (TG_OP = 'INSERT' or TG_OP = 'UPDATE' ) then
      return new;
    else
      return old;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_amountoutstanding() OWNER TO source;

--
-- Name: fn_copypatndata(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_copypatndata() RETURNS "trigger"
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    rec_patn patn%ROWTYPE;

    BEGIN
        -- RAISE NOTICE 'fn_copypatndata: patn__sequence = %', new.evnt_patn__sequence;

        -- ----------------------------------------
        -- need patn_sequence for the search
        -- ----------------------------------------
        if (new.evnt_patn__sequence is null) then
           return new;
        end if;

        -- ----------------------------------------
        -- if update and same patient then do nothing
        -- ----------------------------------------
        if ( TG_OP = 'UPDATE' ) then
          if (new.evnt_patn__sequence = old.evnt_patn__sequence) then
            return new;
          end if;
        end if;
        
        -- ----------------------------------------
        -- search for patient data
        -- ----------------------------------------
        select  *
        into    rec_patn
        from    patn
        where   patn__sequence = new.evnt_patn__sequence;

        -- ----------------------------------------
        -- if not found return
        -- ----------------------------------------
        if ( not found ) then
          return new;
        end if;
        -- RAISE NOTICE 'fn_copypatndata: found ....  patn__sequence = %', new.evnt_patn__sequence;
        -- ----------------------------------------
        -- if not null and new values not null then copy to evnt
        -- ----------------------------------------
        if ( rec_patn.patn_prov_code is not null
                and (new.evnt_prov_code is null
                     or new.evnt_prov_code = '-') ) then
          -- RAISE NOTICE 'fn_copypatndata: setting prov_code from patn';
          new.evnt_prov_code = rec_patn.patn_prov_code;
        end if;
        if ( rec_patn.patn_rfdr_code is not null
                and (new.evnt_rfdr_code is null
                     or new.evnt_rfdr_code = '-') ) then
          -- RAISE NOTICE 'fn_copypatndata: setting rfdr_code from patn';
          new.evnt_rfdr_code = rec_patn.patn_rfdr_code;
        end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_copypatndata() OWNER TO source;

--
-- Name: fn_create_batch(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_create_batch(integer) RETURNS integer
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

        x_invc__sequence ALIAS for $1;
        tmp_invc invc%ROWTYPE;
        tmp_svpf_count integer;
        tmp_mdaf__sequence mdaf.mdaf__sequence%TYPE;
        tmp_mdbt__sequence mdbt.mdbt__sequence%TYPE;

    BEGIN

        -- check for the invoice.

        select  *
        into    tmp_invc
        from    invc
        where   invc__sequence = x_invc__sequence;

        if (not found) then
          RAISE EXCEPTION 'Invoice number % not found', x_invc__sequence;
          return null;
        end if;

        -- count the unclaimed services

        select  count(*)
        into    tmp_svpf_count
        from    svpf
        where   svpf_invc__sequence = x_invc__sequence
        and     svpf_mdaf__sequence is null;

        if (tmp_svpf_count < 1) then
          RAISE EXCEPTION 'There are no services to be claimed for this invoice - % ', x_invc__sequence;
          return null;
        end if;

        -- create a voucher

        select  nextval('mdaf_mdaf__sequence_seq')
        into    tmp_mdaf__sequence;
        insert into mdaf(mdaf__sequence, mdaf_patn__sequence, mdaf_prov_code, mdaf_rfdr_code)
                values(tmp_mdaf__sequence, tmp_invc.invc_patn__sequence, tmp_invc.invc_prov_code, tmp_invc.invc_rfdr_code);
        update  svpf
        set     svpf_mdaf__sequence = tmp_mdaf__sequence
        where   svpf_invc__sequence = x_invc__sequence
        and     svpf_mdaf__sequence is null;

        -- create a batch

        select  nextval('mdbt_mdbt__sequence_seq')
        into    tmp_mdbt__sequence;
        insert into mdbt(mdbt__sequence) values(tmp_mdbt__sequence);
        update  mdaf
        set     mdaf_mdbt__sequence = tmp_mdbt__sequence
        where   mdaf__sequence = tmp_mdaf__sequence;        

    return tmp_mdaf__sequence;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_create_batch(integer) OWNER TO source;

--
-- Name: fn_guess_credit(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_guess_credit(integer) RETURNS numeric
    AS $_$DECLARE

    x_svpf__sequence ALIAS for $1;
    x_cred_amount NUMERIC;
    x_invc__sequence INTEGER;
    tmp_rec record;

    BEGIN

    -- Determine the invoice and the total amount paid
    select      coalesce(sum(cred_amount), 0.0) + coalesce(sum(cred_gst_amount), 0.0),
                cred_invc__sequence
    into        x_cred_amount,
                x_invc__sequence
    from        cred
    where       cred_invc__sequence = (select   svpf_invc__sequence
                                         from   svpf
                                        where   svpf__sequence = x_svpf__sequence)
    group by cred_invc__sequence;

    if (not found) then
        return 0.0;
    end if;

    -- RAISE NOTICE 'invc = %', x_invc__sequence;

    FOR tmp_rec in EXECUTE '
      select    (svpf_amount + svpf_gst_amount) as tmp_svpf_total,
                svpf__sequence
      from      svpf
      where     svpf_invc__sequence = ' || x_invc__sequence || '
      order by  svpf_date_service, svpf__sequence;'

    LOOP

        -- are we at the specified service?
        if (tmp_rec.svpf__sequence = x_svpf__sequence) then
          if (x_cred_amount > tmp_rec.tmp_svpf_total) then
             return tmp_rec.tmp_svpf_total;
          else
             return x_cred_amount;
          end if;
        end if;
        -- decrement
        x_cred_amount := x_cred_amount - tmp_rec.tmp_svpf_total;
        
        -- nothing left
        if (x_cred_amount < 0.0) then
          return 0.0;
        end if;

    END LOOP;

    RAISE EXCEPTION 'An unexpected error occurred - please report this to your supplier';

    return 0.0;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_guess_credit(integer) OWNER TO source;

--
-- Name: fn_invc_closedinvoice(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_invc_closedinvoice() RETURNS "trigger"
    AS $$DECLARE

    x_sep char(1) := '~';
    BEGIN

    if (TG_OP != 'UPDATE' and TG_OP != 'DELETE') then
      RAISE EXCEPTION 'tr_invc_closedinvoice: this trigger can only be used for UPDATE and DELETE';
    end if;

    -- ------------------------------
    -- if invoice is open, then allow
    -- updates or deletes unconditionally
    -- ------------------------------
    
    if ( old.invc_date_printed is null ) then
      if (TG_OP = 'DELETE') then
        return old;
      else
        return new;
      end if;
    end if;

    -- only printed invoices from now on.

    -- ------------------------------
    -- CONSTRAINTS ON DELETE
    -- ------------------------------

    -- block deletes except office admin(32)
    if (TG_OP = 'DELETE') then
      if ( (select perms::integer & 32 from mvac_user where username = current_user) = 32 ) then
        -- audit
        insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
              select    'invc', old.invc__sequence, TG_OP,
                        x_sep || 
                        'invc_dbtr_code' || x_sep ||
                        'invc_bank_code' || x_sep ||
                        'invc_prov_code' || x_sep ||
                        'invc_patn__sequence' || x_sep ||
                        'invc_empl_code' || x_sep ||
                        'invc_feet_code' || x_sep ||
                        'invc_rfdr_code' || x_sep ||
                        'invc_rfdr_date' || x_sep ||
                        'invc_rfdr_period' || x_sep ||
                        'invc_date_created' || x_sep ||
                        'invc_date_printed' || x_sep ||
                        'invc_date_reprint' || x_sep ||
                        'invc_amount' || x_sep ||
                        'invc_paid_amount' || x_sep ||
                        'invc_gst_amount' || x_sep ||
                        'invc_paid_gst_amount',
                        x_sep || 
                        coalesce(old.invc_dbtr_code, '') || x_sep ||
                        coalesce(old.invc_bank_code, '') || x_sep ||
                        coalesce(old.invc_prov_code, '') || x_sep ||
                        coalesce(old.invc_patn__sequence, -1) || x_sep ||
                        coalesce(old.invc_empl_code, '') || x_sep ||
                        coalesce(old.invc_feet_code, '') || x_sep ||
                        coalesce(old.invc_rfdr_code, '') || x_sep ||
                        coalesce(old.invc_rfdr_date::text, '') || x_sep ||
                        coalesce(old.invc_rfdr_period, '') || x_sep ||
                        coalesce(old.invc_date_created::text, '') || x_sep ||
                        coalesce(old.invc_date_printed::text, '') || x_sep ||
                        coalesce(old.invc_date_reprint::text, '') || x_sep ||
                        coalesce(to_char(old.invc_amount,'9999999999.99'), '') || x_sep ||
                        coalesce(to_char(old.invc_paid_amount,'9999999999.99'), '') || x_sep ||
                        coalesce(to_char(old.invc_gst_amount,'9999999999.99'), '') || x_sep ||
                        coalesce(to_char(old.invc_paid_gst_amount,'9999999999.99'), ''),
                        NULL;
        return old;
      else
        RAISE EXCEPTION 'This record cannot be deleted - the invoice number % has been printed. Please contact your Systems Administrator for assistance.', old.invc__sequence;
        return null;
      end if;
    end if;

    -- ------------------------------
    -- CONSTRAINTS ON UPDATE
    -- ------------------------------
    if (TG_OP = 'UPDATE') then

      if ( new.invc_date_printed is null or new.invc_date_printed <> old.invc_date_printed ) then
        if ( (select perms::integer & 32 from mvac_user where username = current_user) = 32 ) then
          -- audit
          insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
              select    'invc', old.invc__sequence, TG_OP,
                        x_sep || 
                        'invc_date_printed',
                        x_sep ||
                        coalesce(old.invc_date_printed::text, ''),
                        x_sep ||
                        coalesce(new.invc_date_printed::text, '');
          return new;
        else
        -- dont allow updates to change date printed.
            RAISE EXCEPTION 'The date-printed on this record cannot be updated - the invoice number % has been printed',
                            old.invc__sequence;
          return null;
        end if;
      end if;
    end if;

    -- ------------------------------
    -- Tidy up.
    -- ------------------------------
    if (TG_OP = 'DELETE') then
      return old;
    else
      return new;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_invc_closedinvoice() OWNER TO source;

--
-- Name: fn_lastservice(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_lastservice() RETURNS "trigger"
    AS $$DECLARE
      x_patn__sequence patn.patn__sequence%TYPE;

    BEGIN
        if (TG_OP = 'INSERT' ) then
          if (new.svpf_date_service is null) then
            return new;
          end if;
          x_patn__sequence = new.svpf_patn__sequence;
        end if;

        if (TG_OP = 'UPDATE' ) then
          if (new.svpf_date_service = old.svpf_date_service) then
            return new;
          end if;
          x_patn__sequence = new.svpf_patn__sequence;
        end if;

        if (TG_OP = 'DELETE' ) then
          x_patn__sequence = old.svpf_patn__sequence;
        end if;

        UPDATE  patn
        set     patn_last_service = (
                        select  max(svpf_date_service)
                        from    svpf
                        where   svpf_patn__sequence = x_patn__sequence )
        where   patn__sequence = x_patn__sequence;
        -- RAISE NOTICE 'setting patn_last_service for %', x_patn__sequence;

    if (TG_OP = 'INSERT' or TG_OP = 'UPDATE' ) then
      return new;
    else
      return old;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_lastservice() OWNER TO source;

--
-- Name: fn_lastvisit(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_lastvisit() RETURNS "trigger"
    AS $$DECLARE
      x_patn__sequence patn.patn__sequence%TYPE;

    BEGIN
        if (TG_OP = 'INSERT' ) then
          if (new.evnt_starttime is null) then
            return new;
          end if;
          x_patn__sequence = new.evnt_patn__sequence;
        end if;

        if (TG_OP = 'UPDATE' ) then
          if ( new.evnt_starttime = old.evnt_starttime) then
            return new;
          end if;
          x_patn__sequence = new.evnt_patn__sequence;
        end if;

        if (TG_OP = 'DELETE' ) then
          x_patn__sequence = old.evnt_patn__sequence;
        end if;

        UPDATE  patn
        set     patn_last_visit = (
                        select  max(evnt_starttime)
                        from    evnt
                        where   evnt_patn__sequence = x_patn__sequence )
        where   patn__sequence = x_patn__sequence;
        -- RAISE NOTICE 'setting patn_last_visit for %', x_patn__sequence;

    if (TG_OP = 'INSERT' or TG_OP = 'UPDATE' ) then
      return new;
    else
      return old;
    end if;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_lastvisit() OWNER TO source;

--
-- Name: fn_patientexport(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_patientexport() RETURNS "trigger"
    AS $$DECLARE

    BEGIN

        if (new.patn__sequence > 0 ) then
          insert into pate(pate_patn__sequence)
          select new.patn__sequence
          except  select  pate_patn__sequence
                  from    pate;
        end if;
    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_patientexport() OWNER TO source;

--
-- Name: fn_patn_dob_check(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_patn_dob_check() RETURNS "trigger"
    AS $$

        BEGIN

        if (new.patn_dob is null) then
          return new;
        end if;

        if (date(new.patn_dob) > date(now()) ) then
                new.patn_dob := new.patn_dob - '1 century'::interval; 
        end if;

        return new;
        END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_patn_dob_check() OWNER TO source;

--
-- Name: fn_patn_null2default(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_patn_null2default() RETURNS "trigger"
    AS $$
        DECLARE
          rec_dbtr dbtr%ROWTYPE;
          dbtr_changed bool;
          dbtr_request bool;

        BEGIN

        if (new.patn_feet_code is null) then
          new.patn_feet_code := '-';
        end if;

        if (new.patn_dbtr_code is null) then
          new.patn_dbtr_code := '-';
        end if;

        -- the "-" character trigger insert/update of patient dbtr record
        -- also refersh if already a patient debtor
        if (( new.patn_dbtr_code = '-'
              or new.patn_dbtr_code ='/'||trim( both from to_char(new.patn__sequence,'0000000')) )
            and new.patn__sequence is not null
            and new.patn__sequence > 0 
            ) then
          -- RAISE NOTICE 'Self debtor - %', new.patn_dbtr_code;
          dbtr_request := false;
          if ( new.patn_dbtr_code = '-' ) then
            dbtr_request := true;
          end if;

          new.patn_dbtr_code := '/'||trim( both from to_char(new.patn__sequence,'0000000'));
          
          select  *
          into    rec_dbtr
          from    dbtr
          where   dbtr_code = new.patn_dbtr_code;
          if ( not found ) then
            rec_dbtr.dbtr_code = new.patn_dbtr_code;
            insert into dbtr( dbtr_code )
                      values(rec_dbtr.dbtr_code );
          end if;
          dbtr_changed := false;

          if ( rec_dbtr.dbtr_name is null or dbtr_request ) then
            rec_dbtr.dbtr_name := new.patn_title||' '||new.patn_fsnam||' '||new.patn_psnam;
            -- RAISE NOTICE 'Changing dbtr_name';
            dbtr_changed := true;
          end if;

          if ( rec_dbtr.dbtr_address is null or dbtr_request ) then
            rec_dbtr.dbtr_address := new.patn_address;
            dbtr_changed := true;
          end if;

          if ( rec_dbtr.dbtr_suburb is null or dbtr_request ) then
            rec_dbtr.dbtr_suburb := new.patn_suburb;
            dbtr_changed := true;
          end if;

          if ( rec_dbtr.dbtr_state is null  or dbtr_request) then
            rec_dbtr.dbtr_state := new.patn_state;
            dbtr_changed := true;
          end if;

          if ( rec_dbtr.dbtr_postcode is null or dbtr_request ) then
            rec_dbtr.dbtr_postcode := new.patn_postcode;
            dbtr_changed := true;
          end if;

          if ( rec_dbtr.dbtr_phone is null or dbtr_request ) then
            rec_dbtr.dbtr_phone := new.patn_phone;
            dbtr_changed := true;
          end if;

          if ( dbtr_changed = true) then
            update dbtr
            set    dbtr_name = rec_dbtr.dbtr_name,
                   dbtr_address = rec_dbtr.dbtr_address,
                   dbtr_suburb = rec_dbtr.dbtr_suburb,
                   dbtr_state = rec_dbtr.dbtr_state,
                   dbtr_postcode = rec_dbtr.dbtr_postcode,
                   dbtr_phone = rec_dbtr.dbtr_phone
            where  dbtr_code = rec_dbtr.dbtr_code;
          end if;
                              
        end if;

        if (new.patn_empl_code is null) then
          new.patn_empl_code := '-';
        end if;

        if (new.patn_rfdr_code is null) then
          new.patn_rfdr_code := '-';
        end if;

        if (new.patn_prov_code is null) then
          new.patn_prov_code := '-';
        end if;

        if (new.patn_flno is null or new.patn_flno = '-') then
          new.patn_flno = new.patn__sequence;
        end if;

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_patn_null2default() OWNER TO source;

--
-- Name: fn_paym_closeddeposit(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_paym_closeddeposit() RETURNS "trigger"
    AS $$DECLARE
    x_paym_bkdp__sequence paym.paym_bkdp__sequence%TYPE;
    x_mtau_attributes mtau.mtau_attributes%TYPE := '';
    x_mtau_before mtau.mtau_before%TYPE := '';
    x_mtau_after mtau.mtau_after%TYPE := '';
    x_sep char(1) := '~';

    BEGIN

    if (TG_OP = 'INSERT') then
      x_paym_bkdp__sequence := new.paym_bkdp__sequence;
    else
      x_paym_bkdp__sequence := old.paym_bkdp__sequence;
    end if;

    --
    -- ok to proceed if not allocated to bank batch or the user has administrator access
    --

    if (x_paym_bkdp__sequence is null or x_paym_bkdp__sequence = 0) then
      if (TG_OP = 'DELETE') then
        return old;
      else
        return new;
      end if;
    else
          -- 32 is office-admin
      if ( (select perms::integer & 32 from mvac_user where username = current_user) = 32 ) then

        if (TG_OP = 'DELETE') then
  
          insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
                  select    'paym', old.paym__sequence, TG_OP,
                            x_sep || 'paym_date_entry' || x_sep ||
                            'paym_user_entry' || x_sep ||
                            'paym_site_entry' || x_sep ||
                            'paym_amount' || x_sep ||
                            'paym_tdtp_code' || x_sep ||
                            'paym_drawer' || x_sep ||
                            'paym_bank' || x_sep ||
                            'paym_branch' || x_sep ||
                            'paym_bkdp__sequence',
                            x_sep || old.paym_date_entry || x_sep ||
                            old.paym_user_entry || x_sep ||
                            old.paym_site_entry || x_sep ||
                            to_char(old.paym_amount,'9999999999.99') || x_sep ||
                            old.paym_tdtp_code || x_sep ||
                            old.paym_drawer || x_sep ||
                            old.paym_bank || x_sep ||
                            old.paym_branch || x_sep ||
                            old.paym_bkdp__sequence,
                            NULL;
          return old;

        else

          -- paym_date_entry
          if (new.paym_date_entry <> old.paym_date_entry ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_date_entry';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_date_entry;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_date_entry;
          end if;
  
          -- paym_user_entry
          if (new.paym_user_entry <> old.paym_user_entry ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_user_entry';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_user_entry;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_user_entry;
          end if;
  
          -- paym_site_entry
          if (new.paym_site_entry <> old.paym_site_entry ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_site_entry';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_site_entry;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_site_entry;
          end if;
  
          -- paym_amount
          if (new.paym_amount <> old.paym_amount ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_amount';
            x_mtau_before     := x_mtau_before     || x_sep || to_char(old.paym_amount, '9999999999.99');
            x_mtau_after      := x_mtau_after      || x_sep || to_char(new.paym_amount, '9999999999.99');
          end if;
  
          -- paym_tdtp_code
          if (new.paym_tdtp_code <> old.paym_tdtp_code ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_tdtp_code';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_tdtp_code;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_tdtp_code;
          end if;
  
          -- paym_drawer
          if (new.paym_drawer <> old.paym_drawer ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_drawer';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_drawer;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_drawer;
          end if;
  
          -- paym_bank
          if (new.paym_bank <> old.paym_bank ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_bank';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_bank;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_bank;
          end if;
  
          -- paym_branch
          if (new.paym_branch <> old.paym_branch ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_branch';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_branch;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_branch;
          end if;
  
          -- paym_bkdp__sequence
          if (new.paym_bkdp__sequence <> old.paym_bkdp__sequence ) then
            x_mtau_attributes := x_mtau_attributes || x_sep || 'paym_bkdp__sequence';
            x_mtau_before     := x_mtau_before     || x_sep || old.paym_bkdp__sequence;
            x_mtau_after      := x_mtau_after      || x_sep || new.paym_bkdp__sequence;
          end if;
  
  
          insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
                  select 'paym', new.paym__sequence, TG_OP, x_mtau_attributes, x_mtau_before, x_mtau_after;
          return new;
        end if;
      end if;
    end if;

    

    RAISE EXCEPTION 'This record cannot be changed or deleted - the deposit batch number % has been created. Please contact your Systems Administrator for assistance.', x_paym_bkdp__sequence;
 
        END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_paym_closeddeposit() OWNER TO source;

--
-- Name: fn_paym_null2default(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_paym_null2default() RETURNS "trigger"
    AS $$DECLARE
       tmp_bkdp__sequence bkdp.bkdp__sequence%TYPE; 
    BEGIN
        if (new.paym_tdtp_code is null) then
          new.paym_tdtp_code := '-';
        end if;

        if (new.paym_bkdp__sequence is null) then
          new.paym_bkdp__sequence := 0;
        end if;

        -- make sure the holding record in bkdp is present
        if (TG_OP = 'INSERT') then
          select bkdp__sequence
          into   tmp_bkdp__sequence
          from   bkdp
          where  bkdp__sequence = 0;

          if not found then
             insert into bkdp (bkdp_desc, bkdp__sequence)
                    values ('Unbanked Payments',0);
          end if;
        end if;

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_paym_null2default() OWNER TO source;

--
-- Name: fn_serv_ckdel(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_serv_ckdel() RETURNS "trigger"
    AS $$
    DECLARE
      tmp_svpf_count integer;
    BEGIN
    -- check for dependents
   
    select into tmp_svpf_count count(*)
    from   svpf
    where  svpf_serv_code = old.serv_code;
    
    if ( TG_OP = 'DELETE' ) then
       if tmp_svpf_count > 0  then
         RAISE EXCEPTION 'The Service Code % has % dependent services recorded, so cannot be deleted',
                old.serv_code, tmp_svpf_count;
       end if;
       return old;
    end if;

    if ( TG_OP = 'UPDATE' ) then
       if ( tmp_svpf_count > 0  and new.serv_code <> old.serv_code ) then
         RAISE EXCEPTION 'The Service Code % has % dependent services recorded, so cannot be changed',
                old.serv_code, tmp_svpf_count;
       end if;
    end if;

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_serv_ckdel() OWNER TO source;

--
-- Name: fn_setbkdpamount(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_setbkdpamount() RETURNS "trigger"
    AS $$DECLARE
    x_before bkdp.bkdp_amount%TYPE;
    x_after bkdp.bkdp_amount%TYPE;
    old_paym_bkdp__sequence paym.paym_bkdp__sequence%TYPE;
    new_paym_bkdp__sequence paym.paym_bkdp__sequence%TYPE;
    x_sep char(1) := '~';

    BEGIN

    -- more than one batch may be involved - eg in transfer.

    old_paym_bkdp__sequence := -1;
    new_paym_bkdp__sequence := -1;

    if (TG_OP = 'DELETE') then
      old_paym_bkdp__sequence := coalesce(old.paym_bkdp__sequence,0);
    end if;

    if (TG_OP = 'INSERT') then
      new_paym_bkdp__sequence := coalesce(new.paym_bkdp__sequence,0);
    end if;

    if (TG_OP = 'UPDATE') then
      old_paym_bkdp__sequence := coalesce(old.paym_bkdp__sequence,0);
      new_paym_bkdp__sequence := coalesce(new.paym_bkdp__sequence,0);
    end if;

    -- the source of the transaction - adjust old balance
    if (old_paym_bkdp__sequence > 0) then

        -- current balance
      select    bkdp_amount
      into      x_before
      from      bkdp
      where     bkdp__sequence = old_paym_bkdp__sequence;

        -- new balance
      select    sum(coalesce(paym_amount,0.00::numeric))
      into      x_after
      from      paym
      where     paym_bkdp__sequence = old_paym_bkdp__sequence;

      update bkdp
      set    bkdp_amount = x_after
      where  bkdp__sequence = old_paym_bkdp__sequence;

      insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
        select 'bkdp', old_paym_bkdp__sequence, 'UPDATE', x_sep||'bkdp_amount', 
                x_sep||to_char(x_before, '9999999999.99'),
                x_sep||to_char(x_after, '9999999999.99');

    end if;

    -- the destination for the transaction - adjust new balance
    if (new_paym_bkdp__sequence > 0) then

        -- current balance
      select    bkdp_amount
      into      x_before
      from      bkdp
      where     bkdp__sequence = new_paym_bkdp__sequence;

        -- new balance
      select    sum(coalesce(paym_amount,0.00::numeric))
      into      x_after
      from      paym
      where     paym_bkdp__sequence = new_paym_bkdp__sequence;

      update bkdp
      set    bkdp_amount = x_after
      where  bkdp__sequence = new_paym_bkdp__sequence;

      insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
        select 'bkdp', new_paym_bkdp__sequence, 'UPDATE', x_sep||'bkdp_amount', 
                x_sep||to_char(x_before, '9999999999.99'),
                x_sep||to_char(x_after, '9999999999.99');

    end if;

    if (TG_OP = 'DELETE') then
      return old;
    else
      return new;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_setbkdpamount() OWNER TO source;

--
-- Name: fn_svpf_closedinvoice(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_svpf_closedinvoice() RETURNS "trigger"
    AS $$DECLARE
    tmp_invc_date_printed invc.invc_date_printed%TYPE;
    old_invc__sequence invc.invc__sequence%TYPE;
    new_invc__sequence invc.invc__sequence%TYPE;
    x_mtau_attributes mtau.mtau_attributes%TYPE := '';
    x_mtau_before mtau.mtau_before%TYPE := '';
    x_mtau_after mtau.mtau_after%TYPE := '';
    x_sep char(1) := '~';
    BEGIN

    old_invc__sequence := -1;
    new_invc__sequence := -1;

    -- ------------------------------  
    -- INSERTS should not be here
    -- ------------------------------  

    if (TG_OP != 'UPDATE' and TG_OP != 'DELETE') then
      RAISE EXCEPTION 'tr_svpf_closedinvoice: this trigger can only be used for UPDATE and DELETE';
    end if;

    -- ------------------------------  
    -- uninteresting DELETES
    -- ------------------------------  
    if ( TG_OP = 'DELETE' ) then
      if (old.svpf_invc__sequence is null or old.svpf_invc__sequence = 0) then
        return old;
      end if;
      old_invc__sequence := old.svpf_invc__sequence;
      new_invc__sequence := old.svpf_invc__sequence;
    end if;


    -- ------------------------------  
    -- UPDATES may be of interest
    -- ------------------------------  
    if (TG_OP = 'UPDATE') then
      old_invc__sequence := old.svpf_invc__sequence;
      new_invc__sequence := new.svpf_invc__sequence;
    end if;
    
    -- ------------------------------  
    -- look for invc_date_printed
    -- ------------------------------ 
    select invc_date_printed
    into   tmp_invc_date_printed
    from   invc
    where  (invc__sequence = old_invc__sequence
           or invc__sequence = new_invc__sequence);

    -- ------------------------------
    -- This trigger might be part 
    -- of an invc delete, so no
    -- parent invc.
    -- ------------------------------
    if ( not found ) then
      tmp_invc_date_printed = now();
    end if;

    -- RAISE NOTICE 'tr_svpf_closedinvoice: tmp_invc_date_printed = %, old_invc__sequence = %, new_invc__sequence = %', tmp_invc_date_printed, old_invc__sequence, new_invc__sequence;

    -- ------------------------------  
    -- ALREADY PRINTED - only
    -- admin can proceed.
    -- ------------------------------

    if ( tmp_invc_date_printed is not null ) then
      -- 32 is office-admin
      if ( (select perms::integer & 32 from mvac_user where username = current_user) != 32 ) then
        RAISE EXCEPTION 'This record cannot be copied, changed or deleted - the invoice number % has been printed. Please contact your Systems Administrator for assistance.',
         old_invc__sequence;
        return null;
      end if;
    end if;

    -- ------------------------------
    -- Audit deletes after printing.
    -- ------------------------------
    if (TG_OP = 'DELETE' and tmp_invc_date_printed is not null ) then
  
      insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
              select    'svpf', old.svpf__sequence, TG_OP,
                        x_sep ||
                        'svpf_date_service' || x_sep ||
                        'svpf_serv_code' || x_sep ||
                        'svpf_percentage' || x_sep ||
                        'svpf_desc' || x_sep ||
                        'svpf_amount' || x_sep ||
                        'svpf_gst_amount' || x_sep ||
                        'svpf_invc__sequence' || x_sep ||
                        'svpf_mdaf__sequence' || x_sep ||
                        'svpf_patn__sequence',
                        x_sep ||
                        coalesce( old.svpf_date_service::text, '' ) || x_sep ||
                        coalesce( old.svpf_serv_code, '' ) || x_sep ||
                        coalesce( old.svpf_percentage, -1 ) || x_sep ||
                        coalesce( old.svpf_desc, '' ) || x_sep ||
                        coalesce( to_char(old.svpf_amount,'9999999999.99'), '' ) || x_sep ||
                        coalesce( to_char(old.svpf_gst_amount,'9999999999.99'), '' ) || x_sep ||
                        coalesce( old.svpf_invc__sequence, -1 ) || x_sep ||
                        coalesce( old.svpf_mdaf__sequence, -1 ) || x_sep ||
                        coalesce( old.svpf_patn__sequence, -1 ),
                        NULL;
      return old;

    end if;

    -- ------------------------------
    -- Audit updates after printing
    -- ------------------------------
  
    if ( TG_OP = 'UPDATE' and tmp_invc_date_printed is not null ) then

      insert into mtau(mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after)
              select    'svpf', old.svpf__sequence, TG_OP,
                        x_sep ||
                        'svpf_date_service' || x_sep ||
                        'svpf_serv_code' || x_sep ||
                        'svpf_percentage' || x_sep ||
                        'svpf_desc' || x_sep ||
                        'svpf_amount' || x_sep ||
                        'svpf_gst_amount' || x_sep ||
                        'svpf_invc__sequence' || x_sep ||
                        'svpf_mdaf__sequence' || x_sep ||
                        'svpf_patn__sequence',
                        x_sep ||
                        coalesce( old.svpf_date_service::text, '' ) || x_sep ||
                        coalesce( old.svpf_serv_code, '' ) || x_sep ||
                        coalesce( old.svpf_percentage, -1 ) || x_sep ||
                        coalesce( old.svpf_desc, '' ) || x_sep ||
                        coalesce( to_char(old.svpf_amount,'9999999999.99'), '' ) || x_sep ||
                        coalesce( to_char(old.svpf_gst_amount,'9999999999.99'), '' ) || x_sep ||
                        coalesce( old.svpf_invc__sequence, -1 ) || x_sep ||
                        coalesce( old.svpf_mdaf__sequence, -1 ) || x_sep ||
                        coalesce( old.svpf_patn__sequence, -1 ),
                        x_sep ||
                        coalesce( new.svpf_date_service::text, '' ) || x_sep ||
                        coalesce( new.svpf_serv_code, '' ) || x_sep ||
                        coalesce( new.svpf_percentage, -1 ) || x_sep ||
                        coalesce( new.svpf_desc, '' ) || x_sep ||
                        coalesce( to_char(new.svpf_amount,'9999999999.99'), '' ) || x_sep ||
                        coalesce( to_char(new.svpf_gst_amount,'9999999999.99'), '' ) || x_sep ||
                        coalesce( new.svpf_invc__sequence, -1 ) || x_sep ||
                        coalesce( new.svpf_mdaf__sequence, -1 ) || x_sep ||
                        coalesce( new.svpf_patn__sequence, -1 );
      return new;
    end if;

    -- ------------------------------
    -- Tidy up.
    -- ------------------------------
    if (TG_OP = 'DELETE') then
      return old;
    else
      return new;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_svpf_closedinvoice() OWNER TO source;

--
-- Name: fn_svpf_null2default(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_svpf_null2default() RETURNS "trigger"
    AS $$
        DECLARE
                tmp_invc__sequence svpf.svpf_invc__sequence%TYPE; 
                tmp_serv_code serv.serv_code%TYPE;
                tmp_fept fept%ROWTYPE;
                tmp_patn patn%ROWTYPE;
                tmp_invc invc%ROWTYPE;
                sequence_id integer;
                x_pos integer;
        BEGIN
        -- Patient is an absolute requirement

        if (new.svpf_patn__sequence is null) then
           RAISE EXCEPTION 'Patient ID number (svpf_patn__sequence) is mandatory';
        end if;

        select *
        into   tmp_patn
        from   patn
        where  patn__sequence = new.svpf_patn__sequence;

        -- add a patn record if missing
        if not found then
          insert into patn(patn__sequence)
          values(new.svpf_patn__sequence);
          select  *
          into    tmp_patn
          from    patn
          where   patn__sequence = new.svpf_patn__sequence;

          if ( not found ) then
            RAISE EXCEPTION 'Unable to create a Patient Record (%)', new.svpf_patn__sequence;
          end if;
        end if;

        -- if missing service code, then use a default
        if (new.svpf_serv_code is null) then
          new.svpf_serv_code := '-';
        end if;

        -- invc can be found or created
        if (new.svpf_invc__sequence is null or new.svpf_invc__sequence = 0) then

          -- look for the newest unprinted invoice for the patient/debtor/prov/feet/rfdr

          select invc_locate(
                tmp_patn.patn__sequence,
                tmp_patn.patn_dbtr_code,
                tmp_patn.patn_prov_code,
                tmp_patn.patn_feet_code,
                tmp_patn.patn_rfdr_code,
                tmp_patn.patn_empl_code,
                tmp_patn.patn_hlfd_code,
                false,          -- unprinted
                true)           -- create if necessary
          into   tmp_invc__sequence;

          if tmp_invc__sequence is null then
              RAISE EXCEPTION 'Unable to locate a suitable invoice';
          else
            -- recover it
            select *
            into   tmp_invc
            from   invc
            where  invc__sequence = sequence_id;
            
            new.svpf_invc__sequence := tmp_invc.invc__sequence;
          end if;
        end if;
        
        -- Now for service code
        select fept.*
        into   tmp_fept
        from   fept,patn
        where  patn__sequence = new.svpf_patn__sequence
        and    fept_serv_code = new.svpf_serv_code
        and    fept_feet_code = patn_feet_code;

        if not found then
          RAISE EXCEPTION 'item % not found for patient %', new.svpf_serv_code,new.svpf_patn__sequence;
          tmp_fept.fept_desc := 'UNKNOWN';
          tmp_fept.fept_amount := 0.00;
          tmp_fept.fept_gst_amount := 0.00;
        end if;
        if ( TG_OP = 'INSERT' ) then
              -- RAISE EXCEPTION 'item = %, desc=%', tmp_fept.fept_serv_code, tmp_fept.fept_desc;
          if (new.svpf_desc is null) then
            new.svpf_desc := tmp_fept.fept_desc;
          end if;
          if (new.svpf_amount is null) then
            new.svpf_amount := tmp_fept.fept_amount * (new.svpf_percentage/100::numeric);
          end if;
          if (new.svpf_gst_amount is null and new.svpf_date_service < 'jul 1 2000' ) then
            new.svpf_gst_amount := tmp_fept.fept_gst_amount * (new.svpf_percentage/100::numeric);
          end if;
        end if;

        if ( TG_OP = 'UPDATE' ) then
           --   RAISE NOTICE 'item = %, desc=%, perc=%', tmp_fept.fept_serv_code,
           --                                              tmp_fept.fept_desc,
           --                                              new.svpf_percentage;
           --   RAISE NOTICE 'amount = %, perc=%, gst=%', tmp_fept.fept_amount,
           --                                               tmp_fept.fept_gst_percentage,
           --                                               tmp_fept.fept_gst_amount;
           -- item code change - refresh description and amount
           if ( new.svpf_serv_code <> old.svpf_serv_code) then
              new.svpf_desc := tmp_fept.fept_desc;
              new.svpf_amount := tmp_fept.fept_amount * (new.svpf_percentage/100::numeric);
           end if;
           -- percentage change - refresh amount from fept, but leave description
           if ( new.svpf_serv_code <> old.svpf_serv_code or new.svpf_percentage <> old.svpf_percentage) then
              new.svpf_amount := tmp_fept.fept_amount * (new.svpf_percentage/100::numeric);
           end if;
           -- always recalculate the GST amount
           if ( new.svpf_date_service > 'jul 1 2000' ) then
             new.svpf_gst_amount := new.svpf_amount * (tmp_fept.fept_gst_percentage/100::numeric);
           end if;
           -- final sanity checks
           if (new.svpf_amount is null) then
             new.svpf_amount := 0.00;
           end if;
           if (new.svpf_gst_amount is null) then
             new.svpf_gst_amount := 0.00;
           end if;
           if (new.svpf_percentage is null
               or new.svpf_percentage < 0) then
             new.svpf_percentage := 100;
           end if;

        end if;

        -- And check for %P in desc - replace with provider
        -- 
        x_pos := position( '~P' in new.svpf_desc);
        if ( x_pos > 0 ) then
          if ( length(new.svpf_desc) > x_pos + 1 ) then
            new.svpf_desc := substring(new.svpf_desc from 1 for (x_pos-1)) || tmp_patn.patn_prov_code || substring(new.svpf_desc from (x_pos+2));
          else
            new.svpf_desc := substring(new.svpf_desc from 1 for (x_pos-1)) || tmp_patn.patn_prov_code;
          end if;
        end if;
    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_svpf_null2default() OWNER TO source;

--
-- Name: fn_vacuumtickets(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION fn_vacuumtickets() RETURNS "trigger"
    AS $$DECLARE

    BEGIN

    if ( TG_OP = 'INSERT' ) then
      delete from mttk where mttk_expires < now();
    end if;

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fn_vacuumtickets() OWNER TO source;

--
-- Name: form_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION form_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.form_code is null ) then
      new.form_code = new.form__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.form_tr_before() OWNER TO source;

--
-- Name: get_param(text, text, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION get_param(text, text, integer) RETURNS text
    AS $_$DECLARE
        multistr   alias for $1;  -- multi-parameter string
        sep        alias for $2;  -- separator
        parnum     alias for $3;  -- parameter number

        par_count  int = 0;
        tmp_str    text := '';
        pos        int;
        parm       text = '';

    BEGIN

        tmp_str := multistr;
        -- skip over the leading params
        WHILE (par_count < parnum)
          LOOP
            -- next separator
            pos = position(sep in tmp_str);
            if (pos < 1) then
               return null::text;
            end if;
            pos := pos + char_length(sep);
            tmp_str := substring(tmp_str from pos);
            par_count := par_count + 1;
        END LOOP;

        -- extract the parameter.
        WHILE (par_count = parnum)
          LOOP
            pos = position(sep in tmp_str);
            if (pos < 1) then
              parm := tmp_str;
            else
              parm := substring(tmp_str, 1, pos-1);
            end if;
            if ( char_length(parm) = 0) then
              return null::text;
            else
              return parm;
            end if;
        END LOOP;

        return null::text;
    END;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.get_param(text, text, integer) OWNER TO source;

--
-- Name: get_paym_total(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION get_paym_total(integer) RETURNS numeric
    AS $_$DECLARE
        tmp_paym_number alias for $1;
        tmp_paym_total paym.paym_amount%TYPE;

    BEGIN

    
      select coalesce( sum(cred_amount + cred_gst_amount), '0.00'::numeric )
      into   tmp_paym_total
      from   cred
      where  cred_paym__sequence = tmp_paym_number;

      return tmp_paym_total;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.get_paym_total(integer) OWNER TO source;

--
-- Name: getfee(text, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION getfee(text, integer) RETURNS numeric
    AS $_$DECLARE
      x_fee feeb.feeb_amount%TYPE;
    BEGIN
      select    feeb_amount
      into      x_fee
      from      feeb
      where     feeb_serv_code = $1
      and       feeb_feet_code = getfeetype($2);

      return x_fee;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.getfee(text, integer) OWNER TO source;

--
-- Name: getfeetype(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION getfeetype(integer) RETURNS text
    AS $_$DECLARE
      x_feet_code feet.feet_code%TYPE;
    BEGIN
      select    feet_code
      into      x_feet_code
      from      feet
      order by feet_code, feet__sequence limit 1 offset $1;
      return x_feet_code;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.getfeetype(integer) OWNER TO source;

--
-- Name: hlfd_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION hlfd_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.hlfd_code is null ) then
      new.hlfd_code = new.hlfd__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.hlfd_tr_before() OWNER TO source;

--
-- Name: invc_age_period(integer, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_age_period(integer, integer) RETURNS integer
    AS $_$DECLARE
    tmp_invc__sequence ALIAS for $1;
    tmp_daysago ALIAS for $2;
    period integer;

    BEGIN

    -- 3600*24 = 86400
--    select  trunc(date_part('epoch',age(invc_date_printed))/(2592000))
    select  trunc(date_part('epoch',age(invc_date_printed))/86400)
    into    period
    from    invc
    where   invc_date_printed is not null
    and     invc__sequence = tmp_invc__sequence;

    if ( not found ) then
      return 0;
    end if;
    period := (period-tmp_daysago)/30;
    if ( period < 0 ) then
      period := 0;
    end if;

    if ( period > 4 ) then
      period := 4;
    end if;

    period := period * 30;

    return period;
      
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_age_period(integer, integer) OWNER TO source;

--
-- Name: invc_balance(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_balance(integer) RETURNS numeric
    AS $_$DECLARE
        invc_number alias for $1;
        rec_invc invc%ROWTYPE;
        balance invc.invc_amount%TYPE;

    BEGIN
        -- get record
        select  *
        into    rec_invc
        from    invc
        where   invc__sequence = invc_number;

        if ( not found ) then
          return null;
        end if;

        if (rec_invc.invc_amount is null) then
          rec_invc.invc_amount = 0;
        end if;

        if (rec_invc.invc_gst_amount is null) then
          rec_invc.invc_gst_amount = 0;
        end if;

        if (rec_invc.invc_paid_amount is null) then
          rec_invc.invc_paid_amount = 0;
        end if;

        if (rec_invc.invc_paid_gst_amount is null) then
         rec_invc.invc_paid_gst_amount  = 0;
        end if;

        balance = rec_invc.invc_amount
                + rec_invc.invc_gst_amount
                - rec_invc.invc_paid_amount
                - rec_invc.invc_paid_gst_amount;

      return balance;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_balance(integer) OWNER TO source;

--
-- Name: invc_balance_then(integer, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_balance_then(integer, integer) RETURNS numeric
    AS $_$DECLARE
        invc_number alias for $1;
        days_ago alias for $2;
        rec_invc invc%ROWTYPE;
        rec_cred cred%ROWTYPE;
        debits svpf.svpf_amount%TYPE;
        credits cred.cred_amount%TYPE;
        balance invc.invc_amount%TYPE;

    BEGIN
        -- get invc record
        select  *
        into    rec_invc
        from    invc
        where   invc__sequence = invc_number
        and     invc_date_printed <= now() - (to_char(days_ago,'9999') || ' days')::interval;

        if ( not found ) then
          -- RAISE NOTICE 'invc_balance_then - % not found', invc_number;
          return null;
        end if;

        if (rec_invc.invc_amount is null) then
          rec_invc.invc_amount = 0;
        end if;

        if (rec_invc.invc_gst_amount is null) then
          rec_invc.invc_gst_amount = 0;
        end if;


        -- get cred record
        select  sum(cred_amount), sum(cred_gst_amount)
        into    rec_cred.cred_amount, rec_cred.cred_gst_amount
        from    cred,paym
        where   cred_invc__sequence = invc_number
        and     cred_paym__sequence = paym.paym__sequence
        and     paym_date_entry <= now() - (to_char(days_ago,'9999') || ' days')::interval;

        if ( not found ) then
          rec_cred.cred_amount = 0;
          rec_cred.cred_gst_amount = 0;
        end if;

        if (rec_cred.cred_amount is null) then
          rec_cred.cred_amount = 0;
        end if;

        if (rec_cred.cred_gst_amount is null) then
         rec_cred.cred_gst_amount  = 0;
        end if;

        balance = rec_invc.invc_amount
                + rec_invc.invc_gst_amount
                - rec_cred.cred_amount
                - rec_cred.cred_gst_amount;

      return balance;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_balance_then(integer, integer) OWNER TO source;

--
-- Name: invc_credit_totals(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_credit_totals() RETURNS "trigger"
    AS $$DECLARE
    sum_cred_amount cred.cred_amount%TYPE;
    sum_cred_gst_amount cred.cred_gst_amount%TYPE;
    rec_invc invc%ROWTYPE;
    rec_paym paym%ROWTYPE;

    BEGIN

      if ( TG_OP = 'DELETE' ) then
        rec_invc.invc__sequence = old.cred_invc__sequence;
        rec_paym.paym__sequence = old.cred_paym__sequence;
      else
        rec_invc.invc__sequence = new.cred_invc__sequence;
        rec_paym.paym__sequence = new.cred_paym__sequence;
      end if;
      
      -- get service totals
      select sum(cred.cred_amount),
             sum(cred.cred_gst_amount)
      into   sum_cred_amount,
             sum_cred_gst_amount
      from   cred
      where cred.cred_invc__sequence = rec_invc.invc__sequence;
      
      if (sum_cred_amount is null) then
        sum_cred_amount := 0.00::numeric;
      end if;
      if (sum_cred_gst_amount is null) then
        sum_cred_gst_amount := 0.00::numeric;
      end if;
      -- raise notice 'invc_credit_totals:sum_cred_amount = %', sum_cred_amount;
      
      update invc
        set invc_paid_amount = sum_cred_amount,
            invc_paid_gst_amount = sum_cred_gst_amount
        where invc.invc__sequence = rec_invc.invc__sequence;

      -- update paym
      if (rec_paym.paym__sequence > 0 ) then
        select  set_paym_total(rec_paym.paym__sequence)
        into    sum_cred_amount;
        -- RAISE NOTICE 'updating payment total for % - %', new.cred_paym__sequence, sum_cred_amount;
      end if;

      if ( TG_OP = 'DELETE' ) then
        return old;
      else
        return new;
      end if;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_credit_totals() OWNER TO source;

--
-- Name: invc_debit_totals(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_debit_totals() RETURNS "trigger"
    AS $$DECLARE
    sum_svpf_amount svpf.svpf_amount%TYPE;
    sum_svpf_gst_amount svpf.svpf_gst_amount%TYPE;
    x_invc__sequence svpf.svpf_invc__sequence%TYPE;

    BEGIN

        if ( TG_OP = 'DELETE' ) then
          x_invc__sequence := old.svpf_invc__sequence;
        else
          x_invc__sequence := new.svpf_invc__sequence;
        end if;

        -- get service totals
        select sum(svpf.svpf_amount),
               sum(svpf.svpf_gst_amount)
        into   sum_svpf_amount,
               sum_svpf_gst_amount
        where svpf.svpf_invc__sequence = x_invc__sequence;

        if (sum_svpf_amount is null) then
          sum_svpf_amount = 0.00;
        end if;
        if (sum_svpf_gst_amount is null) then
          sum_svpf_gst_amount = 0.00;
        end if;

        update invc
          set invc_amount = sum_svpf_amount,
              invc_gst_amount = sum_svpf_gst_amount
          where invc.invc__sequence = x_invc__sequence;

    return new;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_debit_totals() OWNER TO source;

--
-- Name: invc_fix_totals(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_fix_totals(integer) RETURNS numeric
    AS $_$DECLARE
    invc_number alias for $1;

    BEGIN

        update  invc
            set invc_amount = (
                select  coalesce(sum(svpf_amount),0.00)
                from    svpf
                where   svpf_invc__sequence = invc.invc__sequence)
        where   invc__sequence = invc_number;
        update invc
            set invc_gst_amount = (
                select coalesce(sum(svpf_gst_amount),0.00)
                from svpf
                where svpf_invc__sequence = invc.invc__sequence)
        where   invc__sequence = invc_number;
        update invc
            set invc_paid_amount = (
                select coalesce(sum(cred_amount),0.00)
                from cred
                where cred_invc__sequence = invc.invc__sequence)
        where   invc__sequence = invc_number;
        update invc
            set invc_paid_gst_amount = (
                select coalesce(sum(cred_gst_amount),0.00)
                from cred
                    where cred_invc__sequence = invc.invc__sequence)
        where   invc__sequence = invc_number;
    
    return invc_balance(invc_number);

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_fix_totals(integer) OWNER TO source;

--
-- Name: invc_locate(integer, text, text, text, text, text, text, boolean, boolean); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_locate(integer, text, text, text, text, text, text, boolean, boolean) RETURNS integer
    AS $_$

  DECLARE
    a_patn__sequence    ALIAS for $1;
    a_dbtr_code         ALIAS for $2;
    a_prov_code         ALIAS for $3;
    a_feet_code         ALIAS for $4;
    a_rfdr_code         ALIAS for $5;
    a_empl_code         ALIAS for $6;
    a_hlfd_code         ALIAS for $7;
    a_printed           ALIAS for $8;   -- true = ignore printed state
    a_create            ALIAS for $9;   -- true = create if doesn't exist

    x_invc__sequence integer := null;
    x_oid oid;

  BEGIN

    -- look for the newest unprinted invoice for the debtor/patient/prov/feet
    select max(invc__sequence)
    into   x_invc__sequence
    from   invc
    where  invc_patn__sequence  = a_patn__sequence
    and    invc_dbtr_code       = a_dbtr_code
    and    invc_prov_code       = a_prov_code
    and    invc_feet_code       = a_feet_code
    and    invc_empl_code       = a_empl_code
    and    invc_hlfd_code       = a_hlfd_code
    and    (invc_date_printed is null or a_printed);

    if (x_invc__sequence is null) then
      if (a_create) then
        -- Insert a new invc record, from patn defaults
        insert into invc(
            invc_dbtr_code,
            invc_prov_code,
            invc_patn__sequence,
            invc_empl_code,
            invc_feet_code,
            invc_rfdr_code,
            invc_rfdr_date,
            invc_rfdr_period,
            invc_hlfd_code,
            invc_ins_level,
            invc_healthnumb,
            invc_healthcard,
            invc_claim_number,
            invc_accident_date)
        select
            a_dbtr_code,
            a_prov_code,
            a_patn__sequence,
            a_empl_code,
            a_feet_code,
            a_rfdr_code,
            patn.patn_ref_date,
            patn.patn_ref_period,
            a_hlfd_code,
            patn.patn_ins_level,
            patn.patn_healthnumb,
            patn.patn_healthcard,
            patn.patn_claim_number,
            patn.patn_accident_date
        from   patn
        where  patn__sequence = a_patn__sequence;

        if (FOUND) then
          GET DIAGNOSTICS x_oid = RESULT_OID;
          select  invc__sequence
          into    x_invc__sequence
          from    invc
          where   oid = x_oid;
          if (FOUND) then
             return x_invc__sequence;
          end if;
        end if;
      end if;
      return null;
    end if;

    return x_invc__sequence;

  END;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_locate(integer, text, text, text, text, text, text, boolean, boolean) OWNER TO source;

--
-- Name: invc_patient_name(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_patient_name(integer) RETURNS text
    AS $_$DECLARE
    invc_number alias for $1;
    rec_patn patn%ROWTYPE;
    patient_name text;

    BEGIN
    select patn_psnam || ', ' || patn_fsnam
    into   patient_name
    from   patn,invc
    where  invc__sequence = invc_number
    and    patn__sequence = invc_patn__sequence;

    if (not found) then
      RAISE EXCEPTION 'Patient not found for invoice number <%>', invc_number;
      return null;
    end if;
      
    
    return patient_name;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_patient_name(integer) OWNER TO source;

--
-- Name: invc_setprintdates(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_setprintdates(integer) RETURNS boolean
    AS $_$DECLARE
        invc_number alias for $1;
        printed invc.invc_date_printed%TYPE;

    BEGIN
        -- get record
        select  invc_date_printed
        into    printed
        from    invc
        where   invc__sequence = invc_number;

        if ( not found ) then
          return false;
        end if;

        if (printed is null) then
          update invc set invc_date_printed = 'now'::timestamp
          where  invc__sequence = invc_number;
        else
          update invc set invc_date_reprint = 'now'::timestamp
          where  invc__sequence = invc_number;
        end if;

      return true;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_setprintdates(integer) OWNER TO source;

--
-- Name: invc_totals(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION invc_totals(integer) RETURNS numeric
    AS $_$DECLARE
    invc_number alias for $1;
    sum_svpf_amount svpf.svpf_amount%TYPE;
    sum_svpf_gst_amount svpf.svpf_gst_amount%TYPE;
    sum_cred_amount cred.cred_amount%TYPE;
    sum_cred_gst_amount cred.cred_gst_amount%TYPE;
    sum_svpf_balance svpf.svpf_amount%TYPE;

    BEGIN
        -- get service totals
        select sum(svpf.svpf_amount),
               sum(svpf.svpf_gst_amount)
        into   sum_svpf_amount,
               sum_svpf_gst_amount
        where svpf.svpf_invc__sequence = invc_number;

        if (sum_svpf_amount is null) then
          sum_svpf_amount = 0.00;
        end if;
        if (sum_svpf_gst_amount is null) then
          sum_svpf_gst_amount = 0.00;
        end if;

        -- get credit totals
        select sum(cred.cred_amount),
               sum(cred.cred_gst_amount)
        into   sum_cred_amount,
               sum_cred_gst_amount
        where cred.cred_invc__sequence = invc_number;

        if (sum_cred_amount is null) then
          sum_cred_amount = 0.00;
        end if;
        if (sum_cred_gst_amount is null) then
          sum_cred_gst_amount = 0.00;
        end if;

        update invc
          set invc_amount = sum_svpf_amount,
              invc_gst_amount = sum_svpf_gst_amount,
              invc_paid_amount = sum_cred_amount,
              invc_paid_gst_amount = sum_cred_gst_amount
          where invc.invc__sequence = invc_number;

        sum_svpf_balance := sum_svpf_amount + sum_svpf_gst_amount - sum_cred_amount - sum_cred_gst_amount;

    return sum_svpf_balance;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.invc_totals(integer) OWNER TO source;

--
-- Name: isreferralexpired(timestamp without time zone, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION isreferralexpired(timestamp without time zone, integer) RETURNS character
    AS $_$DECLARE
        ref_date alias for $1;
        ref_period alias for $2;

    BEGIN
        if ( ref_period = 0 or ref_period = 99 or ref_period is null
             or (date(ref_date) + (ref_period||' months')::interval) >= date(now()) ) then
          return 'N';
        else
          return 'Y';
        end if;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.isreferralexpired(timestamp without time zone, integer) OWNER TO source;

--
-- Name: locn_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION locn_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.locn_code is null ) then
      new.locn_code = new.locn__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.locn_tr_before() OWNER TO source;

--
-- Name: mtat_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION mtat_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_mtat__sequence mtat.mtat__sequence%TYPE;

    BEGIN

         -- get a mtat__sequence
         select nextval('mtat_mtat__sequence_seq')
         into tmp_mtat__sequence;

         -- add the new row
         insert into mtat( mtat_name, mtat__sequence )
                   values( tmp_mtat__sequence::text, tmp_mtat__sequence);

    return tmp_mtat__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.mtat_insert_row() OWNER TO source;

--
-- Name: mtcl_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION mtcl_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_mtcl__sequence mtcl.mtcl__sequence%TYPE;

    BEGIN

         -- get a mtcl__sequence
         select nextval('mtcl_mtcl__sequence_seq')
         into tmp_mtcl__sequence;

         -- add the new row
         insert into mtcl( mtcl_name, mtcl__sequence )
                   values( tmp_mtcl__sequence::text, tmp_mtcl__sequence);

    return tmp_mtcl__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.mtcl_insert_row() OWNER TO source;

--
-- Name: mtfn_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION mtfn_tr_before() RETURNS "trigger"
    AS $$DECLARE
    rec_mtcl mtcl%ROWTYPE;
    rec_mtat mtat%ROWTYPE;

    BEGIN

    -- check/set mtfn_master_class

    select *
    into   rec_mtcl
    from   mtcl
    where  mtcl_name = new.mtfn_master_class;

    if ( not found ) then
      if ( new.mtfn_master_class = '-' ) then
        -- RAISE NOTICE 'inserting master class record for <%>', new.mtfn_master_class;
        insert into mtcl(mtcl_name) values(new.mtfn_master_class);
      else
        RAISE EXCEPTION 'The TABLE <%> does not exist in the MTCL table', new.mtfn_master_class;
        return null;
      end if;
    end if;

    -- check/set mtfn_other_class

    select *
    into   rec_mtcl
    from   mtcl
    where  mtcl_name = new.mtfn_other_class;

    if ( not found ) then
      if ( new.mtfn_other_class = '-' ) then
        -- RAISE NOTICE 'inserting other class record for <%>', new.mtfn_other_class;
        insert into mtcl(mtcl_name) values(new.mtfn_other_class);
      else
        RAISE EXCEPTION 'The TABLE <%> does not exist in the MTCL table', new.mtfn_other_class;
        return null;
      end if;
    end if;

    -- check/set mtfn_key

    select *
    into   rec_mtat
    from   mtat
    where  mtat_name = new.mtfn_key;

    if ( not found ) then
      if ( new.mtfn_key = '-' ) then
        -- RAISE NOTICE 'inserting attribute record for <%>', new.mtfn_key;
        insert into mtat(mtat_name, mtat_class_name) values(new.mtfn_key, new.mtfn_master_class);
      else
        RAISE EXCEPTION 'The ATTRIBUTE <%> does not exist in the MTAT table', new.mtfn_key;
        return null;
      end if;
    end if;


    -- check/set mtfn_join

    select *
    into   rec_mtat
    from   mtat
    where  mtat_name = new.mtfn_join;

    if ( not found ) then
      if ( new.mtfn_join = '-' ) then
        -- RAISE NOTICE 'inserting attribute record for <%>', new.mtfn_join;
        insert into mtat(mtat_name, mtat_class_name) values(new.mtfn_join, new.mtfn_other_class);
      else
        RAISE EXCEPTION 'The ATTRIBUTE <%> does not exist in the MTAT table', new.mtfn_join;
        return null;
      end if;
    end if;

    -- check/set mtfn_view

    select *
    into   rec_mtat
    from   mtat
    where  mtat_name = new.mtfn_view;

    if ( not found ) then
      if ( new.mtfn_view = '-' ) then
        -- RAISE NOTICE 'inserting attribute record for <%>', new.mtfn_view;
        insert into mtat(mtat_name, mtat_class_name) values(new.mtfn_view, new.mtfn_other_class);
      else
        RAISE EXCEPTION 'The ATTRIBUTE <%> does not exist in the MTAT table', new.mtfn_view;
        return null;
      end if;
    end if;


    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.mtfn_tr_before() OWNER TO source;

--
-- Name: mtrl_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION mtrl_tr_before() RETURNS "trigger"
    AS $$DECLARE
    rec_mtcl mtcl%ROWTYPE;
    rec_mtat mtat%ROWTYPE;

    BEGIN

    -- check/set mtrl_master_class

    select *
    into   rec_mtcl
    from   mtcl
    where  mtcl_name = new.mtrl_master_class;

    if ( not found ) then
      if ( new.mtrl_master_class = '-' ) then
        -- RAISE NOTICE 'inserting master class record for <%>', new.mtrl_master_class;
        insert into mtcl(mtcl_name) values(new.mtrl_master_class);
      else
        RAISE EXCEPTION 'The TABLE <%> does not exist in the MTCL table', new.mtrl_master_class;
        return null;
      end if;
    end if;

    -- check/set mtrl_other_class

    select *
    into   rec_mtcl
    from   mtcl
    where  mtcl_name = new.mtrl_other_class;

    if ( not found ) then
      if ( new.mtrl_other_class = '-' ) then
        -- RAISE NOTICE 'inserting other class record for <%>', new.mtrl_other_class;
        insert into mtcl(mtcl_name) values(new.mtrl_other_class);
      else
        RAISE EXCEPTION 'The TABLE <%> does not exist in the MTCL table', new.mtrl_other_class;
        return null;
      end if;
    end if;

    -- check/set mtrl_key

    select *
    into   rec_mtat
    from   mtat
    where  mtat_name = new.mtrl_key;

    if ( not found ) then
      if ( new.mtrl_key = '-' ) then
        -- RAISE NOTICE 'inserting attribute record for <%>', new.mtrl_key;
        insert into mtat(mtat_name, mtat_class_name) values(new.mtrl_key, new.mtrl_master_class);
      else
        RAISE EXCEPTION 'The ATTRIBUTE <%> does not exist in the MTAT table', new.mtrl_key;
        return null;
      end if;
    end if;


    -- check/set mtrl_join

    select *
    into   rec_mtat
    from   mtat
    where  mtat_name = new.mtrl_join;

    if ( not found ) then
      if ( new.mtrl_join = '-' ) then
        -- RAISE NOTICE 'inserting attribute record for <%>', new.mtrl_join;
        insert into mtat(mtat_name, mtat_class_name) values(new.mtrl_join, new.mtrl_other_class);
      else
        RAISE EXCEPTION 'The ATTRIBUTE <%> does not exist in the MTAT table', new.mtrl_join;
        return null;
      end if;
    end if;


    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.mtrl_tr_before() OWNER TO source;

--
-- Name: mtsv_keys(bytea, integer, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION mtsv_keys(bytea, integer, integer) RETURNS text
    AS $_$DECLARE
    x_tgargs alias for $1;
    x_tgnargs alias for $2;
    x_offset alias for $3;
    x_keys text;
    x_sep text;
    x_count integer;

    BEGIN
    
    x_keys := '';
    x_sep := '';
    x_count = x_offset;

    while x_count < x_tgnargs
      LOOP
        x_keys := x_keys || x_sep || byteaparam(x_tgargs, x_count);
        x_count := x_count + 2;
        x_sep := ',';
      END LOOP;
        
    return x_keys;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.mtsv_keys(bytea, integer, integer) OWNER TO source;

--
-- Name: notv_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION notv_insert_row() RETURNS integer
    AS $$
    DECLARE
         rec_notv notv%ROWTYPE;
         tmp_note__sequence note.note__sequence%TYPE; 
         rec_patn patn%ROWTYPE;
                
    BEGIN

         -- Do not know patient yet, so use 0 
         if ( rec_notv.notv_patn__sequence is null ) then
           -- new invoice = 0 to trigger
           rec_notv.notv_patn__sequence := 0;
            select  *
            into    rec_patn
            from    patn
            where   patn__sequence = rec_notv.notv_patn__sequence;
            -- if not found create a dummy to temporarily satisfy constraints
            if ( not found ) then
              insert into patn(patn__sequence) values(0);
            end if;
         end if;

         -- get a note__sequence
         select nextval('note_note__sequence_seq')
         into tmp_note__sequence;
         -- add the note record 
         insert into note(
                     note_patn__sequence,
                     note__sequence)
               values(
                     rec_notv.notv_patn__sequence,
                     tmp_note__sequence);

    return tmp_note__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.notv_insert_row() OWNER TO source;

--
-- Name: patf_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION patf_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.patf_code is null ) then
      new.patf_code = new.patf__sequence::text;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.patf_tr_before() OWNER TO source;

--
-- Name: patn_patient_name(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION patn_patient_name(integer) RETURNS text
    AS $_$DECLARE
    arg_patn__sequence alias for $1;
    rec_patn patn%ROWTYPE;
    patient_name text;

    BEGIN
    select coalesce(patn_psnam,'')  || ', ' || coalesce(patn_fsnam, '')
    into   patient_name
    from   patn
    where  patn__sequence = arg_patn__sequence;

    if (not found) then
      RAISE EXCEPTION 'Patient not found for ID <%>', arg_patn__sequence;
      return null;
    end if;
      
    
    return patient_name;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.patn_patient_name(integer) OWNER TO source;

--
-- Name: patn_patient_title_name(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION patn_patient_title_name(integer) RETURNS text
    AS $_$DECLARE
    arg_patn__sequence alias for $1;
    rec_patn patn%ROWTYPE;
    patient_name text;

    BEGIN
    select coalesce(patn_title,'')  ||
           ' ' || 
           coalesce( substr(patn_fsnam,1,1)||'.', '') ||
           coalesce(patn_psnam,'')
    into   patient_name
    from   patn
    where  patn__sequence = arg_patn__sequence;

    if (not found) then
      RAISE EXCEPTION 'Patient not found for ID <%>', arg_patn__sequence;
      return null;
    end if;
      
    
    return patient_name;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.patn_patient_title_name(integer) OWNER TO source;

--
-- Name: prov_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION prov_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_prov__sequence prov.prov__sequence%TYPE;

    BEGIN

         -- get a prov__sequence
         select nextval('prov_prov__sequence_seq')
         into tmp_prov__sequence;

         -- add the new row
         insert into prov( prov_code, prov__sequence )
                   values( 'NEW-'||tmp_prov__sequence::text, tmp_prov__sequence);

    return tmp_prov__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.prov_insert_row() OWNER TO source;

--
-- Name: quarter_date(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION quarter_date(timestamp without time zone) RETURNS text
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    arg_ts alias for $1;

    BEGIN

        return extract(year from arg_ts::timestamp)||'-Q'||extract(quarter from arg_ts);
      
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.quarter_date(timestamp without time zone) OWNER TO source;

--
-- Name: rfdr_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION rfdr_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_rfdr__sequence rfdr.rfdr__sequence%TYPE;

    BEGIN

         -- get a rfdr__sequence
         select nextval('rfdr_rfdr__sequence_seq')
         into tmp_rfdr__sequence;

         -- add the new row
         insert into rfdr( rfdr_code, rfdr__sequence )
                   values( tmp_rfdr__sequence::text, tmp_rfdr__sequence);

    return tmp_rfdr__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.rfdr_insert_row() OWNER TO source;

--
-- Name: rfdr_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION rfdr_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( TG_OP = 'UPDATE' or TG_OP = 'INSERT' ) then
      if ( new.rfdr_code is null ) then
         new.rfdr_code := new.rfdr__sequence::text;
      end if;
    end if;

    if ( TG_OP = 'UPDATE' ) then
      if ( old.rfdr_code = '-' and new.rfdr_code != '-') then
        new.rfdr_code := old.rfdr_code;
        RAISE EXCEPTION 'This code (-) cannot be altered';
        return old;
      end if;
    end if;
    if ( TG_OP = 'DELETE') then
       if ( old.rfdr_code = '-') then
         RAISE EXCEPTION 'This code (-) cannot be deleted';
         return old;
      end if;
    end if;

    if (TG_OP = 'DELETE') then
      return old;
    else
      return new;
    end if;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.rfdr_tr_before() OWNER TO source;

--
-- Name: serv_tr_before(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION serv_tr_before() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- set a dummy code
    if ( new.serv_code is null ) then
      new.serv_code = 'NEW-'||new.serv__sequence::text;
    end if;

    if ( new.serv_desc is null ) then
      select  mbst_desc
      into    new.serv_desc
      from    mbst
      where   mbst_item = new.serv_code;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.serv_tr_before() OWNER TO source;

--
-- Name: set_paym_total(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION set_paym_total(integer) RETURNS numeric
    AS $_$DECLARE
        tmp_paym_number alias for $1;
        tmp_paym_total paym.paym_amount%TYPE;

    BEGIN

      tmp_paym_total = get_paym_total( tmp_paym_number );
      update  paym
      set     paym_amount = tmp_paym_total
      where   paym__sequence = tmp_paym_number;

      return tmp_paym_total;

    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.set_paym_total(integer) OWNER TO source;

--
-- Name: short_date(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION short_date(timestamp without time zone) RETURNS text
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    arg_ts alias for $1;

    BEGIN

        return to_char(arg_ts,'DD-MM-YYYY');
      
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.short_date(timestamp without time zone) OWNER TO source;

--
-- Name: svpf_fixdesc(integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION svpf_fixdesc(integer) RETURNS integer
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_svpf__sequence ALIAS for $1;
    tmp_svpf_desc svpf.svpf_desc%TYPE;

    BEGIN

      select svpf_desc || ' ' || serv_desc
      into   tmp_svpf_desc
      from   svpf, serv
      where  svpf__sequence = tmp_svpf__sequence
      and    svpf_serv_code = serv.serv_code;

      update svpf
      set    svpf_desc = trim(both ' ' from tmp_svpf_desc)
      where  svpf__sequence = tmp_svpf__sequence;

    return tmp_svpf__sequence;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.svpf_fixdesc(integer) OWNER TO source;

--
-- Name: svpf_ms_adjust(integer, text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION svpf_ms_adjust(integer, text) RETURNS integer
    AS $_$DECLARE
     -- NAME TABLE.ATTRIBUTE%TYPE;
     -- NAME TABLE%ROWTYPE;
         
     tmp_invc__sequence ALIAS for $1;
     tmp_svpf_date_service ALIAS for $2;
     tmp_rec record;
     eol text;
     count integer;
     new_pc integer;
     ts text;
 
     BEGIN
 
       count := 0;
       ts := quote_literal(tmp_svpf_date_service);
 
     FOR tmp_rec in EXECUTE '
       select    svpf_amount,
                 svpf__sequence
       from      svpf
       where     svpf_invc__sequence = ' || tmp_invc__sequence || '
         and     date(svpf_date_service) = ' || ts || '
         and     svpf_serv_code not in (' ||
                          chr(39) || '104' || chr(39) || ',' ||
                          chr(39) || '105' || chr(39) ||
                  ')
       order by  svpf_amount desc;'
 
     LOOP
         count := count + 1;
         new_pc := 25;
         if ( count = 1) then
           new_pc := 100;
         end if;
         if ( count = 2) then
           new_pc := 50;
         end if;
 
         update svpf
            set svpf_percentage = new_pc
          where svpf__sequence = tmp_rec.svpf__sequence;
 
     END LOOP;
 
 
     return count - 1;
     END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.svpf_ms_adjust(integer, text) OWNER TO source;

--
-- Name: svpv_form(text, text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION svpv_form(text, text) RETURNS text
    AS $_$DECLARE
    arg_patf alias for $1;
    arg_feet alias for $2;
    x_form_code form.form_code%TYPE;

    BEGIN

      -- look for patf match first
      if (length(arg_patf) > 0) then
        select  form_code
        into    x_form_code
        from    form
        where   form_code = 'invoice-svpv_' || arg_patf;
      end if;

      if (length(x_form_code) > 0) then
        return x_form_code;
      end if;

      -- look for feet match next
      if (length(arg_feet) > 0) then
        select  form_code
        into    x_form_code
        from    form
        where   form_code = 'invoice-svpv_' || arg_feet;
      end if;

      if (length(x_form_code) > 0) then
        return x_form_code;
      end if;

      -- default
      return 'invoice-svpv';
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.svpv_form(text, text) OWNER TO source;

--
-- Name: svsm_load(text, text, text); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION svsm_load(text, text, text) RETURNS integer
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

    query text;
    from_date text;
    to_date text;
    date_attribute text;
    stype text;
    ctype text;
    ptype text;

        
    BEGIN
      from_date := quote_literal($1);
      to_date := quote_literal($2);
      date_attribute := $3;
      stype := quote_literal('A');
      ctype := quote_literal('B');
      ptype := quote_literal('C');

      EXECUTE 'delete from svsm;';

      -- SERVICES
      --
      query := '
        insert into svsm(svsm_date_start,
                         svsm_date_end,
                         svsm_type,
                         svsm_prov_code,
                         svsm_prov_name,
                         svsm_count,
                         svsm_serv_code,
                         svsm_desc,
                         svsm_amount,
                         svsm_gst_amount)
          select ' || from_date || ',
                 ' || to_date || ',
                 ' || stype || ',
                 invc_prov_code,
                 prov_name,
                 count(*),
                 svpf_serv_code,
                 serv_desc,
                 sum(svpf_amount),
                 sum(svpf_gst_amount)
            from svpf,invc,serv,prov
           where date(' || date_attribute || ') between ' || from_date || '
                                                        and ' || to_date || '
             and svpf_invc__sequence = invc__sequence
             and svpf_serv_code = serv_code
             and invc_prov_code = prov_code
           group by invc_prov_code, prov_name, svpf_serv_code, serv_desc;';

      -- RAISE NOTICE '%', query;
      EXECUTE query;

      -- this should return the number of rows inserted
      return 0;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.svsm_load(text, text, text) OWNER TO source;

--
-- Name: tdtp_insert_row(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION tdtp_insert_row() RETURNS integer
    AS $$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;
    tmp_tdtp__sequence tdtp.tdtp__sequence%TYPE;

    BEGIN

         -- get a tdtp__sequence
         select nextval('tdtp_tdtp__sequence_seq')
         into tmp_tdtp__sequence;

         -- add the new row
         insert into tdtp( tdtp_code, tdtp__sequence )
                   values( tmp_tdtp__sequence::text, tmp_tdtp__sequence);

    return tmp_tdtp__sequence;
    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.tdtp_insert_row() OWNER TO source;

--
-- Name: tr_before_feeb(); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION tr_before_feeb() RETURNS "trigger"
    AS $$DECLARE

    BEGIN
    -- add SCH amounts from mbst

    if ( coalesce(new.feeb_amount, 0.0) = 0.0) then
        select  coalesce(mbst_sch100,0.0)
        into    new.feeb_amount
        from    mbst
        where   mbst_item = new.feeb_serv_code;
    end if;

    return new;

    END;$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.tr_before_feeb() OWNER TO source;

--
-- Name: wkst_cat_comments(text, integer); Type: FUNCTION; Schema: public; Owner: source
--

CREATE FUNCTION wkst_cat_comments(text, integer) RETURNS text
    AS $_$DECLARE
    -- NAME TABLE.ATTRIBUTE%TYPE;
    -- NAME TABLE%ROWTYPE;

    arg_patn__sequence ALIAS for $1;
    arg_xx__seq ALIAS for $2;
    wkst_row bal_wkst%ROWTYPE;
    tmp_desc text;

    BEGIN

        tmp_desc := '';

        -- find candidates
        --

        FOR wkst_row IN

          select    *
          from      bal_wkst
          where     x_master = arg_patn__sequence
          and       xx__seq > arg_xx__seq
          order by  xx__seq

        LOOP
          -- RAISE NOTICE 'loop:: %', wkst_row.x_service;
          if (wkst_row.x_service != '9999' ) then
            return tmp_desc;
          end if;
          tmp_desc := tmp_desc || ' ' || trim(both from wkst_row.x_details);

        END LOOP;

      

    return tmp_desc;
    END;$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.wkst_cat_comments(text, integer) OWNER TO source;

SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: accl; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE accl (
    accl_code text,
    accl_desc text,
    accl__sequence integer DEFAULT nextval('"accl_accl__sequence_seq"'::text) NOT NULL,
    accl__timestamp timestamp without time zone DEFAULT now(),
    accl__user_entry text DEFAULT "current_user"(),
    accl__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.accl OWNER TO source;

--
-- Name: accl_accl__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE accl_accl__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.accl_accl__sequence_seq OWNER TO source;

--
-- Name: accl_accl__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('accl_accl__sequence_seq', 1, true);


--
-- Name: addr; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE addr (
    addr_name text DEFAULT 'New Record'::text,
    addr_contact text,
    addr_organisation text,
    addr_work_phone text,
    addr_work_fax text,
    addr_mobile_phone text,
    addr_work_email text,
    addr_work_www text,
    addr_work_im text,
    addr_work_street text,
    addr_work_suburb text,
    addr_work_postcode text,
    addr_home_email text,
    addr_home_www text,
    addr_home_im text,
    addr_home_street text,
    addr_home_suburb text,
    addr_home_postcode text,
    addr_home_phone text,
    addr_home_fax text,
    addr_comments text,
    addr__sequence serial NOT NULL,
    addr__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    addr__user_entry text DEFAULT "current_user"() NOT NULL,
    addr__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.addr OWNER TO source;

--
-- Name: addr_addr__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('addr', 'addr__sequence'), 1, false);


--
-- Name: dbtr; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE dbtr (
    dbtr_code text NOT NULL,
    dbtr_name text,
    dbtr_address text,
    dbtr_suburb text,
    dbtr_postcode text,
    dbtr_state text,
    dbtr_phone text,
    dbtr_group text,
    dbtr_last_statement timestamp without time zone,
    dbtr_delay_statement interval DEFAULT '1 mon'::interval,
    dbtr__sequence integer DEFAULT nextval('"dbtr_dbtr__sequence_seq"'::text) NOT NULL,
    dbtr__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    dbtr__user_entry text DEFAULT "current_user"() NOT NULL,
    dbtr__status character(1) DEFAULT 'N'::text NOT NULL,
    dbtr_amount_outstanding numeric(12,2),
    dbtr_first_statement interval DEFAULT '40 days'::interval
);


ALTER TABLE public.dbtr OWNER TO source;

--
-- Name: invc; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE invc (
    invc_dbtr_code text DEFAULT '-'::text NOT NULL,
    invc_bank_code text DEFAULT '-'::text NOT NULL,
    invc_prov_code text DEFAULT '-'::text NOT NULL,
    invc_patn__sequence integer DEFAULT 0 NOT NULL,
    invc_empl_code text DEFAULT '-'::text NOT NULL,
    invc_feet_code text DEFAULT '-'::text NOT NULL,
    invc_rfdr_code text DEFAULT '-'::text NOT NULL,
    invc_rfdr_date timestamp without time zone,
    invc_rfdr_period text,
    invc_date_created timestamp without time zone DEFAULT now(),
    invc_date_printed timestamp without time zone,
    invc_date_reprint timestamp without time zone,
    invc_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    invc_paid_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    invc_gst_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    invc_paid_gst_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    invc__sequence integer DEFAULT nextval('"invc_invc__sequence_seq"'::text) NOT NULL,
    invc__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    invc__user_entry text DEFAULT "current_user"() NOT NULL,
    invc__status character(1) DEFAULT 'N'::text NOT NULL,
    invc_healthcard text,
    invc_claim_number text,
    invc_accident_date timestamp without time zone,
    invc_reference_1 text,
    invc_reference_2 text,
    invc_reference_3 text,
    invc_hlfd_code text,
    invc_ins_level text,
    invc_healthnumb text,
    invc_medicare text
);


ALTER TABLE public.invc OWNER TO source;

--
-- Name: agdi; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW agdi AS
    SELECT invc.invc_dbtr_code AS agdi_dbtr_code, dbtr.dbtr_name AS agdi_dbtr_name, invc_patient_name(invc.invc__sequence) AS agdi_patient, invc.invc_feet_code AS agdi_feet_code, invc.invc__sequence AS agdi_invc__sequence, (((invc.invc_amount + invc.invc_gst_amount) - invc.invc_paid_amount) - invc.invc_paid_gst_amount) AS agdi_amount, invc_age_period(invc.invc__sequence, 0) AS agdi_period, CASE WHEN (invc.invc_date_printed IS NULL) THEN NULL::date ELSE date(invc.invc_date_printed) END AS agdi_date_printed, CASE WHEN (invc.invc_date_reprint IS NULL) THEN NULL::date ELSE date(invc.invc_date_reprint) END AS agdi_date_reprint, invc.invc__sequence AS agdi__sequence, invc.invc__timestamp AS agdi__timestamp, invc.invc__user_entry AS agdi__user_entry, invc.invc__status AS agdi__status FROM invc, dbtr WHERE ((((((invc.invc_amount + invc.invc_gst_amount) - invc.invc_paid_amount) - invc.invc_paid_gst_amount) <> (0.00)::numeric(12,2)) AND (dbtr.dbtr_code = invc.invc_dbtr_code)) AND (invc.invc_date_printed IS NOT NULL));


ALTER TABLE public.agdi OWNER TO source;

--
-- Name: agdd; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW agdd AS
    SELECT agdi.agdi_dbtr_code AS agdd_dbtr_code, agdi.agdi_dbtr_name AS agdd_dbtr_name, sum(agdi.agdi_amount) AS agdd_amount, count(*) AS agdd_count, max(agdi.agdi__sequence) AS agdd__sequence, now() AS agdd__timestamp, "current_user"() AS agdd__user_entry, 'N'::text AS agdd__status FROM agdi GROUP BY agdi.agdi_dbtr_code, agdi.agdi_dbtr_name;


ALTER TABLE public.agdd OWNER TO source;

--
-- Name: agdp; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW agdp AS
    SELECT agdi.agdi_period AS agdp_period, sum(agdi.agdi_amount) AS agdp_amount, count(*) AS agdp_count, max(agdi.agdi__sequence) AS agdp__sequence, now() AS agdp__timestamp, "current_user"() AS agdp__user_entry, 'N'::text AS agdp__status FROM agdi GROUP BY agdi.agdi_period;


ALTER TABLE public.agdp OWNER TO source;

--
-- Name: agdt; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW agdt AS
    SELECT agdi.agdi_feet_code AS agdt_feet_code, sum(agdi.agdi_amount) AS agdt_amount, count(*) AS agdt_count, max(agdi.agdi__sequence) AS agdt__sequence, now() AS agdt__timestamp, "current_user"() AS agdt__user_entry, 'N'::text AS agdt__status FROM agdi GROUP BY agdi.agdi_feet_code;


ALTER TABLE public.agdt OWNER TO source;

--
-- Name: apst; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE apst (
    apst_code text NOT NULL,
    apst_desc text,
    apst_colour text,
    apst__sequence integer DEFAULT nextval('"apst_apst__sequence_seq"'::text) NOT NULL,
    apst__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    apst__user_entry text DEFAULT "current_user"() NOT NULL,
    apst__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.apst OWNER TO source;

--
-- Name: apst_apst__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE apst_apst__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.apst_apst__sequence_seq OWNER TO source;

--
-- Name: apst_apst__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('apst_apst__sequence_seq', 5, true);


--
-- Name: aptd; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE aptd (
    aptd_aptp_code text NOT NULL,
    aptd_desc text DEFAULT 'New Appointment Detail'::text,
    aptd_colour text DEFAULT '#00ffffff'::text,
    aptd_prov_code text DEFAULT '-'::text,
    aptd_locn_code text DEFAULT '-'::text,
    aptd_dayofweek integer,
    aptd_weekofyear text,
    aptd_dayofmonth integer,
    aptd_monthofyear integer,
    aptd_year integer,
    aptd_parallel integer DEFAULT 0,
    aptd_skip integer DEFAULT 0,
    aptd_start_date date,
    aptd_end_date date,
    aptd_recurrence text,
    aptd_starting time without time zone,
    aptd_ending time without time zone,
    aptd__sequence serial NOT NULL,
    aptd__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    aptd__user_entry text DEFAULT "current_user"() NOT NULL,
    aptd__status character(1) DEFAULT 'N'::text NOT NULL,
    CONSTRAINT aptd_aptd_dayofmonth_check CHECK ((((aptd_dayofmonth >= 0) AND (aptd_dayofmonth <= 31)) OR (aptd_dayofmonth IS NULL))),
    CONSTRAINT aptd_aptd_dayofweek_check CHECK ((((aptd_dayofweek >= 0) AND (aptd_dayofweek <= 7)) OR (aptd_dayofweek IS NULL))),
    CONSTRAINT aptd_aptd_monthofyear_check CHECK ((((aptd_monthofyear >= 0) AND (aptd_monthofyear <= 12)) OR (aptd_monthofyear IS NULL))),
    CONSTRAINT aptd_aptd_parallel_check CHECK (((aptd_parallel >= 0) AND (aptd_parallel <= 5))),
    CONSTRAINT aptd_aptd_skip_check CHECK (((aptd_skip >= 0) AND (aptd_skip <= 20))),
    CONSTRAINT aptd_aptd_year_check CHECK ((((aptd_year >= 2002) AND (aptd_year <= 2020)) OR (aptd_year IS NULL)))
);


ALTER TABLE public.aptd OWNER TO source;

--
-- Name: aptd_aptd__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('aptd', 'aptd__sequence'), 1, false);


--
-- Name: aptp; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE aptp (
    aptp_code text NOT NULL,
    aptp_desc text DEFAULT 'New Appointment Type'::text,
    aptp_colour text DEFAULT '#00d3d3d3'::text,
    aptp_duration integer DEFAULT 15,
    aptp_disable integer DEFAULT 0,
    aptp__sequence serial NOT NULL,
    aptp__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    aptp__user_entry text DEFAULT "current_user"() NOT NULL,
    aptp__status character(1) DEFAULT 'N'::text NOT NULL,
    CONSTRAINT aptp_aptp_duration CHECK (((aptp_duration >= 10) AND (aptp_duration <= 60)))
);


ALTER TABLE public.aptp OWNER TO source;

--
-- Name: aptp_aptp__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('aptp', 'aptp__sequence'), 10, true);


--
-- Name: bad_triggers; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW bad_triggers AS
    SELECT pg_trigger.tgname, pg_trigger.tgconstrname, (((('drop trigger "'::text || (pg_trigger.tgname)::text) || '" on '::text) || CASE WHEN (pg_trigger.tgtype = 21) THEN substr((pg_trigger.tgconstrname)::text, 1, 4) ELSE substr((pg_trigger.tgconstrname)::text, (length((pg_trigger.tgconstrname)::text) - 3), 4) END) || ';'::text) AS "drop" FROM pg_trigger WHERE ((((pg_trigger.tgname ~ '^RI_'::text) AND (pg_trigger.tgisconstraint IS TRUE)) AND (((pg_trigger.tgtype = 9) OR (pg_trigger.tgtype = 17)) OR (pg_trigger.tgtype = 21))) AND (pg_trigger.tgconstrrelid = (0)::oid));


ALTER TABLE public.bad_triggers OWNER TO source;

--
-- Name: bank; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE bank (
    bank_code text NOT NULL,
    bank_name text,
    bank_address text,
    bank_suburb text,
    bank_state text,
    bank_postcode text,
    bank_phone text,
    bank_bank text,
    bank_branch text,
    bank_account text,
    bank__sequence integer DEFAULT nextval('"bank_bank__sequence_seq"'::text) NOT NULL,
    bank__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    bank__user_entry text DEFAULT "current_user"() NOT NULL,
    bank__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.bank OWNER TO source;

--
-- Name: bank_bank__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE bank_bank__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.bank_bank__sequence_seq OWNER TO source;

--
-- Name: bank_bank__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('bank_bank__sequence_seq', 20, true);


--
-- Name: bkdp; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE bkdp (
    bkdp_date_created timestamp without time zone DEFAULT now(),
    bkdp_date_printed timestamp without time zone,
    bkdp_user_printed text DEFAULT "current_user"(),
    bkdp_bank_code text DEFAULT '-'::text NOT NULL,
    bkdp_desc text DEFAULT 'New Batch'::text,
    bkdp_amount numeric(12,2) DEFAULT 0.00,
    bkdp__sequence integer DEFAULT nextval('"bkdp_bkdp__sequence_seq"'::text) NOT NULL,
    bkdp__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    bkdp__user_entry text DEFAULT "current_user"() NOT NULL,
    bkdp__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.bkdp OWNER TO source;

--
-- Name: bkdp_bkdp__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE bkdp_bkdp__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.bkdp_bkdp__sequence_seq OWNER TO source;

--
-- Name: bkdp_bkdp__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('bkdp_bkdp__sequence_seq', 99, true);


--
-- Name: cred; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE cred (
    cred_paym__sequence integer NOT NULL,
    cred_invc__sequence integer NOT NULL,
    cred_amount numeric(12,2) DEFAULT 0.00,
    cred_gst_amount numeric(12,2) DEFAULT 0.00,
    cred__sequence integer DEFAULT nextval('"cred_cred__sequence_seq"'::text) NOT NULL,
    cred__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    cred__user_entry text DEFAULT "current_user"() NOT NULL,
    cred__status character(1) DEFAULT 'N'::text NOT NULL,
    cred_notes text
);


ALTER TABLE public.cred OWNER TO source;

--
-- Name: patn; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE patn (
    patn_flno text,
    patn_psnam text,
    patn_fsnam text,
    patn_title text,
    patn_dob timestamp without time zone,
    patn_address text,
    patn_suburb text,
    patn_state text DEFAULT 'VICTORIA'::text,
    patn_postcode text,
    patn_phone text,
    patn_hlfd_code text DEFAULT '-'::text NOT NULL,
    patn_ins_level character(1),
    patn_healthnumb text,
    patn_feet_code text DEFAULT '-'::text NOT NULL,
    patn_medicare text,
    patn_healthcard text,
    patn_dbtr_code text DEFAULT '-'::text NOT NULL,
    patn_empl_code text DEFAULT '-'::text NOT NULL,
    patn_rfdr_code text DEFAULT '-'::text NOT NULL,
    patn_ref_date timestamp without time zone,
    patn_ref_period integer,
    patn_prov_code text DEFAULT '-'::text NOT NULL,
    patn_country text,
    patn_aboriginality character(1),
    patn_sex character(1),
    patn_marital character(1),
    patn_accl_code text,
    patn_accommodation character(1),
    patn_care character(1),
    patn_patf_code text DEFAULT '-'::text NOT NULL,
    patn__sequence integer DEFAULT nextval('"patn_patn__sequence_seq"'::text) NOT NULL,
    patn__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    patn__user_entry text DEFAULT "current_user"() NOT NULL,
    patn__status character(1) DEFAULT 'N'::text NOT NULL,
    patn_last_visit timestamp without time zone,
    patn_last_service timestamp without time zone,
    patn_amount_outstanding numeric(12,2),
    patn_claim_number text,
    patn_accident_date timestamp without time zone
);


ALTER TABLE public.patn OWNER TO source;

--
-- Name: paym; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE paym (
    paym_date_entry timestamp without time zone DEFAULT now() NOT NULL,
    paym_user_entry text DEFAULT "current_user"() NOT NULL,
    paym_site_entry text,
    paym_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    paym_tdtp_code text DEFAULT '-'::text NOT NULL,
    paym_drawer text,
    paym_bank text,
    paym_branch text,
    paym_bkdp__sequence integer DEFAULT 0 NOT NULL,
    paym__sequence integer DEFAULT nextval('"paym_paym__sequence_seq"'::text) NOT NULL,
    paym__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    paym__user_entry text DEFAULT "current_user"() NOT NULL,
    paym__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.paym OWNER TO source;

--
-- Name: tdtp; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE tdtp (
    tdtp_code text NOT NULL,
    tdtp_list text DEFAULT 'Cheques'::text NOT NULL,
    tdtp_subtotal text DEFAULT 'Cheques and Cash'::text NOT NULL,
    tdtp_desc text,
    tdtp_entity text,
    tdtp_location text,
    tdtp__sequence integer DEFAULT nextval('"tdtp_tdtp__sequence_seq"'::text) NOT NULL,
    tdtp__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    tdtp__user_entry text DEFAULT "current_user"() NOT NULL,
    tdtp__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.tdtp OWNER TO source;

--
-- Name: bkdv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW bkdv AS
    SELECT paym.paym_bkdp__sequence AS bkdv_bkdp__sequence, to_char(paym.paym_date_entry, 'DD-MM-YYYY HH24:MI'::text) AS bkdv_date_entry, paym.paym_user_entry AS bkdv_user_entry, paym.paym_site_entry AS bkdv_site_entry, paym.paym_amount AS bkdv_paym_amount, paym.paym_tdtp_code AS bkdv_tdtp_code, tdtp.tdtp_list AS bkdv_tdtp_list, tdtp.tdtp_subtotal AS bkdv_tdtp_subtotal, tdtp.tdtp_desc AS bkdv_tdtp_desc, tdtp.tdtp_entity AS bkdv_tdtp_entity, tdtp.tdtp_location AS bkdv_tdtp_location, paym.paym_drawer AS bkdv_drawer, paym.paym_bank AS bkdv_bank, paym.paym_branch AS bkdv_branch, paym.paym__sequence AS bkdv_paym__sequence, cred.cred_invc__sequence AS bkdv_invc__sequence, cred.cred_amount AS bkdv_cred_amount, cred.cred_gst_amount AS bkdv_cred_gst_amount, invc.invc_patn__sequence AS bkdv_patn__sequence, patn.patn_psnam AS bkdv_patn_psnam, patn.patn_fsnam AS bkdv_patn_fsnam, invc.invc_dbtr_code AS bkdv_dbtr_code, dbtr.dbtr_name AS bkdv_dbtr_name, bank.bank_code AS bkdv_bank_code, bank.bank_name AS bkdv_bank_name, bank.bank_address AS bkdv_bank_address, bank.bank_suburb AS bkdv_bank_suburb, bank.bank_state AS bkdv_bank_state, bank.bank_postcode AS bkdv_bank_postcode, bank.bank_phone AS bkdv_bank_phone, bank.bank_bank AS bkdv_bank_bank, bank.bank_branch AS bkdv_bank_branch, bank.bank_account AS bkdv_bank_account, cred.cred__sequence AS bkdv__sequence, cred.cred__timestamp AS bkdv__timestamp, cred.cred__user_entry AS bkdv__user_entry, cred.cred__status AS bkdv__status FROM paym, tdtp, bank, cred, invc, dbtr, patn WHERE ((((((tdtp.tdtp_code = paym.paym_tdtp_code) AND (cred.cred_paym__sequence = paym.paym__sequence)) AND (invc.invc__sequence = cred.cred_invc__sequence)) AND (patn.patn__sequence = invc.invc_patn__sequence)) AND (dbtr.dbtr_code = invc.invc_dbtr_code)) AND (bank.bank_code = invc.invc_bank_code));


ALTER TABLE public.bkdv OWNER TO source;

--
-- Name: cash; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE cash (
    cash_paym__sequence integer DEFAULT 0 NOT NULL,
    cash_bank_code text DEFAULT '-'::text NOT NULL,
    cash_date timestamp without time zone,
    cash_amount numeric(12,2) DEFAULT 0.00,
    cash_text text,
    cash__sequence integer DEFAULT nextval('"cash_cash__sequence_seq"'::text) NOT NULL,
    cash__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    cash__user_entry text DEFAULT "current_user"() NOT NULL,
    cash__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.cash OWNER TO source;

--
-- Name: cash_cash__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE cash_cash__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cash_cash__sequence_seq OWNER TO source;

--
-- Name: cash_cash__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('cash_cash__sequence_seq', 1, true);


--
-- Name: clsp; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE clsp (
    clsp_code text,
    clsp_desc text,
    clsp__sequence integer DEFAULT nextval('"clsp_clsp__sequence_seq"'::text) NOT NULL,
    clsp__timestamp timestamp without time zone DEFAULT now(),
    clsp__user_entry text DEFAULT "current_user"(),
    clsp__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.clsp OWNER TO source;

--
-- Name: clsp_clsp__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE clsp_clsp__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.clsp_clsp__sequence_seq OWNER TO source;

--
-- Name: clsp_clsp__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('clsp_clsp__sequence_seq', 10, true);


--
-- Name: clst; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE clst (
    clst_serv_code_parent text,
    clst_serv_code_child text,
    clst_feet_code text,
    clst__sequence integer DEFAULT nextval('"clst_clst__sequence_seq"'::text) NOT NULL,
    clst__timestamp timestamp without time zone DEFAULT now(),
    clst__user_entry text DEFAULT "current_user"(),
    clst__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.clst OWNER TO source;

--
-- Name: clst_clst__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE clst_clst__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.clst_clst__sequence_seq OWNER TO source;

--
-- Name: clst_clst__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('clst_clst__sequence_seq', 1, true);


--
-- Name: cnrt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE cnrt (
    cnrt_patn__sequence integer DEFAULT 0 NOT NULL,
    cnrt_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    ctrt_period interval DEFAULT '3 mons'::interval NOT NULL,
    cnrt_count integer DEFAULT 3 NOT NULL,
    cnrt_start_date timestamp without time zone DEFAULT now() NOT NULL,
    cnrt_serv_code text DEFAULT '-'::text NOT NULL,
    cnrt_first_installment numeric(12,2) DEFAULT 0.00 NOT NULL,
    cnrt_other_installment numeric(12,2) DEFAULT 0.00 NOT NULL,
    cnrt_last_date timestamp without time zone,
    cnrt_balance numeric(12,2) DEFAULT 0.00 NOT NULL,
    cnrt_end_date timestamp without time zone,
    cnrt__sequence integer DEFAULT nextval('"cnrt_cnrt__sequence_seq"'::text) NOT NULL,
    cnrt__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    cnrt__user_entry text DEFAULT "current_user"() NOT NULL,
    cnrt__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.cnrt OWNER TO source;

--
-- Name: cnrt_cnrt__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE cnrt_cnrt__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cnrt_cnrt__sequence_seq OWNER TO source;

--
-- Name: cnrt_cnrt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('cnrt_cnrt__sequence_seq', 1, true);


--
-- Name: cnrv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW cnrv AS
    SELECT cnrt.cnrt_patn__sequence AS cnrv_patn__sequence, patn_patient_name(cnrt.cnrt_patn__sequence) AS cnrv_patient_name, cnrt.cnrt_amount AS cnrv_amount, cnrt.ctrt_period AS ctrv_period, cnrt.cnrt_count AS cnrv_count, short_date(cnrt.cnrt_start_date) AS cnrv_start_date, cnrt.cnrt_serv_code AS cnrv_serv_code, cnrt.cnrt_first_installment AS cnrv_first_installment, cnrt.cnrt_other_installment AS cnrv_other_installment, short_date(cnrt.cnrt_last_date) AS cnrv_last_date, cnrt.cnrt_balance AS cnrv_balance, short_date(cnrt.cnrt_end_date) AS cnrv_end_date, cnrt.cnrt__sequence AS cnrv__sequence, cnrt.cnrt__timestamp AS cnrv__timestamp, cnrt.cnrt__user_entry AS cnrv__user_entry, cnrt.cnrt__status AS cnrv__status FROM cnrt;


ALTER TABLE public.cnrv OWNER TO source;

--
-- Name: cnty; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE cnty (
    cnty_code text,
    cnty_desc text,
    cnty__sequence integer DEFAULT nextval('"cnty_cnty__sequence_seq"'::text) NOT NULL,
    cnty__timestamp timestamp without time zone DEFAULT now(),
    cnty__user_entry text DEFAULT "current_user"(),
    cnty__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.cnty OWNER TO source;

--
-- Name: cnty_cnty__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE cnty_cnty__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cnty_cnty__sequence_seq OWNER TO source;

--
-- Name: cnty_cnty__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('cnty_cnty__sequence_seq', 10, true);


--
-- Name: conf; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE conf (
    conf_code text DEFAULT '-'::text NOT NULL,
    conf_desc text,
    conf_value text,
    conf_type integer DEFAULT 0 NOT NULL,
    conf_scope integer,
    conf_access integer,
    conf__sequence integer DEFAULT nextval('"conf_conf__sequence_seq"'::text) NOT NULL,
    conf__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    conf__user_entry text DEFAULT "current_user"() NOT NULL,
    conf__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.conf OWNER TO source;

--
-- Name: conf_conf__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE conf_conf__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.conf_conf__sequence_seq OWNER TO source;

--
-- Name: conf_conf__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('conf_conf__sequence_seq', 15, true);


--
-- Name: cred_cred__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE cred_cred__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cred_cred__sequence_seq OWNER TO source;

--
-- Name: cred_cred__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('cred_cred__sequence_seq', 79233, true);


--
-- Name: crep; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW crep AS
    SELECT invc.invc_dbtr_code AS crep_dbtr_code, invc.invc_bank_code AS crep_bank_code, invc.invc_prov_code AS crep_prov_code, invc.invc_patn__sequence AS crep_patn__sequence, invc.invc_empl_code AS crep_empl_code, invc.invc_feet_code AS crep_feet_code, invc.invc_rfdr_code AS crep_rfdr_code, invc.invc_rfdr_date AS crep_rfdr_date, invc.invc_rfdr_period AS crep_rfdr_period, invc.invc_date_created AS crep_date_created, invc.invc_date_printed AS crep_date_printed, invc.invc_date_reprint AS crep_date_reprint, invc.invc_amount AS crep_amount, invc.invc_paid_amount AS crep_paid_amount, invc.invc_gst_amount AS crep_gst_amount, invc.invc_paid_gst_amount AS crep_paid_gst_amount, cred.cred_paym__sequence AS crep_paym__sequence, cred.cred_invc__sequence AS crep_invc__sequence, cred.cred_amount AS crep_cred_amount, cred.cred_gst_amount AS crep_cred_gst_amount, invc_balance(cred.cred_invc__sequence) AS crep_invc_balance, cred.cred__sequence AS crep__sequence, cred.cred__timestamp AS crep__timestamp, cred.cred__user_entry AS crep__user_entry, cred.cred__status AS crep__status FROM cred, invc WHERE (cred.cred_invc__sequence = invc.invc__sequence);


ALTER TABLE public.crep OWNER TO source;

--
-- Name: crev; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW crev AS
    SELECT paym.paym_date_entry AS crev_date_entry, paym.paym_user_entry AS crev_user_entry, paym.paym_site_entry AS crev_site_entry, paym.paym_amount AS crev_paym_amount, paym.paym_tdtp_code AS crev_tdtp_code, paym.paym_drawer AS crev_drawer, paym.paym_bank AS crev_bank, paym.paym_branch AS crev_branch, paym.paym__sequence AS crev_paym__sequence, cred.cred_invc__sequence AS crev_invc__sequence, cred.cred_amount AS crev_cred_amount, cred.cred_gst_amount AS crev_cred_gst_amount, cred.cred_notes AS crev_cred_notes, invc_balance(cred.cred_invc__sequence) AS crev_invc_balance, cred.cred__sequence AS crev__sequence, cred.cred__timestamp AS crev__timestamp, cred.cred__user_entry AS crev__user_entry, cred.cred__status AS crev__status FROM cred, paym WHERE (cred.cred_paym__sequence = paym.paym__sequence);


ALTER TABLE public.crev OWNER TO source;

--
-- Name: empl; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE empl (
    empl_code text NOT NULL,
    empl_name text,
    empl_address text,
    empl_suburb text,
    empl_postcode text,
    empl_state text,
    empl__sequence integer DEFAULT nextval('"empl_empl__sequence_seq"'::text) NOT NULL,
    empl__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    empl__user_entry text DEFAULT "current_user"() NOT NULL,
    empl__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.empl OWNER TO source;

--
-- Name: feet; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE feet (
    feet_code text NOT NULL,
    feet_desc text,
    feet__sequence integer DEFAULT nextval('"feet_feet__sequence_seq"'::text) NOT NULL,
    feet__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    feet__user_entry text DEFAULT "current_user"() NOT NULL,
    feet__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.feet OWNER TO source;

--
-- Name: prov; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE prov (
    prov_code text NOT NULL,
    prov_provider_num text,
    prov_name text,
    prov_address text,
    prov_suburb text,
    prov_state text,
    prov_postcode text,
    prov_salutation text,
    prov_phone text,
    prov_bank_code text DEFAULT '-'::text NOT NULL,
    prov__sequence integer DEFAULT nextval('"prov_prov__sequence_seq"'::text) NOT NULL,
    prov__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    prov__user_entry text DEFAULT "current_user"() NOT NULL,
    prov__status character(1) DEFAULT 'N'::text NOT NULL,
    prov_colour text
);


ALTER TABLE public.prov OWNER TO source;

--
-- Name: rfdr; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE rfdr (
    rfdr_code text NOT NULL,
    rfdr_name text,
    rfdr_street text,
    rfdr_suburb text,
    rfdr_postcode text,
    rfdr_state text,
    rfdr_provider text,
    rfdr_phone text,
    rfdr_salutation text,
    rfdr_index text,
    rfdr__sequence integer DEFAULT nextval('"rfdr_rfdr__sequence_seq"'::text) NOT NULL,
    rfdr__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    rfdr__user_entry text DEFAULT "current_user"() NOT NULL,
    rfdr__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.rfdr OWNER TO source;

--
-- Name: crlt; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW crlt AS
    SELECT date(cred.cred__timestamp) AS crlt_date_credit, cred.cred_paym__sequence AS crlt_paym__sequence, cred.cred_amount AS crlt_cred_amount, cred.cred_gst_amount AS crlt_cred_gst_amount, (cred.cred_amount + cred.cred_gst_amount) AS crlt_total_amount, cred.cred_notes AS crlt_notes, date(paym.paym_date_entry) AS crlt_date_payment, paym.paym_date_entry AS crlt_ts_payment, paym.paym_user_entry AS crlt_user_entry, paym.paym_site_entry AS crlt_site_entry, paym.paym_amount AS crlt_paym_amount, paym.paym_tdtp_code AS crlt_tdtp_code, paym.paym_drawer AS crlt_drawer, paym.paym_bank AS crlt_bank, paym.paym_branch AS crlt_branch, paym.paym_bkdp__sequence AS crlt_bkdp__sequence, invc.invc__sequence AS crlt_invc__sequence, invc.invc_date_printed AS crlt_invc_date_printed, invc.invc_date_reprint AS crlt_invc_date_reprint, invc.invc_amount AS crlt_invc_amount, invc.invc_gst_amount AS crlt_invc_gst_amount, (invc.invc_paid_amount + invc.invc_paid_gst_amount) AS crlt_invc_credits, cred_summary(invc.invc__sequence, 3) AS crlt_cred_summary, (((invc.invc_amount + invc.invc_gst_amount) - invc.invc_paid_amount) - invc.invc_paid_gst_amount) AS crlt_invc_balance, CASE WHEN (invc.invc_date_printed IS NULL) THEN (now())::date ELSE date(invc.invc_date_printed) END AS crlt_date_printed, CASE WHEN (invc.invc_date_printed IS NULL) THEN NULL::date ELSE (now())::date END AS crlt_date_reprint, CASE WHEN (invc.invc_rfdr_date IS NULL) THEN NULL::date ELSE date(invc.invc_rfdr_date) END AS crlt_rfdr_date, CASE WHEN (invc.invc_rfdr_period = '99'::text) THEN 'Indefinite'::text WHEN ((invc.invc_rfdr_period IS NULL) OR (invc.invc_rfdr_period = '0'::text)) THEN ''::text ELSE (invc.invc_rfdr_period || ' Months'::text) END AS crlt_rfdr_period, ((COALESCE(patn.patn_fsnam, ''::text) || ' '::text) || COALESCE(patn.patn_psnam, ''::text)) AS crlt_patn_name, patn.patn_address AS crlt_patn_address, ((COALESCE(patn.patn_suburb, ''::text) || ' '::text) || COALESCE(patn.patn_postcode, ''::text)) AS crlt_patn_suburb, patn.patn_state AS crlt_patn_state, patn.patn_postcode AS crlt_patn_postcode, short_date(patn.patn_dob) AS crlt_patn_dob, patn.patn_hlfd_code AS crlt_patn_hlfd_code, patn.patn_ins_level AS crlt_patn_ins_level, patn.patn_healthnumb AS crlt_patn_healthnumb, patn.patn_medicare AS crlt_patn_medicare, patn.patn_healthcard AS crlt_patn_healthcard, patn.patn_patf_code AS crlt_patn_patf_code, dbtr_address(dbtr.dbtr_code) AS crlt_dbtr_full_address, dbtr.dbtr_name AS crlt_dbtr_name, dbtr.dbtr_address AS crlt_dbtr_address, ((COALESCE(dbtr.dbtr_suburb, ''::text) || ' '::text) || COALESCE(dbtr.dbtr_postcode, ''::text)) AS crlt_dbtr_suburb, dbtr.dbtr_state AS crlt_dbtr_state, rfdr.rfdr_code AS crlt_rfdr_code, rfdr.rfdr_name AS crlt_rfdr_name, rfdr.rfdr_street AS crlt_rfdr_street, rfdr.rfdr_suburb AS crlt_rfdr_suburb, rfdr.rfdr_postcode AS crlt_rfdr_postcode, rfdr.rfdr_state AS crlt_rfdr_state, rfdr.rfdr_provider AS crlt_rfdr_provider, rfdr.rfdr_phone AS crlt_rfdr_phone, rfdr.rfdr_salutation AS crlt_rfdr_salutation, rfdr.rfdr_index AS crlt_rfdr_index, empl.empl_code AS crlt_empl_code, empl.empl_name AS crlt_empl_name, empl.empl_address AS crlt_empl_address, empl.empl_suburb AS crlt_empl_suburb, empl.empl_postcode AS crlt_empl_postcode, empl.empl_state AS crlt_empl_state, feet.feet_code AS crlt_feet_code, feet.feet_desc AS crlt_feet_desc, prov.prov_code AS crlt_prov_code, prov.prov_provider_num AS crlt_prov_provider_num, prov.prov_name AS crlt_prov_name, prov.prov_address AS crlt_prov_address, prov.prov_suburb AS crlt_prov_suburb, prov.prov_state AS crlt_prov_state, prov.prov_postcode AS crlt_prov_postcode, prov.prov_salutation AS crlt_prov_salutation, prov.prov_phone AS crlt_prov_phone, prov.prov_bank_code AS crlt_prov_bank_code, cred.cred__sequence AS crlt__sequence, cred.cred__timestamp AS crlt__timestamp, cred.cred__user_entry AS crlt__user_entry, cred.cred__status AS crlt__status FROM cred, paym, invc, patn, dbtr, rfdr, empl, feet, prov WHERE ((((((((cred.cred_invc__sequence = invc.invc__sequence) AND (cred.cred_paym__sequence = paym.paym__sequence)) AND (invc.invc_dbtr_code = dbtr.dbtr_code)) AND (invc.invc_patn__sequence = patn.patn__sequence)) AND (invc.invc_rfdr_code = rfdr.rfdr_code)) AND (invc.invc_feet_code = feet.feet_code)) AND (invc.invc_prov_code = prov.prov_code)) AND (invc.invc_empl_code = empl.empl_code));


ALTER TABLE public.crlt OWNER TO source;

--
-- Name: crsm; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE crsm (
    crsm_date_start timestamp without time zone DEFAULT now() NOT NULL,
    crsm_date_end timestamp without time zone DEFAULT now() NOT NULL,
    crsm_type text DEFAULT '-'::text NOT NULL,
    crsm_prov_code text DEFAULT '-'::text NOT NULL,
    crsm_prov_name text,
    crsm_count integer DEFAULT 0 NOT NULL,
    crsm_tdtp_code text DEFAULT '-'::text NOT NULL,
    crsm_desc text,
    crsm_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    crsm_gst_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    crsm__sequence serial NOT NULL,
    crsm__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    crsm__user_entry text DEFAULT "current_user"() NOT NULL,
    crsm__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.crsm OWNER TO source;

--
-- Name: crsm_crsm__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('crsm', 'crsm__sequence'), 1, false);


--
-- Name: dbag; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW dbag AS
    SELECT date((now() - ((to_char(conf_integer('dbst_statement_age'::text), '9999'::text) || ' days'::text))::interval)) AS dbag_date, dbtr.dbtr_code AS dbag_dbtr_code, dbtr.dbtr_name AS dbag_name, dbtr.dbtr_address AS dbag_address, dbtr.dbtr_suburb AS dbag_suburb, dbtr.dbtr_postcode AS dbag_postcode, dbtr.dbtr_state AS dbag_state, dbtr.dbtr_phone AS dbag_phone, dbtr_patient_key(dbtr.dbtr_code) AS dbag_patient_key, short_date(dbtr.dbtr_last_statement) AS dbag_last_statement, dbtr.dbtr_delay_statement AS dbag_delay_statement, dbtr_total_balance(dbtr.dbtr_code, conf_integer('dbst_statement_age'::text)) AS dbag_total_balance, dbtr_period_balance(dbtr.dbtr_code, 0, conf_integer('dbst_statement_age'::text)) AS dbag_balance_0, dbtr_period_balance(dbtr.dbtr_code, 30, conf_integer('dbst_statement_age'::text)) AS dbag_balance_30, dbtr_period_balance(dbtr.dbtr_code, 60, conf_integer('dbst_statement_age'::text)) AS dbag_balance_60, dbtr_period_balance(dbtr.dbtr_code, 90, conf_integer('dbst_statement_age'::text)) AS dbag_balance_90, dbtr_period_balance(dbtr.dbtr_code, 120, conf_integer('dbst_statement_age'::text)) AS dbag_balance_120, dbtr.dbtr__sequence AS dbag__sequence, dbtr.dbtr__timestamp AS dbag__timestamp, dbtr.dbtr__user_entry AS dbag__user_entry, dbtr.dbtr__status AS dbag__status FROM dbtr WHERE (dbtr_total_balance(dbtr.dbtr_code, conf_integer('dbst_statement_age'::text)) <> (0)::numeric);


ALTER TABLE public.dbag OWNER TO source;

--
-- Name: dbst; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW dbst AS
    SELECT invc.invc_dbtr_code AS dbst_dbtr_code, dbtr_address(invc.invc_dbtr_code) AS dbst_full_address, dbtr.dbtr_name AS dbst_name, dbtr.dbtr_address AS dbst_address, dbtr.dbtr_suburb AS dbst_suburb, dbtr.dbtr_postcode AS dbst_postcode, ((dbtr.dbtr_state || ' '::text) || dbtr.dbtr_postcode) AS dbst_state, dbtr.dbtr_phone AS dbst_phone, invc_patient_name(invc.invc__sequence) AS dbst_patient, dbtr_patient_key(dbtr.dbtr_code) AS dbst_patient_key, dbtr.dbtr_group AS dbst_group, dbtr.dbtr_last_statement AS dbst_last_statement, dbtr.dbtr_first_statement AS dbst_first_statement, dbtr_last_invc_printed(invc.invc_dbtr_code) AS dbst_last_invoice, dbtr.dbtr_delay_statement AS dbst_delay_statement, date((now() - (((conf.conf_statement_age)::text || ' days'::text))::interval)) AS dbst_date, dbtr.dbtr_amount_outstanding AS dbst_amount_outstanding, dbtr_total_balance(invc.invc_dbtr_code) AS dbst_total_balance, dbtr_period_balance(dbtr.dbtr_code, 0, conf.conf_statement_age) AS dbst_balance_0, dbtr_period_balance(dbtr.dbtr_code, 30, conf.conf_statement_age) AS dbst_balance_30, dbtr_period_balance(dbtr.dbtr_code, 60, conf.conf_statement_age) AS dbst_balance_60, dbtr_period_balance(dbtr.dbtr_code, 90, conf.conf_statement_age) AS dbst_balance_90, dbtr_period_balance(dbtr.dbtr_code, 120, conf.conf_statement_age) AS dbst_balance_120, invc.invc_feet_code AS dbst_feet_code, invc.invc__sequence AS dbst_invc__sequence, (invc.invc_amount + invc.invc_gst_amount) AS dbst_amount, ((invc.invc_amount + invc.invc_gst_amount) - invc_balance_then(invc.invc__sequence, conf.conf_statement_age)) AS dbst_paid, invc_balance_then(invc.invc__sequence, conf.conf_statement_age) AS dbst_balance, invc_age_period(invc.invc__sequence, conf.conf_statement_age) AS dbst_period, CASE WHEN (invc.invc_date_printed IS NULL) THEN NULL::date ELSE date(invc.invc_date_printed) END AS dbst_date_printed, CASE WHEN (invc.invc_date_reprint IS NULL) THEN NULL::date ELSE date(invc.invc_date_reprint) END AS dbst_date_reprint, CASE WHEN (invc.invc_feet_code ~ 'TAC|WC'::text) THEN invc.invc_claim_number ELSE CASE WHEN (invc.invc_feet_code ~ 'VA'::text) THEN invc.invc_healthcard ELSE ''::text END END AS dbst_reference, ((COALESCE(patn.patn_fsnam, ''::text) || ' '::text) || COALESCE(patn.patn_psnam, ''::text)) AS dbst_patn_name, patn.patn_address AS dbst_patn_address, ((COALESCE(patn.patn_suburb, ''::text) || ' '::text) || COALESCE(patn.patn_postcode, ''::text)) AS dbst_patn_suburb, patn.patn_state AS dbst_patn_state, patn.patn_postcode AS dbst_patn_postcode, short_date(patn.patn_dob) AS dbst_patn_dob, patn.patn_hlfd_code AS dbst_patn_hlfd_code, patn.patn_ins_level AS dbst_patn_ins_level, patn.patn_healthnumb AS dbst_patn_healthnumb, patn.patn_medicare AS dbst_patn_medicare, patn.patn_healthcard AS dbst_patn_healthcard, patn.patn_patf_code AS dbst_patn_patf_code, patn.patn__sequence AS dbst_patn__sequence, invc.invc__sequence AS dbst__sequence, invc.invc__timestamp AS dbst__timestamp, invc.invc__user_entry AS dbst__user_entry, invc.invc__status AS dbst__status FROM invc, dbtr, patn, (SELECT conf_integer('dbst_statement_age'::text) AS conf_statement_age, (now() - (((conf_integer('dbst_statement_age'::text))::text || ' days'::text))::interval) AS conf_statement_date) conf WHERE ((((((dbtr.dbtr_code = invc.invc_dbtr_code) AND (patn.patn_patf_code <> 'HOLD'::text)) AND (invc.invc_date_printed IS NOT NULL)) AND (invc.invc_date_printed < conf.conf_statement_date)) AND (invc_balance_then(invc.invc__sequence, conf.conf_statement_age) IS NOT NULL)) AND (invc.invc_patn__sequence = patn.patn__sequence));


ALTER TABLE public.dbst OWNER TO source;

--
-- Name: dbtr_dbtr__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE dbtr_dbtr__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.dbtr_dbtr__sequence_seq OWNER TO source;

--
-- Name: dbtr_dbtr__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('dbtr_dbtr__sequence_seq', 112188, true);


--
-- Name: dev_ri; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW dev_ri AS
    SELECT t.oid AS trigoid, t.tgname AS trigname, c.relname AS trig_tbl, t.tgtype AS trig_type, t.tgfoid, f.proname AS trigfunc, t.tgenabled, t.tgconstrname, c2.relname AS const_tbl, t.tgdeferrable, t.tginitdeferred FROM pg_trigger t, pg_class c, pg_class c2, pg_proc f WHERE ((((t.tgrelid = c.oid) AND (t.tgconstrrelid = c2.oid)) AND (t.tgfoid = f.oid)) AND (t.tgname ~ '^RI_'::text)) ORDER BY t.oid;


ALTER TABLE public.dev_ri OWNER TO source;

--
-- Name: diag; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE diag (
    diag_epsdserl integer,
    diag_type text,
    diag_icd9 text,
    diag_date_start timestamp without time zone,
    diag_date_end timestamp without time zone,
    diag_desc text,
    diag__sequence integer DEFAULT nextval('"diag_diag__sequence_seq"'::text) NOT NULL,
    diag__timestamp timestamp without time zone DEFAULT now(),
    diag__user_entry text DEFAULT "current_user"(),
    diag__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.diag OWNER TO source;

--
-- Name: diag_diag__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE diag_diag__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.diag_diag__sequence_seq OWNER TO source;

--
-- Name: diag_diag__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('diag_diag__sequence_seq', 1, true);


--
-- Name: docs; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE docs (
    docs_patn__sequence integer,
    docs_url text,
    docs_title text DEFAULT 'UNNAMED'::text NOT NULL,
    docs__sequence integer DEFAULT nextval('"docs_docs__sequence_seq"'::text) NOT NULL,
    docs__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    docs__user_entry text DEFAULT "current_user"() NOT NULL,
    docs__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.docs OWNER TO source;

--
-- Name: docs_docs__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE docs_docs__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.docs_docs__sequence_seq OWNER TO source;

--
-- Name: docs_docs__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('docs_docs__sequence_seq', 11, true);


--
-- Name: drop_trigger; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW drop_trigger AS
    SELECT pg_trigger.tgconstrname, (((('drop trigger "'::text || (pg_trigger.tgname)::text) || '" on '::text) || (ctrig.relname)::text) || ';'::text) AS "drop" FROM pg_trigger, pg_class ctrig, pg_class ccons WHERE (((((pg_trigger.tgname ~ '^RI_'::text) AND (pg_trigger.tgisconstraint IS TRUE)) AND (((pg_trigger.tgtype = 9) OR (pg_trigger.tgtype = 17)) OR (pg_trigger.tgtype = 21))) AND (pg_trigger.tgrelid = ctrig.oid)) AND (pg_trigger.tgconstrrelid = ccons.oid));


ALTER TABLE public.drop_trigger OWNER TO source;

--
-- Name: eftr; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE eftr (
    eftr_date_created timestamp without time zone DEFAULT now(),
    eftr_first__sequence integer,
    eftr_last__sequence integer,
    eftr__sequence integer DEFAULT nextval('"eftr_eftr__sequence_seq"'::text) NOT NULL,
    eftr__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    eftr__user_entry text DEFAULT "current_user"() NOT NULL,
    eftr__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.eftr OWNER TO source;

--
-- Name: eftr_eftr__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE eftr_eftr__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.eftr_eftr__sequence_seq OWNER TO source;

--
-- Name: eftr_eftr__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('eftr_eftr__sequence_seq', 2, true);


--
-- Name: eftv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW eftv AS
    SELECT eftr.eftr__sequence AS eftv_eftr__sequence, paym.paym_bkdp__sequence AS eftv_bkdp__sequence, to_char(paym.paym_date_entry, 'DD-MM-YYYY HH24:MI'::text) AS eftv_date_entry, paym.paym_user_entry AS eftv_user_entry, paym.paym_site_entry AS eftv_site_entry, paym.paym_amount AS eftv_paym_amount, paym.paym_tdtp_code AS eftv_tdtp_code, tdtp.tdtp_list AS eftv_tdtp_list, tdtp.tdtp_subtotal AS eftv_tdtp_subtotal, tdtp.tdtp_desc AS eftv_tdtp_desc, tdtp.tdtp_entity AS eftv_tdtp_entity, tdtp.tdtp_location AS eftv_tdtp_location, paym.paym_drawer AS eftv_drawer, paym.paym_bank AS eftv_bank, paym.paym_branch AS eftv_branch, paym.paym__sequence AS eftv_paym__sequence, cred.cred_invc__sequence AS eftv_invc__sequence, cred.cred_amount AS eftv_cred_amount, cred.cred_gst_amount AS eftv_cred_gst_amount, invc.invc_patn__sequence AS eftv_patn__sequence, patn.patn_psnam AS eftv_patn_psnam, patn.patn_fsnam AS eftv_patn_fsnam, invc.invc_dbtr_code AS eftv_dbtr_code, dbtr.dbtr_name AS eftv_dbtr_name, bank.bank_code AS eftv_bank_code, bank.bank_name AS eftv_bank_name, bank.bank_address AS eftv_bank_address, bank.bank_suburb AS eftv_bank_suburb, bank.bank_state AS eftv_bank_state, bank.bank_postcode AS eftv_bank_postcode, bank.bank_phone AS eftv_bank_phone, bank.bank_bank AS eftv_bank_bank, bank.bank_branch AS eftv_bank_branch, bank.bank_account AS eftv_bank_account, cred.cred__sequence AS eftv__sequence, cred.cred__timestamp AS eftv__timestamp, cred.cred__user_entry AS eftv__user_entry, cred.cred__status AS eftv__status FROM eftr, paym, tdtp, bank, cred, invc, dbtr, patn WHERE (((((((((paym.paym__sequence >= eftr.eftr_first__sequence) AND (paym.paym__sequence <= eftr.eftr_last__sequence)) AND (tdtp.tdtp_list ~* 'directed'::text)) AND (tdtp.tdtp_code = paym.paym_tdtp_code)) AND (cred.cred_paym__sequence = paym.paym__sequence)) AND (invc.invc__sequence = cred.cred_invc__sequence)) AND (patn.patn__sequence = invc.invc_patn__sequence)) AND (dbtr.dbtr_code = invc.invc_dbtr_code)) AND (bank.bank_code = invc.invc_bank_code)) ORDER BY paym.paym__sequence, cred.cred__sequence;


ALTER TABLE public.eftv OWNER TO source;

--
-- Name: empl_empl__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE empl_empl__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.empl_empl__sequence_seq OWNER TO source;

--
-- Name: empl_empl__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('empl_empl__sequence_seq', 10, true);


--
-- Name: epsd; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE epsd (
    epsd_admit_date timestamp without time zone,
    epsd_admit_criteria character(1),
    epsd_admit_type text,
    epsd_admit_source text,
    epsd_neonate_weight smallint,
    epsd_trans_source text,
    epsd_healthfund text,
    epsd_ins_level text,
    epsd_speciality text,
    epsd_lvday_month smallint,
    epsd_lvday_finyr smallint,
    epsd_lvday_total smallint,
    epsd_sepn_date timestamp without time zone,
    epsd_sepn_type text,
    epsd_sepn_transfer text,
    epsd_re_admit text,
    epsd_user_flag_sepn text,
    epsd_study text,
    epsd_user_flag_diag text,
    epsd_patn__sequence integer,
    epsd__sequence integer DEFAULT nextval('"epsd_epsd__sequence_seq"'::text) NOT NULL,
    epsd__timestamp timestamp without time zone DEFAULT now(),
    epsd__user_entry text DEFAULT "current_user"(),
    epsd__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.epsd OWNER TO source;

--
-- Name: epsd_epsd__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE epsd_epsd__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.epsd_epsd__sequence_seq OWNER TO source;

--
-- Name: epsd_epsd__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('epsd_epsd__sequence_seq', 1, true);


--
-- Name: evnt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE evnt (
    evnt_patn__sequence integer DEFAULT 0 NOT NULL,
    evnt_prov_code text DEFAULT '-'::text NOT NULL,
    evnt_rfdr_code text DEFAULT '-'::text NOT NULL,
    evnt_locn_code text DEFAULT 'EM'::text NOT NULL,
    evnt_aptp_code text DEFAULT '-'::text NOT NULL,
    evnt_starttime timestamp without time zone,
    evnt_duration interval DEFAULT '00:15:00'::interval NOT NULL,
    evnt_desc text,
    evnt_apst_code text DEFAULT '-'::text NOT NULL,
    evnt__sequence serial NOT NULL,
    evnt__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    evnt__user_entry text DEFAULT "current_user"() NOT NULL,
    evnt__status character(1) DEFAULT 'N'::text NOT NULL,
    evnt_note_1 text,
    evnt_note_2 text
);


ALTER TABLE public.evnt OWNER TO source;

--
-- Name: evnt_evnt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('evnt', 'evnt__sequence'), 456, true);


--
-- Name: locn; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE locn (
    locn_code text NOT NULL,
    locn_desc text,
    locn_colour text,
    locn__sequence integer DEFAULT nextval('"locn_locn__sequence_seq"'::text) NOT NULL,
    locn__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    locn__user_entry text DEFAULT "current_user"() NOT NULL,
    locn__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.locn OWNER TO source;

--
-- Name: evnv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW evnv AS
    SELECT evnt.evnt_patn__sequence AS evnv_patn__sequence, evnt.evnt_prov_code AS evnv_prov_code, evnt.evnt_rfdr_code AS evnv_rfdr_code, evnt.evnt_locn_code AS evnv_locn_code, evnt.evnt_aptp_code AS evnv_aptp_code, evnt.evnt_apst_code AS evnv_apst_code, evnt.evnt_starttime AS evnv_starttime, evnt.evnt_duration AS evnv_duration, evnt.evnt_desc AS evnv_desc, evnt.evnt_note_1 AS evnv_note_1, evnt.evnt_note_2 AS evnv_note_2, to_char(evnt.evnt_starttime, 'HH:MI am'::text) AS evnv_ev_time, to_char(evnt.evnt_starttime, 'Day DD-MM-YYYY'::text) AS evnv_ev_date, ((date_part('hour'::text, evnt.evnt_duration) * (60)::double precision) + date_part('minute'::text, evnt.evnt_duration)) AS evnv_ev_minutes, patn.patn_flno AS evnv_patn_flno, ((COALESCE(patn.patn_psnam, ''::text) || ', '::text) || COALESCE(patn.patn_fsnam, ''::text)) AS evnv_patn_desc, ((((((((COALESCE(patn.patn_psnam, ''::text) || ', '::text) || COALESCE(patn.patn_fsnam, ''::text)) || '<br>Ph:'::text) || COALESCE(patn.patn_phone, ''::text)) || '<br>Dob:'::text) || COALESCE(short_date(patn.patn_dob), ''::text)) || '<br>'::text) || COALESCE(evnt.evnt_desc, ''::text)) AS evnv_patn_desc_comp, patn.patn_psnam AS evnv_patn_psnam, patn.patn_fsnam AS evnv_patn_fsnam, patn.patn_title AS evnv_patn_title, short_date(patn.patn_dob) AS evnv_patn_dob, patn.patn_address AS evnv_patn_address, patn.patn_suburb AS evnv_patn_suburb, patn.patn_state AS evnv_patn_state, patn.patn_postcode AS evnv_patn_postcode, patn.patn_phone AS evnv_patn_phone, patn.patn_ref_date AS evnv_patn_ref_date, patn.patn_ref_period AS evnv_patn_ref_period, patn.patn_last_visit AS evnv_patn_last_visit, patn.patn_amount_outstanding AS evnv_patn_amount_outstanding, locn.locn_desc AS evnv_locn_desc, aptp.aptp_desc AS evnv_aptp_desc, apst.apst_desc AS evnv_apst_desc, prov.prov_provider_num AS evnv_prov_provider_num, prov.prov_name AS evnv_prov_name, prov.prov_address AS evnv_prov_address, prov.prov_suburb AS evnv_prov_suburb, prov.prov_state AS evnv_prov_state, prov.prov_postcode AS evnv_prov_postcode, prov.prov_salutation AS evnv_prov_salutation, prov.prov_phone AS evnv_prov_phone, prov.prov_bank_code AS evnv_prov_bank_code, rfdr.rfdr_name AS evnv_rfdr_name, rfdr.rfdr_street AS evnv_rfdr_street, rfdr.rfdr_suburb AS evnv_rfdr_suburb, rfdr.rfdr_postcode AS evnv_rfdr_postcode, rfdr.rfdr_state AS evnv_rfdr_state, rfdr.rfdr_provider AS evnv_rfdr_provider, rfdr.rfdr_phone AS evnv_rfdr_phone, rfdr.rfdr_salutation AS evnv_rfdr_salutation, rfdr.rfdr_index AS evnv_rfdr_index, patn.patn_feet_code AS evnv_patn_feet_code, patn.patn_hlfd_code AS evnv_patn_hlfd_code, patn.patn_ins_level AS evnv_patn_ins_level, patn.patn_healthnumb AS evnv_patn_healthnumb, patn.patn_medicare AS evnv_patn_medicare, patn.patn_healthcard AS evnv_patn_healthcard, patn.patn_country AS evnv_patn_country, patn.patn_aboriginality AS evnv_patn_aboriginality, patn.patn_sex AS evnv_patn_sex, patn.patn_marital AS evnv_patn_marital, patn.patn_accl_code AS evnv_patn_accl_code, patn.patn_accommodation AS evnv_patn_accommodation, patn.patn_care AS evnv_patn_care, evnt.evnt__sequence AS evnv__sequence, evnt.evnt__timestamp AS evnv__timestamp, evnt.evnt__user_entry AS evnv__user_entry, evnt.evnt__status AS evnv__status FROM ((((((evnt LEFT JOIN patn ON ((evnt.evnt_patn__sequence = patn.patn__sequence))) LEFT JOIN prov ON ((evnt.evnt_prov_code = prov.prov_code))) LEFT JOIN rfdr ON ((evnt.evnt_rfdr_code = rfdr.rfdr_code))) LEFT JOIN locn ON ((evnt.evnt_locn_code = locn.locn_code))) LEFT JOIN aptp ON ((evnt.evnt_aptp_code = aptp.aptp_code))) LEFT JOIN apst ON ((evnt.evnt_apst_code = apst.apst_code)));


ALTER TABLE public.evnv OWNER TO source;

--
-- Name: evwl; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW evwl AS
    SELECT evnt.evnt_prov_code AS evwl_prov_code, evnt.evnt_aptp_code AS evwl_aptp_code, evnt.evnt_apst_code AS evwl_apst_code, evnt.evnt_desc AS evwl_desc, to_char(evnt.evnt_starttime, 'HH:MI am'::text) AS evwl_ev_time, to_char(evnt.evnt_starttime, 'DD-MM-YYYY'::text) AS evwl_ev_date, ((date_part('hour'::text, evnt.evnt_duration) * (60)::double precision) + date_part('minute'::text, evnt.evnt_duration)) AS evwl_ev_minutes, patn.patn_flno AS evwl_patn_flno, ((patn.patn_psnam || ', '::text) || patn.patn_fsnam) AS evwl_patn_desc, patn.patn_patf_code AS evwl_patf_code, short_date(patn.patn_dob) AS evwl_patn_dob, patn.patn_last_visit AS evwl_patn_last_visit, patn.patn_amount_outstanding AS evwl_patn_amount_outstanding, patn.patn__sequence AS evwl_patn__sequence, rfdr.rfdr_name AS evwl_rfdr_name, evnt.evnt_starttime AS evwl_starttime, evnt.evnt__sequence AS evwl__sequence, evnt.evnt__timestamp AS evwl__timestamp, evnt.evnt__user_entry AS evwl__user_entry, evnt.evnt__status AS evwl__status FROM ((evnt LEFT JOIN patn ON ((evnt.evnt_patn__sequence = patn.patn__sequence))) LEFT JOIN rfdr ON ((evnt.evnt_rfdr_code = rfdr.rfdr_code)));


ALTER TABLE public.evwl OWNER TO source;

--
-- Name: feeb; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE feeb (
    feeb_serv_code text DEFAULT '-'::text NOT NULL,
    feeb_feet_code text DEFAULT '-'::text NOT NULL,
    feeb_amount numeric(12,2) DEFAULT 0.00,
    feeb__sequence integer DEFAULT nextval('"feeb_feeb__sequence_seq"'::text) NOT NULL,
    feeb__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    feeb__user_entry text DEFAULT "current_user"() NOT NULL,
    feeb__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.feeb OWNER TO source;

--
-- Name: feeb_feeb__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE feeb_feeb__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feeb_feeb__sequence_seq OWNER TO source;

--
-- Name: feeb_feeb__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('feeb_feeb__sequence_seq', 51606, true);


--
-- Name: mvac_database; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mvac_database (
    db_name text NOT NULL,
    db_desc text DEFAULT ''::text,
    db_host text DEFAULT 'localhost'::text,
    db_port text DEFAULT '5432'::text,
    db_options text DEFAULT ''::text,
    db_tty text DEFAULT ''::text,
    db_login text DEFAULT ''::text,
    db_pwd text DEFAULT ''::text,
    perms text DEFAULT 1
);


ALTER TABLE public.mvac_database OWNER TO source;

--
-- Name: serv; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE serv (
    serv_code text NOT NULL,
    serv_value integer DEFAULT 1 NOT NULL,
    serv_gst_percentage integer DEFAULT 0,
    serv_desc text,
    serv__sequence integer DEFAULT nextval('"serv_serv__sequence_seq"'::text) NOT NULL,
    serv__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    serv__user_entry text DEFAULT "current_user"() NOT NULL,
    serv__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.serv OWNER TO source;

--
-- Name: feel; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW feel AS
    SELECT mvac_database.db_desc AS feel_db_desc, serv.serv_code AS feel_serv_code, serv.serv_desc AS feel_serv_desc, getfeetype(0) AS feel_fee0_code, getfee(serv.serv_code, 0) AS feel_fee0_amount, getfeetype(1) AS feel_fee1_code, getfee(serv.serv_code, 1) AS feel_fee1_amount, getfeetype(2) AS feel_fee2_code, getfee(serv.serv_code, 2) AS feel_fee2_amount, getfeetype(3) AS feel_fee3_code, getfee(serv.serv_code, 3) AS feel_fee3_amount, getfeetype(4) AS feel_fee4_code, getfee(serv.serv_code, 4) AS feel_fee4_amount, getfeetype(5) AS feel_fee5_code, getfee(serv.serv_code, 5) AS feel_fee5_amount, getfeetype(6) AS feel_fee6_code, getfee(serv.serv_code, 6) AS feel_fee6_amount, getfeetype(7) AS feel_fee7_code, getfee(serv.serv_code, 7) AS feel_fee7_amount, getfeetype(8) AS feel_fee8_code, getfee(serv.serv_code, 8) AS feel_fee8_amount, serv.serv__sequence AS feel__sequence, serv.serv__timestamp AS feel__timestamp, serv.serv__user_entry AS feel__user_entry, serv.serv__status AS feel__status FROM serv, mvac_database;


ALTER TABLE public.feel OWNER TO source;

--
-- Name: feet_feet__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE feet_feet__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feet_feet__sequence_seq OWNER TO source;

--
-- Name: feet_feet__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('feet_feet__sequence_seq', 99, true);


--
-- Name: fept; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW fept AS
    SELECT feeb.feeb_feet_code AS fept_feet_code, feeb.feeb_serv_code AS fept_serv_code, serv.serv_gst_percentage AS fept_gst_percentage, feeb.feeb_amount AS fept_amount, to_char(((feeb.feeb_amount * "numeric"(serv.serv_gst_percentage)) / 100.00), '00.00'::text) AS fept_gst_amount, serv.serv_desc AS fept_desc, feeb.feeb__sequence AS fept__sequence, '2001-10-18 12:09:19'::timestamp without time zone AS fept__timestamp, "current_user"() AS fept__user_entry, 'N'::text AS fept__status FROM feeb, serv WHERE (serv.serv_code = feeb.feeb_serv_code);


ALTER TABLE public.fept OWNER TO source;

--
-- Name: fmdt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE fmdt (
    fmdt_form_code text NOT NULL,
    fmdt_desc text DEFAULT 'New Item'::text,
    fmdt_field_type integer DEFAULT 0 NOT NULL,
    fmdt_section integer DEFAULT 1,
    fmdt_text text,
    fmdt_x_coord integer DEFAULT 0 NOT NULL,
    fmdt_y_coord integer DEFAULT 0 NOT NULL,
    fmdt_width integer DEFAULT 0 NOT NULL,
    fmdt_height integer DEFAULT 12 NOT NULL,
    fmdt_bg_colour text DEFAULT '255,255,255'::text NOT NULL,
    fmdt_fg_colour text DEFAULT '0,0,0'::text NOT NULL,
    fmdt_bd_colour text DEFAULT '0,0,0'::text NOT NULL,
    fmdt_bd_width integer DEFAULT 1 NOT NULL,
    fmdt_bd_style integer DEFAULT 0 NOT NULL,
    fmdt_ft_family text DEFAULT 'Helvetica'::text NOT NULL,
    fmdt_ft_size integer DEFAULT 8 NOT NULL,
    fmdt_ft_weight integer DEFAULT 25 NOT NULL,
    fmdt_ft_italic integer DEFAULT 0 NOT NULL,
    fmdt_hz_align integer DEFAULT 0 NOT NULL,
    fmdt_vt_align integer DEFAULT 2 NOT NULL,
    fmdt_word_wrap integer DEFAULT 0 NOT NULL,
    fmdt_data_type integer DEFAULT 0 NOT NULL,
    fmdt_date_format integer DEFAULT 7 NOT NULL,
    fmdt_precision integer DEFAULT 0 NOT NULL,
    fmdt_currency integer DEFAULT 36 NOT NULL,
    fmdt_neg_colour text DEFAULT '255,0,0'::text NOT NULL,
    fmdt_comma_sep integer DEFAULT 0 NOT NULL,
    fmdt__sequence integer DEFAULT nextval('"fmdt_fmdt__sequence_seq"'::text) NOT NULL,
    fmdt__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    fmdt__user_entry text DEFAULT "current_user"() NOT NULL,
    fmdt__status character(1) DEFAULT 'A'::text NOT NULL
);


ALTER TABLE public.fmdt OWNER TO source;

--
-- Name: fmdt_fmdt__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE fmdt_fmdt__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.fmdt_fmdt__sequence_seq OWNER TO source;

--
-- Name: fmdt_fmdt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('fmdt_fmdt__sequence_seq', 709, true);


--
-- Name: form; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE form (
    form_code text NOT NULL,
    form_desc text DEFAULT 'New Report'::text,
    form_classname text,
    form_page_attribute text,
    form_includes text,
    form_pagesize integer DEFAULT 0 NOT NULL,
    form_orientation integer DEFAULT 0 NOT NULL,
    form_mg_top integer DEFAULT 10 NOT NULL,
    form_mg_bottom integer DEFAULT 10 NOT NULL,
    form_mg_left integer DEFAULT 40 NOT NULL,
    form_mg_right integer DEFAULT 40 NOT NULL,
    form_rh_height integer DEFAULT 0 NOT NULL,
    form_rh_frequency integer DEFAULT 0 NOT NULL,
    form_rf_height integer DEFAULT 0 NOT NULL,
    form_rf_frequency integer DEFAULT 0 NOT NULL,
    form_ph_height integer DEFAULT 45 NOT NULL,
    form_ph_frequency integer DEFAULT 1 NOT NULL,
    form_pf_height integer DEFAULT 35 NOT NULL,
    form_pf_frequency integer DEFAULT 1 NOT NULL,
    form_dt_height integer DEFAULT 30 NOT NULL,
    form__sequence integer DEFAULT nextval('"form_form__sequence_seq"'::text) NOT NULL,
    form__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    form__user_entry text DEFAULT "current_user"() NOT NULL,
    form__status character(1) DEFAULT 'A'::text NOT NULL
);


ALTER TABLE public.form OWNER TO source;

--
-- Name: form_form__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE form_form__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.form_form__sequence_seq OWNER TO source;

--
-- Name: form_form__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('form_form__sequence_seq', 32, true);


--
-- Name: gsti; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW gsti AS
    SELECT invc.invc__sequence AS gsti_invc__sequence, short_date(invc.invc_date_printed) AS gsti_day_date, quarter_date(invc.invc_date_printed) AS gsti_quarter_date, invc.invc_dbtr_code AS gsti_invc_dbtr_code, invc.invc_bank_code AS gsti_invc_bank_code, invc.invc_prov_code AS gsti_invc_prov_code, invc.invc_patn__sequence AS gsti_invc_patn__sequence, invc.invc_empl_code AS gsti_invc_empl_code, invc.invc_feet_code AS gsti_invc_feet_code, invc.invc_rfdr_code AS gsti_invc_rfdr_code, invc.invc_rfdr_date AS gsti_invc_rfdr_date, invc.invc_rfdr_period AS gsti_invc_rfdr_period, invc.invc_date_created AS gsti_invc_date_created, invc.invc_date_printed AS gsti_invc_date_printed, invc.invc_date_reprint AS gsti_invc_date_reprint, invc.invc_amount AS gsti_invc_amount, invc.invc_paid_amount AS gsti_invc_paid_amount, invc.invc_gst_amount AS gsti_invc_gst_amount, invc.invc_paid_gst_amount AS gsti_invc_paid_gst_amount, patn.patn_flno AS gsti_patn_flno, patn.patn_psnam AS gsti_patn_psnam, patn.patn_fsnam AS gsti_patn_fsnam, patn.patn_title AS gsti_patn_title, short_date(patn.patn_dob) AS gsti_patn_dob, patn.patn_address AS gsti_patn_address, patn.patn_suburb AS gsti_patn_suburb, patn.patn_state AS gsti_patn_state, patn.patn_postcode AS gsti_patn_postcode, patn.patn_phone AS gsti_patn_phone, patn.patn_dbtr_code AS gsti_dbtr_code, dbtr.dbtr_name AS gsti_dbtr_name, dbtr.dbtr_address AS gsti_dbtr_address, dbtr.dbtr_suburb AS gsti_dbtr_suburb, dbtr.dbtr_postcode AS gsti_dbtr_postcode, dbtr.dbtr_state AS gsti_dbtr_state, dbtr.dbtr_phone AS gsti_dbtr_phone, patn.patn__sequence AS gsti__sequence, patn.patn__timestamp AS gsti__timestamp, patn.patn__user_entry AS gsti__user_entry, patn.patn__status AS gsti__status FROM ((invc JOIN patn ON ((patn.patn__sequence = invc.invc_patn__sequence))) JOIN dbtr ON ((dbtr.dbtr_code = invc.invc_dbtr_code))) WHERE (invc.invc_gst_amount <> (0)::numeric);


ALTER TABLE public.gsti OWNER TO source;

--
-- Name: gstv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW gstv AS
    SELECT cred.cred_paym__sequence AS gstv_cred_paym__sequence, cred.cred_invc__sequence AS gstv_cred_invc__sequence, cred.cred_amount AS gstv_cred_amount, cred.cred_gst_amount AS gstv_cred_gst_amount, paym.paym_date_entry AS gstv_paym_date_entry, paym.paym_user_entry AS gstv_paym_user_entry, paym.paym_site_entry AS gstv_paym_site_entry, paym.paym_amount AS gstv_paym_amount, paym.paym_tdtp_code AS gstv_paym_tdtp_code, paym.paym_drawer AS gstv_paym_drawer, paym.paym_bank AS gstv_paym_bank, paym.paym_branch AS gstv_paym_branch, paym.paym_bkdp__sequence AS gstv_paym_bkdp__sequence, short_date(bkdp.bkdp_date_created) AS gstv_day_date, quarter_date(bkdp.bkdp_date_created) AS gstv_quarter_date, bkdp.bkdp_date_created AS gstv_bkdp_date_created, bkdp.bkdp_date_printed AS gstv_bkdp_date_printed, bkdp.bkdp_user_printed AS gstv_bkdp_user_printed, bkdp.bkdp_bank_code AS gstv_bkdp_bank_code, bkdp.bkdp_desc AS gstv_bkdp_desc, bkdp.bkdp_amount AS gstv_bkdp_amount, invc.invc_dbtr_code AS gstv_invc_dbtr_code, invc.invc_bank_code AS gstv_invc_bank_code, invc.invc_prov_code AS gstv_invc_prov_code, invc.invc_patn__sequence AS gstv_invc_patn__sequence, invc.invc_empl_code AS gstv_invc_empl_code, invc.invc_feet_code AS gstv_invc_feet_code, invc.invc_rfdr_code AS gstv_invc_rfdr_code, invc.invc_rfdr_date AS gstv_invc_rfdr_date, invc.invc_rfdr_period AS gstv_invc_rfdr_period, invc.invc_date_created AS gstv_invc_date_created, invc.invc_date_printed AS gstv_invc_date_printed, invc.invc_date_reprint AS gstv_invc_date_reprint, invc.invc_amount AS gstv_invc_amount, invc.invc_paid_amount AS gstv_invc_paid_amount, invc.invc_gst_amount AS gstv_invc_gst_amount, invc.invc_paid_gst_amount AS gstv_invc_paid_gst_amount, patn.patn_flno AS gstv_patn_flno, patn.patn_psnam AS gstv_patn_psnam, patn.patn_fsnam AS gstv_patn_fsnam, patn.patn_title AS gstv_patn_title, short_date(patn.patn_dob) AS gstv_patn_dob, patn.patn_address AS gstv_patn_address, patn.patn_suburb AS gstv_patn_suburb, patn.patn_state AS gstv_patn_state, patn.patn_postcode AS gstv_patn_postcode, patn.patn_phone AS gstv_patn_phone, patn.patn_dbtr_code AS gstv_dbtr_code, dbtr.dbtr_name AS gstv_dbtr_name, dbtr.dbtr_address AS gstv_dbtr_address, dbtr.dbtr_suburb AS gstv_dbtr_suburb, dbtr.dbtr_postcode AS gstv_dbtr_postcode, dbtr.dbtr_state AS gstv_dbtr_state, dbtr.dbtr_phone AS gstv_dbtr_phone, patn.patn__sequence AS gstv__sequence, patn.patn__timestamp AS gstv__timestamp, patn.patn__user_entry AS gstv__user_entry, patn.patn__status AS gstv__status FROM cred, paym, bkdp, invc, patn, dbtr WHERE ((((((cred.cred_gst_amount <> (0)::numeric) AND (paym.paym__sequence = cred.cred_paym__sequence)) AND (bkdp.bkdp__sequence = paym.paym_bkdp__sequence)) AND (invc.invc__sequence = cred.cred_invc__sequence)) AND (patn.patn__sequence = invc.invc_patn__sequence)) AND (dbtr.dbtr_code = invc.invc_dbtr_code));


ALTER TABLE public.gstv OWNER TO source;

--
-- Name: hice; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE hice (
    hice_name text,
    hice_input character(1),
    hice_output character(1),
    hice_session character(1),
    hice_transmission character(1),
    hice_length text,
    hice_type text,
    hice_desc text,
    hice__sequence serial NOT NULL,
    hice__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    hice__user_entry text DEFAULT "current_user"() NOT NULL,
    hice__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.hice OWNER TO source;

--
-- Name: hice_hice__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('hice', 'hice__sequence'), 1, false);


--
-- Name: mdaf; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mdaf (
    mdaf_patn__sequence integer,
    mdaf_prov_code text,
    mdaf_rfdr_code text,
    mdaf_voucher text,
    mdaf_date_printed timestamp without time zone,
    mdaf_mdbt__sequence integer,
    mdaf__sequence serial NOT NULL,
    mdaf__timestamp timestamp without time zone DEFAULT now(),
    mdaf__user_entry text DEFAULT "current_user"(),
    mdaf__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.mdaf OWNER TO source;

--
-- Name: mdbt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mdbt (
    mdbt_prov_code text,
    mdbt_first_voucher text,
    mdbt_last_voucher text,
    mdbt_batch_code text,
    mdbt_location_id text,
    mdbt_product text,
    mdbt_version text,
    mdbt_accpaid_ind text,
    mdbt_claimsubauth text,
    mdbt_accunpaid text,
    mdbt_voucher_count integer,
    mdbt_total_amount numeric(12,2),
    mdbt_claim_date timestamp without time zone,
    mdbt_recipient text,
    mdbt_server text,
    mdbt_claim_status text,
    mdbt__sequence serial NOT NULL,
    mdbt__timestamp timestamp without time zone DEFAULT now(),
    mdbt__user_entry text DEFAULT "current_user"(),
    mdbt__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.mdbt OWNER TO source;

--
-- Name: svpf; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE svpf (
    svpf_date_service timestamp without time zone DEFAULT now() NOT NULL,
    svpf_serv_code text DEFAULT '-'::text NOT NULL,
    svpf_percentage integer DEFAULT 100 NOT NULL,
    svpf_desc text,
    svpf_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    svpf_gst_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    svpf_invc__sequence integer DEFAULT 0 NOT NULL,
    svpf_mdaf__sequence integer,
    svpf_patn__sequence integer DEFAULT 0 NOT NULL,
    svpf__sequence integer DEFAULT nextval('"svpf_svpf__sequence_seq"'::text) NOT NULL,
    svpf__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    svpf__user_entry text DEFAULT "current_user"() NOT NULL,
    svpf__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.svpf OWNER TO source;

--
-- Name: hicv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW hicv AS
    SELECT CASE WHEN (invc_balance(svpf.svpf_invc__sequence) = 0.0) THEN 'Y'::text ELSE 'N'::text END AS hicv_accountpaidind, ''::text AS hicv_accountreferencenum, ''::text AS hicv_admissiondate, ''::text AS hicv_aftercareoverrideind, ''::text AS hicv_approvalnum, ''::text AS hicv_associatename, ''::text AS hicv_atsiindicator, ''::text AS hicv_authproxyname, ''::text AS hicv_authproxypasswd, ''::text AS hicv_authproxypasswd_proxyname, ''::text AS hicv_authproxyuserid, ''::text AS hicv_authproxyuserid_proxyname, ''::text AS hicv_authorityapprovalnum, ''::text AS hicv_authorityprescriptionnum, ''::text AS hicv_bankaccountname, ''::text AS hicv_bankaccountnum, ''::text AS hicv_benefitassignmentauthorised, ''::text AS hicv_billingagentid, ''::text AS hicv_buffersize, ((svpf.svpf_amount * (100)::numeric))::integer AS hicv_chargeamount, ''::text AS hicv_claimid, ''::text AS hicv_claimperiodnum, ''::text AS hicv_claimreference, mdbt.mdbt_claimsubauth AS hicv_claimsubmissionauthorised, ''::text AS hicv_claimtypecde, ''::text AS hicv_claimantaddressline1, ''::text AS hicv_claimantaddressline2, ''::text AS hicv_claimantaddresslocality, ''::text AS hicv_claimantaddresspostcode, ''::text AS hicv_claimantdateofbirth, ''::text AS hicv_claimantfamilyname, ''::text AS hicv_claimantfirstname, ''::text AS hicv_claimantmedicarecardnum, ''::text AS hicv_claimantreferencenum, ''::text AS hicv_cliniccode, ''::text AS hicv_communitycode, ''::text AS hicv_compensationclaimind, ''::text AS hicv_contactphonenum, ''::text AS hicv_contenttype, ''::text AS hicv_dateofdispensing, ''::text AS hicv_dateofimmunisation, to_char(mdbt.mdbt_claim_date, 'DDMMYYYY'::text) AS hicv_dateoflodgement, ''::text AS hicv_dateofprescribing, to_char(svpf.svpf_date_service, 'DDMMYYYY'::text) AS hicv_dateofservice, ''::text AS hicv_dateofsupply, ''::text AS hicv_dateoftransmission, ''::text AS hicv_dischargedate, ''::text AS hicv_distancekms, 'N'::text AS hicv_duplicateserviceoverrideind, ''::text AS hicv_entitlementid, ''::text AS hicv_equipmentid, ''::text AS hicv_facilityid, patn.patn_psnam AS hicv_familyname, ''::text AS hicv_fieldquantity, ''::text AS hicv_filepath, ''::text AS hicv_financialinterestdisclosureind, ''::text AS hicv_formcategory, ''::text AS hicv_fundbrandid, ''::text AS hicv_fundpayeeid, ''::text AS hicv_givenname, ''::text AS hicv_glassbottleind, ''::text AS hicv_hclpassphrase, ''::text AS hicv_hepbbirthdosedate, ''::text AS hicv_hepbbirthdoseind, ''::text AS hicv_hospitalind, ''::text AS hicv_hospitalprovidernum, ''::text AS hicv_ifcissuecde, ''::text AS hicv_immediatesupplynecessaryind, ''::text AS hicv_immunisingprovidernum, ''::text AS hicv_informationprovidernum, svpf.svpf_serv_code AS hicv_itemnum, mdbt.mdbt_location_id AS hicv_locationid, ''::text AS hicv_logicpackdir, ''::text AS hicv_medicarenum, ''::text AS hicv_multipleprocedureoverrideind, ''::text AS hicv_nextduedate, ''::text AS hicv_noofpatientsseen, ''::text AS hicv_numberofrepeats, ''::text AS hicv_numberofservices, ''::text AS hicv_opvtypecde, ''::text AS hicv_pbsitemcode, ''::text AS hicv_pbsreferencenum, ''::text AS hicv_participanttype, ''::text AS hicv_patientaddressline1, ''::text AS hicv_patientaddressline2, ''::text AS hicv_patientaddresslocality, ''::text AS hicv_patientaddresspostcode, ''::text AS hicv_patientaliasfamilyname, ''::text AS hicv_patientaliasfirstname, ''::text AS hicv_patientcategory, ''::text AS hicv_patientcontribamt, patn.patn_dob AS hicv_patientdateofbirth, patn.patn_psnam AS hicv_patientfamilyname, patn.patn_fsnam AS hicv_patientfirstname, ''::text AS hicv_patientfundmembershipnum, ''::text AS hicv_patientfundupi, ''::text AS hicv_patientgender, patn.patn_medicare AS hicv_patientmedicarecardnum, ''::text AS hicv_patientproviderchildid, ltrim("substring"(patn.patn_medicare, '/.*$'::text), '/'::text) AS hicv_patientreferencenum, ''::text AS hicv_patientsecondinitial, ''::text AS hicv_payeeprovidernum, ''::text AS hicv_paymentcategory, ''::text AS hicv_periodtypeind, ''::text AS hicv_pharmacyprocessingcode, ''::text AS hicv_pmsclaimid, mdbt.mdbt_product AS hicv_pmsproduct, mdbt.mdbt_version AS hicv_pmsversion, ''::text AS hicv_prescriberid, ''::text AS hicv_previoussupplies, ''::text AS hicv_principalprovidernum, mdbt.mdbt_recipient AS hicv_recipient, to_char(patn.patn_ref_date, 'DDMMYYYY'::text) AS hicv_referraldatefrom, ''::text AS hicv_referraldateto, ''::text AS hicv_referralissuedate, ''::text AS hicv_referraloverridetype, ''::text AS hicv_referraloverridetypecde, patn.patn_ref_period AS hicv_referralperiod, ''::text AS hicv_referralperiodtypecde, prov.prov_provider_num AS hicv_referringprovidernum, ''::text AS hicv_reportstatuscde, ''::text AS hicv_requestcontenttype, ''::text AS hicv_requestissuedate, ''::text AS hicv_requesttypecde, ''::text AS hicv_requesttypeind, ''::text AS hicv_requestingprovidernum, ''::text AS hicv_resubmissionind, ''::text AS hicv_rule3exemptind, ''::text AS hicv_sddreasoncode, ''::text AS hicv_selfdeemedcde, ''::text AS hicv_selfdeemedind, ''::text AS hicv_sender, ''::text AS hicv_sendercontactpersonname, ''::text AS hicv_sendercontactpersonphone, ''::text AS hicv_serialnum, mdbt.mdbt_server AS hicv_server, ''::text AS hicv_servicetext, ''::text AS hicv_servicetype, 'S'::text AS hicv_servicetypecde, prov.prov_provider_num AS hicv_servicingprovidernum, ''::text AS hicv_sessionid, ''::text AS hicv_timeduration, to_char(mdbt.mdbt_claim_date, 'HH24MM'::text) AS hicv_timeoflodgement, to_char(svpf.svpf_date_service, 'HH24MM'::text) AS hicv_timeofservice, ''::text AS hicv_timeoftransmission, ''::text AS hicv_transactionid, ''::text AS hicv_transmissionid, ''::text AS hicv_transmissiontype, ''::text AS hicv_treatmentlocation, ''::text AS hicv_uniquepharmacyprescriptionnum, ''::text AS hicv_vaccinebatchnum, ''::text AS hicv_vaccinecode, ''::text AS hicv_vaccinedose, ''::text AS hicv_veteranfilenum, mdbt.mdbt__sequence AS hicv_mdbt__sequence, mdaf.mdaf__sequence AS hicv_mdaf__sequence, mdbt.mdbt__sequence AS hicv__sequence, mdbt.mdbt__timestamp AS hicv__timestamp, mdbt.mdbt__user_entry AS hicv__user_entry, mdbt.mdbt__status AS hicv__status FROM (((((mdbt LEFT JOIN mdaf ON ((mdaf.mdaf_mdbt__sequence = mdbt.mdbt__sequence))) LEFT JOIN svpf ON ((svpf.svpf_mdaf__sequence = mdaf.mdaf__sequence))) LEFT JOIN patn ON ((patn.patn__sequence = mdaf.mdaf_patn__sequence))) LEFT JOIN prov ON ((prov.prov_code = mdbt.mdbt_prov_code))) LEFT JOIN rfdr ON ((rfdr.rfdr_code = mdaf.mdaf_rfdr_code)));


ALTER TABLE public.hicv OWNER TO source;

--
-- Name: hlfd; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE hlfd (
    hlfd_code text NOT NULL,
    hlfd_group text,
    hlfd_desc text,
    hlfd__sequence integer DEFAULT nextval('"hlfd_hlfd__sequence_seq"'::text) NOT NULL,
    hlfd__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    hlfd__user_entry text DEFAULT "current_user"() NOT NULL,
    hlfd__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.hlfd OWNER TO source;

--
-- Name: hlfd_hlfd__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE hlfd_hlfd__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hlfd_hlfd__sequence_seq OWNER TO source;

--
-- Name: hlfd_hlfd__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('hlfd_hlfd__sequence_seq', 20, true);


--
-- Name: icd9; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE icd9 (
    icd9_codetype character(1),
    icd9_code text,
    icd9_age_edit character(1),
    icd9_low_age smallint,
    icd9_high_age smallint,
    icd9_sex_edit character(1),
    icd9_code_edit character(1),
    icd9_area_edit character(1),
    icd9_digit_5 text,
    icd9_desc text,
    icd9__sequence integer DEFAULT nextval('"icd9_icd9__sequence_seq"'::text) NOT NULL,
    icd9__timestamp timestamp without time zone DEFAULT now(),
    icd9__user_entry text DEFAULT "current_user"(),
    icd9__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.icd9 OWNER TO source;

--
-- Name: icd9_icd9__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE icd9_icd9__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.icd9_icd9__sequence_seq OWNER TO source;

--
-- Name: icd9_icd9__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('icd9_icd9__sequence_seq', 11, true);


--
-- Name: inst; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE inst (
    inst_code text,
    inst_desc text,
    inst_addr text,
    inst_suburb text,
    inst_postc text,
    inst_cont text,
    inst__sequence integer DEFAULT nextval('"inst_inst__sequence_seq"'::text) NOT NULL,
    inst__timestamp timestamp without time zone DEFAULT now(),
    inst__user_entry text DEFAULT "current_user"(),
    inst__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.inst OWNER TO source;

--
-- Name: inst_inst__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE inst_inst__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.inst_inst__sequence_seq OWNER TO source;

--
-- Name: inst_inst__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('inst_inst__sequence_seq', 10, true);


--
-- Name: invc_invc__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE invc_invc__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.invc_invc__sequence_seq OWNER TO source;

--
-- Name: invc_invc__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('invc_invc__sequence_seq', 20169, true);


--
-- Name: labl; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE labl (
    labl_id text,
    labl_subtype text,
    labl_text_label text,
    labl_class_name text,
    labl_attribute_name text,
    labl_row integer,
    labl_column integer,
    labl__sequence integer DEFAULT nextval('"labl_labl__sequence_seq"'::text) NOT NULL,
    labl__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    labl__user_entry text DEFAULT "current_user"() NOT NULL,
    labl__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.labl OWNER TO source;

--
-- Name: labl_labl__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE labl_labl__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.labl_labl__sequence_seq OWNER TO source;

--
-- Name: labl_labl__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('labl_labl__sequence_seq', 1, true);


--
-- Name: locn_locn__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE locn_locn__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.locn_locn__sequence_seq OWNER TO source;

--
-- Name: locn_locn__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('locn_locn__sequence_seq', 4, true);


--
-- Name: lthd; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE lthd (
    lthd_prov_code text,
    lthd_target_id text,
    lthd_order integer,
    lthd_type text,
    lthd_data text,
    lthd_x_coord integer,
    lthd_y_coord integer,
    lthd_scale numeric(3,1),
    lthd_font text,
    lthd_size numeric(4,1),
    lthd_align character(1),
    lthd__sequence integer DEFAULT nextval('"lthd_lthd__sequence_seq"'::text) NOT NULL,
    lthd__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    lthd__user_entry text DEFAULT "current_user"() NOT NULL,
    lthd__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.lthd OWNER TO source;

--
-- Name: lthd_lthd__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE lthd_lthd__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.lthd_lthd__sequence_seq OWNER TO source;

--
-- Name: lthd_lthd__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('lthd_lthd__sequence_seq', 1, true);


--
-- Name: mbst; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mbst (
    mbst_item integer,
    mbst_desc text,
    mbst_sch100 numeric(12,2),
    mbst_sch75 numeric(12,2),
    mbst_sch85 numeric(12,2),
    mbst__sequence serial NOT NULL,
    mbst__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mbst__user_entry text DEFAULT "current_user"() NOT NULL,
    mbst__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mbst OWNER TO source;

--
-- Name: mbst_mbst__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mbst', 'mbst__sequence'), 9568, true);


--
-- Name: mdaf_mdaf__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mdaf', 'mdaf__sequence'), 10, true);


--
-- Name: mdbt_mdbt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mdbt', 'mdbt__sequence'), 4, true);


--
-- Name: mdcr; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mdcr (
    mdcr_paym__sequence integer NOT NULL,
    mdcr_svpf__sequence integer NOT NULL,
    mdcr_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    mdcr__sequence integer DEFAULT nextval('"mdcr_mdcr__sequence_seq"'::text) NOT NULL,
    mdcr__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mdcr__user_entry text DEFAULT "current_user"() NOT NULL,
    mdcr__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mdcr OWNER TO source;

--
-- Name: mdcr_mdcr__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mdcr_mdcr__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mdcr_mdcr__sequence_seq OWNER TO source;

--
-- Name: mdcr_mdcr__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mdcr_mdcr__sequence_seq', 1, true);


--
-- Name: mtad; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtad (
    mtad_title text,
    mtad_icon text,
    mtad_parent text,
    mtad_class text,
    mtad_access integer DEFAULT 31 NOT NULL,
    mtad_list_order text DEFAULT 'Z-LAST'::text NOT NULL,
    mtad__sequence serial NOT NULL,
    mtad__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtad__user_entry text DEFAULT "current_user"() NOT NULL,
    mtad__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mtad OWNER TO source;

--
-- Name: mtad_mtad__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mtad', 'mtad__sequence'), 9, true);


--
-- Name: mtag; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtag (
    mtag_name text DEFAULT 'new'::text NOT NULL,
    mtag_title text DEFAULT 'new'::text,
    mtag_parent text,
    mtag_access integer DEFAULT 31 NOT NULL,
    mtag_list_order text DEFAULT 'Z-LAST'::text NOT NULL,
    mtag__sequence serial NOT NULL,
    mtag__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtag__user_entry text DEFAULT "current_user"() NOT NULL,
    mtag__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mtag OWNER TO source;

--
-- Name: mtag_mtag__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mtag', 'mtag__sequence'), 1, true);


--
-- Name: mtal; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtal (
    mtal_mtat_name text,
    mtal_mtop_code text,
    mtal_value text,
    mtal_colour text,
    mtal_priority integer DEFAULT 0,
    mtal__sequence serial NOT NULL,
    mtal__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtal__user_entry text DEFAULT "current_user"() NOT NULL,
    mtal__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mtal OWNER TO source;

--
-- Name: mtal_mtal__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mtal', 'mtal__sequence'), 8, true);


--
-- Name: mtat; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtat (
    mtat_access text DEFAULT '31'::text NOT NULL,
    mtat_name text DEFAULT 'NAME'::text NOT NULL,
    mtat_type text DEFAULT 'text'::text NOT NULL,
    mtat_length integer DEFAULT 1 NOT NULL,
    mtat_attributes text,
    mtat_operator text DEFAULT '='::text NOT NULL,
    mtat_title text DEFAULT 'TITLE'::text NOT NULL,
    mtat_class_name text DEFAULT '-'::text NOT NULL,
    mtat_displen integer DEFAULT 10 NOT NULL,
    mtat_browse_order integer DEFAULT 500 NOT NULL,
    mtat_view_order integer DEFAULT 500 NOT NULL,
    mtat_input_method text,
    mtat_default text,
    mtat_htmltagatt text,
    mtat__sequence integer DEFAULT nextval('"mtat_mtat__sequence_seq"'::text) NOT NULL,
    mtat__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtat__user_entry text DEFAULT "current_user"() NOT NULL,
    mtat__status character(1) DEFAULT 'A'::bpchar NOT NULL
);


ALTER TABLE public.mtat OWNER TO source;

--
-- Name: mtat_mtat__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mtat_mtat__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mtat_mtat__sequence_seq OWNER TO source;

--
-- Name: mtat_mtat__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mtat_mtat__sequence_seq', 4094, true);


--
-- Name: mtau; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtau (
    mtau_table_name text NOT NULL,
    mtau_row_sequence integer NOT NULL,
    mtau_operation text NOT NULL,
    mtau_attributes text,
    mtau_before text,
    mtau_after text,
    mtau__sequence serial NOT NULL,
    mtau__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtau__user_entry text DEFAULT "current_user"() NOT NULL,
    mtau__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mtau OWNER TO source;

--
-- Name: mtau_mtau__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mtau', 'mtau__sequence'), 14, true);


--
-- Name: mtcl; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtcl (
    mtcl_access text DEFAULT '2'::text NOT NULL,
    mtcl_name text DEFAULT 'NAME'::text NOT NULL,
    mtcl_title text DEFAULT 'TITLE'::text NOT NULL,
    mtcl_group text,
    mtcl_matrix_order integer,
    mtcl_order_by text,
    mtcl_group_by text,
    mtcl_primary text,
    mtcl_userkey text,
    mtcl_userlabel text,
    mtcl_query_limit integer DEFAULT 200,
    mtcl_query_offset integer DEFAULT 0,
    mtcl_extras text,
    mtcl__sequence integer DEFAULT nextval('"mtcl_mtcl__sequence_seq"'::text) NOT NULL,
    mtcl__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtcl__user_entry text DEFAULT "current_user"() NOT NULL,
    mtcl__status character(1) DEFAULT 'A'::bpchar NOT NULL
);


ALTER TABLE public.mtcl OWNER TO source;

--
-- Name: mtcl_mtcl__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mtcl_mtcl__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mtcl_mtcl__sequence_seq OWNER TO source;

--
-- Name: mtcl_mtcl__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mtcl_mtcl__sequence_seq', 254, true);


--
-- Name: mtfn; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtfn (
    mtfn_title text DEFAULT 'TITLE'::text NOT NULL,
    mtfn_master_class text DEFAULT '-'::text NOT NULL,
    mtfn_key text DEFAULT '-'::text NOT NULL,
    mtfn_other_class text DEFAULT '-'::text NOT NULL,
    mtfn_join text DEFAULT '-'::text NOT NULL,
    mtfn_view text DEFAULT '-'::text NOT NULL,
    mtfn__sequence integer DEFAULT nextval('"mtfn_mtfn__sequence_seq"'::text) NOT NULL,
    mtfn__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtfn__user_entry text DEFAULT "current_user"() NOT NULL,
    mtfn__status character(1) DEFAULT 'A'::bpchar NOT NULL
);


ALTER TABLE public.mtfn OWNER TO source;

--
-- Name: mtfn_mtfn__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mtfn_mtfn__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mtfn_mtfn__sequence_seq OWNER TO source;

--
-- Name: mtfn_mtfn__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mtfn_mtfn__sequence_seq', 540, true);


--
-- Name: mtop; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtop (
    mtop_code text NOT NULL,
    mtop_desc text,
    mtop__sequence serial NOT NULL,
    mtop__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtop__user_entry text DEFAULT "current_user"() NOT NULL,
    mtop__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mtop OWNER TO source;

--
-- Name: mtop_mtop__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mtop', 'mtop__sequence'), 10, true);


--
-- Name: mtpt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtpt (
    mtpt_name text DEFAULT 'NAME'::text NOT NULL,
    mtpt_rcs_header text DEFAULT 'RCS HEADER'::text NOT NULL,
    mtpt__sequence integer DEFAULT nextval('"mtpt_mtpt__sequence_seq"'::text) NOT NULL,
    mtpt__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtpt__user_entry text DEFAULT "current_user"() NOT NULL,
    mtpt__status character(1) DEFAULT 'A'::text NOT NULL
);


ALTER TABLE public.mtpt OWNER TO source;

--
-- Name: mtpt_mtpt__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mtpt_mtpt__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mtpt_mtpt__sequence_seq OWNER TO source;

--
-- Name: mtpt_mtpt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mtpt_mtpt__sequence_seq', 39, true);


--
-- Name: mtrl; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtrl (
    mtrl_title text DEFAULT '-'::text NOT NULL,
    mtrl_master_class text DEFAULT '-'::text NOT NULL,
    mtrl_key text DEFAULT '-'::text NOT NULL,
    mtrl_other_class text DEFAULT '-'::text NOT NULL,
    mtrl_join text DEFAULT '-'::text NOT NULL,
    mtrl__sequence integer DEFAULT nextval('"mtrl_mtrl__sequence_seq"'::text) NOT NULL,
    mtrl__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtrl__user_entry text DEFAULT "current_user"() NOT NULL,
    mtrl__status character(1) DEFAULT 'A'::bpchar NOT NULL
);


ALTER TABLE public.mtrl OWNER TO source;

--
-- Name: mtrl_mtrl__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mtrl_mtrl__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mtrl_mtrl__sequence_seq OWNER TO source;

--
-- Name: mtrl_mtrl__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mtrl_mtrl__sequence_seq', 323, true);


--
-- Name: mtsv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW mtsv AS
    SELECT byteaparam(pg_trigger.tgargs, 0) AS mtsv_name, byteaparam(pg_trigger.tgargs, 1) AS mtsv_master_class, mtsv_keys(pg_trigger.tgargs, (pg_trigger.tgnargs)::integer, 4) AS mtsv_key, byteaparam(pg_trigger.tgargs, 2) AS mtsv_other_class, mtsv_keys(pg_trigger.tgargs, (pg_trigger.tgnargs)::integer, 5) AS mtsv_join, CASE WHEN (pg_trigger.tgtype = 9) THEN 'D'::text WHEN (pg_trigger.tgtype = 17) THEN 'U'::text WHEN (pg_trigger.tgtype = 21) THEN 'O'::text ELSE '?'::text END AS mtsv_type, pg_trigger.oid AS mtsv__sequence, now() AS mtsv__timestamp, "current_user"() AS mtsv__user_entry, 'V'::bpchar AS mtsv__status FROM pg_trigger WHERE ((pg_trigger.tgnargs >= 6) AND (pg_trigger.tgisconstraint = true));


ALTER TABLE public.mtsv OWNER TO source;

--
-- Name: mttb; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mttb (
    mttb_name text DEFAULT 'NAME'::text NOT NULL,
    mttb_rcs_header text DEFAULT 'RCS HEADER'::text NOT NULL,
    mttb_notes text,
    mttb__sequence integer DEFAULT nextval('"mttb_mttb__sequence_seq"'::text) NOT NULL,
    mttb__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mttb__user_entry text DEFAULT "current_user"() NOT NULL,
    mttb__status character(1) DEFAULT 'A'::text NOT NULL
);


ALTER TABLE public.mttb OWNER TO source;

--
-- Name: mttb_mttb__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE mttb_mttb__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.mttb_mttb__sequence_seq OWNER TO source;

--
-- Name: mttb_mttb__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('mttb_mttb__sequence_seq', 182, true);


--
-- Name: mttk; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mttk (
    mttk_code text NOT NULL,
    mttk_expires timestamp without time zone DEFAULT (now() + '00:01:00'::interval) NOT NULL,
    mttk__sequence serial NOT NULL,
    mttk__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mttk__user_entry text DEFAULT "current_user"() NOT NULL,
    mttk__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.mttk OWNER TO source;

--
-- Name: mttk_mttk__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mttk', 'mttk__sequence'), 1, false);


--
-- Name: mtvs; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mtvs (
    mtvs_schema_name text,
    mtvs_schema_version text,
    mtvs_product_name text,
    mtvs_product_version text,
    mtvs_desc text,
    mtvs__sequence serial NOT NULL,
    mtvs__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    mtvs__user_entry text DEFAULT "current_user"() NOT NULL,
    mtvs__status character(1) DEFAULT '-'::text NOT NULL
);


ALTER TABLE public.mtvs OWNER TO source;

--
-- Name: mtvs_mtvs__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('mtvs', 'mtvs__sequence'), 1, false);


--
-- Name: mvac_label; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mvac_label (
    perms integer NOT NULL,
    label text
);


ALTER TABLE public.mvac_label OWNER TO source;

--
-- Name: mvac_sessions; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mvac_sessions (
    sid text DEFAULT ''::text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    val text,
    changed character varying(14) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.mvac_sessions OWNER TO source;

--
-- Name: mvac_user; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE mvac_user (
    uid text NOT NULL,
    username text DEFAULT ''::text NOT NULL,
    userdesc text DEFAULT ''::text NOT NULL,
    "password" text DEFAULT ''::text NOT NULL,
    perms text,
    email text DEFAULT ''::text
);


ALTER TABLE public.mvac_user OWNER TO source;

--
-- Name: note; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE note (
    note_patn__sequence integer,
    note_desc text,
    note__sequence integer DEFAULT nextval('"note_note__sequence_seq"'::text) NOT NULL,
    note__timestamp timestamp without time zone DEFAULT now(),
    note__user_entry text DEFAULT "current_user"(),
    note__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.note OWNER TO source;

--
-- Name: note_note__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE note_note__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.note_note__sequence_seq OWNER TO source;

--
-- Name: note_note__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('note_note__sequence_seq', 18529, true);


--
-- Name: notv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW notv AS
    SELECT note.note_patn__sequence AS notv_patn__sequence, to_char(note.note__timestamp, 'Day DD-MM-YYYY HH:MM am'::text) AS notv_time, note.note_desc AS notv_desc, patn.patn_flno AS notv_patn_flno, ((patn.patn_psnam || ', '::text) || patn.patn_fsnam) AS notv_patn_desc, patn.patn_psnam AS notv_patn_psnam, patn.patn_fsnam AS notv_patn_fsnam, patn.patn_title AS notv_patn_title, short_date(patn.patn_dob) AS notv_patn_dob, patn.patn_address AS notv_patn_address, patn.patn_suburb AS notv_patn_suburb, patn.patn_state AS notv_patn_state, patn.patn_postcode AS notv_patn_postcode, patn.patn_phone AS notv_patn_phone, patn.patn_country AS notv_patn_country, patn.patn_aboriginality AS notv_patn_aboriginality, patn.patn_sex AS notv_patn_sex, patn.patn_marital AS notv_patn_marital, patn.patn_accl_code AS notv_patn_accl_code, patn.patn_accommodation AS notv_patn_accommodation, patn.patn_care AS notv_patn_care, note.note__sequence AS notv__sequence, note.note__timestamp AS notv__timestamp, note.note__user_entry AS notv__user_entry, note.note__status AS notv__status FROM (note LEFT JOIN patn ON ((note.note_patn__sequence = patn.patn__sequence)));


ALTER TABLE public.notv OWNER TO source;

--
-- Name: pate; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE pate (
    pate_patn__sequence integer,
    pate__sequence serial NOT NULL,
    pate__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    pate__user_entry text DEFAULT "current_user"() NOT NULL,
    pate__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.pate OWNER TO source;

--
-- Name: pate_pate__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('pate', 'pate__sequence'), 20338, true);


--
-- Name: patf; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE patf (
    patf_code text NOT NULL,
    patf_desc text,
    patf__sequence integer DEFAULT nextval('"patf_patf__sequence_seq"'::text) NOT NULL,
    patf__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    patf__user_entry text DEFAULT "current_user"() NOT NULL,
    patf__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.patf OWNER TO source;

--
-- Name: patf_patf__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE patf_patf__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.patf_patf__sequence_seq OWNER TO source;

--
-- Name: patf_patf__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('patf_patf__sequence_seq', 5, true);


--
-- Name: patn_patn__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE patn_patn__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.patn_patn__sequence_seq OWNER TO source;

--
-- Name: patn_patn__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('patn_patn__sequence_seq', 20342, true);


--
-- Name: patv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW patv AS
    SELECT patn.patn_flno AS patv_flno, patn.patn_psnam AS patv_psnam, patn.patn_fsnam AS patv_fsnam, patn.patn_title AS patv_title, short_date(patn.patn_dob) AS patv_dob, patn.patn_address AS patv_address, patn.patn_suburb AS patv_suburb, patn.patn_state AS patv_state, patn.patn_postcode AS patv_postcode, patn.patn_phone AS patv_phone, patn.patn_hlfd_code AS patv_hlfd_code, hlfd.hlfd_group AS patv_hlfd_group, hlfd.hlfd_desc AS patv_hlfd_desc, patn.patn_ins_level AS patv_ins_level, patn.patn_healthnumb AS patv_healthnumb, patn.patn_feet_code AS patv_feet_code, feet.feet_desc AS patv_feet_desc, patn.patn_medicare AS patv_medicare, patn.patn_healthcard AS patv_healthcard, patn.patn_dbtr_code AS patv_dbtr_code, dbtr.dbtr_name AS patv_dbtr_name, dbtr.dbtr_address AS patv_dbtr_address, dbtr.dbtr_suburb AS patv_dbtr_suburb, dbtr.dbtr_postcode AS patv_dbtr_postcode, dbtr.dbtr_state AS patv_dbtr_state, dbtr.dbtr_phone AS patv_dbtr_phone, patn.patn_empl_code AS patv_empl_code, empl.empl_name AS patv_empl_name, empl.empl_address AS patv_empl_address, empl.empl_suburb AS patv_empl_suburb, empl.empl_postcode AS patv_empl_postcode, empl.empl_state AS patv_empl_state, patn.patn_rfdr_code AS patv_rfdr_code, rfdr.rfdr_name AS patv_rfdr_name, rfdr.rfdr_street AS patv_rfdr_street, rfdr.rfdr_suburb AS patv_rfdr_suburb, rfdr.rfdr_postcode AS patv_rfdr_postcode, rfdr.rfdr_state AS patv_rfdr_state, rfdr.rfdr_provider AS patv_rfdr_provider, rfdr.rfdr_phone AS patv_rfdr_phone, rfdr.rfdr_salutation AS patv_rfdr_salutation, rfdr.rfdr_index AS patv_rfdr_index, short_date(patn.patn_ref_date) AS patv_ref_date, patn.patn_ref_period AS patv_ref_period, patn.patn_prov_code AS patv_prov_code, prov.prov_provider_num AS patv_prov_provider_num, prov.prov_name AS patv_prov_name, prov.prov_address AS patv_prov_address, prov.prov_suburb AS patv_prov_suburb, prov.prov_state AS patv_prov_state, prov.prov_postcode AS patv_prov_postcode, prov.prov_salutation AS patv_prov_salutation, prov.prov_phone AS patv_prov_phone, prov.prov_bank_code AS patv_prov_bank_code, patn.patn_country AS patv_country, patn.patn_aboriginality AS patv_aboriginality, patn.patn_sex AS patv_sex, patn.patn_marital AS patv_marital, patn.patn_accl_code AS patv_accl_code, patn.patn_accommodation AS patv_accommodation, patn.patn_care AS patv_care, patn.patn__sequence AS patv__sequence, patn.patn__timestamp AS patv__timestamp, patn.patn__user_entry AS patv__user_entry, patn.patn__status AS patv__status FROM ((((((patn LEFT JOIN rfdr ON ((patn.patn_rfdr_code = rfdr.rfdr_code))) LEFT JOIN hlfd ON ((patn.patn_hlfd_code = hlfd.hlfd_code))) LEFT JOIN feet ON ((patn.patn_feet_code = feet.feet_code))) LEFT JOIN dbtr ON ((patn.patn_dbtr_code = dbtr.dbtr_code))) LEFT JOIN empl ON ((patn.patn_empl_code = empl.empl_code))) LEFT JOIN prov ON ((patn.patn_prov_code = prov.prov_code)));


ALTER TABLE public.patv OWNER TO source;

--
-- Name: paym_paym__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE paym_paym__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.paym_paym__sequence_seq OWNER TO source;

--
-- Name: paym_paym__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('paym_paym__sequence_seq', 20267, true);


--
-- Name: pcde; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE pcde (
    pcde_postcode text,
    pcde_locality text,
    pcde_state text,
    pcde_comments text,
    pcde_delivery_office text,
    pcde_presort_indicator text,
    pcde_parcelzone text,
    pcde_bsp_number text,
    pcde_bsp_name text,
    pcde_category text,
    pcde__sequence serial NOT NULL,
    pcde__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    pcde__user_entry text DEFAULT "current_user"() NOT NULL,
    pcde__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.pcde OWNER TO source;

--
-- Name: pcde_pcde__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('pcde', 'pcde__sequence'), 16984, true);


--
-- Name: pemd; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW pemd AS
    SELECT ((((((((((((((((((((((((((((rpad(patn.patn_flno, 9) || rpad(CASE WHEN (patn.patn_title IS NOT NULL) THEN patn.patn_title WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 5)) || rpad(CASE WHEN (patn.patn_psnam IS NOT NULL) THEN patn.patn_psnam WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 30)) || rpad(CASE WHEN (patn.patn_fsnam IS NOT NULL) THEN patn.patn_fsnam WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 30)) || rpad(CASE WHEN (patn.patn_address IS NOT NULL) THEN patn.patn_address WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 40)) || rpad(CASE WHEN (patn.patn_suburb IS NOT NULL) THEN patn.patn_suburb WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 25)) || rpad(CASE WHEN (patn.patn_postcode IS NOT NULL) THEN patn.patn_postcode WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 4)) || rpad(CASE WHEN ((date(patn.patn_dob))::text IS NOT NULL) THEN (date(patn.patn_dob))::text WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 10)) || rpad(CASE WHEN (patn.patn_medicare IS NOT NULL) THEN patn.patn_medicare WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 12)) || rpad(CASE WHEN (patn.patn_medicare IS NOT NULL) THEN patn.patn_medicare WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 1)) || rpad(CASE WHEN (patn.patn_healthcard IS NOT NULL) THEN patn.patn_healthcard WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 14)) || rpad(CASE WHEN (patn.patn_healthcard IS NOT NULL) THEN patn.patn_healthcard WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 14)) || rpad(CASE WHEN (patn.patn_phone IS NOT NULL) THEN patn.patn_phone WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 14)) || rpad(CASE WHEN (patn.patn_phone IS NOT NULL) THEN patn.patn_phone WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 14)) || rpad(' '::text, 1)) || rpad((CASE WHEN (patn.patn_sex IS NOT NULL) THEN patn.patn_sex WHEN ('' IS NOT NULL) THEN ''::bpchar ELSE NULL::bpchar END)::text, 1)) || rpad(' '::text, 14)) || rpad(CASE WHEN (patn.patn_flno IS NOT NULL) THEN patn.patn_flno WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 10)) || rpad(' '::text, 9)) || rpad(' '::text, 1)) || rpad(' '::text, 100)) || rpad(CASE WHEN (rfdr.rfdr_name IS NOT NULL) THEN rfdr.rfdr_name WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 50)) || rpad(CASE WHEN ((date(patn.patn_ref_date))::text IS NOT NULL) THEN (date(patn.patn_ref_date))::text WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 10)) || rpad(CASE WHEN ((patn.patn_ref_period IS NULL) OR (patn.patn_ref_period = 99)) THEN '00'::text ELSE '12'::text END, 2)) || rpad(CASE WHEN (patn.patn_healthnumb IS NOT NULL) THEN patn.patn_healthnumb WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 20)) || rpad(CASE WHEN (hlfd.hlfd_desc IS NOT NULL) THEN hlfd.hlfd_desc WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END, 40)) || rpad(''::text, 10)) || rpad('N'::text, 1)) || rpad(' '::text, 14)) AS pemd_export, pate.pate_patn__sequence AS pemd__sequence, pate.pate__timestamp AS pemd__timestamp, pate.pate__user_entry AS pemd__user_entry, pate.pate__status AS pemd__status FROM (((pate JOIN patn ON ((patn.patn__sequence = pate.pate_patn__sequence))) LEFT JOIN hlfd ON ((hlfd.hlfd_code = patn.patn_hlfd_code))) LEFT JOIN rfdr ON ((rfdr.rfdr_code = patn.patn_rfdr_code)));


ALTER TABLE public.pemd OWNER TO source;

--
-- Name: pmsc; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW pmsc AS
    SELECT cred.cred_invc__sequence AS pmsc_invc__sequence, cred.cred_paym__sequence AS pmsc_paym__sequence, (cred.cred_amount + cred.cred_gst_amount) AS pmsc_total_amount, cred.cred_amount AS pmsc_amount, cred.cred_gst_amount AS pmsc_gst_amount, to_char(cred.cred__timestamp, 'YYYY-MM'::text) AS pmsc_month, cred.cred__sequence AS pmsc__sequence, '2001-10-10 12:57:53'::timestamp without time zone AS pmsc__timestamp, "current_user"() AS pmsc__user_entry, 'N'::text AS pmsc__status FROM cred;


ALTER TABLE public.pmsc OWNER TO source;

--
-- Name: pmsp; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW pmsp AS
    SELECT pmsc.pmsc_month AS pmsp_month, sum(pmsc.pmsc_amount) AS pmsp_amount, sum(pmsc.pmsc_gst_amount) AS pmsp_gst_amount, sum(pmsc.pmsc_total_amount) AS pmsp_total_amount, count(*) AS pmsp_count, max(pmsc.pmsc__sequence) AS pmsp__sequence, '2001-10-10 12:57:56'::timestamp without time zone AS pmsp__timestamp, "current_user"() AS pmsp__user_entry, 'N'::text AS pmsp__status FROM pmsc GROUP BY pmsc.pmsc_month;


ALTER TABLE public.pmsp OWNER TO source;

--
-- Name: prnt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE prnt (
    prnt_type integer,
    prnt_access integer,
    prnt_name text NOT NULL,
    prnt_desc text,
    prnt_command text,
    prnt__sequence integer DEFAULT nextval('"prnt_prnt__sequence_seq"'::text) NOT NULL,
    prnt__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    prnt__user_entry text DEFAULT "current_user"() NOT NULL,
    prnt__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.prnt OWNER TO source;

--
-- Name: prnt_prnt__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE prnt_prnt__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.prnt_prnt__sequence_seq OWNER TO source;

--
-- Name: prnt_prnt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('prnt_prnt__sequence_seq', 1, true);


--
-- Name: prov_prov__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE prov_prov__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.prov_prov__sequence_seq OWNER TO source;

--
-- Name: prov_prov__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('prov_prov__sequence_seq', 39, true);


--
-- Name: ptss; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW ptss AS
    SELECT to_char(svpf_patn.svpf_date_service, 'YYYY'::text) AS ptss_year_service, svpf_patn.svpf_serv_code AS ptss_serv_code, invc.invc_feet_code AS ptss_feet_code, svpf_patn.patn_hlfd_code AS ptss_hlfd_code, count(*) AS ptts_count, 1 AS ptss__sequence, now() AS ptss__timestamp, "current_user"() AS ptss__user_entry, 'V'::text AS ptss__status FROM ((svpf JOIN patn ON ((svpf.svpf_patn__sequence = patn.patn__sequence))) svpf_patn JOIN invc ON ((svpf_patn.svpf_invc__sequence = invc.invc__sequence))) GROUP BY to_char(svpf_patn.svpf_date_service, 'YYYY'::text), svpf_patn.svpf_serv_code, invc.invc_feet_code, svpf_patn.patn_hlfd_code, 6, now(), "current_user"(), 9;


ALTER TABLE public.ptss OWNER TO source;

--
-- Name: pyas; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE pyas (
    pyas_paym__sequence integer NOT NULL,
    pyas_svpf__sequence integer NOT NULL,
    pyas_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    pyas__sequence integer DEFAULT nextval('"pyas_pyas__sequence_seq"'::text) NOT NULL,
    pyas__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    pyas__user_entry text DEFAULT "current_user"() NOT NULL,
    pyas__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.pyas OWNER TO source;

--
-- Name: pyas_pyas__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE pyas_pyas__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.pyas_pyas__sequence_seq OWNER TO source;

--
-- Name: pyas_pyas__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('pyas_pyas__sequence_seq', 1, true);


--
-- Name: rfdr_rfdr__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE rfdr_rfdr__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.rfdr_rfdr__sequence_seq OWNER TO source;

--
-- Name: rfdr_rfdr__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('rfdr_rfdr__sequence_seq', 28804, true);


--
-- Name: ri_check; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW ri_check AS
    SELECT DISTINCT mtsv.mtsv_name AS ri_name, (((((((((((('select distinct '::text || quote_literal(mtsv.mtsv_key)) || '::text, '::text) || mtsv.mtsv_key) || ' from '::text) || mtsv.mtsv_master_class) || ' except select '::text) || quote_literal(mtsv.mtsv_key)) || '::text, '::text) || mtsv.mtsv_join) || ' from '::text) || mtsv.mtsv_other_class) || ';'::text) AS ri_sql FROM mtsv ORDER BY mtsv.mtsv_name, (((((((((((('select distinct '::text || quote_literal(mtsv.mtsv_key)) || '::text, '::text) || mtsv.mtsv_key) || ' from '::text) || mtsv.mtsv_master_class) || ' except select '::text) || quote_literal(mtsv.mtsv_key)) || '::text, '::text) || mtsv.mtsv_join) || ' from '::text) || mtsv.mtsv_other_class) || ';'::text);


ALTER TABLE public.ri_check OWNER TO source;

--
-- Name: ri_count; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW ri_count AS
    SELECT pg_trigger.tgconstrname, count(*) AS count FROM pg_trigger, pg_class ctrig WHERE ((((pg_trigger.tgname ~ '^RI_'::text) AND (pg_trigger.tgisconstraint IS TRUE)) AND (((pg_trigger.tgtype = 9) OR (pg_trigger.tgtype = 17)) OR (pg_trigger.tgtype = 21))) AND (pg_trigger.tgrelid = ctrig.oid)) GROUP BY pg_trigger.tgconstrname;


ALTER TABLE public.ri_count OWNER TO source;

--
-- Name: sclt; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE sclt (
    sclt_date date,
    sclt_patn_name text,
    sclt_dc text,
    sclt_prov_code text,
    sclt_prov_name text,
    sclt_type text,
    sclt_desc text,
    sclt_invc__sequence integer,
    sclt_debit numeric(12,2),
    sclt_gst_debit numeric(12,2),
    sclt_credit numeric(12,2),
    sclt_gst_credit numeric(12,2),
    sclt_total_amount numeric(12,2),
    sclt__sequence serial NOT NULL,
    sclt__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    sclt__user_entry text DEFAULT "current_user"() NOT NULL,
    sclt__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.sclt OWNER TO source;

--
-- Name: sclt_sclt__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sclt', 'sclt__sequence'), 1, false);


--
-- Name: serv_serv__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE serv_serv__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.serv_serv__sequence_seq OWNER TO source;

--
-- Name: serv_serv__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('serv_serv__sequence_seq', 6106, true);


--
-- Name: ssms; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW ssms AS
    SELECT svpf.svpf_serv_code AS ssms_serv_code, (svpf.svpf_amount + svpf.svpf_gst_amount) AS ssms_total_amount, svpf.svpf_amount AS ssms_amount, svpf.svpf_gst_amount AS ssms_gst_amount, to_char(svpf.svpf_date_service, 'YYYY-MM'::text) AS ssms_month, svpf.svpf_date_service AS ssms_date_service, svpf.svpf__sequence AS ssms__sequence, '2001-10-10 12:57:59'::timestamp without time zone AS ssms__timestamp, "current_user"() AS ssms__user_entry, 'N'::text AS ssms__status FROM svpf;


ALTER TABLE public.ssms OWNER TO source;

--
-- Name: ssmc; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW ssmc AS
    SELECT ssms.ssms_month AS ssmc_month, ssms.ssms_serv_code AS ssmc_serv_code, sum(ssms.ssms_amount) AS ssmc_amount, sum(ssms.ssms_gst_amount) AS ssmc_gst_amount, sum(ssms.ssms_total_amount) AS ssmc_total_amount, count(*) AS ssmc_count, max(ssms.ssms__sequence) AS ssmc__sequence, '2001-10-10 12:58:05'::timestamp without time zone AS ssmc__timestamp, "current_user"() AS ssmc__user_entry, 'N'::text AS ssmc__status FROM ssms GROUP BY ssms.ssms_month, ssms.ssms_serv_code;


ALTER TABLE public.ssmc OWNER TO source;

--
-- Name: ssmp; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW ssmp AS
    SELECT ssms.ssms_month AS ssmp_month, sum(ssms.ssms_amount) AS ssmp_amount, sum(ssms.ssms_gst_amount) AS ssmp_gst_amount, sum(ssms.ssms_total_amount) AS ssmp_total_amount, count(*) AS ssmp_count, max(ssms.ssms__sequence) AS ssmp__sequence, '2001-10-10 12:58:02'::timestamp without time zone AS ssmp__timestamp, "current_user"() AS ssmp__user_entry, 'N'::text AS ssmp__status FROM ssms GROUP BY ssms.ssms_month;


ALTER TABLE public.ssmp OWNER TO source;

--
-- Name: stts; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE stts (
    stts_epsdserl integer,
    stts_start_date timestamp without time zone,
    stts_account_class text,
    stts_accom_type text,
    stts_care_type text,
    stts__sequence integer DEFAULT nextval('"stts_stts__sequence_seq"'::text) NOT NULL,
    stts__timestamp timestamp without time zone DEFAULT now(),
    stts__user_entry text DEFAULT "current_user"(),
    stts__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.stts OWNER TO source;

--
-- Name: stts_stts__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE stts_stts__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.stts_stts__sequence_seq OWNER TO source;

--
-- Name: stts_stts__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('stts_stts__sequence_seq', 1, true);


--
-- Name: surg; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE surg (
    surg_patn__sequence integer,
    surg_symptoms text,
    surg_class text,
    surg_diag_codes text,
    surg_diagnosis text,
    surg_treatment text,
    surg_oprn_codes text,
    surg_operation text,
    surg_oprn_date timestamp without time zone,
    surg_oprn_place text,
    surg_photo_code text,
    surg__sequence serial NOT NULL,
    surg__timestamp timestamp without time zone DEFAULT now(),
    surg__user_entry text DEFAULT "current_user"(),
    surg__status character(1) DEFAULT 'N'::text
);


ALTER TABLE public.surg OWNER TO source;

--
-- Name: surg_surg__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('surg', 'surg__sequence'), 15197, true);


--
-- Name: surv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW surv AS
    SELECT patn.patn_psnam AS surv_psnam, patn.patn_fsnam AS surv_fsnam, short_date(patn.patn_dob) AS surv_dob, surg.surg_symptoms AS surv_symptoms, surg.surg_class AS surv_class, surg.surg_diag_codes AS surv_diag_codes, surg.surg_diagnosis AS surv_diagnosis, surg.surg_treatment AS surv_treatment, surg.surg_oprn_codes AS surv_oprn_codes, surg.surg_operation AS surv_operation, surg.surg_oprn_date AS surv_oprn_date, surg.surg_oprn_place AS surv_oprn_place, surg.surg_photo_code AS surv_photo_code, surg.surg__sequence AS surv__sequence, surg.surg__timestamp AS surv__timestamp, surg.surg__user_entry AS surv__user_entry, surg.surg__status AS surv__status FROM (surg LEFT JOIN patn ON ((surg.surg_patn__sequence = patn.patn__sequence)));


ALTER TABLE public.surv OWNER TO source;

--
-- Name: svlt; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW svlt AS
    SELECT date(svpf.svpf_date_service) AS svlt_date_service, svpf.svpf_date_service AS svlt_ts_service, CASE WHEN (svpf.svpf_serv_code ~* '/i$'::text) THEN ("substring"(svpf.svpf_serv_code, 1, (length(svpf.svpf_serv_code) - 2)) || '*'::text) ELSE svpf.svpf_serv_code END AS svlt_serv_code, svpf.svpf_percentage AS svlt_percentage, svpf.svpf_desc AS svlt_desc, svpf.svpf_amount AS svlt_amount, svpf.svpf_gst_amount AS svlt_gst_amount, (svpf.svpf_amount + svpf.svpf_gst_amount) AS svlt_total_amount, svpf.svpf_patn__sequence AS svlt_patn__sequence, invc.invc__sequence AS svlt_invc__sequence, invc.invc_date_printed AS svlt_invc_date_printed, invc.invc_date_reprint AS svlt_invc_date_reprint, invc.invc_amount AS svlt_invc_amount, invc.invc_gst_amount AS svlt_invc_gst_amount, (invc.invc_paid_amount + invc.invc_paid_gst_amount) AS svlt_invc_credits, cred_summary(invc.invc__sequence, 3) AS svlt_cred_summary, (((invc.invc_amount + invc.invc_gst_amount) - invc.invc_paid_amount) - invc.invc_paid_gst_amount) AS svlt_invc_balance, CASE WHEN (invc.invc_date_printed IS NULL) THEN (now())::date ELSE date(invc.invc_date_printed) END AS svlt_date_printed, CASE WHEN (invc.invc_date_printed IS NULL) THEN NULL::date ELSE (now())::date END AS svlt_date_reprint, CASE WHEN (invc.invc_rfdr_date IS NULL) THEN NULL::date ELSE date(invc.invc_rfdr_date) END AS svlt_rfdr_date, CASE WHEN (invc.invc_rfdr_period = '99'::text) THEN 'Indefinite'::text WHEN ((invc.invc_rfdr_period IS NULL) OR (invc.invc_rfdr_period = '0'::text)) THEN ''::text ELSE (invc.invc_rfdr_period || ' Months'::text) END AS svlt_rfdr_period, ((COALESCE(patn.patn_fsnam, ''::text) || ' '::text) || COALESCE(patn.patn_psnam, ''::text)) AS svlt_patn_name, patn.patn_address AS svlt_patn_address, ((COALESCE(patn.patn_suburb, ''::text) || ' '::text) || COALESCE(patn.patn_postcode, ''::text)) AS svlt_patn_suburb, patn.patn_state AS svlt_patn_state, patn.patn_postcode AS svlt_patn_postcode, short_date(patn.patn_dob) AS svlt_patn_dob, patn.patn_hlfd_code AS svlt_patn_hlfd_code, patn.patn_ins_level AS svlt_patn_ins_level, patn.patn_healthnumb AS svlt_patn_healthnumb, patn.patn_medicare AS svlt_patn_medicare, patn.patn_healthcard AS svlt_patn_healthcard, patn.patn_patf_code AS svlt_patn_patf_code, dbtr_address(dbtr.dbtr_code) AS svlt_dbtr_full_address, dbtr.dbtr_name AS svlt_dbtr_name, dbtr.dbtr_address AS svlt_dbtr_address, ((COALESCE(dbtr.dbtr_suburb, ''::text) || ' '::text) || COALESCE(dbtr.dbtr_postcode, ''::text)) AS svlt_dbtr_suburb, dbtr.dbtr_state AS svlt_dbtr_state, rfdr.rfdr_code AS svlt_rfdr_code, rfdr.rfdr_name AS svlt_rfdr_name, rfdr.rfdr_street AS svlt_rfdr_street, rfdr.rfdr_suburb AS svlt_rfdr_suburb, rfdr.rfdr_postcode AS svlt_rfdr_postcode, rfdr.rfdr_state AS svlt_rfdr_state, rfdr.rfdr_provider AS svlt_rfdr_provider, rfdr.rfdr_phone AS svlt_rfdr_phone, rfdr.rfdr_salutation AS svlt_rfdr_salutation, rfdr.rfdr_index AS svlt_rfdr_index, empl.empl_code AS svlt_empl_code, empl.empl_name AS svlt_empl_name, empl.empl_address AS svlt_empl_address, empl.empl_suburb AS svlt_empl_suburb, empl.empl_postcode AS svlt_empl_postcode, empl.empl_state AS svlt_empl_state, feet.feet_code AS svlt_feet_code, feet.feet_desc AS svlt_feet_desc, prov.prov_code AS svlt_prov_code, prov.prov_provider_num AS svlt_prov_provider_num, prov.prov_name AS svlt_prov_name, prov.prov_address AS svlt_prov_address, prov.prov_suburb AS svlt_prov_suburb, prov.prov_state AS svlt_prov_state, prov.prov_postcode AS svlt_prov_postcode, prov.prov_salutation AS svlt_prov_salutation, prov.prov_phone AS svlt_prov_phone, prov.prov_bank_code AS svlt_prov_bank_code, svpf.svpf__sequence AS svlt__sequence, svpf.svpf__timestamp AS svlt__timestamp, svpf.svpf__user_entry AS svlt__user_entry, svpf.svpf__status AS svlt__status FROM svpf, invc, patn, dbtr, rfdr, empl, feet, prov WHERE (((((((svpf.svpf_invc__sequence = invc.invc__sequence) AND (invc.invc_dbtr_code = dbtr.dbtr_code)) AND (invc.invc_patn__sequence = patn.patn__sequence)) AND (invc.invc_rfdr_code = rfdr.rfdr_code)) AND (invc.invc_feet_code = feet.feet_code)) AND (invc.invc_prov_code = prov.prov_code)) AND (invc.invc_empl_code = empl.empl_code));


ALTER TABLE public.svlt OWNER TO source;

--
-- Name: svpf_svpf__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE svpf_svpf__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.svpf_svpf__sequence_seq OWNER TO source;

--
-- Name: svpf_svpf__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('svpf_svpf__sequence_seq', 142010, true);


--
-- Name: svpv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW svpv AS
    SELECT date(svpf.svpf_date_service) AS svpv_date_service, svpf.svpf_date_service AS svpv_ts_service, CASE WHEN (svpf.svpf_serv_code ~* '/i$'::text) THEN ("substring"(svpf.svpf_serv_code, 1, (length(svpf.svpf_serv_code) - 2)) || '*'::text) ELSE svpf.svpf_serv_code END AS svpv_serv_code, svpf.svpf_percentage AS svpv_percentage, svpf.svpf_desc AS svpv_desc, svpf.svpf_amount AS svpv_amount, svpf.svpf_gst_amount AS svpv_gst_amount, (svpf.svpf_amount + svpf.svpf_gst_amount) AS svpv_total_amount, svpf.svpf_patn__sequence AS svpv_patn__sequence, invc.invc__sequence AS svpv_invc__sequence, invc.invc_date_printed AS svpv_invc_date_printed, invc.invc_date_reprint AS svpv_invc_date_reprint, invc.invc_amount AS svpv_invc_amount, invc.invc_gst_amount AS svpv_invc_gst_amount, (invc.invc_paid_amount + invc.invc_paid_gst_amount) AS svpv_invc_credits, cred_summary(invc.invc__sequence, 3) AS svpv_cred_summary, (((invc.invc_amount + invc.invc_gst_amount) - invc.invc_paid_amount) - invc.invc_paid_gst_amount) AS svpv_invc_balance, CASE WHEN (invc.invc_date_printed IS NULL) THEN (now())::date ELSE date(invc.invc_date_printed) END AS svpv_date_printed, CASE WHEN (invc.invc_date_printed IS NULL) THEN NULL::date ELSE (now())::date END AS svpv_date_reprint, CASE WHEN (invc.invc_rfdr_date IS NULL) THEN NULL::date ELSE date(invc.invc_rfdr_date) END AS svpv_rfdr_date, CASE WHEN (invc.invc_rfdr_period = '99'::text) THEN 'Indefinite'::text WHEN ((invc.invc_rfdr_period IS NULL) OR (invc.invc_rfdr_period = '0'::text)) THEN ''::text ELSE (invc.invc_rfdr_period || ' Months'::text) END AS svpv_rfdr_period, hlfd.hlfd_desc AS svpv_hlfd_desc, invc.invc_ins_level AS svpv_invc_ins_level, invc.invc_healthnumb AS svpv_invc_healthnumb, invc.invc_healthcard AS svpv_invc_healthcard, invc.invc_medicare AS svpv_invc_medicare, invc.invc_claim_number AS svpv_invc_claim_number, date(invc.invc_accident_date) AS svpv_invc_accident_date, invc.invc_reference_1 AS svpv_invc_reference_1, invc.invc_reference_2 AS svpv_invc_reference_2, invc.invc_reference_3 AS svpv_invc_reference_3, ((COALESCE(patn.patn_fsnam, ''::text) || ' '::text) || COALESCE(patn.patn_psnam, ''::text)) AS svpv_patn_name, patn.patn_address AS svpv_patn_address, ((COALESCE(patn.patn_suburb, ''::text) || ' '::text) || COALESCE(patn.patn_postcode, ''::text)) AS svpv_patn_suburb, patn.patn_state AS svpv_patn_state, patn.patn_postcode AS svpv_patn_postcode, short_date(patn.patn_dob) AS svpv_patn_dob, patn.patn_hlfd_code AS svpv_patn_hlfd_code, patn.patn_ins_level AS svpv_patn_ins_level, patn.patn_healthnumb AS svpv_patn_healthnumb, patn.patn_medicare AS svpv_patn_medicare, patn.patn_healthcard AS svpv_patn_healthcard, patn.patn_patf_code AS svpv_patn_patf_code, patn.patn_claim_number AS svpv_patn_claim_number, date(patn.patn_accident_date) AS svpv_patn_accident_date, dbtr_address(dbtr.dbtr_code) AS svpv_dbtr_full_address, dbtr.dbtr_name AS svpv_dbtr_name, dbtr.dbtr_address AS svpv_dbtr_address, ((COALESCE(dbtr.dbtr_suburb, ''::text) || ' '::text) || COALESCE(dbtr.dbtr_postcode, ''::text)) AS svpv_dbtr_suburb, dbtr.dbtr_state AS svpv_dbtr_state, rfdr.rfdr_code AS svpv_rfdr_code, rfdr.rfdr_name AS svpv_rfdr_name, rfdr.rfdr_street AS svpv_rfdr_street, rfdr.rfdr_suburb AS svpv_rfdr_suburb, rfdr.rfdr_postcode AS svpv_rfdr_postcode, rfdr.rfdr_state AS svpv_rfdr_state, CASE WHEN ((rfdr.rfdr_provider IS NULL) OR (length(rfdr.rfdr_provider) < 1)) THEN ((((((COALESCE(rfdr.rfdr_street, ''::text) || ','::text) || COALESCE(rfdr.rfdr_suburb, ''::text)) || ' '::text) || COALESCE(rfdr.rfdr_postcode, ''::text)) || ' '::text) || COALESCE(rfdr.rfdr_state, ''::text)) ELSE rfdr.rfdr_provider END AS svpv_rfdr_provider, rfdr.rfdr_phone AS svpv_rfdr_phone, rfdr.rfdr_salutation AS svpv_rfdr_salutation, rfdr.rfdr_index AS svpv_rfdr_index, empl.empl_code AS svpv_empl_code, empl.empl_name AS svpv_empl_name, empl.empl_address AS svpv_empl_address, empl.empl_suburb AS svpv_empl_suburb, empl.empl_postcode AS svpv_empl_postcode, empl.empl_state AS svpv_empl_state, feet.feet_code AS svpv_feet_code, feet.feet_desc AS svpv_feet_desc, prov.prov_code AS svpv_prov_code, prov.prov_provider_num AS svpv_prov_provider_num, prov.prov_name AS svpv_prov_name, prov.prov_address AS svpv_prov_address, prov.prov_suburb AS svpv_prov_suburb, prov.prov_state AS svpv_prov_state, prov.prov_postcode AS svpv_prov_postcode, prov.prov_salutation AS svpv_prov_salutation, prov.prov_phone AS svpv_prov_phone, prov.prov_bank_code AS svpv_prov_bank_code, svpv_form(patn.patn_patf_code, feet.feet_code) AS svpv_form_code, svpf.svpf__sequence AS svpv__sequence, svpf.svpf__timestamp AS svpv__timestamp, svpf.svpf__user_entry AS svpv__user_entry, svpf.svpf__status AS svpv__status FROM ((((((((svpf LEFT JOIN invc ON ((svpf.svpf_invc__sequence = invc.invc__sequence))) LEFT JOIN patn ON ((invc.invc_patn__sequence = patn.patn__sequence))) LEFT JOIN dbtr ON ((invc.invc_dbtr_code = dbtr.dbtr_code))) LEFT JOIN rfdr ON ((invc.invc_rfdr_code = rfdr.rfdr_code))) LEFT JOIN empl ON ((invc.invc_empl_code = empl.empl_code))) LEFT JOIN feet ON ((invc.invc_feet_code = feet.feet_code))) LEFT JOIN prov ON ((invc.invc_prov_code = prov.prov_code))) LEFT JOIN hlfd ON ((invc.invc_hlfd_code = hlfd.hlfd_code)));


ALTER TABLE public.svpv OWNER TO source;

--
-- Name: svrv; Type: VIEW; Schema: public; Owner: source
--

CREATE VIEW svrv AS
    SELECT date(svpf.svpf_date_service) AS svrv_date_service, svpf.svpf_date_service AS svrv_ts_service, CASE WHEN (svpf.svpf_serv_code ~* '/i$'::text) THEN ("substring"(svpf.svpf_serv_code, 1, (length(svpf.svpf_serv_code) - 2)) || '*'::text) ELSE svpf.svpf_serv_code END AS svrv_serv_code, svpf.svpf_percentage AS svrv_percentage, svpf.svpf_desc AS svrv_desc, svpf.svpf_amount AS svrv_amount, svpf.svpf_gst_amount AS svrv_gst_amount, (svpf.svpf_amount + svpf.svpf_gst_amount) AS svrv_total_amount, svpf.svpf_patn__sequence AS svrv_patn__sequence, ((CASE WHEN (patn.patn_fsnam IS NOT NULL) THEN patn.patn_fsnam WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END || ' '::text) || CASE WHEN (patn.patn_psnam IS NOT NULL) THEN patn.patn_psnam WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END) AS svrv_patn_name, patn.patn_address AS svrv_patn_address, ((CASE WHEN (patn.patn_suburb IS NOT NULL) THEN patn.patn_suburb WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END || ' '::text) || CASE WHEN (patn.patn_postcode IS NOT NULL) THEN patn.patn_postcode WHEN ('' IS NOT NULL) THEN ''::text ELSE NULL::text END) AS svrv_patn_suburb, patn.patn_state AS svrv_patn_state, patn.patn_postcode AS svrv_patn_postcode, short_date(patn.patn_dob) AS svrv_patn_dob, patn.patn_hlfd_code AS svrv_patn_hlfd_code, patn.patn_ins_level AS svrv_patn_ins_level, patn.patn_healthnumb AS svrv_patn_healthnumb, patn.patn_medicare AS svrv_patn_medicare, patn.patn_healthcard AS svrv_patn_healthcard, patn.patn_patf_code AS svrv_patn_patf_code, patn.patn_claim_number AS svrv_patn_claim_number, date(patn.patn_accident_date) AS svrv_patn_accident_date, svpf.svpf__sequence AS svrv__sequence, svpf.svpf__timestamp AS svrv__timestamp, svpf.svpf__user_entry AS svrv__user_entry, svpf.svpf__status AS svrv__status FROM svpf, patn WHERE (svpf.svpf_patn__sequence = patn.patn__sequence);


ALTER TABLE public.svrv OWNER TO source;

--
-- Name: svsm; Type: TABLE; Schema: public; Owner: source; Tablespace: 
--

CREATE TABLE svsm (
    svsm_date_start timestamp without time zone DEFAULT now() NOT NULL,
    svsm_date_end timestamp without time zone DEFAULT now() NOT NULL,
    svsm_type text DEFAULT '-'::text NOT NULL,
    svsm_prov_code text DEFAULT '-'::text NOT NULL,
    svsm_prov_name text,
    svsm_count integer DEFAULT 0 NOT NULL,
    svsm_serv_code text DEFAULT '-'::text NOT NULL,
    svsm_desc text,
    svsm_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    svsm_gst_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    svsm__sequence serial NOT NULL,
    svsm__timestamp timestamp without time zone DEFAULT now() NOT NULL,
    svsm__user_entry text DEFAULT "current_user"() NOT NULL,
    svsm__status character(1) DEFAULT 'N'::text NOT NULL
);


ALTER TABLE public.svsm OWNER TO source;

--
-- Name: svsm_svsm__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('svsm', 'svsm__sequence'), 1, false);


--
-- Name: tdtp_tdtp__sequence_seq; Type: SEQUENCE; Schema: public; Owner: source
--

CREATE SEQUENCE tdtp_tdtp__sequence_seq
    INCREMENT BY 1
    MAXVALUE 2147483647
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tdtp_tdtp__sequence_seq OWNER TO source;

--
-- Name: tdtp_tdtp__sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: source
--

SELECT pg_catalog.setval('tdtp_tdtp__sequence_seq', 13, true);


--
-- Data for Name: accl; Type: TABLE DATA; Schema: public; Owner: source
--

COPY accl (accl_code, accl_desc, accl__sequence, accl__timestamp, accl__user_entry, accl__status) FROM stdin;
-	\N	10	2005-01-30 12:06:29.897101	source	N
\.


--
-- Data for Name: addr; Type: TABLE DATA; Schema: public; Owner: source
--

COPY addr (addr_name, addr_contact, addr_organisation, addr_work_phone, addr_work_fax, addr_mobile_phone, addr_work_email, addr_work_www, addr_work_im, addr_work_street, addr_work_suburb, addr_work_postcode, addr_home_email, addr_home_www, addr_home_im, addr_home_street, addr_home_suburb, addr_home_postcode, addr_home_phone, addr_home_fax, addr_comments, addr__sequence, addr__timestamp, addr__user_entry, addr__status) FROM stdin;
\.


--
-- Data for Name: apst; Type: TABLE DATA; Schema: public; Owner: source
--

COPY apst (apst_code, apst_desc, apst_colour, apst__sequence, apst__timestamp, apst__user_entry, apst__status) FROM stdin;
-	Default	#FF0000	0	2003-04-18 16:06:07.971671	source	N
SN	Seen	#ff00ff00	3	2004-08-25 10:27:25.267939	source	N
AT	Attended	#ffffff00	2	2004-07-21 09:24:57.338925	source	N
BL	Billed	#ff5555ff	4	2004-08-25 13:46:24.721543	source	N
DNA	Did not attend	#ffffaaff	5	2004-09-03 15:16:36.555807	source	N
\.


--
-- Data for Name: aptd; Type: TABLE DATA; Schema: public; Owner: source
--

COPY aptd (aptd_aptp_code, aptd_desc, aptd_colour, aptd_prov_code, aptd_locn_code, aptd_dayofweek, aptd_weekofyear, aptd_dayofmonth, aptd_monthofyear, aptd_year, aptd_parallel, aptd_skip, aptd_start_date, aptd_end_date, aptd_recurrence, aptd_starting, aptd_ending, aptd__sequence, aptd__timestamp, aptd__user_entry, aptd__status) FROM stdin;
\.


--
-- Data for Name: aptp; Type: TABLE DATA; Schema: public; Owner: source
--

COPY aptp (aptp_code, aptp_desc, aptp_colour, aptp_duration, aptp_disable, aptp__sequence, aptp__timestamp, aptp__user_entry, aptp__status) FROM stdin;
-	Default	#00d3d3d3	15	0	1	2005-01-13 11:21:58.068882	source	N
OP	Review	#00ffaa00	15	0	3	2005-01-13 15:04:24.916903	source	N
NP	New Patient	#0055ff00	15	0	2	2005-01-13 11:22:57.238465	source	N
PR	Procedure	#000055ff	15	0	4	2005-01-13 15:04:33.680944	source	N
MLR	Medico-Legal	#00ffff00	15	0	7	2005-01-14 11:52:00.110377	mell	N
ROC	Removal of Cast	#00aaaa7f	15	0	8	2005-01-14 14:21:06.485049	mell	N
PO	Post OP	#00ff00ff	15	0	6	2005-01-13 15:36:51.650494	mell	N
MISC	Miscellaneous	#0000ffff	15	0	9	2005-01-14 15:20:45.685666	mell	N
BLK 2	BLOCK	#00ff0000	30	0	10	2005-01-17 15:07:50.443764	mell	N
BLK	BLOCK	#00ff0000	60	0	5	2005-01-13 15:05:04.680884	source	N
\.


--
-- Data for Name: bank; Type: TABLE DATA; Schema: public; Owner: source
--

COPY bank (bank_code, bank_name, bank_address, bank_suburb, bank_state, bank_postcode, bank_phone, bank_bank, bank_branch, bank_account, bank__sequence, bank__timestamp, bank__user_entry, bank__status) FROM stdin;
-	\N	\N	\N	\N	\N	\N	\N	\N	\N	20	2005-01-30 12:06:30.39238	source	N
\.


--
-- Data for Name: bkdp; Type: TABLE DATA; Schema: public; Owner: source
--

COPY bkdp (bkdp_date_created, bkdp_date_printed, bkdp_user_printed, bkdp_bank_code, bkdp_desc, bkdp_amount, bkdp__sequence, bkdp__timestamp, bkdp__user_entry, bkdp__status) FROM stdin;
\.


--
-- Data for Name: cash; Type: TABLE DATA; Schema: public; Owner: source
--

COPY cash (cash_paym__sequence, cash_bank_code, cash_date, cash_amount, cash_text, cash__sequence, cash__timestamp, cash__user_entry, cash__status) FROM stdin;
\.


--
-- Data for Name: clsp; Type: TABLE DATA; Schema: public; Owner: source
--

COPY clsp (clsp_code, clsp_desc, clsp__sequence, clsp__timestamp, clsp__user_entry, clsp__status) FROM stdin;
-	\N	10	2005-01-30 12:06:30.62727	source	N
\.


--
-- Data for Name: clst; Type: TABLE DATA; Schema: public; Owner: source
--

COPY clst (clst_serv_code_parent, clst_serv_code_child, clst_feet_code, clst__sequence, clst__timestamp, clst__user_entry, clst__status) FROM stdin;
\.


--
-- Data for Name: cnrt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY cnrt (cnrt_patn__sequence, cnrt_amount, ctrt_period, cnrt_count, cnrt_start_date, cnrt_serv_code, cnrt_first_installment, cnrt_other_installment, cnrt_last_date, cnrt_balance, cnrt_end_date, cnrt__sequence, cnrt__timestamp, cnrt__user_entry, cnrt__status) FROM stdin;
\.


--
-- Data for Name: cnty; Type: TABLE DATA; Schema: public; Owner: source
--

COPY cnty (cnty_code, cnty_desc, cnty__sequence, cnty__timestamp, cnty__user_entry, cnty__status) FROM stdin;
-	\N	10	2005-01-30 12:06:30.861075	source	N
\.


--
-- Data for Name: conf; Type: TABLE DATA; Schema: public; Owner: source
--

COPY conf (conf_code, conf_desc, conf_value, conf_type, conf_scope, conf_access, conf__sequence, conf__timestamp, conf__user_entry, conf__status) FROM stdin;
-	\N	\N	0	\N	\N	0	2001-10-11 07:37:49	source	N
\.


--
-- Data for Name: cred; Type: TABLE DATA; Schema: public; Owner: source
--

COPY cred (cred_paym__sequence, cred_invc__sequence, cred_amount, cred_gst_amount, cred__sequence, cred__timestamp, cred__user_entry, cred__status, cred_notes) FROM stdin;
\.


--
-- Data for Name: crsm; Type: TABLE DATA; Schema: public; Owner: source
--

COPY crsm (crsm_date_start, crsm_date_end, crsm_type, crsm_prov_code, crsm_prov_name, crsm_count, crsm_tdtp_code, crsm_desc, crsm_amount, crsm_gst_amount, crsm__sequence, crsm__timestamp, crsm__user_entry, crsm__status) FROM stdin;
\.


--
-- Data for Name: dbtr; Type: TABLE DATA; Schema: public; Owner: source
--

COPY dbtr (dbtr_code, dbtr_name, dbtr_address, dbtr_suburb, dbtr_postcode, dbtr_state, dbtr_phone, dbtr_group, dbtr_last_statement, dbtr_delay_statement, dbtr__sequence, dbtr__timestamp, dbtr__user_entry, dbtr__status, dbtr_amount_outstanding, dbtr_first_statement) FROM stdin;
-	\N	\N	\N	\N	\N	\N	\N	\N	1 mon	112183	2005-01-30 12:06:31.157121	source	N	87.00	40 days
\.


--
-- Data for Name: diag; Type: TABLE DATA; Schema: public; Owner: source
--

COPY diag (diag_epsdserl, diag_type, diag_icd9, diag_date_start, diag_date_end, diag_desc, diag__sequence, diag__timestamp, diag__user_entry, diag__status) FROM stdin;
\.


--
-- Data for Name: docs; Type: TABLE DATA; Schema: public; Owner: source
--

COPY docs (docs_patn__sequence, docs_url, docs_title, docs__sequence, docs__timestamp, docs__user_entry, docs__status) FROM stdin;
\.


--
-- Data for Name: eftr; Type: TABLE DATA; Schema: public; Owner: source
--

COPY eftr (eftr_date_created, eftr_first__sequence, eftr_last__sequence, eftr__sequence, eftr__timestamp, eftr__user_entry, eftr__status) FROM stdin;
\.


--
-- Data for Name: empl; Type: TABLE DATA; Schema: public; Owner: source
--

COPY empl (empl_code, empl_name, empl_address, empl_suburb, empl_postcode, empl_state, empl__sequence, empl__timestamp, empl__user_entry, empl__status) FROM stdin;
-	\N	\N	\N	\N	\N	10	2005-01-30 12:06:31.664671	source	N
\.


--
-- Data for Name: epsd; Type: TABLE DATA; Schema: public; Owner: source
--

COPY epsd (epsd_admit_date, epsd_admit_criteria, epsd_admit_type, epsd_admit_source, epsd_neonate_weight, epsd_trans_source, epsd_healthfund, epsd_ins_level, epsd_speciality, epsd_lvday_month, epsd_lvday_finyr, epsd_lvday_total, epsd_sepn_date, epsd_sepn_type, epsd_sepn_transfer, epsd_re_admit, epsd_user_flag_sepn, epsd_study, epsd_user_flag_diag, epsd_patn__sequence, epsd__sequence, epsd__timestamp, epsd__user_entry, epsd__status) FROM stdin;
\.


--
-- Data for Name: evnt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY evnt (evnt_patn__sequence, evnt_prov_code, evnt_rfdr_code, evnt_locn_code, evnt_aptp_code, evnt_starttime, evnt_duration, evnt_desc, evnt_apst_code, evnt__sequence, evnt__timestamp, evnt__user_entry, evnt__status, evnt_note_1, evnt_note_2) FROM stdin;
\.


--
-- Data for Name: feeb; Type: TABLE DATA; Schema: public; Owner: source
--

COPY feeb (feeb_serv_code, feeb_feet_code, feeb_amount, feeb__sequence, feeb__timestamp, feeb__user_entry, feeb__status) FROM stdin;
-	-	0.00	51508	2005-01-30 12:06:33.381204	source	N
-	MC	0.00	51510	2005-01-30 12:06:33.381204	source	N
-	MLR	0.00	51511	2005-01-30 12:06:33.381204	source	N
-	PRIV	0.00	51512	2005-01-30 12:06:33.381204	source	N
-	SCH	0.00	51513	2005-01-30 12:06:33.381204	source	N
-	TAC	0.00	51514	2005-01-30 12:06:33.381204	source	N
-	VA	0.00	51515	2005-01-30 12:06:33.381204	source	N
-	WC	0.00	51516	2005-01-30 12:06:33.381204	source	N
104	-	0.00	51517	2005-01-31 13:57:54.703261	source	N
104	MC	0.00	51519	2005-01-31 13:57:54.703261	source	N
104	MLR	0.00	51520	2005-01-31 13:57:54.703261	source	N
104	PRIV	0.00	51521	2005-01-31 13:57:54.703261	source	N
104	TAC	0.00	51523	2005-01-31 13:57:54.703261	source	N
104	VA	0.00	51524	2005-01-31 13:57:54.703261	source	N
104	WC	0.00	51525	2005-01-31 13:57:54.703261	source	N
104	SCH	76.00	51522	2005-01-31 13:57:54.703261	source	N
105	-	36.40	51599	2005-02-08 20:14:08.029748	source	N
105	MC	36.40	51600	2005-02-08 20:14:08.029748	source	N
105	MLR	36.40	51601	2005-02-08 20:14:08.029748	source	N
105	PRIV	36.40	51602	2005-02-08 20:14:08.029748	source	N
105	SCH	36.40	51603	2005-02-08 20:14:08.029748	source	N
105	TAC	36.40	51604	2005-02-08 20:14:08.029748	source	N
105	VA	36.40	51605	2005-02-08 20:14:08.029748	source	N
105	WC	36.40	51606	2005-02-08 20:14:08.029748	source	N
\.


--
-- Data for Name: feet; Type: TABLE DATA; Schema: public; Owner: source
--

COPY feet (feet_code, feet_desc, feet__sequence, feet__timestamp, feet__user_entry, feet__status) FROM stdin;
-	\N	84	2005-01-14 08:46:26.980265	source	N
PRIV	PRIVATE	85	2005-01-14 08:46:26.980265	source	N
VA	Veterans Affairs	95	2005-01-18 09:26:08.431426	source	N
MC	MEDICARE	86	2005-01-14 08:46:26.980265	source	N
TAC	TAC	90	2005-01-14 08:46:26.980265	source	N
WC	Work Cover	94	2005-01-18 09:25:53.48895	source	N
SCH	SCHEDULE FEE	89	2005-01-14 08:46:26.980265	source	N
MLR	MEDICO-LEGAL	91	2005-01-14 08:46:26.980265	source	N
\.


--
-- Data for Name: fmdt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY fmdt (fmdt_form_code, fmdt_desc, fmdt_field_type, fmdt_section, fmdt_text, fmdt_x_coord, fmdt_y_coord, fmdt_width, fmdt_height, fmdt_bg_colour, fmdt_fg_colour, fmdt_bd_colour, fmdt_bd_width, fmdt_bd_style, fmdt_ft_family, fmdt_ft_size, fmdt_ft_weight, fmdt_ft_italic, fmdt_hz_align, fmdt_vt_align, fmdt_word_wrap, fmdt_data_type, fmdt_date_format, fmdt_precision, fmdt_currency, fmdt_neg_colour, fmdt_comma_sep, fmdt__sequence, fmdt__timestamp, fmdt__user_entry, fmdt__status) FROM stdin;
creditcard	New Item	0	3	Please charge my credit card for the payment of this account.	0	20	400	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	0	2	1	0	7	0	36	255,0,0	0	12	2004-03-28 19:53:38.253505	source	A
creditcard	New Item	0	3	BankCard	0	35	40	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	13	2004-03-28 19:53:38.313596	source	A
creditcard	BCbox	0	3		45	35	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	2	2	1	0	7	0	36	255,0,0	0	14	2004-03-28 19:53:38.372554	source	A
creditcard	New Item	0	3	Visa	60	35	40	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	15	2004-03-28 19:53:38.428749	source	A
creditcard	visabox	0	3		80	35	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	16	2004-03-28 19:53:38.486427	source	A
creditcard	New Item	0	3	Mastercard	95	35	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	17	2004-03-28 19:53:38.544001	source	A
creditcard	MCbox	0	3		145	35	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	18	2004-03-28 19:53:38.601625	source	A
creditcard	New Item	0	3		0	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	19	2004-03-28 19:53:38.660675	source	A
creditcard	New Item	0	3		14	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	20	2004-03-28 19:53:38.717997	source	A
creditcard	New Item	0	3		28	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	21	2004-03-28 19:53:38.775527	source	A
creditcard	New Item	0	3		42	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	22	2004-03-28 19:53:38.833047	source	A
creditcard	New Item	0	3		60	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	23	2004-03-28 19:53:38.890757	source	A
creditcard	New Item	0	3		74	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	24	2004-03-28 19:53:38.949352	source	A
creditcard	New Item	0	3		88	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	25	2004-03-28 19:53:39.005928	source	A
creditcard	New Item	0	3		102	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	26	2004-03-28 19:53:39.06346	source	A
creditcard	New Item	0	3		120	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	27	2004-03-28 19:53:39.121097	source	A
creditcard	New Item	0	3		134	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	28	2004-03-28 19:53:39.17864	source	A
creditcard	New Item	0	3		148	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	29	2004-03-28 19:53:39.236661	source	A
creditcard	New Item	0	3		162	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	30	2004-03-28 19:53:39.293807	source	A
creditcard	New Item	0	3		180	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	31	2004-03-28 19:53:39.351443	source	A
creditcard	New Item	0	3		194	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	32	2004-03-28 19:53:39.409021	source	A
creditcard	New Item	0	3		208	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	33	2004-03-28 19:53:39.466523	source	A
creditcard	New Item	0	3		222	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	34	2004-03-28 19:53:39.524613	source	A
creditcard	New Item	0	3	Expiry Date:	240	50	55	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	0	2	0	0	7	0	36	255,0,0	0	35	2004-03-28 19:53:39.581749	source	A
creditcard	New Item	0	3		300	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	36	2004-03-28 19:53:39.668503	source	A
creditcard	New Item	0	3		314	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	37	2004-03-28 19:53:39.726043	source	A
creditcard	New Item	0	3		335	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	38	2004-03-28 19:53:39.783667	source	A
creditcard	New Item	0	3		349	50	12	12	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	39	2004-03-28 19:53:39.841221	source	A
creditcard	New Item	0	3	Cardholder:	0	73	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	0	2	0	0	7	0	36	255,0,0	0	40	2004-03-28 19:53:39.900818	source	A
creditcard	New Item	0	3	Signature:	270	73	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	0	2	0	0	7	0	36	255,0,0	0	41	2004-03-28 19:53:39.958354	source	A
creditcard	CHline	2	3		65	81	180	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	42	2004-03-28 19:53:40.016117	source	A
creditcard	SIGline	2	3		335	81	180	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	43	2004-03-28 19:53:40.073539	source	A
invoice-svpv	New Item	0	2	Referred by:	0	412	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	581	2005-01-23 15:19:54.435275	source	A
invoice-svpv	New Item	0	2	Provider No:	0	424	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	582	2005-01-23 15:19:54.447462	source	A
invoice-svpv	New Item	0	2	Referral Date:	0	436	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	583	2005-01-23 15:19:54.459388	source	A
invoice-svpv	New Item	0	2	Referral Period:	0	448	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	584	2005-01-23 15:19:54.471382	source	A
invoice-svpv	New Item	1	2	svpv_rfdr_name	90	412	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	585	2005-01-23 15:19:54.489585	source	A
invoice-svpv	New Item	1	2	svpv_rfdr_provider	90	424	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	586	2005-01-23 15:19:54.501445	source	A
invoice-svpv	New Item	1	2	svpv_rfdr_date	90	436	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	587	2005-01-23 15:19:54.513392	source	A
invoice-svpv	New Item	1	2	svpv_rfdr_period	90	448	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	588	2005-01-23 15:19:54.525414	source	A
invoice-svpv_VA	New Item	0	2	VX Number:	0	472	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	593	2005-01-23 15:20:09.470448	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_address	56	24	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	624	2005-01-23 15:20:27.913326	source	A
invoice-svpv_base	New Item	1	2	svpv_patn_address	330	24	170	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	625	2005-01-23 15:20:27.925274	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_suburb	56	36	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	626	2005-01-23 15:20:27.937271	source	A
invoice-svpv_base	New Item	1	2	svpv_patn_suburb	330	36	170	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	627	2005-01-23 15:20:27.949276	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_state	56	48	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	628	2005-01-23 15:20:27.961257	source	A
invoice-svpv_base	New Item	1	2	svpv_patn_state	330	48	170	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	629	2005-01-23 15:20:27.973255	source	A
invoice-svpv_base	New Item	1	2	svpv_date_service:8	0	130	78	24	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	0	0	0	7	0	36	255,0,0	0	630	2005-01-23 15:20:27.985275	source	A
invoice-svpv_base	New Item	1	2	svpv_serv_code:8	80	130	48	24	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	0	0	0	7	0	36	255,0,0	0	631	2005-01-23 15:20:27.997305	source	A
invoice-svpv_base	New Item	1	2	svpv_desc:8	130	130	240	24	255,255,255	0,0,0	0,0,0	1	0	Helvetiva	10	25	0	0	0	1	0	7	0	36	255,0,0	0	632	2005-01-23 15:20:28.015285	source	A
invoice-svpv_base	New Item	1	2	svpv_amount:8	370	130	50	24	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	0	0	0	7	0	36	255,0,0	0	633	2005-01-23 15:20:28.027265	source	A
invoice-svpv_base	New Item	1	2	svpv_gst_amount:8	420	130	80	24	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	0	0	0	7	0	36	255,0,0	0	634	2005-01-23 15:20:28.039251	source	A
invoice-svpv_base	New Item	1	2	_PAGE	480	390	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	635	2005-01-23 15:20:28.051243	source	A
invoice-svpv_base	New Item	1	2	svpv_invc_amount	400	414	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	636	2005-01-23 15:20:28.069328	source	A
invoice-svpv_base	New Item	1	2	svpv_invc_gst_amount	400	426	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	637	2005-01-23 15:20:28.081587	source	A
invoice-svpv_base	New Item	1	2	svpv_invc_credits	400	438	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	638	2005-01-23 15:20:28.093274	source	A
invoice-svpv_base	New Item	1	2	svpv_cred_summary	270	450	230	36	255,255,255	0,0,0	0,0,0	1	0	Courier	8	25	1	0	2	0	0	7	0	36	255,0,0	0	639	2005-01-23 15:20:28.105301	source	A
invoice-svpv_base	New Item	1	2	svpv_invc_balance	400	490	100	20	240,240,240	0,0,0	0,0,0	0	0	Helvetica	10	75	0	1	1	0	0	7	0	36	255,0,0	0	640	2005-01-23 15:20:28.117358	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_name	0	530	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	641	2005-01-23 15:20:28.129338	source	A
invoice-svpv_base	New Item	1	2	svpv_invc__sequence	400	530	115	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	642	2005-01-23 15:20:28.141343	source	A
eventlist-evnv	New Item	0	1	Appointment List	0	10	515	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	14	75	0	1	1	1	0	7	0	36	255,0,0	0	104	2004-07-21 09:22:10.032407	source	A
eventlist-evnv	New Item	0	2	Provider:	0	0	75	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	1	1	0	7	0	36	255,0,0	0	105	2004-07-21 09:22:10.138817	source	A
eventlist-evnv	New Item	0	2	Date:	270	0	80	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	2	1	1	0	7	0	36	255,0,0	0	106	2004-07-21 09:22:10.196556	source	A
eventlist-evnv	New Item	0	2	Patient	60	30	118	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	108	2004-07-21 09:22:10.312978	source	A
eventlist-evnv	New Item	0	2	Phone	180	30	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	109	2004-07-21 09:22:10.385332	source	A
eventlist-evnv	New Item	0	2	Referrer	260	30	98	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	110	2004-07-21 09:22:10.442784	source	A
eventlist-evnv	New Item	0	2	Notes	360	30	155	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	111	2004-07-21 09:22:10.499879	source	A
eventlist-evnv	New Item	0	2	Printed on:	0	730	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	1	0	7	0	36	255,0,0	0	112	2004-07-21 09:22:10.558111	source	A
eventlist-evnv	New Item	0	2	Page:	425	730	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	1	0	7	0	36	255,0,0	0	113	2004-07-21 09:22:10.615142	source	A
eventlist-evnv	New Item	1	2	evnv_ev_date	355	0	150	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	0	1	0	0	7	0	36	255,0,0	0	115	2004-07-21 09:22:10.730977	source	A
eventlist-evnv	New Item	1	2	evnv_patn_desc:20	60	60	118	30	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	75	0	0	1	1	0	7	0	36	255,0,0	0	117	2004-07-21 09:22:10.846322	source	A
eventlist-evnv	New Item	1	2	evnv_patn_phone:20	180	60	78	30	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	1	1	0	7	0	36	255,0,0	0	118	2004-07-21 09:22:10.903438	source	A
eventlist-evnv	New Item	1	2	evnv_rfdr_name:20	260	60	98	30	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	1	1	0	7	0	36	255,0,0	0	119	2004-07-21 09:22:10.9612	source	A
eventlist-evnv	New Item	1	2	evnv_desc:20	360	60	155	30	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	1	0	0	7	0	36	255,0,0	0	120	2004-07-21 09:22:11.018774	source	A
eventlist-evnv	New Item	1	2	_PAGE	480	730	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	1	0	7	0	36	255,0,0	0	121	2004-07-21 09:22:11.076541	source	A
eventlist-evnv	New Item	2	2		0	25	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	122	2004-07-21 09:22:11.134584	source	A
eventlist-evnv	New Item	2	2		0	45	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	123	2004-07-21 09:22:11.221448	source	A
eventlist-evnv	New Item	2	2		0	720	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	124	2004-07-21 09:22:11.263733	source	A
eventlist-evnv	Report Date	200	2		55	730	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	125	2004-07-21 09:22:11.321649	source	A
dbaged	New Item	0	1	Aged Debtor List	300	0	300	30	255,255,255	0,0,0	0,0,0	1	0	Times	20	25	0	1	1	0	0	7	0	36	255,0,0	0	126	2004-07-21 10:09:39.980074	source	A
dbaged	New Item	0	1	ID	0	45	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	127	2004-07-21 10:09:40.081362	source	A
dbaged	New Item	0	1	Name	60	45	98	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	128	2004-07-21 10:09:40.139106	source	A
dbaged	New Item	0	1	Street	160	45	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	129	2004-07-21 10:09:40.196734	source	A
dbaged	New Item	0	1	Suburb	240	45	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	130	2004-07-21 10:09:40.255705	source	A
dbaged	New Item	0	1	Phone	300	45	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	131	2004-07-21 10:09:40.315887	source	A
dbaged	New Item	0	1	Statement	380	45	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	132	2004-07-21 10:09:40.359245	source	A
dbaged	New Item	0	1	Delay	440	45	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	133	2004-07-21 10:09:40.431256	source	A
dbaged	New Item	0	1	Current	500	45	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	134	2004-07-21 10:09:40.545852	source	A
dbaged	New Item	0	1	30	540	45	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	135	2004-07-21 10:09:40.5893	source	A
dbaged	New Item	0	1	60	580	45	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	136	2004-07-21 10:09:40.647396	source	A
dbaged	New Item	0	1	90	620	45	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	137	2004-07-21 10:09:40.704597	source	A
dbaged	New Item	0	1	120	660	45	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	138	2004-07-21 10:09:40.762197	source	A
dbaged	New Item	0	1	Total	700	45	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	139	2004-07-21 10:09:40.820467	source	A
dbaged	New Item	2	1		0	40	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	1	1	0	0	7	0	36	255,0,0	0	140	2004-07-21 10:09:40.877534	source	A
dbaged	New Item	2	1		0	60	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	141	2004-07-21 10:09:40.935715	source	A
dbaged	New Item	1	2	dbag_dbtr_code	0	0	54	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	142	2004-07-21 10:09:40.992876	source	A
dbaged	New Item	1	2	dbag_patient_key	55	0	98	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	143	2004-07-21 10:09:41.050432	source	A
dbaged	New Item	1	2	dbag_address	160	0	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	144	2004-07-21 10:09:41.108687	source	A
dbaged	New Item	1	2	dbag_suburb	240	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	145	2004-07-21 10:09:41.165844	source	A
dbaged	New Item	1	2	dbag_phone	300	0	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	146	2004-07-21 10:09:41.237773	source	A
dbaged	New Item	1	2	dbag_last_statement	380	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	147	2004-07-21 10:09:41.295861	source	A
dbaged	New Item	1	2	dbag_delay_statement	440	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	148	2004-07-21 10:09:41.352996	source	A
dbaged	New Item	1	2	dbag_balance_0	500	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	149	2004-07-21 10:09:41.424998	source	A
dbaged	New Item	1	2	dbag_balance_30	540	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	150	2004-07-21 10:09:41.483066	source	A
dbaged	New Item	1	2	dbag_balance_60	580	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	151	2004-07-21 10:09:41.540359	source	A
dbaged	New Item	1	2	dbag_balance_90	620	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	152	2004-07-21 10:09:41.597938	source	A
dbaged	New Item	1	2	dbag_balance_120	660	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	153	2004-07-21 10:09:41.656126	source	A
dbaged	New Item	1	2	dbag_total_balance	700	0	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	154	2004-07-21 10:09:41.713213	source	A
dbaged	New Item	0	3	Date:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	155	2004-07-21 10:09:41.771296	source	A
dbaged	New Item	0	3	Page #	700	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	156	2004-07-21 10:09:41.8286	source	A
dbaged	New Item	1	3	dbag_date	40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	157	2004-07-21 10:09:41.886632	source	A
dbaged	New Item	2	3		0	0	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	158	2004-07-21 10:09:41.943901	source	A
dbaged	New Item	201	3	 	740	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	159	2004-07-21 10:09:42.001518	source	A
dbaged	New Item	0	4	TOTALS:	440	10	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	160	2004-07-21 10:09:42.059702	source	A
dbaged	New Item	101	4	dbag_balance_0_0	500	10	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	4	7	0	36	255,0,0	0	161	2004-07-21 10:09:42.118809	source	A
dbaged	New Item	101	4	dbag_balance_30_0	540	10	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	4	7	0	36	255,0,0	0	162	2004-07-21 10:09:42.162075	source	A
dbaged	New Item	101	4	dbag_balance_60_0	580	10	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	4	7	0	36	255,0,0	0	163	2004-07-21 10:09:42.20553	source	A
dbaged	New Item	101	4	dbag_balance_90_0	620	10	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	4	7	0	36	255,0,0	0	164	2004-07-21 10:09:42.263628	source	A
dbaged	New Item	101	4	dbag_balance_120_0	660	10	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	4	7	0	36	255,0,0	0	165	2004-07-21 10:09:42.306894	source	A
dbaged	New Item	101	4	dbag_total_balance_0	700	10	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	4	7	0	36	255,0,0	0	166	2004-07-21 10:09:42.383984	source	A
list-svlt	New Item	0	1	Services List	0	20	315	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	18	75	0	1	2	0	0	7	0	36	255,0,0	0	167	2004-07-21 10:09:57.774854	source	A
list-svlt	New Item	0	1	Date	0	53	56	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	168	2004-07-21 10:09:57.818507	source	A
list-svlt	New Item	0	1	Patient	80	53	190	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	169	2004-07-21 10:09:57.861779	source	A
list-svlt	New Item	0	1	Service	280	53	58	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	170	2004-07-21 10:09:57.907212	source	A
list-svlt	New Item	0	1	Amount	352	53	50	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	171	2004-07-21 10:09:57.9505	source	A
list-svlt	New Item	0	1	GST	412	53	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	172	2004-07-21 10:09:57.993797	source	A
list-svlt	New Item	0	1	Total	452	53	60	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	173	2004-07-21 10:09:58.05166	source	A
list-svlt	New Item	1	1	svlt_prov_name	320	20	195	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	1	1	0	0	7	0	36	255,0,0	0	174	2004-07-21 10:09:58.109198	source	A
list-svlt	Ruler	2	1		0	80	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	175	2004-07-21 10:09:58.168222	source	A
list-svlt	New Item	1	2	svlt_date_service	0	0	53	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	176	2004-07-21 10:09:58.22582	source	A
list-svlt	New Item	1	2	svlt_prov_code	55	0	18	10	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	177	2004-07-21 10:09:58.28354	source	A
list-svlt	New Item	1	2	svlt_patn_name	80	0	190	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	178	2004-07-21 10:09:58.341107	source	A
list-svlt	New Item	1	2	svlt_serv_code	280	0	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	179	2004-07-21 10:09:58.398907	source	A
list-svlt	New Item	1	2	svlt_amount	354	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	180	2004-07-21 10:09:58.456393	source	A
list-svlt	New Item	1	2	svlt_gst_amount	412	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	181	2004-07-21 10:09:58.514187	source	A
list-svlt	New Item	1	2	svlt_total_amount	452	0	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	182	2004-07-21 10:09:58.571719	source	A
list-svlt	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	183	2004-07-21 10:09:58.629363	source	A
list-svlt	New Item	0	3	Page #	450	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	184	2004-07-21 10:09:58.687094	source	A
list-svlt	New Item	2	3	Ruler	0	0	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	185	2004-07-21 10:09:58.744677	source	A
list-svlt	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	186	2004-07-21 10:09:58.843197	source	A
list-svlt	Page counter	201	3		495	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	187	2004-07-21 10:09:58.888588	source	A
list-svlt	New Item	0	4	Totals:	285	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	188	2004-07-21 10:09:58.946339	source	A
list-svlt	ruler	2	4		285	12	230	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	189	2004-07-21 10:09:59.003951	source	A
list-svlt	New Item	101	4	svlt_amount_0	352	20	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	190	2004-07-21 10:09:59.06153	source	A
list-svlt	New Item	101	4	svlt_gst_amount_0	412	20	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	191	2004-07-21 10:09:59.104982	source	A
list-svlt	New Item	101	4	svlt_total_amount_0	452	20	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	192	2004-07-21 10:09:59.14823	source	A
list-crsm	New Item	0	1	Credit Summary	0	20	315	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	18	75	0	1	2	0	0	7	0	36	255,0,0	0	193	2004-07-21 10:10:06.034946	source	A
list-crsm	New Item	0	1	Provider	0	53	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	194	2004-07-21 10:10:06.086172	source	A
list-crsm	New Item	0	1	Type	50	53	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	195	2004-07-21 10:10:06.143765	source	A
list-crsm	New Item	0	1	Description	100	53	250	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	196	2004-07-21 10:10:06.219121	source	A
list-crsm	New Item	0	1	Amount	352	53	50	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	197	2004-07-21 10:10:06.273868	source	A
list-crsm	New Item	0	1	GST	412	53	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	198	2004-07-21 10:10:06.331472	source	A
list-crsm	New Item	0	1	Count	452	53	60	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	199	2004-07-21 10:10:06.38934	source	A
list-crsm	New Item	1	1	crsm_prov_name	320	20	195	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	1	1	0	0	7	0	36	255,0,0	0	200	2004-07-21 10:10:06.448084	source	A
list-crsm	Ruler	2	1		0	80	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	201	2004-07-21 10:10:06.505891	source	A
list-crsm	New Item	1	2	crsm_prov_code	0	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	202	2004-07-21 10:10:06.563473	source	A
list-crsm	New Item	1	2	crsm_tdtp_code	50	0	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	203	2004-07-21 10:10:06.6212	source	A
list-crsm	New Item	1	2	crsm_desc	100	0	250	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	204	2004-07-21 10:10:06.6788	source	A
list-crsm	New Item	1	2	crsm_amount	354	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	205	2004-07-21 10:10:06.736427	source	A
list-crsm	New Item	1	2	crsm_gst_amount	412	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	206	2004-07-21 10:10:06.79414	source	A
list-crsm	New Item	1	2	crsm_count	452	0	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	207	2004-07-21 10:10:06.8517	source	A
list-crsm	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	208	2004-07-21 10:10:06.909443	source	A
list-crsm	New Item	0	3	Page #	450	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	209	2004-07-21 10:10:06.966989	source	A
list-crsm	New Item	2	3	Ruler	0	0	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	210	2004-07-21 10:10:07.024748	source	A
list-crsm	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	211	2004-07-21 10:10:07.082366	source	A
list-crsm	Page counter	201	3		495	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	212	2004-07-21 10:10:07.179269	source	A
list-crsm	New Item	0	4	Totals:	285	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	213	2004-07-21 10:10:07.22624	source	A
list-crsm	ruler	2	4		285	12	230	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	214	2004-07-21 10:10:07.283852	source	A
list-crsm	New Item	101	4	crsm_amount_0	352	20	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	215	2004-07-21 10:10:07.341549	source	A
list-crsm	New Item	101	4	crsm_gst_amount_0	412	20	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	216	2004-07-21 10:10:07.38488	source	A
list-crsm	New Item	101	4	crsm_count_0	452	20	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	2	7	0	36	255,0,0	0	217	2004-07-21 10:10:07.428306	source	A
list-svsm	New Item	0	1	Service Summary	0	20	315	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	18	75	0	1	2	0	0	7	0	36	255,0,0	0	218	2004-07-21 10:10:12.32858	source	A
list-svsm	New Item	0	1	Provider	0	53	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	219	2004-07-21 10:10:12.38658	source	A
list-svsm	New Item	0	1	Service	50	53	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	220	2004-07-21 10:10:12.444179	source	A
list-svsm	New Item	0	1	Description	100	53	250	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	221	2004-07-21 10:10:12.501839	source	A
list-svsm	New Item	0	1	Amount	352	53	50	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	222	2004-07-21 10:10:12.559454	source	A
list-svsm	New Item	0	1	GST	412	53	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	223	2004-07-21 10:10:12.617218	source	A
list-svsm	New Item	0	1	Count	452	53	60	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	224	2004-07-21 10:10:12.674824	source	A
list-svsm	New Item	1	1	svsm_prov_name	320	20	195	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	1	1	0	0	7	0	36	255,0,0	0	225	2004-07-21 10:10:12.732417	source	A
list-svsm	Ruler	2	1		0	80	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	226	2004-07-21 10:10:12.791414	source	A
list-svsm	New Item	1	2	svsm_prov_code	0	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	227	2004-07-21 10:10:12.834859	source	A
list-svsm	New Item	1	2	svsm_serv_code	50	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	228	2004-07-21 10:10:12.92172	source	A
list-svsm	New Item	1	2	svsm_desc	100	0	250	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	229	2004-07-21 10:10:12.966974	source	A
list-svsm	New Item	1	2	svsm_amount	354	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	230	2004-07-21 10:10:13.024741	source	A
list-svsm	New Item	1	2	svsm_gst_amount	412	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	231	2004-07-21 10:10:13.091618	source	A
list-svsm	New Item	1	2	svsm_count	452	0	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	232	2004-07-21 10:10:13.139917	source	A
list-svsm	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	233	2004-07-21 10:10:13.197646	source	A
list-svsm	New Item	0	3	Page #	450	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	234	2004-07-21 10:10:13.255175	source	A
list-svsm	New Item	2	3	Ruler	0	0	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	235	2004-07-21 10:10:13.312977	source	A
list-svsm	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	236	2004-07-21 10:10:13.37242	source	A
list-svsm	Page counter	201	3		495	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	237	2004-07-21 10:10:13.459416	source	A
list-svsm	New Item	0	4	Totals:	285	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	238	2004-07-21 10:10:13.500221	source	A
list-svsm	ruler	2	4		285	12	230	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	239	2004-07-21 10:10:13.557724	source	A
list-svsm	New Item	101	4	svsm_amount_0	352	20	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	240	2004-07-21 10:10:13.615516	source	A
list-svsm	New Item	101	4	svsm_gst_amount_0	412	20	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	241	2004-07-21 10:10:13.67309	source	A
list-svsm	New Item	101	4	svsm_count_0	452	20	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	2	7	0	36	255,0,0	0	242	2004-07-21 10:10:13.730793	source	A
list-svpv	New Item	0	1	Services List	0	20	315	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	18	75	0	1	2	0	0	7	0	36	255,0,0	0	243	2004-07-21 10:10:18.8712	source	A
list-svpv	New Item	0	1	Date	0	53	56	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	244	2004-07-21 10:10:18.929255	source	A
list-svpv	New Item	0	1	Patient	69	53	112	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	245	2004-07-21 10:10:18.986804	source	A
list-svpv	New Item	0	1	Service	184	53	58	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	246	2004-07-21 10:10:19.046536	source	A
list-svpv	New Item	0	1	Description	246	53	103	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	247	2004-07-21 10:10:19.104155	source	A
list-svpv	New Item	0	1	Amount	352	53	50	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	248	2004-07-21 10:10:19.162449	source	A
list-svpv	New Item	0	1	GST	412	53	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	249	2004-07-21 10:10:19.220898	source	A
list-svpv	New Item	0	1	Total	452	53	60	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	250	2004-07-21 10:10:19.278461	source	A
list-svpv	New Item	1	1	svpv_prov_name	320	20	195	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	1	1	0	0	7	0	36	255,0,0	0	251	2004-07-21 10:10:19.336087	source	A
list-svpv	Ruler	2	1		0	80	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	252	2004-07-21 10:10:19.393844	source	A
list-svpv	New Item	1	2	svpv_date_service	0	0	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	253	2004-07-21 10:10:19.451393	source	A
list-svpv	New Item	1	2	svpv_patn_name	73	0	118	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	254	2004-07-21 10:10:19.52348	source	A
list-svpv	New Item	1	2	svpv_serv_code	194	0	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	255	2004-07-21 10:10:19.581097	source	A
list-svpv	New Item	1	2	svpv_desc	242	0	104	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	256	2004-07-21 10:10:19.638644	source	A
list-svpv	New Item	1	2	svpv_amount	354	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	257	2004-07-21 10:10:19.696407	source	A
list-svpv	New Item	1	2	svpv_gst_amount	412	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	258	2004-07-21 10:10:19.753899	source	A
list-svpv	New Item	1	2	svpv_total_amount	452	0	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	259	2004-07-21 10:10:19.797443	source	A
list-svpv	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	260	2004-07-21 10:10:19.869847	source	A
list-svpv	New Item	0	3	Page #	450	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	261	2004-07-21 10:10:19.91299	source	A
list-svpv	New Item	2	3	Ruler	0	0	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	262	2004-07-21 10:10:19.956456	source	A
list-svpv	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	263	2004-07-21 10:10:19.999789	source	A
list-svpv	Page counter	201	3		495	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	264	2004-07-21 10:10:20.043052	source	A
list-svpv	New Item	0	4	Totals:	285	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	265	2004-07-21 10:10:20.086548	source	A
list-svpv	ruler	2	4		285	12	230	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	266	2004-07-21 10:10:20.144627	source	A
list-svpv	New Item	101	4	svpv_amount_0	352	20	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	267	2004-07-21 10:10:20.201857	source	A
list-svpv	New Item	101	4	svpv_gst_amount_0	412	20	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	268	2004-07-21 10:10:20.259499	source	A
list-svpv	New Item	101	4	svpv_total_amount_0	452	20	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	269	2004-07-21 10:10:20.350541	source	A
gst-receipts	New Item	0	1	GST Receipts Report	0	20	515	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	18	75	0	0	2	0	0	7	0	36	255,0,0	0	270	2004-07-21 10:10:25.459569	source	A
gst-receipts	New Item	0	1	Date	0	45	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	271	2004-07-21 10:10:25.503303	source	A
gst-receipts	New Item	0	1	Patient	70	45	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	272	2004-07-21 10:10:25.546503	source	A
gst-receipts	New Item	0	1	Debtor	170	45	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	273	2004-07-21 10:10:25.590012	source	A
gst-receipts	New Item	0	1	Invoice	310	45	40	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	274	2004-07-21 10:10:25.633228	source	A
gst-receipts	New Item	0	1	Payment ID	360	45	50	24	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	275	2004-07-21 10:10:25.676841	source	A
gst-receipts	New Item	0	1	Payment Total	415	45	50	24	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	276	2004-07-21 10:10:25.719995	source	A
gst-receipts	New Item	0	1	GST	470	45	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	277	2004-07-21 10:10:25.763223	source	A
gst-receipts	Ruler	2	1		0	80	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	278	2004-07-21 10:10:25.821067	source	A
gst-receipts	New Item	1	2	gstv_day_date	0	0	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	279	2004-07-21 10:10:25.880118	source	A
gst-receipts	New Item	1	2	gstv_invc_patn__sequence	70	0	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	280	2004-07-21 10:10:25.9377	source	A
gst-receipts	New Item	1	2	gstv_patn_psnam	110	0	55	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	281	2004-07-21 10:10:25.9953	source	A
gst-receipts	New Item	1	2	gstv_dbtr_code	170	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	282	2004-07-21 10:10:26.053049	source	A
gst-receipts	New Item	1	2	gstv_dbtr_name	220	0	95	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	283	2004-07-21 10:10:26.110563	source	A
gst-receipts	New Item	1	2	gstv_cred_invc__sequence	320	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	284	2004-07-21 10:10:26.168303	source	A
gst-receipts	New Item	1	2	gstv_cred_paym__sequence	370	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	285	2004-07-21 10:10:26.225891	source	A
gst-receipts	New Item	1	2	gstv_paym_amount	420	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	286	2004-07-21 10:10:26.285645	source	A
gst-receipts	New Item	1	2	gstv_cred_gst_amount	470	0	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	287	2004-07-21 10:10:26.343554	source	A
gst-receipts	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	288	2004-07-21 10:10:26.400805	source	A
gst-receipts	New Item	0	3	Page #	450	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	289	2004-07-21 10:10:26.458602	source	A
gst-receipts	New Item	2	3	Ruler	0	0	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	290	2004-07-21 10:10:26.516091	source	A
gst-receipts	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	291	2004-07-21 10:10:26.573891	source	A
gst-receipts	Page counter	201	3		495	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	292	2004-07-21 10:10:26.646453	source	A
gst-receipts	New Item	0	4	Totals:	330	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	293	2004-07-21 10:10:26.703967	source	A
gst-receipts	ruler	2	4		330	12	185	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	294	2004-07-21 10:10:26.747489	source	A
gst-receipts	New Item	101	4	gstv_paym_amount_0	400	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	295	2004-07-21 10:10:26.7907	source	A
gst-receipts	New Item	101	4	gstv_cred_gst_amount_0	470	20	45	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	296	2004-07-21 10:10:26.873033	source	A
notelist-notv	New Item	0	1	Patient Notes	0	10	515	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	14	75	0	1	1	1	0	7	0	36	255,0,0	0	297	2004-07-21 10:10:31.278678	source	A
notelist-notv	New Item	0	2	Patient:	0	0	75	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	1	1	0	7	0	36	255,0,0	0	298	2004-07-21 10:10:31.33654	source	A
notelist-notv	New Item	0	2	DOB:	270	0	80	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	2	1	1	0	7	0	36	255,0,0	0	299	2004-07-21 10:10:31.394299	source	A
notelist-notv	New Item	0	2	Timestamp	0	30	150	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	300	2004-07-21 10:10:31.437563	source	A
notelist-notv	New Item	0	2	NOTES	150	30	350	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	301	2004-07-21 10:10:31.48093	source	A
notelist-notv	New Item	0	2	Printed on:	0	730	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	1	0	7	0	36	255,0,0	0	302	2004-07-21 10:10:31.524226	source	A
notelist-notv	New Item	0	2	Page:	425	730	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	1	0	7	0	36	255,0,0	0	303	2004-07-21 10:10:31.567656	source	A
notelist-notv	New Item	1	2	notv_patn_desc	80	0	200	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	1	1	0	7	0	36	255,0,0	0	304	2004-07-21 10:10:31.611019	source	A
notelist-notv	New Item	1	2	notv_patn_dob	355	0	150	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	1	0	0	7	0	36	255,0,0	0	305	2004-07-21 10:10:31.670025	source	A
notelist-notv	New Item	1	2	notv_time:10	0	60	150	60	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	50	0	0	0	1	0	7	0	36	255,0,0	0	306	2004-07-21 10:10:31.727609	source	A
notelist-notv	New Item	1	2	notv_desc:10	155	60	350	60	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	50	0	0	0	1	0	7	0	36	255,0,0	0	307	2004-07-21 10:10:31.785373	source	A
notelist-notv	New Item	1	2	_PAGE	480	730	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	1	0	7	0	36	255,0,0	0	308	2004-07-21 10:10:31.842939	source	A
notelist-notv	New Item	2	2		0	25	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	309	2004-07-21 10:10:31.938954	source	A
notelist-notv	New Item	2	2		0	45	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	310	2004-07-21 10:10:31.986906	source	A
notelist-notv	New Item	2	2		0	720	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	311	2004-07-21 10:10:32.044391	source	A
notelist-notv	Report Date	200	2		55	730	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	312	2004-07-21 10:10:32.102231	source	A
patv2	Name	1	1	patv_psnam~, ~patv_fsnam	25	28	210	36	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	0	1	0	7	0	36	255,0,0	0	313	2004-07-21 10:10:39.475888	source	A
patv2	Address	1	1	patv_address~, ~patv_suburb~, ~patv_postcode	240	28	312	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	314	2004-07-21 10:10:39.51959	source	A
patv2	Referror Name	1	1	patv_rfdr_name	240	50	312	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	315	2004-07-21 10:10:39.577118	source	A
patv2	New Item	1	1	patv_rfdr_street	240	62	312	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	316	2004-07-21 10:10:39.634928	source	A
patv2	New Item	1	1	patv_rfdr_suburb~ ~patv_rfdr_postcode	240	74	312	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	317	2004-07-21 10:10:39.69255	source	A
patv2	New Item	1	1	DOB: ~patv_dob	240	98	312	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	318	2004-07-21 10:10:39.789603	source	A
patv2	Payer	1	1	patv_dbtr_name~  ~patv_dbtr_phone	50	165	502	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	319	2004-07-21 10:10:39.837722	source	A
patv2	New Item	1	1	Ref: ~patv_ref_date	50	274	502	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	25	0	0	2	0	0	7	0	36	255,0,0	0	320	2004-07-21 10:10:39.895491	source	A
dbstatement	New Item	0	2	Statement of Account	300	76	215	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	1	1	0	7	0	36	255,0,0	0	321	2004-07-21 10:10:43.879748	source	A
dbstatement	New Item	0	2	Invoice #	20	110	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	322	2004-07-21 10:10:43.925549	source	A
dbstatement	New Item	0	2	Date	100	110	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	323	2004-07-21 10:10:43.966932	source	A
dbstatement	New Item	0	2	Patient	180	110	148	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	324	2004-07-21 10:10:44.053397	source	A
dbstatement	New Item	0	2	Amount	330	110	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	325	2004-07-21 10:10:44.111195	source	A
dbstatement	New Item	0	2	Paid	390	110	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	326	2004-07-21 10:10:44.168959	source	A
dbstatement	New Item	0	2	Unpaid	450	110	55	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	327	2004-07-21 10:10:44.283717	source	A
dbstatement	New Item	0	2	Total Amount Outstanding	0	520	450	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	2	2	0	0	7	0	36	255,0,0	0	328	2004-07-21 10:10:44.345405	source	A
dbstatement	New Item	0	2	Current	400	536	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	329	2004-07-21 10:10:44.400342	source	A
dbstatement	New Item	0	2	30 Days	400	548	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	330	2004-07-21 10:10:44.457956	source	A
dbstatement	New Item	0	2	60 Days	400	560	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	331	2004-07-21 10:10:44.515644	source	A
dbstatement	New Item	0	2	90 Days	400	572	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	332	2004-07-21 10:10:44.573293	source	A
dbstatement	New Item	0	2	120 Days	400	584	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	333	2004-07-21 10:10:44.631046	source	A
dbstatement	New Item	0	2	Page:	400	600	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	334	2004-07-21 10:10:44.68859	source	A
dbstatement	New Item	1	2	dbst_name	56	0	200	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	335	2004-07-21 10:10:44.746208	source	A
dbstatement	New Item	1	2	dbst_address	56	12	200	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	336	2004-07-21 10:10:44.803848	source	A
dbstatement	New Item	1	2	dbst_suburb	56	24	200	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	337	2004-07-21 10:10:44.861478	source	A
dbstatement	New Item	1	2	dbst_state	56	36	200	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	338	2004-07-21 10:10:44.919278	source	A
dbstatement	New Item	1	2	dbst_date	300	50	215	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	339	2004-07-21 10:10:44.976827	source	A
dbstatement	New Item	1	2	_ITEM:30	0	130	18	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	340	2004-07-21 10:10:45.034732	source	A
dbstatement	New Item	1	2	dbst_invc__sequence:30	20	130	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	341	2004-07-21 10:10:45.092117	source	A
dbstatement	New Item	1	2	dbst_date_printed:30	100	130	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	342	2004-07-21 10:10:45.149741	source	A
dbstatement	New Item	1	2	dbst_patient:30	180	130	148	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	343	2004-07-21 10:10:45.207505	source	A
dbstatement	New Item	1	2	dbst_amount:30	330	130	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	344	2004-07-21 10:10:45.265013	source	A
dbstatement	New Item	1	2	dbst_paid:30	390	130	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	345	2004-07-21 10:10:45.308521	source	A
dbstatement	New Item	1	2	dbst_balance:30	450	130	55	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	346	2004-07-21 10:10:45.351704	source	A
dbstatement	New Item	1	2	dbst_total_balance	450	520	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	2	2	0	0	7	0	36	255,0,0	0	347	2004-07-21 10:10:45.411575	source	A
dbstatement	New Item	1	2	dbst_balance_0	450	536	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	348	2004-07-21 10:10:45.469061	source	A
dbstatement	New Item	1	2	dbst_balance_30	450	548	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	349	2004-07-21 10:10:45.526726	source	A
dbstatement	New Item	1	2	dbst_balance_60	450	560	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	350	2004-07-21 10:10:45.584451	source	A
dbstatement	New Item	1	2	dbst_balance_90	450	572	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	351	2004-07-21 10:10:45.641989	source	A
dbstatement	New Item	1	2	dbst_balance_120	450	584	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	352	2004-07-21 10:10:45.699764	source	A
dbstatement	New Item	1	2	_PAGE	480	600	35	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	353	2004-07-21 10:10:45.757283	source	A
dbstatement	New Item	2	2		0	94	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	354	2004-07-21 10:10:45.847078	source	A
dbstatement	New Item	2	2		0	510	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	355	2004-07-21 10:10:45.886959	source	A
list-sclt	New Item	0	1	DEBITS and CREDITS	0	20	378	20	255,255,255	0,0,0	0,0,0	1	0	Times	12	75	0	0	2	0	0	7	0	36	255,0,0	0	356	2004-07-21 10:10:54.459894	source	A
list-sclt	New Item	0	1	Date	0	55	58	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	357	2004-07-21 10:10:54.503565	source	A
list-sclt	New Item	0	1	Patient	60	55	158	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	358	2004-07-21 10:10:54.546972	source	A
list-sclt	New Item	0	1	D/C	220	55	18	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	2	2	0	0	7	0	36	255,0,0	0	359	2004-07-21 10:10:54.590273	source	A
list-sclt	New Item	0	1	Type	240	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	0	2	0	0	7	0	36	255,0,0	0	360	2004-07-21 10:10:54.633572	source	A
list-sclt	New Item	0	1	Description	290	55	148	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	0	2	0	0	7	0	36	255,0,0	0	361	2004-07-21 10:10:54.677019	source	A
list-sclt	New Item	0	1	Invoice	450	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	0	2	0	0	7	0	36	255,0,0	0	362	2004-07-21 10:10:54.736724	source	A
list-sclt	New Item	0	1	Debit	510	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	2	2	0	0	7	0	36	255,0,0	0	363	2004-07-21 10:10:54.80867	source	A
list-sclt	New Item	0	1	GST	560	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	2	2	1	0	7	0	36	255,0,0	0	364	2004-07-21 10:10:54.867604	source	A
list-sclt	New Item	0	1	Credit	610	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	365	2004-07-21 10:10:54.925293	source	A
list-sclt	New Item	0	1	GST	660	55	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	366	2004-07-21 10:10:54.982871	source	A
list-sclt	New Item	0	1	Total	700	55	60	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	367	2004-07-21 10:10:55.040655	source	A
list-sclt	New Item	1	1	sclt_prov_name	380	20	380	20	255,255,255	0,0,0	0,0,0	1	0	Times	12	75	0	2	2	0	0	7	0	36	255,0,0	0	368	2004-07-21 10:10:55.098186	source	A
list-sclt	Ruler	2	1		0	80	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	369	2004-07-21 10:10:55.155971	source	A
list-sclt	New Item	1	2	sclt_date	0	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	370	2004-07-21 10:10:55.213505	source	A
list-sclt	New Item	1	2	sclt_patn_name	60	0	158	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	371	2004-07-21 10:10:55.271123	source	A
list-sclt	New Item	1	2	sclt_dc	220	0	18	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	2	2	0	0	7	0	36	255,0,0	0	372	2004-07-21 10:10:55.328864	source	A
list-sclt	New Item	1	2	sclt_type	240	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	0	2	0	0	7	0	36	255,0,0	0	373	2004-07-21 10:10:55.386398	source	A
list-sclt	New Item	1	2	sclt_desc	290	0	148	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	0	2	0	0	7	0	36	255,0,0	0	374	2004-07-21 10:10:55.444203	source	A
list-sclt	New Item	1	2	sclt_invc__sequence	450	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	2	2	0	0	7	0	36	255,0,0	0	375	2004-07-21 10:10:55.50179	source	A
list-sclt	New Item	1	2	sclt_debit	510	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	2	2	0	0	7	0	36	255,0,0	0	376	2004-07-21 10:10:55.559534	source	A
list-sclt	New Item	1	2	sclt_gst_debit	560	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	377	2004-07-21 10:10:55.617097	source	A
list-sclt	New Item	1	2	sclt_credit	610	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	378	2004-07-21 10:10:55.674684	source	A
list-sclt	New Item	1	2	sclt_gst_credit	660	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	379	2004-07-21 10:10:55.732368	source	A
list-sclt	New Item	1	2	sclt_total_amount	700	0	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	380	2004-07-21 10:10:55.775665	source	A
list-sclt	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	381	2004-07-21 10:10:55.819117	source	A
list-sclt	New Item	0	3	Page #	700	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	382	2004-07-21 10:10:55.862335	source	A
list-sclt	New Item	2	3	Ruler	0	0	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	383	2004-07-21 10:10:55.905868	source	A
list-sclt	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	384	2004-07-21 10:10:55.949324	source	A
list-sclt	Page counter	201	3		740	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	385	2004-07-21 10:10:56.078873	source	A
list-sclt	New Item	0	4	Totals:	440	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	386	2004-07-21 10:10:56.122071	source	A
list-sclt	ruler	2	4		440	12	320	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	387	2004-07-21 10:10:56.165457	source	A
list-sclt	New Item	101	4	sclt_debit_0	510	20	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	388	2004-07-21 10:10:56.24003	source	A
list-sclt	New Item	101	4	sclt_gst_debit_0	560	20	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	389	2004-07-21 10:10:56.332779	source	A
list-sclt	New Item	101	4	sclt_credit_0	610	20	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	390	2004-07-21 10:10:56.383961	source	A
list-sclt	New Item	101	4	sclt_gst_credit_0	660	20	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	391	2004-07-21 10:10:56.441546	source	A
list-sclt	New Item	101	4	sclt_total_amount_0	700	20	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	392	2004-07-21 10:10:56.499133	source	A
list-crlt	New Item	0	1	CREDITS LIST	0	20	378	20	255,255,255	0,0,0	0,0,0	1	0	Times	12	75	0	0	2	0	0	7	0	36	255,0,0	0	393	2004-07-21 10:11:06.103795	source	A
list-crlt	New Item	0	1	Date	0	55	58	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	394	2004-07-21 10:11:06.161621	source	A
list-crlt	New Item	0	1	Patient	60	55	158	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	395	2004-07-21 10:11:06.219353	source	A
list-crlt	New Item	0	1	Pay#	220	55	43	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	2	2	0	0	7	0	36	255,0,0	0	396	2004-07-21 10:11:06.276942	source	A
list-crlt	New Item	0	1	T	275	55	13	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	0	2	0	0	7	0	36	255,0,0	0	397	2004-07-21 10:11:06.334662	source	A
list-crlt	New Item	0	1	Drawer	290	55	148	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	0	2	0	0	7	0	36	255,0,0	0	398	2004-07-21 10:11:06.394269	source	A
list-crlt	New Item	0	1	Bank	440	55	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	0	2	0	0	7	0	36	255,0,0	0	399	2004-07-21 10:11:06.452136	source	A
list-crlt	New Item	0	1	Amount	490	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	1	2	2	1	0	7	0	36	255,0,0	0	400	2004-07-21 10:11:06.525154	source	A
list-crlt	New Item	0	1	Invoice	550	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	401	2004-07-21 10:11:06.582926	source	A
list-crlt	New Item	0	1	Credit	600	55	48	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	402	2004-07-21 10:11:06.640455	source	A
list-crlt	New Item	0	1	GST	650	55	38	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	403	2004-07-21 10:11:06.698226	source	A
list-crlt	New Item	0	1	Total	690	55	58	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	404	2004-07-21 10:11:06.755936	source	A
list-crlt	New Item	1	1	crlt_prov_name	380	20	380	20	255,255,255	0,0,0	0,0,0	1	0	Times	12	75	0	2	2	0	0	7	0	36	255,0,0	0	405	2004-07-21 10:11:06.813419	source	A
list-crlt	Ruler	2	1		0	80	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	406	2004-07-21 10:11:06.871187	source	A
list-crlt	New Item	1	2	crlt_date_credit	0	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	407	2004-07-21 10:11:06.928744	source	A
list-crlt	New Item	1	2	crlt_patn_name	60	0	158	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	408	2004-07-21 10:11:06.986455	source	A
list-crlt	New Item	1	2	crlt_paym__sequence	220	0	43	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	2	2	0	0	7	0	36	255,0,0	0	409	2004-07-21 10:11:07.031219	source	A
list-crlt	New Item	1	2	crlt_tdtp_code	275	0	13	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	0	2	0	0	7	0	36	255,0,0	0	410	2004-07-21 10:11:07.073215	source	A
list-crlt	New Item	1	2	crlt_drawer	290	0	148	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	0	2	0	0	7	0	36	255,0,0	0	411	2004-07-21 10:11:07.11651	source	A
list-crlt	New Item	1	2	crlt_bank	440	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	0	2	0	0	7	0	36	255,0,0	0	412	2004-07-21 10:11:07.159871	source	A
list-crlt	New Item	1	2	crlt_paym_amount	490	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	1	2	2	0	0	7	0	36	255,0,0	0	413	2004-07-21 10:11:07.203182	source	A
list-crlt	New Item	1	2	crlt_invc__sequence	550	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	414	2004-07-21 10:11:07.246484	source	A
list-crlt	New Item	1	2	crlt_cred_amount	600	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	415	2004-07-21 10:11:07.289909	source	A
list-crlt	New Item	1	2	crlt_cred_gst_amount	650	0	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	416	2004-07-21 10:11:07.347519	source	A
list-crlt	New Item	1	2	crlt_total_amount	690	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	417	2004-07-21 10:11:07.405243	source	A
list-crlt	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	418	2004-07-21 10:11:07.462805	source	A
list-crlt	New Item	0	3	Page #	700	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	419	2004-07-21 10:11:07.520514	source	A
list-crlt	New Item	2	3	Ruler	0	0	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	420	2004-07-21 10:11:07.592997	source	A
list-crlt	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	421	2004-07-21 10:11:07.650706	source	A
list-crlt	Page counter	201	3		740	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	422	2004-07-21 10:11:07.708309	source	A
list-crlt	New Item	0	4	Totals:	530	20	65	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	2	36	255,0,0	0	423	2004-07-21 10:11:07.766008	source	A
list-crlt	ruler	2	4		530	12	230	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	424	2004-07-21 10:11:07.823656	source	A
list-crlt	New Item	101	4	crlt_cred_amount_0	600	20	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	425	2004-07-21 10:11:07.885912	source	A
list-crlt	New Item	101	4	crlt_cred_gst_amount_0	650	20	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	426	2004-07-21 10:11:07.970493	source	A
list-crlt	New Item	101	4	crlt_total_amount_0	690	20	60	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	4	7	0	36	255,0,0	0	427	2004-07-21 10:11:08.027169	source	A
list-patn	New Item	0	1		0	0	0	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	428	2004-07-21 10:11:23.592359	source	A
list-patn	New Item	0	1	Patient List	0	0	760	30	255,255,255	0,0,0	0,0,0	1	0	Times	20	25	0	1	1	0	0	7	0	36	255,0,0	0	429	2004-07-21 10:11:23.650234	source	A
list-patn	New Item	0	1	File	0	45	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	430	2004-07-21 10:11:23.708019	source	A
list-patn	New Item	0	1	Surname	60	45	118	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	431	2004-07-21 10:11:23.765616	source	A
list-patn	New Item	0	1	Firstname	180	45	118	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	432	2004-07-21 10:11:23.823291	source	A
list-patn	New Item	0	1	Street	300	45	178	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	433	2004-07-21 10:11:23.881881	source	A
list-patn	New Item	0	1	Suburb	480	45	168	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	434	2004-07-21 10:11:23.938662	source	A
list-patn	New Item	0	1	Phone	650	45	110	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	435	2004-07-21 10:11:23.99753	source	A
list-patn	New Item	2	1		0	40	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	1	1	0	0	7	0	36	255,0,0	0	436	2004-07-21 10:11:24.055254	source	A
list-patn	New Item	2	1		0	60	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	437	2004-07-21 10:11:24.114836	source	A
list-patn	New Item	1	2	patn_flno	0	0	58	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	438	2004-07-21 10:11:24.17263	source	A
list-patn	New Item	1	2	patn_psnam	60	0	118	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	439	2004-07-21 10:11:24.23016	source	A
list-patn	New Item	1	2	patn_fsnam	180	0	118	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	440	2004-07-21 10:11:24.287859	source	A
list-patn	New Item	1	2	patn_address	300	0	178	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	441	2004-07-21 10:11:24.345403	source	A
list-patn	New Item	1	2	patn_suburb	480	0	168	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	442	2004-07-21 10:11:24.403044	source	A
list-patn	New Item	1	2	patn_phone	650	0	110	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	443	2004-07-21 10:11:24.446508	source	A
list-patn	New Item	0	3	Date:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	444	2004-07-21 10:11:24.48973	source	A
list-patn	New Item	0	3	Page #	700	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	445	2004-07-21 10:11:24.533146	source	A
list-patn	New Item	2	3		0	0	760	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	446	2004-07-21 10:11:24.576458	source	A
list-patn	New Item	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	447	2004-07-21 10:11:24.659046	source	A
list-patn	New Item	201	3		740	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	448	2004-07-21 10:11:24.70611	source	A
eventlist-evnv	New Item	0	2	Start	0	30	40	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	107	2004-07-21 09:22:10.255551	source	A
eventlist-evnv	New Item	1	2	evnv_ev_time:20	0	60	40	30	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	1	0	0	7	0	36	255,0,0	0	116	2004-07-21 09:22:10.788302	source	A
eventlist-evnv	New Item	0	2	T	42	30	16	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	2	1	0	7	0	36	255,0,0	0	454	2005-01-14 15:18:37.458554	source	A
eventlist-evnv	New Item	1	2	evnv_aptp_code:20	42	60	16	30	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	1	0	0	7	0	36	255,0,0	0	455	2005-01-14 15:20:21.463803	source	A
eventlist-evnv	New Item	1	2	evnv_prov_name	80	0	200	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	0	1	1	0	7	0	36	255,0,0	0	114	2004-07-21 09:22:10.672953	source	A
invoice-svpv_TAC	New Item	0	2	Claim number:	0	460	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	589	2005-01-23 15:20:01.928826	source	A
invoice-svpv_TAC	New Item	0	2	Accident date:	0	472	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	590	2005-01-23 15:20:01.94689	source	A
invoice-svpv_WC	New Item	0	2	Insurance Co:	0	460	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	595	2005-01-23 15:20:15.380125	source	A
invoice-svpv_WC	New Item	0	2	Claim number:	0	472	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	596	2005-01-23 15:20:15.392173	source	A
invoice-svpv_base	New Item	0	1	Account to:	48	136	180	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	601	2005-01-23 15:20:27.619267	source	A
invoice-svpv_base	New Item	0	1	Patient:	320	136	180	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	602	2005-01-23 15:20:27.631236	source	A
invoice-svpv_base	New Item	0	2	Tax Invoice	300	76	215	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	1	1	0	7	0	36	255,0,0	0	603	2005-01-23 15:20:27.64921	source	A
invoice-svpv_base	New Item	0	2	Service Date	0	110	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	604	2005-01-23 15:20:27.661193	source	A
invoice-svpv_base	New Item	0	2	Item	80	110	50	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	605	2005-01-23 15:20:27.673198	source	A
invoice-svpv_base	New Item	0	2	Description	130	110	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	606	2005-01-23 15:20:27.685236	source	A
invoice-svpv_base	New Item	0	2	Fee	350	110	70	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	607	2005-01-23 15:20:27.697237	source	A
invoice-svpv_base	New Item	0	2	GST	420	110	80	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	608	2005-01-23 15:20:27.709259	source	A
invoice-svpv_base	New Item	0	2	Notes	0	390	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	1	1	0	7	0	36	255,0,0	0	609	2005-01-23 15:20:27.721485	source	A
invoice-svpv_base	New Item	0	2	INVOICE SUMMARY	270	390	230	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	1	1	0	7	0	36	255,0,0	0	610	2005-01-23 15:20:27.733216	source	A
invoice-svpv_base	New Item	0	2	Page:	400	390	78	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	611	2005-01-23 15:20:27.745188	source	A
invoice-svpv_base	New Item	0	2	Total Fees:	270	414	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	612	2005-01-23 15:20:27.757452	source	A
invoice-svpv_base	New Item	0	2	GST:	270	426	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	613	2005-01-23 15:20:27.769201	source	A
invoice-svpv_base	New Item	0	2	Less payments received:	270	438	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	614	2005-01-23 15:20:27.781196	source	A
invoice-svpv_base	New Item	0	2	INVOICE BALANCE	270	490	130	20	240,240,240	0,0,0	0,0,0	0	0	Helvetica	10	75	0	1	1	1	0	7	0	36	255,0,0	0	615	2005-01-23 15:20:27.793187	source	A
invoice-svpv_base	New Item	0	2	REMITTANCE	0	512	70	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	1	0	7	0	36	255,0,0	0	616	2005-01-23 15:20:27.805223	source	A
invoice-svpv_base	New Item	0	2	Invoice Number:	270	530	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	617	2005-01-23 15:20:27.82319	source	A
invoice-svpv_base	New Item	0	2	Invoice Date:	270	542	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	618	2005-01-23 15:20:27.835184	source	A
invoice-svpv_base	New Item	0	2	Reprinted:	270	554	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	619	2005-01-23 15:20:27.847247	source	A
invoice-svpv_base	New Item	0	2	Invoice Balance:	270	566	120	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	1	0	7	0	36	255,0,0	0	620	2005-01-23 15:20:27.859281	source	A
invoice-svpv_base	New Item	1	2	svpv_date_printed	300	0	215	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	1	1	0	7	0	36	255,0,0	0	621	2005-01-23 15:20:27.871282	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_name	56	12	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	622	2005-01-23 15:20:27.883263	source	A
invoice-svpv_base	New Item	1	2	svpv_patn_name	330	12	170	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	623	2005-01-23 15:20:27.895292	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_address	0	542	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	643	2005-01-23 15:20:28.153329	source	A
invoice-svpv_base	New Item	1	2	svpv_date_printed	400	542	115	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	644	2005-01-23 15:20:28.169263	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_suburb	0	554	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	645	2005-01-23 15:20:28.18334	source	A
invoice-svpv_base	New Item	1	2	svpv_date_reprint	400	554	115	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	646	2005-01-23 15:20:28.195364	source	A
invoice-svpv_base	New Item	1	2	svpv_dbtr_state	0	566	220	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	647	2005-01-23 15:20:28.207392	source	A
invoice-svpv_base	New Item	1	2	svpv_invc_balance	400	566	115	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	0	0	7	0	36	255,0,0	0	648	2005-01-23 15:20:28.219354	source	A
invoice-svpv_base	New Item	2	2		0	94	515	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	649	2005-01-23 15:20:28.231386	source	A
invoice-svpv_base	New Item	2	2		0	408	220	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	650	2005-01-23 15:20:28.243331	source	A
invoice-svpv_base	New Item	2	2		270	408	245	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	651	2005-01-23 15:20:28.255328	source	A
invoice-svpv_base	New Item	2	2		75	518	440	0	255,255,255	0,0,0	0,0,0	1	2	Helvetica	10	25	0	1	1	1	0	7	0	36	255,0,0	0	652	2005-01-23 15:20:28.273348	source	A
fee-report-landscape	New Item	0	1	Fee Report	0	20	300	20	255,255,255	0,0,0	0,0,0	1	0	Helvetica	18	75	0	0	2	0	0	7	0	36	255,0,0	0	667	2005-01-25 12:29:15.310947	source	A
fee-report-landscape	New Item	0	1	Item	0	55	68	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	668	2005-01-25 12:29:15.335093	source	A
fee-report-landscape	New Item	0	1	Service	70	55	128	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	669	2005-01-25 12:29:15.347044	source	A
fee-report-landscape	New Item	1	1	feel_db_desc	585	20	200	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	12	75	0	2	2	0	0	7	0	36	255,0,0	0	670	2005-01-25 12:29:15.359029	source	A
fee-report-landscape	New Item	1	1	feel_fee0_code	200	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	671	2005-01-25 12:29:15.371018	source	A
fee-report-landscape	New Item	1	1	feel_fee1_code	250	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	672	2005-01-25 12:29:15.383078	source	A
fee-report-landscape	New Item	1	1	feel_fee2_code	300	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	673	2005-01-25 12:29:15.39505	source	A
fee-report-landscape	New Item	1	1	feel_fee3_code	350	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	1	0	7	0	36	255,0,0	0	674	2005-01-25 12:29:15.413094	source	A
fee-report-landscape	New Item	1	1	feel_fee4_code	400	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	675	2005-01-25 12:29:15.425045	source	A
fee-report-landscape	New Item	1	1	feel_fee5_code	450	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	676	2005-01-25 12:29:15.43838	source	A
fee-report-landscape	New Item	1	1	feel_fee6_code	500	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	677	2005-01-25 12:29:15.449048	source	A
fee-report-landscape	New Item	1	1	feel_fee7_code	550	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	678	2005-01-25 12:29:15.461042	source	A
fee-report-landscape	New Item	1	1	feel_fee8_code	600	55	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	2	2	0	0	7	0	36	255,0,0	0	679	2005-01-25 12:29:15.473027	source	A
fee-report-landscape	Ruler	2	1		0	80	785	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	680	2005-01-25 12:29:15.485039	source	A
fee-report-landscape	New Item	1	2	feel_serv_code	0	0	68	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	681	2005-01-25 12:29:15.497022	source	A
fee-report-landscape	New Item	1	2	feel_serv_desc	70	0	128	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	682	2005-01-25 12:29:15.509026	source	A
fee-report-landscape	New Item	1	2	feel_fee0_amount	200	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	683	2005-01-25 12:29:15.521022	source	A
fee-report-landscape	New Item	1	2	feel_fee1_amount	250	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	684	2005-01-25 12:29:15.539172	source	A
fee-report-landscape	New Item	1	2	feel_fee2_amount	300	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	685	2005-01-25 12:29:15.551141	source	A
fee-report-landscape	New Item	1	2	feel_fee3_amount	350	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	686	2005-01-25 12:29:15.563125	source	A
fee-report-landscape	New Item	1	2	feel_fee4_amount	400	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	687	2005-01-25 12:29:15.575109	source	A
fee-report-landscape	New Item	1	2	feel_fee5_amount	450	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	688	2005-01-25 12:29:15.587102	source	A
fee-report-landscape	New Item	1	2	feel_fee6_amount	500	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	689	2005-01-25 12:29:15.599144	source	A
fee-report-landscape	New Item	1	2	feel_fee7_amount	550	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	690	2005-01-25 12:29:15.611115	source	A
fee-report-landscape	New Item	1	2	feel_fee8_amount	600	0	48	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	691	2005-01-25 12:29:15.623166	source	A
fee-report-landscape	Timestamp	0	3	Printed:	0	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	692	2005-01-25 12:29:15.635202	source	A
fee-report-landscape	New Item	0	3	Page #	720	5	38	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	693	2005-01-25 12:29:15.647315	source	A
fee-report-landscape	New Item	2	3	Ruler	0	0	785	0	255,255,255	0,0,0	0,0,0	1	1	Helvetica	8	25	0	0	2	0	0	7	0	36	255,0,0	0	694	2005-01-25 12:29:15.659463	source	A
fee-report-landscape	Report Date	200	3		40	5	100	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	0	0	17	0	36	255,0,0	0	695	2005-01-25 12:29:15.671572	source	A
fee-report-landscape	Page counter	201	3		765	5	20	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	0	0	7	0	36	255,0,0	0	696	2005-01-25 12:29:15.683362	source	A
lhinvc	Letterhead	0	1	Mr. D. Surgeon	0	0	300	30	255,255,255	0,0,0	0,0,0	1	0	Times	16	75	0	0	2	1	0	7	0	36	255,0,0	0	697	2005-01-25 22:05:26.830503	source	A
lhinvc	New Item	0	1	XYZ Private Hospital	250	18	265	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	698	2005-01-25 22:05:26.839641	source	A
lhinvc	New Item	0	1	M.B.,B.S.,F.R.A.C.S	0	30	300	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	1	0	7	0	36	255,0,0	0	699	2005-01-25 22:05:26.851608	source	A
lhinvc	New Item	0	1	33 Somewhere Street	250	30	265	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	700	2005-01-25 22:05:26.863597	source	A
lhinvc	New Item	0	1	East Melbourne	250	42	265	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	701	2005-01-25 22:05:26.881659	source	A
lhinvc	New Item	0	1	Specialist Surgery	0	44	250	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	1	0	7	0	36	255,0,0	0	702	2005-01-25 22:05:26.893609	source	A
lhinvc	New Item	0	1	Victoria 3002	250	54	265	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	2	2	1	0	7	0	36	255,0,0	0	703	2005-01-25 22:05:26.911619	source	A
lhinvc	New Item	0	1	Provider No: 09987645H	0	58	250	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	1	0	7	0	36	255,0,0	0	704	2005-01-25 22:05:26.927513	source	A
lhinvc	New Item	0	1	Telephone: 9499 9999	300	66	215	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	2	2	1	0	7	0	36	255,0,0	0	705	2005-01-25 22:05:26.941627	source	A
lhinvc	New Item	0	1	ABN: 97 333 222 111	0	72	250	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	25	0	0	2	1	0	7	0	36	255,0,0	0	706	2005-01-25 22:05:26.953647	source	A
lhinvc	New Item	0	1	24 Hours	300	78	215	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	2	2	1	0	7	0	36	255,0,0	0	707	2005-01-25 22:05:26.964291	source	A
lhinvc	New Item	0	3	Make cheques payable to D. Surgeon	0	8	250	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	8	75	0	0	2	1	0	7	0	36	255,0,0	0	708	2005-01-25 22:05:26.977629	source	A
invoice-svpv_VA	New Item	1	2	svpv_invc_healthcard	90	472	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	594	2005-01-23 15:20:09.482608	source	A
invoice-svpv_TAC	New Item	1	2	svpv_invc_claim_number	90	460	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	591	2005-01-23 15:20:01.958849	source	A
invoice-svpv_WC	New Item	1	2	svpv_invc_claim_number	90	472	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	598	2005-01-23 15:20:15.416159	source	A
invoice-svpv_TAC	New Item	1	2	svpv_invc_accident_date	90	472	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	592	2005-01-23 15:20:01.970843	source	A
invoice-svpv_WC	New Item	1	2	svpv_invc_hlfd_code	90	460	140	12	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	25	0	0	2	0	0	7	0	36	255,0,0	0	597	2005-01-23 15:20:15.404238	source	A
invoice-svpv	New Item	1	2	svpv_invc_reference_1	0	486	240	22	255,255,255	0,0,0	0,0,0	1	0	Helvetica	10	75	0	0	2	0	0	7	0	36	255,0,0	0	709	2005-01-25 22:16:58.172376	source	A
\.


--
-- Data for Name: form; Type: TABLE DATA; Schema: public; Owner: source
--

COPY form (form_code, form_desc, form_classname, form_page_attribute, form_includes, form_pagesize, form_orientation, form_mg_top, form_mg_bottom, form_mg_left, form_mg_right, form_rh_height, form_rh_frequency, form_rf_height, form_rf_frequency, form_ph_height, form_ph_frequency, form_pf_height, form_pf_frequency, form_dt_height, form__sequence, form__timestamp, form__user_entry, form__status) FROM stdin;
fee-report-landscape	Fee Report-Landscape	feel			0	1	10	10	40	40	0	0	35	2	90	1	50	1	12	30	2005-01-25 12:29:15.291208	source	A
creditcard	Credit Card 				0	0	10	10	40	40	0	0	0	0	45	1	35	1	30	3	2004-03-28 19:53:38.118651	source	A
lhinvc	Letterhead				0	0	10	10	40	40	0	0	0	0	150	1	50	1	671	31	2005-01-25 22:05:26.803289	source	A
invoice-svpv	Standard Invoice	svpv	svpv_invc__sequence	invoice-svpv_base,lhinvc,creditcard	0	0	10	10	40	40	0	0	0	0	150	1	110	1	611	23	2005-01-23 15:19:54.423083	source	A
dbaged	Aged Debtor List	dbag		lhdbag	0	1	10	10	40	40	0	0	35	2	65	1	35	1	12	6	2004-07-21 10:09:39.812128	source	A
list-svlt	Services List	svlt	svlt_prov_name		0	0	10	10	40	40	0	0	35	2	90	1	50	1	12	7	2004-07-21 10:09:57.675636	source	A
list-crsm	Credit Summary	crsm	crsm_prov_code		0	0	10	10	40	40	0	0	35	2	90	1	50	1	12	8	2004-07-21 10:10:05.92076	source	A
list-svsm	Service Summary	svsm	svsm_prov_code		0	0	10	10	40	40	0	0	35	2	90	1	50	1	12	9	2004-07-21 10:10:12.23047	source	A
list-svpv	Services List	svpv	svpv_prov_name		0	0	10	10	40	40	0	0	35	2	90	1	50	1	12	10	2004-07-21 10:10:18.747043	source	A
gst-receipts	GST  Receipts	gstv			0	0	10	10	40	40	0	0	35	2	90	1	50	1	12	11	2004-07-21 10:10:25.3556	source	A
notelist-notv	Appointment List	notv	notv_patn__sequence	 	0	0	10	10	40	40	0	0	0	0	50	1	50	1	771	12	2004-07-21 10:10:31.150636	source	A
patv2	History Envelope - centre	patv			0	1	110	10	250	40	0	0	0	0	320	1	35	1	20	13	2004-07-21 10:10:39.372992	source	A
dbstatement	Debtor Statement	dbst	dbst_dbtr_code	lhinvc,creditcard	0	0	10	10	40	40	0	0	0	0	150	1	100	1	621	14	2004-07-21 10:10:43.786131	source	A
list-sclt	Credits and Debits	sclt	sclt_prov_name		0	1	10	10	40	40	0	0	35	2	90	1	35	1	12	15	2004-07-21 10:10:54.357152	source	A
list-crlt	Credits List	crlt	crlt_prov_name		0	1	10	10	40	40	0	0	35	2	90	1	35	1	12	16	2004-07-21 10:11:06.009414	source	A
list-patn	Patient List	patn			0	1	10	10	40	40	0	0	0	0	65	1	35	1	12	17	2004-07-21 10:11:23.5015	source	A
eventlist-evnv	Appointment List	evnv	evnv_prov_code, evnv_ev_date:evnv_starttime	 	0	0	10	10	40	40	0	0	0	0	50	1	50	1	771	5	2004-07-21 09:22:09.747278	source	A
invoice-svpv_TAC	WorkCover Invoice	svpv	svpv_invc__sequence	invoice-svpv,invoice-svpv_base,lhinvc,creditcard	0	0	10	10	40	40	0	0	0	0	150	1	110	1	611	24	2005-01-23 15:20:01.918233	source	A
invoice-svpv_VA	WorkCover Invoice	svpv	svpv_invc__sequence	invoice-svpv,invoice-svpv_base,lhinvc,creditcard	0	0	10	10	40	40	0	0	0	0	150	1	110	1	611	25	2005-01-23 15:20:09.453105	source	A
invoice-svpv_WC	WorkCover Invoice	svpv	svpv_invc__sequence	invoice-svpv,invoice-svpv_base,lhinvc,creditcard	0	0	10	10	40	40	0	0	0	0	150	1	110	1	611	26	2005-01-23 15:20:15.368139	source	A
invoice-svpv_base	Basic Invoice layout	svpv	svpv_invc__sequence	lhinvc,creditcard	0	0	10	10	40	40	0	0	0	0	150	1	110	1	611	28	2005-01-23 15:20:27.601304	source	A
-	New Report	\N	\N	\N	0	0	10	10	40	40	0	0	0	0	45	1	35	1	30	32	2005-01-30 12:06:31.991888	source	A
\.


--
-- Data for Name: hice; Type: TABLE DATA; Schema: public; Owner: source
--

COPY hice (hice_name, hice_input, hice_output, hice_session, hice_transmission, hice_length, hice_type, hice_desc, hice__sequence, hice__timestamp, hice__user_entry, hice__status) FROM stdin;
ClaimDate	\N	Y	\N	\N	8	N	DDMMYYYY The date of lodgement of the claim. 	4	2005-02-05 14:18:58.135078	source	N
AuthorisationDate	\N	Y	\N	\N	8	N	Format: DDMMYYYY The date on which the DirectBillClaim/DVAClaim was authorised. 	1	2005-02-05 14:18:58.135078	source	N
CardFlag	\N	Y	\N	\N	1	A	Returned Output:  A= Identification amended  C= Veteran File Number changed  Space= No change   DVA only. Indication of changes to DVA card.  	2	2005-02-05 14:18:58.135078	source	N
ClaimBenefitPaid	\N	Y	\N	\N	9	N	The amount in cents eg: an amount of $27.50 is indicated as 00002750 The amount of benefit paid for the claim. 	3	2005-02-05 14:18:58.135078	source	N
ClaimErrorCode	\N	Y	\N	\N	\N	AN	See Return Codes. Can be multiple integers separated by commas Return Codes associated with Claim. 	5	2005-02-05 14:18:58.135078	source	N
ClaimErrorLevel	\N	Y	\N	\N	1	A	Return Output:  A = Acceptable  U = Unacceptable   Acceptable - the claim can be accepted and will be referred to a Medicare staff operator.  Unacceptable - the claim cannot be accepted with the current error(s).    	6	2005-02-05 14:18:58.135078	source	N
ClaimFundAssessmentCde	\N	Y	\N	\N	1	A	Return Output: A - Accepted R - Rejected W - Warning  The assessment status of a claim on it's return to the Hub from the Fund.  	7	2005-02-05 14:18:58.135078	source	N
ClaimFundExplanationCode	\N	Y	\N	\N	4	N	The Fund's explanation (reason) code for the claim assessment status. 	8	2005-02-05 14:18:58.135078	source	N
ClaimFundExplanationText	\N	Y	\N	\N	50	A	The Fund's explanation text for the claim explanation code. 	9	2005-02-05 14:18:58.135078	source	N
CorrectedMedicareNum	\N	Y	\N	\N	11	N	Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming   Level: Prescription Record  Corrected Medicare number as supplied by HIC to the Approved Supplier. This field will only be populated where a relevant reason code has been issued and under conditions where it is possible to determine and return a corrected Medicare number.   	11	2005-02-05 14:18:58.135078	source	N
CurrentClaimantMedicareCardNum	\N	Y	\N	\N	10	N	Medicare Card number, as known by Medicare. Returned when this information differs from that which was sent by the client system.   	12	2005-02-05 14:18:58.135078	source	N
CurrentClaimantReferenceNum	\N	Y	\N	\N	1	N	The claimants individual Reference Number, as known by Medicare. Returned when this information differs from that which was sent by the client system.  	13	2005-02-05 14:18:58.135078	source	N
CurrentPatientFirstName	\N	Y	\N	\N	40	A	Patient's first name, as known by Medicare. Returned when this information differs from that which was sent by the client system.   	14	2005-02-05 14:18:58.135078	source	N
CurrentPatientMedicareCardNum	\N	Y	\N	\N	10	N	Medicare Card number, as known by Medicare. Returned when this information differs from that which was sent by the client system.   	15	2005-02-05 14:18:58.135078	source	N
CurrentPatientReferenceNum	\N	Y	\N	\N	1	N	The patients individual Reference Number, as known by Medicare. Returned when this information differs from that which was sent by the client system.  	16	2005-02-05 14:18:58.135078	source	N
DateOfPreparation	\N	Y	\N	\N	8	N	Returned Output: Date represented in numeric format as DDMMYYYY.  Use: PBS - Preassessment, Claiming, Cancellation   Level: Header  Date that the response was prepared (Canberra time).  	17	2005-02-05 14:18:58.135078	source	N
DateUpdated	\N	Y	\N	\N	8	N	Returned Output: Date represented in numeric format as DDMMYYYY.  Use: getParticipants   The date that the record was last updated.  	18	2005-02-05 14:18:58.135078	source	N
DepositAmount	\N	Y	\N	\N	9	N	The amount in cents eg: an amount of $27.50 is indicated as 00002750 The amount (to be) deposited into the bank account as payment. 	19	2005-02-05 14:18:58.135078	source	N
DispensedPrice	\N	Y	\N	\N	9	N	Returned Output: The price of the item in cents.   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming   Level: Prescription Record  The dispensed price (in cents) of the drug including any patient contribution, but excluding brand price premiums and therapeutic group premiums.  	20	2005-02-05 14:18:58.135078	source	N
EncounterErrorCode	\N	Y	\N	\N	\N	AN	See Return Codes. Can be multiple integers separated by commas Return Codes associated with Encounter. 	21	2005-02-05 14:18:58.135078	source	N
EncounterId	\N	Y	\N	\N	2	N	Sequential number within claim Identifies encounter within claim 	22	2005-02-05 14:18:58.135078	source	N
EntitlementIdNotificationEndDate	\N	Y	\N	\N	8	N	Returned Output: Date represented in numeric format as DDMMYYYY.   Constraints: Will be null if not applicable. Use: PBS - Claiming   Level: Prescription Record  A notification date is set when an entitlement number is first given a reason code. Supply after this date using this entitlement number will result in a rejection. If rejected after a timed warning, a date will continue to be returned. (Returned for 'timed warning' only)   	23	2005-02-05 14:18:58.135078	source	N
EpisodeErrorCode	\N	Y	\N	\N	\N	AN	See Return Codes. Can be multiple integers separated by commas Return Codes associated with Episode. 	24	2005-02-05 14:18:58.135078	source	N
EpisodeId	\N	Y	\N	\N	4	A	Must be 4 characters. A-Z, 0-9 Identifies episode within claim. This is the objectId assigned to the Episode when the claim was prepared.  	25	2005-02-05 14:18:58.135078	source	N
ExplanationCode	\N	Y	\N	\N	3	A	See Explanation Codes Medicare explanation code  for assessment result 	26	2005-02-05 14:18:58.135078	source	N
FundBenefitAmount	\N	Y	\N	\N	9	N	Returned Output: In cents i.e. $1.00 is '100'.  The Fund benefit paid/payable for this individual service in cents.  	27	2005-02-05 14:18:58.135078	source	N
FundStatusCode	\N	Y	\N	\N	4	N	Returned Output:  Funds PVF assessment result code.  	28	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode1	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or reject code relating to this item. The reason code will only be returned if it is flagged to be returned to Approved Supplier  	29	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode10	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	30	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode2	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	31	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode3	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	32	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode4	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	33	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode5	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	34	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode6	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	35	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode7	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	36	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode8	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   	37	2005-02-05 14:18:58.135078	source	N
InformationWarningErrorCode9	\N	Y	\N	\N	5	A	Returned Output: Reason type, then Space, then Three-character reason code. eg. 'W 123'   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming, Cancellation   Level: Prescription Record  Indicates the presence of a warning, information or error code relating to this item.   LodgementDateTime  8 N Format: DDMMYYYY Must be a valid date Can not be in the future   Use:StatusRequest; RetrieveReport  Level: Claim  The date the claim was originally lodged to the Hub.    	38	2005-02-05 14:18:58.135078	source	N
MedicareBenefitAmount	\N	Y	\N	\N	9	N	Returned Output: In cents i.e. $1.00 is '100'.  The medicare benefit paid/payable for this individual service in cents.  	39	2005-02-05 14:18:58.135078	source	N
MedicareCardFlag	\N	Y	\N	\N	1	AN	Returned Output:  A= Patient identification amended  I= Patient Medicare Issue number changed  C= Patient Medicare Number changed  W= Patient card used will expire shortly  S= Patient card expired. Future services may be rejected.  X= Old Medicare issue number for patient. Future services may be rejected.  Space= No change   An indicator that details the problem Medicare has with the submitted Medicare card.  	40	2005-02-05 14:18:58.135078	source	N
MedicareExplanationCode	\N	Y	\N	\N	3	N	Medicare Service Explanation / Reason Code. Provides additional information on the assessment of a service. 	41	2005-02-05 14:18:58.135078	source	N
MedicareNumberNotificationEndDate	\N	Y	\N	\N	8	N	Returned Output: Date represented in numeric format as DDMMYYYY.   Constraints: Will be null if not applicable.  This field will only be populated where a Medicare reason code has been issued and an end date is appropriate.  Use: PBS - Claiming   Level: Prescription Record  A notification date is set when a Medicare number is first given the relevant reason code. Supply after this date using this Medicare number will result in a rejection. If rejected after a timed warning, a date will continue to be returned. (Returned for a 'timed warning' only)   	42	2005-02-05 14:18:58.135078	source	N
MedicareNumberValidToDate	\N	Y	\N	\N	8	N	Returned Output: Date represented in numeric format as DDMMYYYY.   Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming   Level: Prescription Record  The absolute end date for a corrected Medicare card. This represents the last date for which the returned corrected Medicare number is valid. This field will only be populated where a corrected Medicare number is returned.  	43	2005-02-05 14:18:58.135078	source	N
MedicareStatusCode	\N	Y	\N	\N	4	A	Returned Output: 0 - indicating that the patient is eligible.  or A 4-digit return code.  Use: OPV Reporting   Return Code associated with OPV request.   	44	2005-02-05 14:18:58.135078	source	N
NetPrice	\N	Y	\N	\N	9	N	The price of the item in cents.  Constraints: Will be null if not applicable. Use: PBS - Preassessment, Claiming   Level: Prescription Record  The PBS rebate to the Pharmacy. This price excludes any patient contribution, brand price premiums and therapeutic group premiums.   	45	2005-02-05 14:18:58.135078	source	N
ParticipantContactNum	\N	Y	\N	\N	19	N	Use: getParticipants  Where:  ParticipantType = F, returns the contact number of the health fund for practitioners to contact ie. HelpDesk number.    	46	2005-02-05 14:18:58.135078	source	N
ParticipantId	\N	Y	\N	\N	3	A	Use: getParticipants  Where:  ParticipantType = F, returns the FundBrandId.    	47	2005-02-05 14:18:58.135078	source	N
ParticipantName	\N	Y	\N	\N	40	A	Use: getParticipants  Where:  ParticipantType = F, returns the Trading Name of the health fund.    	48	2005-02-05 14:18:58.135078	source	N
PaymentRunDate	\N	Y	\N	\N	8	N	Format: DDMMYYYY The date on which the HIC is requesting the RBA to make the payment. 	49	2005-02-05 14:18:58.135078	source	N
PaymentRunNum	\N	Y	\N	\N	3	N	Sequential number allocated to payment run Payment runs numbered up to 999 then recycle from 1 	50	2005-02-05 14:18:58.135078	source	N
PBSCancelNum	\N	Y	\N	\N	12	N	Use: Cancellation  Level: Prescription Record  Unique identifier created by the HIC when the script was cancelled.   	51	2005-02-05 14:18:58.135078	source	N
ProcessStatusCde	\N	Y	\N	\N	\N	AN	Values:  RECEIVED - The claim has been received and accepted for processing  MEDICARE_UNVERIFIED - Delayed PVM failed  MEDICARE_VERIFIED - PVM completed; performing PVF  MEDICARE_REJECTED - The claim has been rejected by Medicare and a report is available  HEALTH_FUND_UNVERIFIED - PVF failed  HEALTH_FUND_VERIFIED - PVF completed  HEALTH_FUND_REJECTED - The claim has been rejected by the Health Fund and a report is available  MEDICARE_ASSESSING - The claim is currently being assessed by Medicare  HEALTH_FUND_ASSESSING - The claim is currently being assessed by the nominated Health Fund  COMPLETE - The claim assessment is complete and a report is now available  Note: for IMC status, the ProcessStatusCde will be prefixed with IMC.  Use:StatusRequest; RetrieveReport  Level: Claim    Result 1 A Returned Output: Claim: A = Original Item claim accepted for payment please forward prescription at end of claim period R = Original Item claim rejected for payment do not send hard copy prescription S = Original Item claim paperwork required prior to payment F = Financial adjustment G = Non-financial adjustment  Pre-Assessment: P = Item claim okay at pre-assessment Q = Item claim failed CEV check at pre-assessment M = Item claim failed generic, non-CEV check at pre-assessment N = Item claim failed both CEV and generic non-CEV checks at pre-assessment  Cancel: C = Item claim cancelled B = Item cannot be cancelled  Use: PBS - Preassessment, Claiming, Result   Level: Prescription record  This indicates the pre-assessment, claiming or cancellation result status of an item.  	53	2005-02-05 14:18:58.135078	source	N
ScheduleFee	\N	Y	\N	\N	9	N	Returned Output: The amount in cents.  The fee determined in the Medical Benefits Schedule for this individual service.   	54	2005-02-05 14:18:58.135078	source	N
ServiceBenefitAmount	\N	Y	\N	\N	9	N	The amount in cents. The amount of benefit assessed as payable for the service. 	55	2005-02-05 14:18:58.135078	source	N
ServiceErrorCode	\N	Y	\N	\N	\N	AN	See Return Codes. Can be multiple integers separated by commas Return Codes associated with Service. 	56	2005-02-05 14:18:58.135078	source	N
ServiceErrorLevel	\N	Y	\N	\N	1	A	Returned Output:  A = Acceptable.  U = Unacceptable.   Return Codes associated with service Acceptable - the claim can be accepted and will be referred to a Medicare staff operator. Unacceptable - the claim cannot be accepted with the current error(s).   	57	2005-02-05 14:18:58.135078	source	N
ServiceFundAssessmentCde	\N	Y	\N	\N	1	A	Returned Output: A = Accepted R = Rejected W = Warning  The assessment status of a service on its return to the Hub from the Fund.   	58	2005-02-05 14:18:58.135078	source	N
ServiceFundExplanationCode	\N	Y	\N	\N	4	N	The Fund's explanation (reason) code for the service assessment status. Provides additional information on the assessment of a service. ServiceFundExplanationText 50 T  The Fund's explanation text for the service explanation code.   	59	2005-02-05 14:18:58.135078	source	N
ServiceId	\N	Y	\N	\N	4	A	Must be 4 characters. A-Z, 0-9 A unique identifier for the service within the claim. This is the ObjectId assigned to the service when created.  	60	2005-02-05 14:18:58.135078	source	N
SupplementaryServiceCount	\N	Y	\N	\N	3	N	Format: With leading zeros. eg "004".  Use: DVA - LMO's only.  The count of all payable services post claims assessment.   	62	2005-02-05 14:18:58.135078	source	N
TimeOfPreparation	\N	Y	\N	\N	6	A	Returned Output: Time (24-hour) represented in string format as HHMMSS. Use: PBS   Level: Header  Time that the response was prepared (Canberra time).   	63	2005-02-05 14:18:58.135078	source	N
TotalSupplementaryAmount	\N	Y	\N	\N	7	N	Format: Amount returned is in cents with leading zeros ie. an amount of $3.00 will be returned as "0000300". Use: DVA - LMO's only.  The total amount of the supplementary payment.   	64	2005-02-05 14:18:58.135078	source	N
VoucherId	\N	Y	\N	\N	2	N	Sequential numbered within claim Identifies voucher within claim This is the ObjectId assigned to the Voucher when created.  	68	2005-02-05 14:18:58.135078	source	N
ClaimId	Y	Y	\N	\N	6	AN	Returned Output: The first 5 characters are numeric. The 6th character is always = '%' Use: IMC Reporting  Level: Claim  Claim identifier. Used, in conjunction with the receipt date, to uniquely identify claims sent to a health fund.  '%' identifies the claim as an IMC.  	10	2005-02-05 14:18:58.135078	source	N
PmsClaimId	Y	Y	\N	\N	22	AN	Format: This element is a composite made of the following elements presented in order  LocationId  DateOfLodgement  TimeOfLodgement   Use: Patient Claims   Claim Identifier.  This element is used for Bulk Bill, DVA and ACIR claims as an input element and differs fom the format presented here. See the relevent entry in the Input Elements for details   	52	2005-02-05 14:18:58.135078	source	N
SessionId	Y	Y	\N	\N	10	N	Unique identifier for the current session. Must be passed to all function calls occurring within that session.  	61	2005-02-05 14:18:58.135078	source	N
TransmissionErrorCode	\N	Y	\N	Y	\N	N	See Return Codes. Transmission data element. A transmission level error response as a positive integer 	65	2005-02-05 14:18:58.135078	source	N
AccountPaidInd	Y	\N	\N	\N	1	A	Y = Paid in full N = Unpaid (default) Use: Patient Claims  Level: Claim  Indicates whether or not an account has been paid in full.   	220	2005-02-05 14:21:18.577464	source	N
AccountReferenceId	Y	\N	\N	\N	20	AN	 Format: For IMC claims the size is 20, otherwise the size is 9.  Use: Patient Claims; IMC  Level: Claim  Account Reference (ACRF). A reference used by the claim submitter to identify a claim.  This reference will be printed on the statement that accompanies the benefit cheque.   	69	2005-02-05 14:21:18.577464	source	N
AccountReferenceNum	Y	\N	\N	\N	8	A	Format: XNNNNNNN  Values for the 'X' Prefix:  For GP and Specialist  M = Medical A = Admissions  For Pathology:  P = Pathology  For Diagnostic Imaging:  D = Diagnostic  Use: DVA  Level: Service  A reference identifying the service for the locations records.   	70	2005-02-05 14:21:18.577464	source	N
AdmissionDate	Y	\N	\N	\N	8	D	Format: DDMMYYYY  Constraints:  Must be a valid date  Must be present where the DischargeDate element is populated  Must be greater than or equal to the PatientDateOfBirth  Must be less than or equal to each DateOfService   Use: IMC  Level: Voucher  Date the patient was admitted to hospital for the stay that incurred the attached services.   	71	2005-02-05 14:21:18.577464	source	N
AfterCareOverrideInd	Y	\N	\N	\N	1	A	Values: Y = Not Normal after care N = Normal (default).  Constraints: If Y, ServiceTypeCde cannot be set to P.  Use: Bulk Bill; Patient Claims; IMC  Level: Service  Indicates if service is part of normal aftercare for the patient.  	72	2005-02-05 14:21:18.577464	source	N
ApprovalNum	Y	\N	\N	\N	6	A	Use: PBS - Preassessment, Claiming, Cancellation  Level: Header  The approved supplier's approval number.  	73	2005-02-05 14:21:18.577464	source	N
AssociateName	Y	\N	\N	\N	3	A	Values: for IMC, use FundBrandId   Constraints: Mutually exclusive to TransactionId(s).  Use: StatusRequest   Level: Claim  Where populated, only statuses of claims for the particular Associate Name will be reported on.  	74	2005-02-05 14:21:18.577464	source	N
AtsiIndicator	Y	\N	\N	\N	1	A	Values: Y = Of Aboriginal or Torres Strait Islander Decent N = Not of Aboriginal of Torres Strait Islander Decent  Use: ACIR (except Next Due Date)  Level: Encounter  An indication of whether the person receiving the immunisation is of Aboriginal or Torres Strait Islander descent.  	75	2005-02-05 14:21:18.577464	source	N
AuthorityApprovalNum	Y	\N	\N	\N	8	A	THIS FIELD IS FOR FUTURE USE Use: PBS - Preassessment, Claiming  Level: Prescription Record  The authority number allocated by HIC and given to the prescriber, if applicable.   	76	2005-02-05 14:21:18.577464	source	N
AuthorityPrescriptionNum	Y	\N	\N	\N	8	N	Use: PBS - Preassessment, Claiming  Level:Prescription Record  The authority number relating to the item, if applicable. Required if the item is prescribed under an authority number. This is the number that appears on the top right of the authority prescription form.  	77	2005-02-05 14:21:18.577464	source	N
BankAccountName	Y	\N	\N	\N	30	A	If one element of the EFT details BankAccountName  BankAccountNum  BSBCode is present, all three must be present. Claim must have AccountPaidInd set to Y  Use: Patient Claims  Level: Claim  Used for EFT payments.  The claimants bank or financial institution account number.   	83	2005-02-05 14:21:18.577464	source	N
BankAccountNum	Y	\N	\N	\N	9	A	If one element of EFT details BankAccountName  BankAccountNum  BSBCode is present, all 3 must be present .  Claim must have AccountPaidInd set to Y  Use: Patient Claims  Level: Claim  Used for EFT payments. The claimants bank or financial institution account number.   	84	2005-02-05 14:21:18.577464	source	N
BenefitAssignmentAuthorised	Y	\N	\N	\N	1	A	Values: Y = Authorised N = Not Authorised (default) Must be set to Y to submit the claim. Use: Bulk Bill; DVA  Level: Service  Indicates that the patient has authorised the assignment of their right of benefit to the practitioner.   	85	2005-02-05 14:21:18.577464	source	N
BillingAgentId	Y	\N	\N	\N	8	A	Constraints: Must conform to Provider Check Digit Routine. See Provider Number Validation for validation details.  Use: IMC  Level: Claim  The provider number of the billing agent.   Brand 2 A Constraints: Required if the prescription refers to an item by brand. Must match the published manufacturer's code. Use: PBS - Preassessment, Claiming  Level: Prescription Record  The manufacturer's code relating to the brand of the item.   BSBCode 6 N If one element of the EFT details  BankAccountName  BankAccountNum  BSBCode is present, all three must be present. Claim must have AccountPaidInd set to Y  Use: Patient Claims  Level: Claim  Used for EFT Payments. The BSB code for the bank and branch where the account is held.  	86	2005-02-05 14:21:18.577464	source	N
BufferSize	Y	\N	\N	\N	\N	N	Use: All  Level: All   The size of the OutputBuffer, specified in bytes.  It is recommended that the buffer be at least 1024  Users of the C DLL (ie., those interfacing from non-Java environments) must provide an appropriately sized output buffer for values returned from some CA functions. If the buffer is too small, return code 2034 is generated (where possible) by the C DLL and the buffer will contain the minimum required size for the buffer.   	87	2005-02-05 14:21:18.577464	source	N
ChargeAmount	Y	\N	\N	\N	9	N	Format: In cents ie $1.00 is 100  Constraints: Minimum amount is 100 (if non zero). Notional charge acceptable for patient claims only. Use: Bulk Bill; Patient Claims; DVA; IMC   Level: Service  The amount charged for the service in cents.  For Bulk Bill and DVA claims, this is the benefit assigned.  	88	2005-02-05 14:21:18.577464	source	N
ClaimantAddressLine1	Y	\N	\N	\N	40	A	Must be present if an address is supplied Use: Patient Claims  Level: Claim  First line of the address to be used for the claim.  	89	2005-02-05 14:21:18.577464	source	N
ClaimantAddressLine2	Y	\N	\N	\N	40	A	Use: Patient Claims  Level: Claim  Second line of the address to be used for the claim.  	90	2005-02-05 14:21:18.577464	source	N
ClaimantAddressLocality	Y	\N	\N	\N	40	A	Must be present if an address is supplied. Should not contain any state code Use: Patient Claims  Level: Claim  The locality of the address to be used for the claim.  	91	2005-02-05 14:21:18.577464	source	N
ClaimantAddressPostcode	Y	\N	\N	\N	4	N	Must be present if an address is supplied Use: Patient Claims  Level: Claim  The post code for the address to be used for the claim.  	92	2005-02-05 14:21:18.577464	source	N
ClaimantDateOfBirth	Y	\N	\N	\N	8	D	Format : DDMMYYYY  Must be a valid date. Must not be a date in the future. Must be supplied if any of:  ClaimantMedicareCardNum  ClaimantFamilyName  ClaimantReferenceNum  ClaimantFirstName  have been supplied.  Use: Patient Claims  Level: Claim  The claimants Date of Birth when the patient and the claimant are not one and the same. Required if claimant is not the patient.  	93	2005-02-05 14:21:18.577464	source	N
AuthProxyPasswd	Y	\N	Y	\N	\N	AN	Default password to be used for authentication at any proxy where no specific value has been set.   	79	2005-02-05 14:21:18.577464	source	N
ClaimantFamilyName	Y	\N	\N	\N	40	A	Must be supplied if any of: ClaimantMedicareCardNum  ClaimantReferenceNum  ClaimantFirstName  ClaimantDateOfBirth  have been supplied. Use: Patient Claims  Level: Claim  The claimants family name when the patient and the claimant are not one and the same. Required if claimant is not the patient.  	94	2005-02-05 14:21:18.577464	source	N
ClaimantFirstName	Y	\N	\N	\N	40	A	Must be supplied if any of: ClaimantMedicareCardNum  ClaimantFamilyName  ClaimantReferenceNum  ClaimantDateOfBirth  have been supplied. Use: Patient Claims  Level: Claim  The claimants first name when the patient and claimant are not one and the same. Required if claimant is not the patient  	95	2005-02-05 14:21:18.577464	source	N
ClaimantMedicareCardNum	Y	\N	\N	\N	10	N	Must be supplied if any of: ClaimantFamilyName  ClaimantReferenceNum  ClaimantFirstName  ClaimantDateOfBirth  have been supplied.  See Medicare Card Number Validation for validation details.  Use: Patient Claims  Level: Claim  The claimants Medicare Card number when the patient and claimant are not one and the same.   	96	2005-02-05 14:21:18.577464	source	N
ClaimantReferenceNum	Y	\N	\N	\N	1	N	Must be supplied if any of: ClaimantMedicareCardNum  ClaimantFamilyName  ClaimantFirstName  ClaimantDateOfBirth  have been supplied. Use: Patient Claims  Level: Claim  The claimants individual Reference Number (found to the left of the claimants name on their Medicare card), when the patient and claimant are not one and the same.  	97	2005-02-05 14:21:18.577464	source	N
ClaimPeriodNum	Y	\N	\N	\N	4	N	Format:YYSQ where:  YY is the last two digits of the year  SQ is the number indicating the number of the claim submitted this calendar year.  If SQ <= 9, it should be prefixed with a 0. Use: PBS - Claiming, Cancellation  Level: Header  Indicates the sequential order and calendar year of the claim.   	98	2005-02-05 14:21:18.577464	source	N
ClaimReference	Y	\N	\N	\N	4	N	Values: Range of 0001 to 9999.  Use: PBS - Claiming, Cancellation  Level: Header  The number of the transmission part within the claim.   	99	2005-02-05 14:21:18.577464	source	N
ClaimSubmissionAuthorised	Y	\N	\N	\N	1	A	Values: Y = Authorised N = Unauthorised (default) Must be set to Y to submit claim Use: Patient Claims  Level: Claim  Indicates that claimant has authorised the location to submit the claim to Medicare on their behalf.   	100	2005-02-05 14:21:18.577464	source	N
ClaimTypeCde	Y	\N	\N	\N	2	A	Values: AG = Agreements SC = Scheme  Use: IMC  Level: Claim  Determines the Health Fund processing class under which a claim is submitted.   	101	2005-02-05 14:21:18.577464	source	N
ClinicCode	Y	\N	\N	\N	4	A	Use: ACIR (excluding NextDueDate); NT providers only  Level: Encounter  The clinic code where the immunisation was administered.   	102	2005-02-05 14:21:18.577464	source	N
CommunityCode	Y	\N	\N	\N	5	A	Use: ACIR (excluding NextDueDate); NT providers only  Level: Encounter  The community code of the person receiving the immunisation.  	103	2005-02-05 14:21:18.577464	source	N
CompensationClaimInd	Y	\N	\N	\N	1	A	Values: Y = subject to a compensation claim. N = not subject to compensation (default). Use: IMC  Level: Voucher  Indicates whether or not the voucher contains services that are subject to a compensation claim.  	104	2005-02-05 14:21:18.577464	source	N
ContactPhoneNum	Y	\N	\N	\N	19	A	Use: Patient Claims; ACIR (excluding NextDueDate); Qld providers only  Level: Patient Claims - Claim; ACIR - Episode  Phone number of the claimant/patient in case there is a need to contact them regarding the claim.  	105	2005-02-05 14:21:18.577464	source	N
ContentType	Y	\N	\N	\N	64	AN	Use: Transmission  Level: Transmission  Indicates the content type included in the transmission  	106	2005-02-05 14:21:18.577464	source	N
DateOfDispensing	Y	\N	\N	\N	\N	N	N Values: Date represented in numeric format as DDMMYYYY  Use: PBS - Preassessment, Claiming  Level: Prescription Record  The date on which the prescription was dispensed.  	107	2005-02-05 14:21:18.577464	source	N
DateOfImmunisation	Y	\N	\N	\N	8	D	Format: DDMMYYYY Must be a valid date. Can not be in the future. Must be after the DOB. Use: ACIR (excluding NextDueDate)  Level: Encounter  The immunisation date on which the patient received the immunisation from the provider.  	108	2005-02-05 14:21:18.577464	source	N
DateOfLodgement	Y	\N	\N	\N	8	D	Format: DDMMYYYY Must be a valid date Can not be in the future  Use: Patient Claims; Same Day Delete  Level: Claim  The date of lodgement of the claim. Note: Should be the computer system date when the claim was created.  	109	2005-02-05 14:21:18.577464	source	N
DateOfPrescribing	Y	\N	\N	\N	8	N	Format: DDMMYYYY Must be valid date.   Constraints: The Client System software should not default this field to the current date. Use: PBS - Preassessment, Claiming  Level: Prescription Record  The date that the prescriber wrote the prescription.   	110	2005-02-05 14:21:18.577464	source	N
DateOfService	Y	\N	\N	\N	8	D	Format: DDMMYYYY Must be a valid date Cannot be in the future Must be less than 6 in the past  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Bulk Bill, Patient Claims and DVA - Voucher; IMC - Service  The date the service was rendered to the patient.  	111	2005-02-05 14:21:18.577464	source	N
DateOfSupply	Y	\N	\N	\N	8	N	Values: Date represented in numeric format as DDMMYYYY.   Constraints: This field is required at claiming if the item has been supplied to the patient. Use: PBS - Claiming  Level: Prescription Record  The date on which the pharmaceutical benefit was supplied.   	112	2005-02-05 14:21:18.577464	source	N
DischargeDate	Y	\N	\N	\N	8	D	Format: DDMMYYYY  Constraints:  If the DischargeDate is present, AdmissionDate must also be present.  must be a valid date  cannot be a future date  must be greater than or equal to the PatientDateOfBirth  must be greater than or equal to the AdmissionDate  must be greater than or equal to each DateOfService   Use: IMC  Level: Voucher  The date at which the patient was discharged from their stay in hospital.  	114	2005-02-05 14:21:18.577464	source	N
DistanceKms	Y	\N	\N	\N	3	N	Use: DVA  Level: Voucher  Indicates traveling distance involved in a Home, Nursing Home or Hospital visit.  For a kilometre payment to be made TreatmentLocation of the services within the voucher must be V or H.   	115	2005-02-05 14:21:18.577464	source	N
DuplicateServiceOverrideInd	Y	\N	\N	\N	1	A	Values: Y = Not Duplicate N = Duplicate (Default)  Constraints: If Y:  either the ServiceText or TimeOfService element must also be set.  ServiceTypeCde cannot be set to P.   Use: Bulk Bill; Patient Claims; IMC   Level: Service  Indicates if practitioner attended patient on more than one occasion on same day.  	116	2005-02-05 14:21:18.577464	source	N
EntitlementId	Y	\N	\N	\N	11	A	Format: Must match the appropriate format for the entitlement identifier being used.  Constraints: This field is not required for payment categories:  1 (General)  5 (Doctor's Bag Order Forms)   Use: PBS - Preassessment, Claiming  Level: Prescription Record  Indicates the number of the following cards:  Health Care Card  Pensioner Concession Card  Repatriation Health Card (Specific or All Conditions)  Commonwealth Seniors Health Card  Repatriation Pharmaceutical Benefits Card  Safety Net Entitlement card  Safety Net Concession card    	117	2005-02-05 14:21:18.577464	source	N
EquipmentId	Y	\N	\N	\N	5	N	Constraints: If present:  ServiceTypeCde must be set to S.  LSPNum must be present.  FieldQuantity must be present.  Mutually exclusive to:  ReferralPeriodTypeCde  ReferringProviderNum  ReferralIssueDate  ReferralPeriod  NoOfPatientsSeen  TimeDuration   Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Service  The identification number (allocated by the Dept. of Health & Ageing) of equipment used for the service. Usually applies to radiotherapy equipment  	118	2005-02-05 14:21:18.577464	source	N
FacilityId	Y	\N	\N	\N	8	AN	Constraints: First 7 characters must be numeric, 8th character must be alpha. See Provider Number Validation for validation details. Must be set if ClaimTypeCde is set to AG or SC. Use: IMC  Level: Claim  The Commonwealth Hospital Facility Provider Number. A unique identifier of a Registered Hospital or Day Care Facility.   	119	2005-02-05 14:21:18.577464	source	N
FamilyName	Y	\N	\N	\N	40	A	Values: The family name as per the Medicare or DVA card.  Constraints: This field is not required for Doctor's Bag Order Forms.  Use: PBS - Preassessment, Claiming  Level: Prescription Record  The surname of the person for whom the prescription was written sourced from Medicare card or equivalent DVA card.   	120	2005-02-05 14:21:18.577464	source	N
FieldQuantity	Y	\N	\N	\N	1	N	Constraints: If present:  ServiceTypeCde must be set to S.  LSPNum must be present.  EquipmentId must be present.  Mutually exclusive to:  ReferralPeriodTypeCde  ReferringProviderNum  ReferralIssueDate  ReferralPeriod  NoOfPatientsSeen  TimeDuration   Use: - Bulk Bill; DVA; Patient Claims; IMC  Level: - Service  The number of fields irradiated.  	121	2005-02-05 14:21:18.577464	source	N
FilePath	Y	\N	\N	\N	\N	AN	The location of the directory containing the PSI Store. 	122	2005-02-05 14:21:18.577464	source	N
FormCategory	Y	\N	\N	\N	1	A	Values:  1 = Original  2 = Repeat  3 = Original authority  4 = Repeat authorisation relating to an authority  5 = Deferred supply authorisation  6 = Prescription written by a participating dental practitioner  7 = Doctor's bag order form  8 = DVA Authority  9 = DVA Authority Repeat Form   Use: PBS - Preassessment, Claiming  Level: Prescription Record  Identifies the prescription form type.  	123	2005-02-05 14:21:18.577464	source	N
FinancialInterestDisclosureInd	Y	\N	\N	\N	1	N	Values: Y = Financial Interest Disclosed. N = No Financial Interest Disclosed. (Default) Constraints: If ClaimTypeCde is set to SC, then FinancialInterestDisclosureInd must be Y.  Use: IMC  Level: Voucher  Indicates that the Provider providing hospital treatment or associated professional attention under a gap cover scheme has disclosed to the insured person any financial interest that the first-mentioned Provider or associated professional person has in any products or services recommended or given to the insured person.  	124	2005-02-05 14:21:18.577464	source	N
FundBrandId	Y	\N	\N	\N	3	A	Use: IMC, OPV  Level: Claim  A unique identifier for each Health Fund Brand Name.   	125	2005-02-05 14:21:18.577464	source	N
FundPayeeId	Y	\N	\N	\N	12	AN	Use: IMC  Level: Claim  The Health Fund Agreement identifier for the practitioner (which at a Fund is mapped to payment arrangement details).   	126	2005-02-05 14:21:18.577464	source	N
GivenName	Y	\N	\N	\N	40	A	Values: The given name as per the Medicare or DVA card.  Constraints: This field is not required for Doctor's Bag Order Forms. Use: PBS - Preassessment, Claiming  Level: Prescription Record  The given name of the person for whom the prescription was written sourced from their Medicare card or equivalent DVA card.   	127	2005-02-05 14:21:18.577464	source	N
GlassBottleInd	Y	\N	\N	\N	1	A	Values: Y = True N = False  Use: PBS - Preassessment, Claiming  Level: Prescription Record  Indicates whether or not a glass bottle is being claimed for the medicine. This is only applicable for the following extemporaneously prepared items (ones that the pharmacy has to prepare from individual ingredients) eye drops, ear drops and nasal instillations where the standard polythene container is not appropriate.   	128	2005-02-05 14:21:18.577464	source	N
HclPassphrase	Y	\N	\N	\N	\N	AN	the Passphrase to unlock the PSI Store containing the location certificate. 	129	2005-02-05 14:21:18.577464	source	N
HepBBirthDoseDate	Y	\N	\N	\N	8	N	Format: DDMMYYYY.  Must be a valid date. Date must be on or after 1/1/1996. Must be on or after DOB. Cannot be in the future  Use: ACIR (except NextDueDate)  Level: Encounter  The Date of a child's Hep B Birth Dose.  	130	2005-02-05 14:21:18.577464	source	N
HepBBirthDoseInd	Y	\N	\N	\N	1	A	Values: Y = Hep B Birth dose was administered by a different provider Blank = Hep B Birth dose was not administered or advised Use: ACIR (except NextDueDate)  Level: Encounter  Where the child has received a Hep B Birth dose from a different provider.    	131	2005-02-05 14:21:18.577464	source	N
HospitalInd	Y	\N	\N	\N	1	A	Values: Y = In Hospital N = Not In Hospital (Default) If Y, the name or provider number of the hospital must be provided in the ServiceText field. Use: Bulk Bill; Patient Claims  Level: Service  Indicates if service rendered in hospital or not.   	132	2005-02-05 14:21:18.577464	source	N
HospitalProviderNum	Y	\N	\N	\N	8	A	Constraints: This field is only required if the benefit was supplied in an approved public hospital Use: PBS - Preassessment, Claiming  Level: Prescription Record  Provider number of the public hospital where the prescription originated.   	133	2005-02-05 14:21:18.577464	source	N
IFCIssueCde	Y	\N	\N	\N	1	A	Values: V - Verbal W - Written N - Not Issued (default).  Constraints: If ClaimTypeCde is set to AG, then IFCIssueCde must be either V or W. If ClaimTypeCde is set to SC, then IFCIssueCde must be W.  Use: IMC  Level: Voucher  Indicates 'IFC' was provided prior to the Episode of care.  	134	2005-02-05 14:21:18.577464	source	N
ImmediateSupplyNecessaryInd	Y	\N	\N	\N	1	A	Values: Y = True N = False  Use: PBS - Preassessment, Claiming  Level: Prescription Record  Indicates that immediate supply was necessary as per regulation 25.   	135	2005-02-05 14:21:18.577464	source	N
ImmunisingProviderNum	Y	\N	\N	\N	7	A	See Provider Number Validation for validation details. Use: ACIR - General Immunisation  Level: Claim  The provider or ancillary number (as allocated by HIC) of the provider who administered the immunisation.   	136	2005-02-05 14:21:18.577464	source	N
InformationProviderNum	Y	\N	\N	\N	8	A	See Provider Number Validation for validation details. Use: ACIR  Level: Claim  The provider or ancillary number (as allocated by HIC) of the provider or body providing the immunisation data.   	137	2005-02-05 14:21:18.577464	source	N
ItemNum	Y	\N	\N	\N	5	A	Constraints: MISC is only applicable to Patient Claims.  If MISC is used there must also be a non-zero ChargeAmount.  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Service  Item numbers in Medicare claims denote services provided and are contained in the Medicare Benefits Schedule Book (see the Dept. of Health & Ageing website for details) or denoted as MISC .   Item numbers in DVA medical claims denote specific DVA services which are available from DVA.  LCCId  3 A If Bulk Bill must be present for a Pathology Claim. Use: Bulk Bill; Patient Claims; DVA  Level: Service  Licensed Collection Centre Identifier. Note: now known as Specimen Collection Point.  	138	2005-02-05 14:21:18.577464	source	N
MedicareNum	Y	\N	\N	\N	11	N	Constraints: Not required for payment categories:  5 (Doctor's Bag Order Forms)  4 (DVA File Number Used)   Use: PBS - Preassessment, Claiming  Level: Prescription Record  The Medicare card number (including card issue number and individual reference number) of the person for whom the prescription was written.   	141	2005-02-05 14:21:18.577464	source	N
MultipleProcedureOverrideInd	Y	\N	\N	\N	1	A	Values: Y = Not Multiple N = Multiple (Default)  Constraints:  If present, ServiceTypeCde cannot be set to P.  If present, the reason for the override must be included in the ServiceText  Mutually exclusive with: NoOfPatientsSeen   Use: Bulk Bill; Patient Claims; IMC  Level: Service  Indicates whether service part of a multiple procedure or not.  Note: when set, the associated claim is automatically sent to pend.   	142	2005-02-05 14:21:18.577464	source	N
NextDueDate	Y	\N	\N	\N	8	A	Format: DDMMYYYY  Must be a valid date. Must be a date in the future. Must be after DOB. Use: Next Due Date  Level: Encounter  The date the next immunisation is due.   	143	2005-02-05 14:21:18.577464	source	N
NoOfPatientsSeen	Y	\N	\N	\N	2	N	Values: 01-99 Defaults to 01.  Constraints: Non Zero  If DVA, is required for the following professional attendance items:  Nursing Home  Hospital  Home Visits  If present, ServiceTypeCde must not be set to P. Mutually exclusive with:  ReferralPeriodTypeCde  ReferringProviderNum  ReferralIssueDate  ReferralPeriod  RequestingProviderNum  RequestTypeCde  RequestIssueDate  LSPNum  EquipmentId  TimeDuration  FieldQuantity  MultipleProcedureOverrideInd   Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Service  The number of patients seen. Note: for specialist claims, this is the number of Services.  	144	2005-02-05 14:21:18.577464	source	N
NumberOfRepeats	Y	\N	\N	\N	2	N	Use: PBS - Preassessment, Claiming  Level: Prescription Record  Indicates the number of repeats ordered by the prescriber. Zero is an acceptable value for this field, if applicable.   	145	2005-02-05 14:21:18.577464	source	N
NumberOfServices	Y	\N	\N	\N	2	N	Filled with leading zeros Use: DVA - specialist services  Level: Service  Identifies the number of services  	146	2005-02-05 14:21:18.577464	source	N
OPVTypeCde	Y	\N	\N	\N	3	A	Values: PVM = Medicare only PVF = Fund OPV = Both Use: OPV  Level: Claim  Identifies the type of Online Patient Verification request that is to be submitted.  	147	2005-02-05 14:21:18.577464	source	N
ParticipantType	Y	\N	\N	\N	1	AN	Values: F = Health Funds  Use: getParticipants   Identifies all current HIC Online particpants of the type specified  	148	2005-02-05 14:21:18.577464	source	N
PatientAddressLine1	Y	\N	\N	\N	40	A	Must be present if an address is supplied Use: ACIR  Level: Encounter  First line of the address to be used for patient.  	149	2005-02-05 14:21:18.577464	source	N
PatientAddressLine2	Y	\N	\N	\N	40	A	Use: ACIR  Level: Encounter  Second line of the address to be used for patient.  	150	2005-02-05 14:21:18.577464	source	N
PatientAddressLocality	Y	\N	\N	\N	40	A	Constraints:  Must be present if an address is supplied.  Should not contain any state codes.  If DVA must be present if Personal Details Type is Voucher.   Use: DVA; ACIR  Level: ACIR - Encounter; DVA - Voucher  The locality for the address to be used for patient.  	151	2005-02-05 14:21:18.577464	source	N
PatientAddressPostcode	Y	\N	\N	\N	4	N	Constraints:  Must be present if an address is supplied  Mandatory for ACIR   Use: DVA; ACIR  Level: ACIR - Encounter; DVA - Voucher  The postcode for the address to be used for patient.  	152	2005-02-05 14:21:18.577464	source	N
PatientAliasFamilyName	Y	\N	\N	\N	40	AN	Format: 1- 40 valid characters:  Alphas (A-Z)  Hyphens (Max 3)  Apostrophes  Numerics  Spaces  Chars 1: must be alpha  Use: IMC; OPV  Level: IMC - Voucher; OPV - Claim  Patient's Family Name as known to Health Fund if different to that known by Medicare.  	153	2005-02-05 14:21:18.577464	source	N
PatientAliasFirstName	Y	\N	\N	\N	40	AN	Format: 1- 40 valid characters:  Alphas (A-Z)  Hyphens (Max 3)  Apostrophes  Numerics  Spaces  Chars 1: must be alpha  Use: IMC; OPV  Level: IMC - Voucher; OPV - Claim  Patient's First Name as known to Health Fund if different to that known by Medicare.  	154	2005-02-05 14:21:18.577464	source	N
PatientCategory	Y	\N	\N	\N	1	A	Values: H = Private hospital patient (paperless) B = Public hospital patient N = Nursing home C = Paperless public hospital patient 0 (Zero) = Community patient Use: PBS - Preassessment, Claiming  Level: Prescription Record  Identifies the patient category.   	155	2005-02-05 14:21:18.577464	source	N
PatientContribAmt	Y	\N	\N	\N	7	N	Format: amount in cents.  Values: Defaults to zero If a non zero amount, it must be at least 100 (ie no amount less than $1.00 may be entered.)  Constraints: Must be zero if AccountPaidInd = Y Use: Patient Claims  Level: Service  The amount paid by a patient to a provider for a service. It can be any amount paid by the patient where the service charge has not been fully paid.   	156	2005-02-05 14:21:18.577464	source	N
PatientDateOfBirth	Y	\N	\N	\N	8	N	Format : DDMMYYYY  Must be a valid date. Must not be a date in the future. Must be supplied if any of:  PatientMedicareCardNum  PatientFamilyName  PatientReferenceNum  PatientFirstName  have been supplied.  Use: Bulk Bill; Patient Claims; DVA; ACIR; OPV; IMC  Level: Patient Claims & OPV - Claim; Bulk Bill, DVA & IMC - Voucher; ACIR - Encounter  The patients Date of Birth.  	157	2005-02-05 14:21:18.577464	source	N
LocationId	Y	\N	Y	Y	8	AN	Format: XXXNNNNN  First 3 characters identify client system product or supplier. Use: Session  Level: Session  The identifier allocated to the location.   	139	2005-02-05 14:21:18.577464	source	N
PatientFamilyName	Y	\N	\N	\N	40	AN	Format: 1- 40 valid characters:  Alphas (A-Z)  Hyphens (Max 3)  Apostrophes  Numerics  Spaces  Chars 1: must be alpha Note: If DVA, PatientFamilyName must be present if Personal Details is of Type Voucher Must be supplied if any of:  PatientDateOfBirth  PatientMedicareCardNum  PatientReferenceNum  PatientFirstName  have been supplied.  Use: Bulk Bill; Patient Claims; DVA; ACIR; OPV; IMC  Level: Patient Claims & OPV - Claim; Bulk Bill, DVA & IMC - Voucher; ACIR - Encounter  The patients family name.   	158	2005-02-05 14:21:18.577464	source	N
PatientFirstName	Y	\N	\N	\N	40	AN	Format: 1- 40 valid characters:  Alphas (A-Z)  Hyphens (Max 1)  Apostrophes  Numerics  Spaces  Must be supplied if any of:  PatientDateOfBirth  PatientMedicareCardNum  PatientFamilyName  PatientReferenceNum  have been supplied.  Use: Bulk Bill; Patient Claims; DVA; ACIR; OPV; IMC  Level: Patient Claims & OPV - Claim; Bulk Bill, DVA & IMC - Voucher; ACIR - Encounter  The patients first given name. Where a patient has only one name, that name should appear in the PatientFamilyName field and the word Onlyname be entered in the PatientFirstName field.   	159	2005-02-05 14:21:18.577464	source	N
PatientFundMembershipNum	Y	\N	\N	\N	19	AN	Use: IMC; OPV  Level: IMC - Voucher; OPV - Claim  Patient's Health Fund Membership number.  	160	2005-02-05 14:21:18.577464	source	N
PatientFundUPI	Y	\N	\N	\N	2	N	Use: IMC; OPV  Level: IMC - Voucher; OPV - Claim  Fund 'Universal Patient Identifier' (UPI). The UPI appears on the Patient's fund membership card to uniquely identify individuals. (Fund equivalent of Medicare PatientReferenceNum).  	161	2005-02-05 14:21:18.577464	source	N
PatientGender	Y	\N	\N	\N	1	A	Values: M = Male F = Female   Use: DVA; ACIR; IMC; OPV  Level: DVA & IMC - Voucher; ACIR - Encounter; OPV - Claim  Patient gender  	162	2005-02-05 14:21:18.577464	source	N
PatientMedicareCardNum	Y	\N	\N	\N	10	N	See Medicare Card Number Validation for validation details. Must be supplied if any of: PatientDateOfBirth  PatientFamilyName  PatientReferenceNum  PatientFirstName  have been supplied.  Use: Bulk Bill; Patient Claims; ACIR; OPV; IMC  Level: Patient Claims & OPV - claim, Bulk Bill & IMC - Voucher; ACIR - Encounter  The patients Medicare Card Number.  	163	2005-02-05 14:21:18.577464	source	N
PatientProviderChildId	Y	\N	\N	\N	10	A	Use: ACIR  Level: Encounter  The reference allocated by the provider for the patient.  	164	2005-02-05 14:21:18.577464	source	N
PatientReferenceNum	Y	\N	\N	\N	1	N	Must be supplied if any of: PatientDateOfBirth  PatientMedicareCardNum  PatientFamilyName  PatientFirstName  have been supplied.   Constraints: Cannot be zero  Use: Bulk Bill; Patient Claims; ACIR; OPV; IMC  Level: Patient Claims & OPV - claim, Bulk Bill & IMC - Voucher; ACIR - Encounter  The patients Medicare Reference Number. This number appears to the left of the patients name on their Medicare card.  	165	2005-02-05 14:21:18.577464	source	N
PatientSecondInitial	Y	\N	\N	\N	1	A	 Use: DVA; IMC  Level: Voucher  The second initial of the patient's second given name.  	166	2005-02-05 14:21:18.577464	source	N
PayeeProviderNum	Y	\N	\N	\N	8	A	See Provider Number Validation for validation details. Use: Bulk Bill; Patient Claims; DVA  Level: Claim  The provider number of the principal provider where the payment is to be directed to other than the servicing provider.   	167	2005-02-05 14:21:18.577464	source	N
PaymentCategory	Y	\N	\N	\N	1	N	Values: 1 = General benefit 2 = PBS Safety Net (free) 3 = Concessional benefit 4 = Repatriation 5 = Doctor's bag order form Use: PBS - Preassessment, Claiming  Level: Prescription Record  Indicates the type of benefit and level of patient co-payment.   	168	2005-02-05 14:21:18.577464	source	N
PBSItemCode	Y	\N	\N	\N	6	A	Constraints:  Matches the item code published in the Schedule of Pharmaceutical Benefits.  Required for all non-repatriation items.  For unlisted RPBS benefits this field should be completed '000000'.   Use: PBS - Preassessment, Claiming  Level: Prescription Record  Item code of the medication, which appears in the Schedule of Pharmaceutical Benefits.   	169	2005-02-05 14:21:18.577464	source	N
PBSReferenceNum	Y	\N	\N	\N	12	A	Constraints: Not required at claiming if item has not been pre-assessed. Use: PBS - Claiming, Cancellation  Level: Prescription Record  A number created by HIC when a pre-assessment was requested by pharmacy.   	170	2005-02-05 14:21:18.577464	source	N
PharmacyProcessingCode	Y	\N	\N	\N	2	A	Values: 00 - No override 01 - New Centrelink customer (see note below) 02 -ISP not available  Note: the pharmacy has sighted information showing that the consumer is a new customer to Centrelink that day and is actually entitled to PBS at the concessional rate.   Use: PBS - Claiming  Level: Prescription Record  Indicates that the pharmacist has elected to make supply at concession level, despite assessment result.  	172	2005-02-05 14:21:18.577464	source	N
PrescriberId	Y	\N	\N	\N	7	A	Use: PBS - Preassessment, Claiming  Level: Prescription Record  The PBS identifier for the prescriber. A doctor (or other prescriber) only has one prescriber number, which covers all of their practices.   	176	2005-02-05 14:21:18.577464	source	N
PreviousSupplies	Y	\N	\N	\N	2	N	Use: PBS - Preassessment, Claiming  Level: Prescription Record  Number of times that this set of an original prescription and its repeats have already been supplied. Zero is an acceptable value for this field, if applicable.   Price 7 N Values: The price of the item in cents.  Constraints: This fields is required where any of the following events occurs:  Pharmacy has elected to price all non-standard extemporaneously prepared items  Pharmacy has elected to claim an exceptionally priced extemporaneously prepared item  Where the item does not appear in either the Schedule of PBS or RPBS benefits and it has been prior approved by DVA (an unlisted RPBS item)  This field should contain the price of the item in cents. If none of these circumstances apply, this field should be set to 0 (zero).  Use: PBS - Preassessment, Claiming  Level: Prescription Record  The price of the item.  	177	2005-02-05 14:21:18.577464	source	N
PrincipalProviderNum	Y	\N	\N	\N	8	AN	Format: See Provider Number Validation for validation details.   Constraints: Must not be the same stem (first 6 numbers) as the ReferringProviderNum or RequestingProviderNum (where present).  Use: IMC  Level: Claim  The Principal Provider Number is used to direct payment to a provider other than the servicing provider.   Quantity 5 N  Use: PBS - Preassessment, Claiming  Level: Prescription Record  Quantity of the item supplied. For Regulation 24 this is the total quantity supplied (the original plus repeats).  ReceivedFromDateTime ? DT Constraints:  must be a valid date-time  must be less than or equal to ReceivedToDateTime  may be set equal to ReceivedToDateTime to specifiy a single day.   Use: StatusRequest  Level: Claim  The start date time for a request selection.  ReceivedToDateTime ? DT Constraints:  must be a valid date-time  must be greater than or equal to ReceivedFromDateTime  may be set equal to ReceivedFromDateTime to specifiy a single day.   Use: StatusRequest  Level: Claim  The end date time for a request selection.  	178	2005-02-05 14:21:18.577464	source	N
ReferralDateFrom	Y	\N	\N	\N	8	N	Format: DDMMYYYY Must be a valid date Must be present if Referral details supplied.  Use: DVA - Specialist Services  Level: Voucher  The date from which the referral is valid.  	179	2005-02-05 14:21:18.577464	source	N
ReferralDateTo	Y	\N	\N	\N	8	N	Format: DDMMYYYY Must be a valid date Must be present if Referral details supplied. Must not be before ReferralDateFrom  Use: DVA - Specialist Services  Level: Voucher  The date until which the referral is valid.  	180	2005-02-05 14:21:18.577464	source	N
ReferralIssueDate	Y	\N	\N	\N	8	D	Format: DDMMYYYY  Constraints: Must be a valid date Must be greater than or equal to the PatientDateOfBirth. Must be present if Referral details supplied. Must not be a date in the future. Must not be after each DateOfService. If DVA, must be present if the service is of type Specialist Referral.  If present, the ServiceTypeCde must be set to S.  Must be present if ReferringProviderNum, ReferralPeriodTypeCde or ReferralPeriod are set.  Mutually Exclusive to: SelfDeemedCde NoOfPatientsSeen EquipmentId FieldQuantity ReferralOverrideTypeCde RequestingProviderNum RequestTypeCde RequestIssueDate.  Use: Bulk Bill; Patient Claims; DVA, IMC  Level: Voucher  The date the referral was issued.   	181	2005-02-05 14:21:18.577464	source	N
ReferralOverrideTypeCde	Y	\N	\N	\N	1	AN	Values: L = Lost  E = Emergency H = Hospital N = Not required (default) Constraints: Can only be used when ServiceTypeCde is set to S. Must be present where ServiceTypeCde is set to S, and the following elements are not set:  ReferralIssueDate  ReferringProviderNum  ReferralPeriodTypeCde  ReferralDateTo  ReferralDateFrom  If set to H, Hospital details must be included in the ServiceText.   Mutually exclusive to: NoOfPatientsSeen SelfDeemedCde  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Voucher  Indicates why referral services were provided without referral from another practitioner.   	182	2005-02-05 14:21:18.577464	source	N
ReferralPeriod	Y	\N	\N	\N	2	N	Constraints: Cannot be 00 or 99. Can only be used if ServiceTypeCde is set to S. Must be set if ReferralPeriodTypeCde is set to N. Cannot be set if ReferralPeriodTypeCde is set to S or I.  Mutually exclusive to: SelfDeemedCde NoOfPatientsSeen EquipmentId FieldQuantity RequestingProviderNum RequestIssueDate RequestTypeCde.  Use: IMC  Level: Voucher  The length of the referral in months.   	184	2005-02-05 14:21:18.577464	source	N
ReferralPeriodTypeCde	Y	\N	\N	\N	1	A	Values: S - Standard (12 months from a GP and 3 months from a Specialist) N - Non standard I � Indefinite Constraints:  Mutually Exclusive to: SelfDeemedCde NoOfPatientsSeen EquipmentId FieldQuantity ReferralOverrideTypeCde RequestingProviderNum RequestTypeCde RequestIssueDate.   For IMC Must be set where: ServiceTypeCde is set to S AND ReferralOverrideTypeCde has not been set.   For DVA If N: the data elements ReferralDateFrom and ReferralDateTo must contain entries detailing the length of the referral period.  For Bulk Bill and Patient Claims If N: the period must be specified in the ServiceText   Must be present if ReferringProviderNum and ReferralIssueDate are present.  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Voucher  Indicates period of referral.   	185	2005-02-05 14:21:18.577464	source	N
ReferringProviderNum	Y	\N	\N	\N	8	AN	Constraints: See Provider Number Validation for validation details. Must be present if either ReferralIssueDate or ReferralPeriodTypeCde are present.  Can only be used if ServiceTypeCde = S.  Must not be the same stem (first 6 numbers) as the ServicingProviderNum.  Mutually exclusive to: SelfDeemedCde NoOfPatientsSeen EquipmentId FieldQuantity RequestingProviderNum RequestTypeCde RequestIssueDate.  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Voucher  The provider number (allocated by the HIC) of the referring provider.   Regulation24Ind 1 A Values: Y = True N = False  Use: PBS - Preassessment, Claiming  Level: Prescription Record  Indicates whether the supply of the original prescription and repeat(s) is made at one time pursuant to Regulation 24.   	186	2005-02-05 14:21:18.577464	source	N
ReportStatusCde	Y	\N	\N	\N	\N	AN	Values:  PROCESSING  READY  REPORTED   Constraints: Mutually exclusive to TransactionId(s).   Use: StatusRequest  Level: Claim   The claim status to be used to select claims for the report.   	187	2005-02-05 14:21:18.577464	source	N
RequestContentType	Y	\N	\N	\N	\N	AN	Values: for IMC, use InpatientMedicalClaim   Constraints: Mutually exclusive to TransactionId(s).  Use: StatusRequest  Level: Claim  The ContentType of the original transmission which is the subject of this request.   	188	2005-02-05 14:21:18.577464	source	N
RequestingProviderNum	Y	\N	\N	\N	8	AN	Constraints: Must conform to the Provider Check Digit routine. See Provider Number Validation for validation details.  Must be present if Pathology or Diagnostic Imaging Request, except where all services self deemed.  Must not be the same stem (first 6 numbers) as the ServicingProviderNum.  Can only be used if ServiceTypeCde is set to S or P.  Must be present if RequestTypeCde or RequestIssueDate are present.  Mutually exclusive to: NoOfPatientsSeen ReferringProviderNum ReferralPeriodTypeCde ReferralPeriod ReferralIssueDate SelfDeemedCde.  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Voucher  The provider number (allocated by the HIC) of the requesting provider.   	189	2005-02-05 14:21:18.577464	source	N
RequestIssueDate	Y	\N	\N	\N	8	N	Format: DDMMYYYY  Constraints: Must be a valid date. Must not be in the future. Must be present if Pathology or Diagnostic Imaging request. Must not be after DateOfService. Must be greater than or equal to the PatientDateOfBirth.  Can only be used if ServiceTypeCde = S or P.  Must be present if RequestingProviderNum, or RequestTypeCde are present.  Mutually exclusive to: NoOfPatientsSeen SelfDeemedCde ReferringProviderNum ReferralPeriodTypeCde ReferralPeriod ReferralIssueDate.  Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Voucher  Date the request was issued.   	190	2005-02-05 14:21:18.577464	source	N
RequestTypeCde	Y	\N	\N	\N	1	AN	Values: P = Pathology D = Diagnostic Imaging  If P then the ServiceTypeCde on the claim, if applicable, must be set to P. If D then the ServiceTypeCde on the claim, if applicable, must be set to S.  Mutually exclusive to: SelfDeemedCde ReferringProviderNum ReferralPeriodTypeCde ReferralPeriod ReferralIssueDate   Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Voucher  Indication of the type of a request  	192	2005-02-05 14:21:18.577464	source	N
ResubmissionInd	Y	\N	\N	\N	1	A	Values: Y = True N = False  Use: PBS - Claiming  Level: Prescription Record  Indicates whether the script was previously rejected in another claim and is being resubmitted.   	193	2005-02-05 14:21:18.577464	source	N
Rule3ExemptInd	Y	\N	\N	\N	1	A	Values: Y = Exempt N = Not Exempt (default)  Constraints: If Y, then:  the ServiceTypeCde must be set to P.  TimeOfService must be set.   If used in a Bulk Bill claim, ServiceTypeCde must be set to P  Use: Bulk Bill; Patient Claims; IMC  Level: Service  Indicates if Rule 3 in Medicare Benefits Schedule Book applies or not.   SCPId 3 AN Constraints: Cannot be 000.  If present, ServiceTypeCde must be set to P.  Mutually exclusive to:   ReferralPeriodTypeCde  ReferringProviderNum  ReferralIssueDate  ReferralPeriod  Use: IMC  Level: Service  Specimen Collection Point. For pathology services only.   	194	2005-02-05 14:21:18.577464	source	N
SDDReasonCode	Y	\N	\N	\N	3	N	Format: nnn Fixed length.  Values: 001 - Incorrect Patient Selection 002 - Incorrect Provider Details 003 - Incorrect Date of Service 004 - Incorrect Item Number Claimed 005 - Omitted Text on Original Claim 006 - Incorrect Payment Type (ie Paid / Unpaid) 007 - Other  Use: Same Day Delete  Level: Claim  The reason code supporting the same day deletion request.  	195	2005-02-05 14:21:18.577464	source	N
SelfDeemedCde	Y	\N	\N	\N	2	AN	Values: SD = Self Deemed SS = Substituted Service N = Not Self Deemed (default) Note: Y = Self Deemed is no longer supported Constraints: If present, ServiceTypeCde must be set to either P or S.  Use: Bulk Bill; Patient Claims; IMC  Level: Service  Request details not required if SelfDeemedCde = SD. Indicator is available for services rendered in the following situations:  Services rendered by a consultant physician or specialist, in the course of that consultant physician or specialist practising his or her speciality  Services rendered as an additional service to a valid requested service   A substituted service is a service judged to be more appropriate for the diagnosis of the patient's condition than the original service requested.  	197	2005-02-05 14:21:18.577464	source	N
SenderContactPersonName	Y	\N	\N	\N	40	AN	Use: IMC  Level: Claim  Name of contact at claim submission site to be contacted should clarification about claim details be required.   	198	2005-02-05 14:21:18.577464	source	N
SenderContactPersonPhone	Y	\N	\N	\N	19	AN	Use: IMC  Level: Claim  Phone number of contact at claim submission site to be used should clarification about claim details be required.   	199	2005-02-05 14:21:18.577464	source	N
SerialNum	Y	\N	\N	\N	5	N	Use: PBS - Preassessment, Claiming  Level: Prescription Record  The serial number must start at 1 for each payment category within a claim period, and run sequentially within that claim period.  	217	2005-02-05 14:21:18.577464	source	N
ServiceText	Y	\N	\N	\N	50	AN	Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Service  Free text used to provide additional information to assist with the benefit assessment of the service.   	201	2005-02-05 14:21:18.577464	source	N
ServiceTypeCde	Y	\N	\N	\N	1	A	Values: P = pathology services S = specialist services (including diagnostic imaging) O = other  Constraints: All ItemNum/s within the claim must be consistent with the Service Type selected. P is not valid for DVA.  Use: Bulk Bill; DVA; IMC  Level: Bulk Bill & DVA = Claim; IMC = Voucher  Indicates the type of service that makes up the claim.  	203	2005-02-05 14:21:18.577464	source	N
ServicingProviderNum	Y	\N	\N	\N	8	AN	Must conform to Provider Check Digit Routine. See Provider Number Validation for validation details. Must not be the same stem (first 6 numbers) as the ReferringProviderNum or RequestingProviderNum (where present).  For IMC, if PrincipalProviderNum is not set on the claim, the ServicingProviderNum must be the same for all vouchers.  Use: Bulk Bill; Patient Claims; DVA; OPV: IMC  Level: Claim except IMC (voucher)  The provider number (as allocated by the HIC) of the medical practitioner rendering the service(s).  	204	2005-02-05 14:21:18.577464	source	N
TimeDuration	Y	\N	\N	\N	3	N	Format: Time in minutes.   Constraints: Up to 3 digit numeric, cannot be 000. If present, ServiceTypeCde must not be set to P.  Use: Bulk Bill; Patient Claims; IMC  Level: Service  The duration of the service in minutes.  	205	2005-02-05 14:21:18.577464	source	N
TimeOfLodgement	Y	\N	\N	\N	6	N	Format: HHMMSS Note: Should be the computer system time when the claim was created. Use: Patient Claims; Same Day Delete  Level: Claim  The time of lodgement for the claim.  	206	2005-02-05 14:21:18.577464	source	N
TimeOfService	Y	\N	\N	\N	4	N	Format: HHMM expressed using a twenty four hour clock eg. 1435 for 2.35pm. Use: Bulk Bill; Patient Claims; IMC  Level: Bulk Bill and Patient Claims - Voucher; IMC - service  The time the service(s) was rendered.  	207	2005-02-05 14:21:18.577464	source	N
TransactionId	Y	\N	\N	\N	24	N	Use: Bulk Bill; Patient Claims; DVA; ACIR; StatusRequest; RetrieveReport  Level: Claim  A unique identifier (provided by getUniqueId())maintained throughout the life of a claim.  	210	2005-02-05 14:21:18.577464	source	N
TreatmentLocation	Y	\N	\N	\N	1	A	Values: V = Home Visit H = Hospital R = Rooms Space = Not Specified  Cannot have mixed values within a single voucher  Cannot be a Pathology claim. Note: Home visits do not apply to Diagnostic Image Use: DVA  Level: Services    	211	2005-02-05 14:21:18.577464	source	N
UniquePharmacyPrescriptionNum	Y	\N	\N	\N	20	A	Use: PBS - Preassessment, Claiming, Cancellation  Level: Prescription Record  This is a unique number allocated by the PDS and stays with that prescription throughout its lifecycle.   An individual prescription will only ever have one number allocated to it and that number will not be re-allocated to other prescriptions  	212	2005-02-05 14:21:18.577464	source	N
VaccineBatchNum	Y	\N	\N	\N	15	A	Format: 1-15 chars Mandatory for Queensland Use: ACIR - General Immunisation  Level: Episode  The batch number associated with the vaccine administered.  	213	2005-02-05 14:21:18.577464	source	N
VaccineCode	Y	\N	\N	\N	6	A	Format: 1-6 Alpha chars Use: ACIR - except Next Due Date  Level: Episode  The code of the vaccine that was administered.  May be up to 5 codes per encounter. See Vaccines in the HOL Classic Logic Pack documentation (HOL_Classic.chm) for details  	214	2005-02-05 14:21:18.577464	source	N
VaccineDose	Y	\N	\N	\N	2	N	Format: two (2) numeric chars Use: ACIR - General Immunisation  Level: Episode  The dose of the vaccine administered  	215	2005-02-05 14:21:18.577464	source	N
VeteranFileNum	Y	\N	\N	\N	9	A	See DVA File Number Validation for validation details.    	216	2005-02-05 14:21:18.577464	source	N
PeriodTypeInd	Y	\N	\N	\N	\N	\N	Note: this element has been deprecated and may not be supported by future releases. Use ReferralPeriodTypeCde instead.	171	2005-02-05 14:21:18.577464	source	N
ReferralOverrideType	Y	\N	\N	\N	\N	\N	Note: this element has been deprecated and may not be supported by future releases. Use ReferralOverrideTypeCde instead.	183	2005-02-05 14:21:18.577464	source	N
RequestTypeInd	Y	\N	\N	\N	\N	\N	Note: this element has been deprecated and may not be supported by future releases. Use RequestTypeCde instead.	191	2005-02-05 14:21:18.577464	source	N
SelfDeemedInd	Y	\N	\N	\N	\N	\N	Note: this element has been deprecated and may not be supported by future releases. Use SelfDeemedCde instead.	196	2005-02-05 14:21:18.577464	source	N
ServiceType	Y	\N	\N	\N	\N	\N	Note: this element has been deprecated and may not be supported by future releases. Use ServiceTypeCde instead.	202	2005-02-05 14:21:18.577464	source	N
AuthProxyName	Y	\N	Y	\N	\N	AN	Contains the name of the last proxy for which authentication was requested. This is the name with which the proxy identifies itself.  Set by the HIC Online CA when authentication is requested. The value to be held in the data element is retrieved from the proxy configuration.  May be retrieved with the use of the function getSessionElement(), but may not be manually set.   	78	2005-02-05 14:21:18.577464	source	N
AuthProxyPasswd.<proxyname>	Y	\N	Y	\N	\N	AN	Password to be used for authentication at the proxy <proxyname>, where: <proxyname> is the value set in AuthProxyName   	80	2005-02-05 14:21:18.577464	source	N
AuthProxyUserId	Y	\N	Y	\N	\N	AN	Default userid to be used for authentication at any proxy where no specific value has been set.   	81	2005-02-05 14:21:18.577464	source	N
AuthProxyUserId.<proxyname>	Y	\N	Y	\N	\N	AN	Userid to be used for authentication at the proxy <proxyname>, where: <proxyname> is the value set in AuthProxyName   	82	2005-02-05 14:21:18.577464	source	N
Server	Y	\N	Y	\N	50	AN	Values:  Production: www2.hic.gov.au/ext (default)  Test: www2.hic.gov.au/pext/ext   Use: Session  Level: Session  URL of HIC Online server. Only needs to be specified during testing phase.  HIC Online CA will use default production address if not specified.  	200	2005-02-05 14:21:18.577464	source	N
LogicPackDir	Y	\N	Y	\N	\N	AN	Use: Session *  Level: Session *   The location of the directory in which logic pack specific jar files are stored.   * - LogicPackDir may be set either as an environment variable (see Set Environment), or as a Session variable (with setSessionElement. Note: this must not be in the classpath  LSPNum 6 N Constraints: Cannot be set to 000000. If present, ServiceTypeCde must be set to S. Mutually exclusive to:  ReferralPeriodTypeCde  ReferringProviderNum  ReferralIssueDate  ReferralPeriod  NoOfPatientsSeen  TimeDuration  MultipleProcedureOverrideInd   Use: Bulk Bill; Patient Claims; DVA; IMC  Level: Service  Location Specific Practice Number Only to be used in association with:  services listed in the Diagnostic Imaging Services Table (DIST)  Group T2  Radiation Oncology services in the General Medical Services Table (GMST)  Where these services occur this field is to be considered mandatory. For details on the services that require an LSPN specified see LSPN Requirements   	140	2005-02-05 14:21:18.577464	source	N
PmsProduct	Y	\N	Y	\N	64	A	Use: Session  Level: Session  Name of the client system as known to HIC.  	174	2005-02-05 14:21:18.577464	source	N
PmsVersion	Y	\N	Y	\N	64	A	Use: Session  Level: Session  Version of the client system as known to HIC.  	175	2005-02-05 14:21:18.577464	source	N
Recipient	\N	\N	Y	\N	8	AN	Values:  ebus@hic.gov.au for production (default)  ebus.test@hic.gov.au for testing  Use: Session  Level: Session  E-mail address associated with the Location Certificate (HCL) of the intended message recipient. Needs to be specified during testing.  HIC Online CA will use default production address for HIC if not specified.  	218	2005-02-05 14:21:18.577464	source	N
Sender	Y	\N	Y	\N	40	AN	Use: Session  Level: Session  eSignature version 1.06 supported only one location signing certificate per cryptostore, the HIC eSignature API version 2 can store multiple location signing certificates within its PSI Store.  The Sender element allows the email address or subject name of the location certificate to be set. This certificate will then be used for signing the outgoing message. By default, the first signing certificate in the PSI Store will be used.  	219	2005-02-05 14:21:18.577464	source	N
TransmissionId	Y	Y	\N	Y	64	N	Available after a successful send Transmission data element. Identifier of transmission. This element is 64 digits unless it has been set by the client system through getUniqueId, in which case it is 24 digits.  	66	2005-02-05 14:18:58.135078	source	N
TransmissionType	Y	\N	Y	Y	1	A	Values: D = Development P = Production (default) T = Test (not supported for HolMedical)   Use: Transmission  Level: Transmission  Indicates whether the transaction is to be treated as test or live data.   	209	2005-02-05 14:21:18.577464	source	N
DateOfTransmission	Y	\N	\N	Y	8	D	Format: DDMMYYYY Must be a valid date Cannot be in the future  Use: Transmission  Level: Transmission  The date of the transmission.  DBClaimId       This element has been deprecated, see PmsClaimId  	113	2005-02-05 14:21:18.577464	source	N
TimeOfTransmission	Y	\N	\N	Y	6	N	Format: HHMMSS Use: Transmission  Level: Transmission  The time of transmission.  	208	2005-02-05 14:21:18.577464	source	N
LocationId	\N	Y	\N	\N	\N	AN	See Return Codes. Can be multiple integers separated by commas Return Codes associated with Voucher. 	67	2005-02-05 14:18:58.135078	source	N
\.


--
-- Data for Name: hlfd; Type: TABLE DATA; Schema: public; Owner: source
--

COPY hlfd (hlfd_code, hlfd_group, hlfd_desc, hlfd__sequence, hlfd__timestamp, hlfd__user_entry, hlfd__status) FROM stdin;
-	\N	\N	20	2005-01-30 12:06:32.268256	source	N
\.


--
-- Data for Name: icd9; Type: TABLE DATA; Schema: public; Owner: source
--

COPY icd9 (icd9_codetype, icd9_code, icd9_age_edit, icd9_low_age, icd9_high_age, icd9_sex_edit, icd9_code_edit, icd9_area_edit, icd9_digit_5, icd9_desc, icd9__sequence, icd9__timestamp, icd9__user_entry, icd9__status) FROM stdin;
\N	-	\N	\N	\N	\N	\N	\N	\N	\N	11	2005-01-30 12:06:32.500978	source	N
\.


--
-- Data for Name: inst; Type: TABLE DATA; Schema: public; Owner: source
--

COPY inst (inst_code, inst_desc, inst_addr, inst_suburb, inst_postc, inst_cont, inst__sequence, inst__timestamp, inst__user_entry, inst__status) FROM stdin;
-	\N	\N	\N	\N	\N	10	2005-01-30 12:06:32.71757	source	N
\.


--
-- Data for Name: invc; Type: TABLE DATA; Schema: public; Owner: source
--

COPY invc (invc_dbtr_code, invc_bank_code, invc_prov_code, invc_patn__sequence, invc_empl_code, invc_feet_code, invc_rfdr_code, invc_rfdr_date, invc_rfdr_period, invc_date_created, invc_date_printed, invc_date_reprint, invc_amount, invc_paid_amount, invc_gst_amount, invc_paid_gst_amount, invc__sequence, invc__timestamp, invc__user_entry, invc__status, invc_healthcard, invc_claim_number, invc_accident_date, invc_reference_1, invc_reference_2, invc_reference_3, invc_hlfd_code, invc_ins_level, invc_healthnumb, invc_medicare) FROM stdin;
\.


--
-- Data for Name: labl; Type: TABLE DATA; Schema: public; Owner: source
--

COPY labl (labl_id, labl_subtype, labl_text_label, labl_class_name, labl_attribute_name, labl_row, labl_column, labl__sequence, labl__timestamp, labl__user_entry, labl__status) FROM stdin;
\.


--
-- Data for Name: locn; Type: TABLE DATA; Schema: public; Owner: source
--

COPY locn (locn_code, locn_desc, locn_colour, locn__sequence, locn__timestamp, locn__user_entry, locn__status) FROM stdin;
-	\N	\N	4	2005-01-17 09:07:31.612222	source	N
EM	East Melbourne	#ffffaa00	2	2004-08-12 11:48:03.188856	source	N
\.


--
-- Data for Name: lthd; Type: TABLE DATA; Schema: public; Owner: source
--

COPY lthd (lthd_prov_code, lthd_target_id, lthd_order, lthd_type, lthd_data, lthd_x_coord, lthd_y_coord, lthd_scale, lthd_font, lthd_size, lthd_align, lthd__sequence, lthd__timestamp, lthd__user_entry, lthd__status) FROM stdin;
\.


--
-- Data for Name: mbst; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mbst (mbst_item, mbst_desc, mbst_sch100, mbst_sch75, mbst_sch85, mbst__sequence, mbst__timestamp, mbst__user_entry, mbst__status) FROM stdin;
\.


--
-- Data for Name: mdaf; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mdaf (mdaf_patn__sequence, mdaf_prov_code, mdaf_rfdr_code, mdaf_voucher, mdaf_date_printed, mdaf_mdbt__sequence, mdaf__sequence, mdaf__timestamp, mdaf__user_entry, mdaf__status) FROM stdin;
\.


--
-- Data for Name: mdbt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mdbt (mdbt_prov_code, mdbt_first_voucher, mdbt_last_voucher, mdbt_batch_code, mdbt_location_id, mdbt_product, mdbt_version, mdbt_accpaid_ind, mdbt_claimsubauth, mdbt_accunpaid, mdbt_voucher_count, mdbt_total_amount, mdbt_claim_date, mdbt_recipient, mdbt_server, mdbt_claim_status, mdbt__sequence, mdbt__timestamp, mdbt__user_entry, mdbt__status) FROM stdin;
\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4	2005-02-08 20:14:52.181267	source	N
\.


--
-- Data for Name: mdcr; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mdcr (mdcr_paym__sequence, mdcr_svpf__sequence, mdcr_amount, mdcr__sequence, mdcr__timestamp, mdcr__user_entry, mdcr__status) FROM stdin;
\.


--
-- Data for Name: mtad; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtad (mtad_title, mtad_icon, mtad_parent, mtad_class, mtad_access, mtad_list_order, mtad__sequence, mtad__timestamp, mtad__user_entry, mtad__status) FROM stdin;
Application Detail	\N	METADATA	mtad	31	Z-LAST	1	2004-03-28 13:55:26.878473	source	N
Application Groups	\N	METADATA	mtag	31	Z-LAST	2	2004-03-28 13:55:26.878473	source	N
Alerts	\N	METADATA	mtal	31	Z-LAST	3	2004-03-28 13:55:26.878473	source	N
Attribute Meta Data	\N	METADATA	mtat	31	Z-LAST	4	2004-03-28 13:55:26.878473	source	N
Class Meta Data	\N	METADATA	mtcl	31	Z-LAST	5	2004-03-28 13:55:26.878473	source	N
Foreign Meta Data	\N	METADATA	mtfn	31	Z-LAST	6	2004-03-28 13:55:26.878473	source	N
Comparison Operators	\N	METADATA	mtop	31	Z-LAST	7	2004-03-28 13:55:26.878473	source	N
Relation Meta Data	\N	METADATA	mtrl	31	Z-LAST	8	2004-03-28 13:55:26.878473	source	N
mtsv	\N	METADATA	mtsv	31	Z-LAST	9	2004-03-28 13:55:26.878473	source	N
\.


--
-- Data for Name: mtag; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtag (mtag_name, mtag_title, mtag_parent, mtag_access, mtag_list_order, mtag__sequence, mtag__timestamp, mtag__user_entry, mtag__status) FROM stdin;
METADATA	Meta Data	\N	64	Z-LAST	1	2004-03-28 13:55:24.122365	source	N
\.


--
-- Data for Name: mtal; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtal (mtal_mtat_name, mtal_mtop_code, mtal_value, mtal_colour, mtal_priority, mtal__sequence, mtal__timestamp, mtal__user_entry, mtal__status) FROM stdin;
svpf_invc_balance	4	0.00	#FF0000	1	2	2004-03-28 13:55:51.730507	source	N
patn_amount_outstanding	4	0.00	#FF0000	1	7	2005-09-14 11:33:09.44922	source	N
patn_ref_expired	3	Y	#FF0000	1	8	2005-09-17 19:11:18.615806	source	N
\.


--
-- Data for Name: mtat; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtat (mtat_access, mtat_name, mtat_type, mtat_length, mtat_attributes, mtat_operator, mtat_title, mtat_class_name, mtat_displen, mtat_browse_order, mtat_view_order, mtat_input_method, mtat_default, mtat_htmltagatt, mtat__sequence, mtat__timestamp, mtat__user_entry, mtat__status) FROM stdin;
31	patv_hlfd_desc	text	30		~*	Hlfd Desc	patv	30	130	130	10			2416	2001-10-19 12:33:38	source	A
31	patv_hlfd_group	text	30		~*	Hlfd Group	patv	30	120	120	10			2417	2001-10-19 12:33:39	source	A
2	patv_ins_level	char	0		~*	Insurance level	patv	3	173	173	SYSTEM			2418	2001-10-19 12:33:39	source	A
2	patv_marital	char	0		~*	Marital Status	patv	1	0	0	SYSTEM			2419	2001-10-19 12:33:40	source	A
2	patv_medicare	text	0		~*	Medicare Number	patv	15	10	160	40			2420	2001-10-19 12:33:40	source	A
2	patv_phone	text	0		~*	Phone	patv	30	10	110	40			2421	2001-10-19 12:33:40	source	A
2	patv_postcode	text	0		~*	Postcode	patv	4	10	100	40			2422	2001-10-19 12:33:41	source	A
31	patv_prov_address	text	30		~*	Provider Address	patv	30	480	232	RO			2423	2001-10-19 12:33:41	source	A
31	patv_prov_bank_code	text	30		~*	Provider Bank Code	patv	30	540	239	RO			2424	2001-10-19 12:33:41	source	A
2	patv_prov_code	text	0		~*	Usual   provider (code)	patv	5	10	230	40	-		2425	2001-10-19 12:33:42	source	A
31	patv_prov_name	text	30		~*	Provider Name	patv	30	470	231	RO			2426	2001-10-19 12:33:42	source	A
31	patv_prov_phone	text	30		~*	Provider Phone	patv	30	530	236	RO			2427	2001-10-19 12:33:43	source	A
31	patv_prov_postcode	text	30		~*	Provider Postcode	patv	30	510	234	RO			2428	2001-10-19 12:33:43	source	A
31	patv_prov_provider_num	text	30		~*	Provider Provider Num	patv	30	460	238	RO			2429	2001-10-19 12:33:43	source	A
31	patv_prov_salutation	text	30		~*	Provider Salutation	patv	30	520	237	RO			2430	2001-10-19 12:33:44	source	A
31	patv_prov_state	text	30		~*	Provider State	patv	30	500	235	RO			2431	2001-10-19 12:33:44	source	A
31	patv_prov_suburb	text	30		~*	Provider Suburb	patv	30	490	233	RO			2432	2001-10-19 12:33:45	source	A
2	patv_psnam	text	0		~*	Surname	patv	25	11	30	20			2433	2001-10-19 12:33:45	source	A
2	patv_ref_date	date	0		=	Referral date	patv	12	10	210	40	today		2434	2001-10-19 12:33:45	source	A
2	patv_ref_period	integer	0		=	Referral period	patv	5	10	220	40	12		2435	2001-10-19 12:33:46	source	A
2	patv_rfdr_code	text	0		~*	Usual Referrer (code)	patv	12	10	200	40			2436	2001-10-19 12:33:46	source	A
31	patv_rfdr_index	text	30		~*	Referrer Index	patv	30	420	209	RO			2437	2001-10-19 12:33:47	source	A
31	patv_rfdr_name	text	30		~*	Referrer Name	patv	30	340	201	RO			2438	2001-10-19 12:33:47	source	A
31	patv_rfdr_phone	text	30		~*	Referrer Phone	patv	30	400	206	RO			2439	2001-10-19 12:33:47	source	A
31	patv_rfdr_postcode	text	30		~*	Referrer Postcode	patv	30	370	204	RO			2440	2001-10-19 12:33:48	source	A
31	patv_rfdr_provider	text	30		~*	Referrer Provider	patv	30	390	208	RO			2441	2001-10-19 12:33:48	source	A
31	patv_rfdr_salutation	text	30		~*	Referrer Salutation	patv	30	410	207	RO			2442	2001-10-19 12:33:49	source	A
31	patv_rfdr_state	text	30		~*	Referrer State	patv	30	380	205	RO			2443	2001-10-19 12:33:49	source	A
31	patv_rfdr_street	text	30		~*	Referrer Street	patv	30	350	202	RO			2444	2001-10-19 12:33:49	source	A
31	patv_rfdr_suburb	text	30		~*	Referrer Suburb	patv	30	360	203	RO			2445	2001-10-19 12:33:50	source	A
2	patv_sex	char	0		~*	Gender	patv	1	0	0	SYSTEM			2446	2001-10-19 12:33:50	source	A
31	mtfn_join	text	0	not null	~*	Foreign Primary Key	mtfn	30	50	50				158	2001-10-10 12:25:16	source	A
31	mtfn_key	text	0	not null	~*	Foreign Key	mtfn	30	30	30				159	2001-10-10 12:25:17	source	A
31	mtfn_master_class	text	0	not null	~*	Local Class	mtfn	20	20	20				160	2001-10-10 12:25:17	source	A
31	mtfn_other_class	text	0	not null	~*	Foreign Class	mtfn	10	40	40				161	2001-10-10 12:25:18	source	A
31	mtfn_view	text	0		~*	View Attribute	mtfn	30	60	60				163	2001-10-10 12:25:18	source	A
31	mtrl_master_class	text	0		~*	Master Class	mtrl	20	20	20				170	2001-10-10 12:25:26	source	A
31	mtrl_other_class	text	0		~*	Child Class	mtrl	10	40	40				171	2001-10-10 12:25:26	source	A
2	patv_state	text	0		~*	State	patv	3	10	90	10	Victoria		2447	2001-10-19 12:33:50	source	A
2	patv_suburb	text	0		~*	Suburb	patv	30	10	80	40			2448	2001-10-19 12:33:51	source	A
2	patv_title	text	0		~*	Title	patv	6	10	50	20			2449	2001-10-19 12:33:51	source	A
31	svpv_invc_balance	numeric	30		~*	Invc Balance	svpv	30	130	130	10			2789	2002-02-09 08:02:22	source	A
31	svpv_invc_credits	numeric	30		~*	Invc Credits	svpv	30	120	120	10			2790	2002-02-09 08:02:22	source	A
31	svpv_invc_date_printed	date	10		~*	Invc Date Printed	svpv	10	140	140	10			2791	2002-02-09 08:02:22	source	A
31	svpv_invc_date_reprint	date	10		~*	Invc Date Reprint	svpv	10	150	150	10			2792	2002-02-09 08:02:22	source	A
31	svpv_invc_gst_amount	numeric	786434		~*	Invc Gst Amount	svpv	786434	110	110	10			2793	2002-02-09 08:02:23	source	A
31	svpv_patn__sequence	int4	10		~*	Patn  Sequence	svpv	10	80	80	10			2794	2002-02-09 08:02:23	source	A
31	svpv_patn_address	text	30		~*	Patn Address	svpv	30	180	180	10			2795	2002-02-09 08:02:23	source	A
31	svpv_patn_dob	text	30		~*	Patn Dob	svpv	30	230	230	10			2796	2002-02-09 08:02:23	source	A
31	svpv_patn_healthcard	text	30		~*	Patn Healthcard	svpv	30	260	260	10			2797	2002-02-09 08:02:24	source	A
31	svpv_patn_healthnumb	text	30		~*	Patn Healthnumb	svpv	30	240	240	10			2798	2002-02-09 08:02:24	source	A
31	svpv_patn_hlfd_code	text	30		~*	Patn Hlfd Code	svpv	30	220	220	10			2799	2002-02-09 08:02:24	source	A
31	svpv_patn_ins_level	bpchar	1		~*	Patn Ins Level	svpv	1	230	230	10			2800	2002-02-09 08:02:25	source	A
31	svpv_patn_medicare	text	30		~*	Patn Medicare	svpv	30	250	250	10			2801	2002-02-09 08:02:25	source	A
31	svpv_patn_name	text	30		~*	Patn Name	svpv	30	170	170	10			2802	2002-02-09 08:02:25	source	A
31	svpv_patn_patf_code	text	30		~*	Patn Patf Code	svpv	30	290	290	10			2803	2002-02-09 08:02:25	source	A
2	patv_aboriginality	char	0		~*	Aboriginality	patv	1	0	0	SYSTEM			2389	2001-10-19 12:33:27	source	A
2	patv_accl_code	text	0		~*	Account type	patv	3	0	0	SYSTEM			2390	2001-10-19 12:33:28	source	A
2	patv_accommodation	char	0		~*	Accommodation type	patv	1	0	0	SYSTEM			2391	2001-10-19 12:33:28	source	A
2	patv_address	text	0		~*	Street	patv	30	10	70	40			2392	2001-10-19 12:33:28	source	A
2	patv_care	char	0		~*	Care type	patv	1	0	0	SYSTEM			2393	2001-10-19 12:33:29	source	A
2	patv_country	text	0		~*	Country of birth	patv	4	0	0	SYSTEM			2394	2001-10-19 12:33:29	source	A
31	patv_dbtr_address	text	30		~*	Debtor Address	patv	30	220	184	RO			2395	2001-10-19 12:33:30	source	A
2	patv_dbtr_code	text	0		~*	Usual Debtor (code)	patv	12	10	180	40			2396	2001-10-19 12:33:30	source	A
31	patv_dbtr_name	text	30		~*	Debtor Name	patv	30	210	182	RO			2397	2001-10-19 12:33:30	source	A
31	patv_dbtr_phone	text	30		~*	Debtor Phone	patv	30	260	189	RO			2398	2001-10-19 12:33:31	source	A
31	patv_dbtr_postcode	text	30		~*	Debtor Postcode	patv	30	240	187	RO			2399	2001-10-19 12:33:31	source	A
31	patv_dbtr_state	text	30		~*	Debtor State	patv	30	250	188	RO			2400	2001-10-19 12:33:32	source	A
31	patv_dbtr_suburb	text	30		~*	Debtor Suburb	patv	30	230	186	RO			2401	2001-10-19 12:33:32	source	A
31	crep_date_reprint	timestamp	47		~*	Invoice Reprinted	crep	10	10	220	RO			2248	2001-10-19 12:32:14	source	A
31	patv_empl_address	text	30		~*	Employer Address	patv	30	290	282	RO			2403	2001-10-19 12:33:33	source	A
2	patv_empl_code	text	0		~*	Usual Employer (code)	patv	12	0	280	40	-		2404	2001-10-19 12:33:33	source	A
31	patv_empl_name	text	30		~*	Employer Name	patv	30	280	281	RO			2405	2001-10-19 12:33:34	source	A
31	patv_empl_postcode	text	30		~*	Employer Postcode	patv	30	310	310	RO			2406	2001-10-19 12:33:34	source	A
31	patv_empl_state	text	30		~*	Employer State	patv	30	320	320	RO			2407	2001-10-19 12:33:34	source	A
31	patv_empl_suburb	text	30		~*	Employer Suburb	patv	30	300	283	RO			2408	2001-10-19 12:33:35	source	A
2	patv_feet_code	text	0		~*	Fee level	patv	5	10	150	40	-		2409	2001-10-19 12:33:35	source	A
31	patv_feet_desc	text	30		~*	Feet Desc	patv	30	170	170	10			2410	2001-10-19 12:33:36	source	A
2	patv_flno	text	0		~*	File number	patv	10	10	45	40			2411	2001-10-19 12:33:36	source	A
2	patv_fsnam	text	0		~*	Firstname	patv	20	12	40	20			2412	2001-10-19 12:33:37	source	A
2	patv_healthcard	text	0		~*	Reference	patv	15	10	170	20			2413	2001-10-19 12:33:37	source	A
2	patv_healthnumb	text	0		~*	Health Fund number	patv	30	174	174	SYSTEM			2414	2001-10-19 12:33:38	source	A
2	patv_hlfd_code	text	0		~*	Health Fund	patv	10	172	172	40			2415	2001-10-19 12:33:38	source	A
31	svpv_patn_postcode	text	30		~*	Patn Postcode	svpv	30	210	210	10			2804	2002-02-09 08:02:26	source	A
31	svpv_patn_state	text	30		~*	Patn State	svpv	30	200	200	10			2805	2002-02-09 08:02:26	source	A
31	svpv_patn_suburb	text	30		~*	Patn Suburb	svpv	30	190	190	10			2806	2002-02-09 08:02:26	source	A
31	svpv_percentage	int4	10		~*	Percentage	svpv	10	30	30	10			2807	2002-02-09 08:02:27	source	A
31	svpv_prov_address	text	30		~*	Prov Address	svpv	30	460	460	10			2808	2002-02-09 08:02:27	source	A
31	svpv_prov_bank_code	text	30		~*	Prov Bank Code	svpv	30	520	520	10			2809	2002-02-09 08:02:27	source	A
31	svpv_prov_code	text	30		~*	Prov Code	svpv	30	430	430	10			2810	2002-02-09 08:02:27	source	A
31	svpv_prov_name	text	30		~*	Prov Name	svpv	30	450	450	10			2811	2002-02-09 08:02:28	source	A
31	svpv_prov_phone	text	30		~*	Prov Phone	svpv	30	510	510	10			2812	2002-02-09 08:02:28	source	A
31	svpv_prov_postcode	text	30		~*	Prov Postcode	svpv	30	490	490	10			2813	2002-02-09 08:02:28	source	A
31	svpv_prov_provider_num	text	30		~*	Prov Provider Num	svpv	30	440	440	10			2814	2002-02-09 08:02:28	source	A
31	svpv_prov_salutation	text	30		~*	Prov Salutation	svpv	30	500	500	10			2815	2002-02-09 08:02:29	source	A
31	svpv_prov_state	text	30		~*	Prov State	svpv	30	480	480	10			2816	2002-02-09 08:02:29	source	A
31	svpv_prov_suburb	text	30		~*	Prov Suburb	svpv	30	470	470	10			2817	2002-02-09 08:02:29	source	A
31	svpv_rfdr_code	text	30		~*	Rfdr Code	svpv	30	250	250	10			2818	2002-02-09 08:02:30	source	A
31	svpv_rfdr_date	date	10		~*	Rfdr Date	svpv	10	160	160	10			2819	2002-02-09 08:02:30	source	A
31	svpv_rfdr_index	text	30		~*	Rfdr Index	svpv	30	340	340	10			2820	2002-02-09 08:02:30	source	A
31	svpv_rfdr_name	text	30		~*	Rfdr Name	svpv	30	250	250	10			2821	2002-02-09 08:02:30	source	A
31	svpv_rfdr_phone	text	30		~*	Rfdr Phone	svpv	30	320	320	10			2822	2002-02-09 08:02:31	source	A
31	svpv_rfdr_postcode	text	30		~*	Rfdr Postcode	svpv	30	290	290	10			2823	2002-02-09 08:02:31	source	A
31	svpv_rfdr_provider	text	30		~*	Rfdr Provider	svpv	30	260	260	10			2824	2002-02-09 08:02:31	source	A
31	svpv_rfdr_salutation	text	30		~*	Rfdr Salutation	svpv	30	330	330	10			2825	2002-02-09 08:02:32	source	A
31	svpv_rfdr_state	text	30		~*	Rfdr State	svpv	30	300	300	10			2826	2002-02-09 08:02:32	source	A
31	svpv_rfdr_street	text	30		~*	Rfdr Street	svpv	30	270	270	10			2827	2002-02-09 08:02:32	source	A
31	svpv_rfdr_suburb	text	30		~*	Rfdr Suburb	svpv	30	280	280	10			2828	2002-02-09 08:02:32	source	A
31	svpv_serv_code	text	30		~*	Serv Code	svpv	30	20	20	10			2829	2002-02-09 08:02:33	source	A
31	svpv_total_amount	numeric	30		~*	Total Amount	svpv	30	70	70	10			2830	2002-02-09 08:02:33	source	A
31	dbtr_group	text	30	\N	~*	Group	dbtr	30	80	80	10			2831	2002-02-09 08:14:36	source	A
31	dbtr_last_statement	timestamp	47	\N	~*	Last Statement	dbtr	47	90	90	10			2832	2002-02-09 08:14:36	source	A
31	dbtr_delay_statement	interval	47	\N	~*	Delay Statement	dbtr	47	100	100	10			2833	2002-02-09 08:14:36	source	A
31	dbst_date_reprint	date	10		~*	Date Reprint	dbst	10	220	220	10			2277	2001-10-19 12:32:29	source	A
31	dbst_dbtr_code	text	30		~*	Dbtr Code	dbst	30	10	10	10			2278	2001-10-19 12:32:29	source	A
31	dbst_feet_code	text	30		~*	Feet Code	dbst	30	150	150	10			2279	2001-10-19 12:32:30	source	A
31	dbst_invc__sequence	int4	10		~*	Invc  Sequence	dbst	10	160	160	10			2280	2001-10-19 12:32:30	source	A
31	dbst_name	text	30		~*	Name	dbst	30	20	20	10			2281	2001-10-19 12:32:30	source	A
31	dbst_paid	numeric	30		~*	Paid	dbst	30	180	180	10			2282	2001-10-19 12:32:31	source	A
31	dbst_patient	text	30		=	Patient	dbst	30	500	75	10			2283	2001-10-19 12:32:31	source	A
31	dbst_period	int4	10		~*	Period	dbst	10	200	200	10			2284	2001-10-19 12:32:31	source	A
31	dbst_phone	text	30		~*	Phone	dbst	30	70	70	10			2285	2001-10-19 12:32:32	source	A
31	dbst_postcode	text	30		~*	Postcode	dbst	30	50	50	10			2286	2001-10-19 12:32:32	source	A
31	dbst_state	text	30		~*	State	dbst	30	60	60	10			2287	2001-10-19 12:32:33	source	A
31	dbst_suburb	text	30		~*	Suburb	dbst	30	40	40	10			2288	2001-10-19 12:32:33	source	A
31	dbst_total_balance	numeric	30		~*	Total Balance	dbst	30	90	90	10			2289	2001-10-19 12:32:33	source	A
31	dbag_address	text	30		~*	Address	dbag	30	30	30	10			2294	2001-10-19 12:32:39	source	A
31	dbag_balance_0	numeric	30		~*	Balance 0	dbag	30	90	90	10			2295	2001-10-19 12:32:39	source	A
31	dbag_balance_120	numeric	30		~*	Balance 120	dbag	30	130	130	10			2296	2001-10-19 12:32:39	source	A
31	dbag_balance_30	numeric	30		~*	Balance 30	dbag	30	100	100	10			2297	2001-10-19 12:32:40	source	A
31	dbag_balance_60	numeric	30		~*	Balance 60	dbag	30	110	110	10			2298	2001-10-19 12:32:40	source	A
31	dbag_balance_90	numeric	30		~*	Balance 90	dbag	30	120	120	10			2299	2001-10-19 12:32:41	source	A
31	dbag_dbtr_code	text	30		~*	Dbtr Code	dbag	30	10	10	10			2300	2001-10-19 12:32:41	source	A
31	dbag_name	text	30		~*	Name	dbag	30	20	20	10			2301	2001-10-19 12:32:41	source	A
31	dbag_phone	text	30		~*	Phone	dbag	30	70	70	10			2302	2001-10-19 12:32:42	source	A
31	dbag_postcode	text	30		~*	Postcode	dbag	30	50	50	10			2303	2001-10-19 12:32:42	source	A
31	dbag_state	text	30		~*	State	dbag	30	60	60	10			2304	2001-10-19 12:32:42	source	A
31	dbag_suburb	text	30		~*	Suburb	dbag	30	40	40	10			2305	2001-10-19 12:32:43	source	A
31	dbag_total_balance	numeric	30		~*	Total Balance	dbag	30	80	80	10			2306	2001-10-19 12:32:43	source	A
31	cnrv_amount	numeric	786434		~*	Total Amount	cnrv	786434	30	30	10			2311	2001-10-19 12:32:48	source	A
31	cnrv_balance	numeric	786434		~*	Balance	cnrv	786434	110	110	RO			2312	2001-10-19 12:32:49	source	A
31	cnrv_count	int4	10		~*	# Payments	cnrv	10	50	50	10			2313	2001-10-19 12:32:49	source	A
31	cnrv_end_date	text	30		~*	Final payment date	cnrv	30	120	120	RO			2314	2001-10-19 12:32:50	source	A
31	cnrv_first_installment	numeric	786434		~*	First amount	cnrv	786434	80	80	10			2315	2001-10-19 12:32:50	source	A
31	cnrv_last_date	text	30		~*	Last paid date	cnrv	30	100	100	RO			2316	2001-10-19 12:32:50	source	A
31	cnrv_other_installment	numeric	786434		~*	Other amounts	cnrv	786434	90	90	10			2317	2001-10-19 12:32:51	source	A
31	cnrv_patient_name	text	30		~*	Patient Name	cnrv	30	20	125	RO			2318	2001-10-19 12:32:51	source	A
31	cnrv_patn__sequence	int4	10		~*	ID	cnrv	10	10	128	RO			2319	2001-10-19 12:32:52	source	A
31	cnrv_serv_code	text	30		~*	Service Code	cnrv	30	70	70	10			2320	2001-10-19 12:32:52	source	A
31	cnrv_start_date	text	30		~*	Start Date	cnrv	30	60	60	10			2321	2001-10-19 12:32:52	source	A
31	ctrv_period	interval	47		~*	Period	cnrv	47	40	40	10			2322	2001-10-19 12:32:53	source	A
31	fept_amount	numeric	786434		~*	Amount	fept	786434	40	40	RO			2232	2001-10-19 12:32:04	source	A
31	fept_desc	text	30		~*	Description	fept	30	60	60	RO			2233	2001-10-19 12:32:04	source	A
31	fept_feet_code	text	30		~*	Feet Code	fept	30	10	10	RO			2234	2001-10-19 12:32:04	source	A
31	fept_gst_amount	numeric	30		~*	GST Amount	fept	30	50	50	RO			2235	2001-10-19 12:32:05	source	A
31	fept_gst_percentage	int4	10		~*	GST Percentage	fept	10	30	30	RO			2236	2001-10-19 12:32:06	source	A
31	fept_serv_code	text	30		~*	Serv Code	fept	30	20	20	RO			2237	2001-10-19 12:32:06	source	A
31	crep_amount	numeric	786434		~*	Invoice Amount	crep	10	10	40	RO			2242	2001-10-19 12:32:11	source	A
31	crep_bank_code	text	30		~*	Invoice Bank Code	crep	10	10	400	RO			2243	2001-10-19 12:32:12	source	A
31	crep_cred_amount	numeric	786434		~*	Credit Amount	crep	10	10	20	10			2244	2001-10-19 12:32:12	source	A
31	crep_cred_gst_amount	numeric	786434		~*	Credit GST Amount	crep	10	10	30	10			2245	2001-10-19 12:32:12	source	A
31	crep_rfdr_date	timestamp	47		~*	Invoice Referral Date	crep	10	10	470	RO			2261	2001-10-19 12:32:19	source	A
31	ssms_date_service	timestamp	1		~*	Date of service	ssms	10	10	10	RO			2188	2001-10-19 12:31:29	source	A
31	crev_date_entry	timestamp	47		~*	Date Entered	crev	10	10	10	10			2220	2001-10-19 12:31:55	source	A
31	crep_dbtr_code	text	30		~*	Invoice Debtor Code	crep	10	10	410	RO			2249	2001-10-19 12:32:14	source	A
31	crep_empl_code	text	30		~*	Invoice Employer Code	crep	10	10	420	RO			2250	2001-10-19 12:32:14	source	A
31	crep_feet_code	text	30		~*	Invoice Fee Level	crep	10	10	430	RO			2251	2001-10-19 12:32:15	source	A
31	crep_gst_amount	numeric	786434		~*	Invoice GST 	crep	10	10	110	RO			2252	2001-10-19 12:32:15	source	A
31	crep_invc__sequence	int4	10		~*	Invoice Number	crep	10	10	10	10			2253	2001-10-19 12:32:15	source	A
31	crep_invc_balance	numeric	30		~*	Invoice Balance	crep	10	10	140	RO			2254	2001-10-19 12:32:16	source	A
31	crep_paid_amount	numeric	786434		~*	Invoice Amount Paid	crep	10	10	120	RO			2255	2001-10-19 12:32:16	source	A
31	crep_paid_gst_amount	numeric	786434		~*	Invoice GST Amount Paid	crep	10	10	130	RO			2256	2001-10-19 12:32:17	source	A
31	crep_patn__sequence	int4	10		~*	Patient ID	crep	10	10	440	RO			2257	2001-10-19 12:32:17	source	A
31	crep_paym__sequence	int4	10		~*	Payment ID	crep	10	10	500	RO			2258	2001-10-19 12:32:18	source	A
31	crep_prov_code	text	30		~*	Invoice Provider Code	crep	10	10	450	RO			2259	2001-10-19 12:32:18	source	A
31	crep_rfdr_code	text	30		~*	Invoice Referror Code	crep	10	10	460	RO			2260	2001-10-19 12:32:18	source	A
2	agdi_date_printed	timestamp	1		=	Printed	agdi	10	40	40	RO			2134	2001-10-19 12:30:41	source	A
31	crep_rfdr_period	text	30		~*	Invoice Referral Period	crep	10	10	480	RO			2262	2001-10-19 12:32:19	source	A
31	dbst_address	text	30		~*	Address	dbst	30	30	30	10			2267	2001-10-19 12:32:25	source	A
31	dbst_amount	numeric	30		~*	Amount	dbst	30	170	170	10			2268	2001-10-19 12:32:25	source	A
31	dbst_balance	numeric	30		~*	Balance	dbst	30	190	190	10			2269	2001-10-19 12:32:26	source	A
31	dbst_balance_0	numeric	30		~*	Balance 0	dbst	30	100	100	10			2270	2001-10-19 12:32:26	source	A
31	dbst_balance_120	numeric	30		~*	Balance 120	dbst	30	140	140	10			2271	2001-10-19 12:32:26	source	A
31	dbst_balance_30	numeric	30		~*	Balance 30	dbst	30	110	110	10			2272	2001-10-19 12:32:27	source	A
31	dbst_balance_60	numeric	30		~*	Balance 60	dbst	30	120	120	10			2273	2001-10-19 12:32:27	source	A
31	dbst_balance_90	numeric	30		~*	Balance 90	dbst	30	130	130	10			2274	2001-10-19 12:32:28	source	A
31	dbst_date	date	10		~*	Date	dbst	10	80	80	10			2275	2001-10-19 12:32:28	source	A
31	dbst_date_printed	date	10		~*	Date Printed	dbst	10	210	210	10			2276	2001-10-19 12:32:28	source	A
31	ssms_amount	numeric	1		~*	Fee	ssms	10	10	40	RO			2187	2001-10-19 12:31:29	source	A
2	agdi_date_reprint	timestamp	1		=	Reprinted	agdi	10	50	50	RO			2135	2001-10-19 12:30:42	source	A
31	ssms_gst_amount	numeric	1		~*	GST	ssms	10	10	50	RO			2189	2001-10-19 12:31:29	source	A
31	ssms_month	text	1		~*	Month	ssms	10	10	60	RO			2190	2001-10-19 12:31:30	source	A
31	ssms_serv_code	text	1		~*	Code	ssms	10	10	20	RO			2191	2001-10-19 12:31:30	source	A
31	ssms_total_amount	numeric	1		~*	Total	ssms	10	10	30	RO			2192	2001-10-19 12:31:31	source	A
31	ssmp_amount	numeric	1		~*	Amount	ssmp	10	10	30	RO			2197	2001-10-19 12:31:37	source	A
31	ssmp_count	int4	1		~*	Count	ssmp	10	10	20	RO			2198	2001-10-19 12:31:37	source	A
2	ssmp_gst_amount	numeric(12,2)	1		=	GST	ssmp	10	10	40	RO			2199	2001-10-19 12:31:38	source	A
31	ssmp_month	text	1		~*	Month	ssmp	30	10	10	RO			2200	2001-10-19 12:31:38	source	A
2	ssmp_total_amount	numeric(12,2)	1		=	Total	ssmp	10	10	50	RO			2201	2001-10-19 12:31:38	source	A
31	ssmc_amount	numeric	1		~*	Amount	ssmc	10	10	30	RO			2206	2001-10-19 12:31:45	source	A
31	ssmc_count	int4	1		~*	Count	ssmc	10	10	20	RO			2207	2001-10-19 12:31:45	source	A
2	ssmc_gst_amount	numeric(12,2)	1		=	GST	ssmc	10	10	40	RO			2208	2001-10-19 12:31:45	source	A
2	ssmc_month	text	1		~*	Month	ssmc	10	5	5	RO			2209	2001-10-19 12:31:46	source	A
31	ssmc_serv_code	text	1		~*	Code	ssmc	10	10	10	RO			2210	2001-10-19 12:31:46	source	A
2	ssmc_total_amount	numeric(12,2)	1		=	Total	ssmc	10	10	50	RO			2211	2001-10-19 12:31:47	source	A
31	crev_bank	text	30		~*	Bank	crev	10	10	110	10			2216	2001-10-19 12:31:53	source	A
31	crev_branch	text	30		~*	Branch	crev	10	10	120	10			2217	2001-10-19 12:31:53	source	A
31	crev_cred_amount	numeric	786434		~*	Credit Amount	crev	10	10	20	10			2218	2001-10-19 12:31:54	source	A
31	crev_cred_gst_amount	numeric	786434		~*	Credit GST Amount	crev	10	10	30	10			2219	2001-10-19 12:31:54	source	A
31	crev_drawer	text	30		~*	Drawer	crev	10	10	100	10			2221	2001-10-19 12:31:55	source	A
31	crev_invc_balance	text	1		=	Balance	crev	10	500	55	RO			2223	2001-10-19 12:31:56	source	A
31	crev_paym_amount	numeric	786434		~*	Payment Amount	crev	10	10	130	RO			2224	2001-10-19 12:31:56	source	A
31	crev_tdtp_code	text	30		~*	Tender Type	crev	10	10	95	FSL=20			2226	2001-10-19 12:31:57	source	A
31	crev_user_entry	text	30		~*	Entered By	crev	10	10	140	RO			2227	2001-10-19 12:31:57	source	A
2	agdi_feet_code	text	1		~*	Fee Type	agdi	20	15	15	RO			2138	2001-10-19 12:30:43	source	A
2	agdi_invc__sequence	integer	1		=	Invoice	agdi	10	35	35	RO			2139	2001-10-19 12:30:43	source	A
31	agdi_patient	text	1		=	Patient	agdi	30	14	14	RO			2140	2001-10-19 12:30:44	source	A
2	agdi_period	interval	1		~*	Period - days	agdi	10	10	20	RO			2141	2001-10-19 12:30:44	source	A
2	agdd_amount	numeric(12,2)	1		=	Unpaid	agdd	10	20	20	RO			2146	2001-10-19 12:30:52	source	A
2	agdd_count	integer	1		=	Count	agdd	10	30	30	RO			2147	2001-10-19 12:30:52	source	A
2	agdd_dbtr_code	text	1		~*	Debtor	agdd	10	10	10	RO			2148	2001-10-19 12:30:53	source	A
2	agdd_dbtr_name	text	1		~*	Name	agdd	30	12	12	RO			2149	2001-10-19 12:30:53	source	A
2	agdp_amount	numeric(12,2)	1		=	Unpaid	agdp	10	20	20	RO			2154	2001-10-19 12:30:59	source	A
2	agdp_count	integer	1		=	Count	agdp	10	30	30	RO			2155	2001-10-19 12:31:00	source	A
2	agdp_period	integer	1		~*	Period - days	agdp	10	10	10	RO			2156	2001-10-19 12:31:00	source	A
2	agdt_amount	numeric(12,2)	1		=	Unpaid	agdt	10	20	20	RO			2161	2001-10-19 12:31:06	source	A
2	agdt_count	integer	1		=	Count	agdt	10	30	30	RO			2162	2001-10-19 12:31:07	source	A
2	agdt_feet_code	text	1		~*	Fee type	agdt	10	10	10	RO			2163	2001-10-19 12:31:07	source	A
31	pmsc_amount	numeric	1		~*	Amount	pmsc	10	10	20	RO			2168	2001-10-19 12:31:13	source	A
31	pmsc_gst_amount	numeric	1		~*	GST	pmsc	10	10	30	RO			2169	2001-10-19 12:31:13	source	A
31	pmsc_invc__sequence	int4	1		~*	Invoice	pmsc	10	10	60	RO			2170	2001-10-19 12:31:14	source	A
31	pmsc_month	text	1		~*	Month	pmsc	10	10	70	RO			2171	2001-10-19 12:31:14	source	A
31	pmsc_paym__sequence	int4	1		~*	Payment #	pmsc	10	10	50	RO			2172	2001-10-19 12:31:15	source	A
31	pmsc_total_amount	numeric	1		~*	Total Amount	pmsc	10	10	40	RO			2173	2001-10-19 12:31:15	source	A
31	pmsp_amount	numeric	1		~*	Amount	pmsp	10	10	30	RO			2178	2001-10-19 12:31:21	source	A
31	pmsp_count	int4	1		~*	Count	pmsp	10	10	20	RO			2179	2001-10-19 12:31:22	source	A
31	pmsp_gst_amount	numeric	1		~*	GST	pmsp	10	10	40	RO			2180	2001-10-19 12:31:22	source	A
31	pmsp_month	text	1		~*	Month	pmsp	10	10	10	RO			2181	2001-10-19 12:31:22	source	A
31	pmsp_total_amount	numeric	1		~*	Total	pmsp	10	10	50	RO			2182	2001-10-19 12:31:23	source	A
2	serv_code	text	0		~*	Code	serv	30	10	10	10			2093	2001-10-19 12:30:06	source	A
2	serv_desc	text	0		~*	Description	serv	30	10	30	10			2094	2001-10-19 12:30:06	source	A
2	serv_gst_percentage	float	0		=	GST %	serv	5	25	25	SELECT=0,0%;10,10%			2095	2001-10-19 12:30:07	source	A
2	serv_value	integer	0		=	Unit Value	serv	30	10	20	10	1		2096	2001-10-19 12:30:07	source	A
2	stts_accom_type	text	0		~*	Accommodation type	stts	30	10	40	10			2101	2001-10-19 12:30:15	source	A
2	stts_account_class	text	0		~*	Account class	stts	30	10	30	10			2102	2001-10-19 12:30:15	source	A
2	stts_care_type	text	0		~*	Care type	stts	30	10	50	10			2103	2001-10-19 12:30:15	source	A
2	stts_epsdserl	integer	0		=	Episode serial number	stts	30	10	10	10			2104	2001-10-19 12:30:16	source	A
2	stts_start_date	date	0		=	Status date	stts	30	10	20	10			2105	2001-10-19 12:30:16	source	A
31	tdtp_desc	text	1		~*	Description	tdtp	30	10	10	10	New Tender Type		2124	2001-10-19 12:30:33	source	A
2	tdtp_list	text	1		~*	Listing group	tdtp	30	50	50		New Listing Group		2126	2001-10-19 12:30:34	source	A
2	tdtp_subtotal	text	1		~*	Subtotal Group	tdtp	30	60	60		New Subtotal Group		2128	2001-10-19 12:30:35	source	A
31	agdi_amount	numeric	1		~*	Unpaid	agdi	10	10	30	RO			2133	2001-10-19 12:30:41	source	A
31	agdi_dbtr_code	text	1		~*	Debtor	agdi	10	10	10	RO			2136	2001-10-19 12:30:42	source	A
2	agdi_dbtr_name	text	1		~*	Name	agdi	30	12	12	RO			2137	2001-10-19 12:30:43	source	A
31	prnt_access	int4	1		=	Access	prnt	10	20	20	SELECT=0,Guest;1,User;10,Administrator;			2049	2001-10-19 12:29:32	source	A
31	prnt_command	text	1		~*	Command	prnt	40	60	60	TEXTAREA=3			2050	2001-10-19 12:29:32	source	A
31	prnt_desc	text	1		~*	Description	prnt	40	40	40	40	New Printer		2051	2001-10-19 12:29:33	source	A
31	prnt_name	text	1		~*	Name	prnt	30	30	30	10	New Printer		2052	2001-10-19 12:29:33	source	A
31	prnt_type	int4	1		=	Printer type	prnt	10	10	10	SELECT=1,Internal;2,External;	1		2053	2001-10-19 12:29:33	source	A
2	pyas_amount	numeric(12,2)	0		=	Amount assigned	pyas	30	10	30	10			2072	2001-10-19 12:29:49	source	A
2	pyas_paym__sequence	integer	0		=	Payment serial number	pyas	30	10	10	10			2073	2001-10-19 12:29:50	source	A
2	pyas_svpf__sequence	integer	0		=	Service serial number	pyas	30	10	20	10			2074	2001-10-19 12:29:50	source	A
2	rfdr_name	text	0		~*	Name	rfdr	30	20	20	10			2081	2001-10-19 12:29:55	source	A
2	rfdr_phone	text	1		~*	Phone	rfdr	10	75	75				2082	2001-10-19 12:29:56	source	A
2	rfdr_street	text	0		~*	Street	rfdr	30	30	30	10			2087	2001-10-19 12:29:58	source	A
31	svpv_amount	numeric	786434		~*	Amount	svpv	786434	50	50	10			2770	2002-02-09 08:02:16	source	A
31	svpv_cred_summary	text	30		~*	Cred Summary	svpv	30	130	130	10			2771	2002-02-09 08:02:17	source	A
31	svpv_date_service	date	10		~*	Date Service	svpv	10	10	10	10			2772	2002-02-09 08:02:17	source	A
31	svpv_dbtr_address	text	30		~*	Dbtr Address	svpv	30	220	220	10			2773	2002-02-09 08:02:17	source	A
31	svpv_dbtr_name	text	30		~*	Dbtr Name	svpv	30	210	210	10			2774	2002-02-09 08:02:17	source	A
31	svpv_dbtr_state	text	30		~*	Dbtr State	svpv	30	240	240	10			2775	2002-02-09 08:02:18	source	A
31	svpv_dbtr_suburb	text	30		~*	Dbtr Suburb	svpv	30	230	230	10			2776	2002-02-09 08:02:18	source	A
31	svpv_desc	text	30		~*	Desc	svpv	30	40	40	10			2777	2002-02-09 08:02:18	source	A
31	svpv_empl_address	text	30		~*	Empl Address	svpv	30	370	370	10			2778	2002-02-09 08:02:18	source	A
31	svpv_empl_code	text	30		~*	Empl Code	svpv	30	350	350	10			2779	2002-02-09 08:02:19	source	A
31	svpv_empl_name	text	30		~*	Empl Name	svpv	30	360	360	10			2780	2002-02-09 08:02:19	source	A
31	svpv_empl_postcode	text	30		~*	Empl Postcode	svpv	30	390	390	10			2781	2002-02-09 08:02:19	source	A
31	svpv_empl_state	text	30		~*	Empl State	svpv	30	400	400	10			2782	2002-02-09 08:02:20	source	A
31	mtcl_group_by	text	0		~*	Group By	mtcl	20	70	70	10			126	2001-10-10 12:24:52	source	A
31	mtcl_matrix_order	int4	0		~*	Matrix Order	mtcl	5	50	50	10			127	2001-10-10 12:24:52	source	A
31	mtcl_order_by	text	0		~*	Order By	mtcl	30	100	100	10			129	2001-10-10 12:24:53	source	A
31	mtcl_primary	text	0		~*	Primary Key	mtcl	10	80	80	10			130	2001-10-10 12:24:54	source	A
31	mtcl_query_limit	int4	0		~*	Query Limit	mtcl	5	90	90	10	200		131	2001-10-10 12:24:54	source	A
31	mtcl_query_offset	int4	0		~*	Query Offset	mtcl	5	100	100	10	0		132	2001-10-10 12:24:54	source	A
31	mtcl_userkey	text	1		=	User Key	mtcl	10	82	82	10			134	2001-10-10 12:24:55	source	A
31	mtcl_userlabel	text	1		=	User Label	mtcl	10	84	84	10			135	2001-10-10 12:24:56	source	A
31	svpv_empl_suburb	text	30		~*	Empl Suburb	svpv	30	380	380	10			2783	2002-02-09 08:02:20	source	A
31	svpv_feet_code	text	30		~*	Feet Code	svpv	30	410	410	10			2784	2002-02-09 08:02:20	source	A
31	svpv_feet_desc	text	30		~*	Feet Desc	svpv	30	420	420	10			2785	2002-02-09 08:02:20	source	A
31	svpv_gst_amount	numeric	786434		~*	Gst Amount	svpv	786434	60	60	10			2786	2002-02-09 08:02:21	source	A
31	svpv_invc__sequence	int4	10		~*	Invc  Sequence	svpv	10	90	90	10			2787	2002-02-09 08:02:21	source	A
31	svpv_invc_amount	numeric	786434		~*	Invc Amount	svpv	786434	100	100	10			2788	2002-02-09 08:02:21	source	A
31	eftv_tdtp_desc	text	30		~*	Tdtp Desc	eftv	30	90	90	10			2696	2002-02-09 08:01:41	source	A
31	eftv_tdtp_entity	text	30		~*	Tdtp Entity	eftv	30	100	100	10			2697	2002-02-09 08:01:41	source	A
31	eftv_tdtp_list	text	30		~*	Tdtp List	eftv	30	70	70	10			2698	2002-02-09 08:01:41	source	A
2	paym_branch	text	0		~*	Branch	paym	30	10	80	10	=tdtp_location		2039	2001-10-19 12:29:22	source	A
2	paym_drawer	text	0		~*	Drawer	paym	30	10	60	10			2041	2001-10-19 12:29:23	source	A
2	lthd_target_id	text	1		~*	Target Form	lthd	20	12	12		INVOICE		1955	2001-10-19 12:28:18	source	A
2	lthd_type	text	0		~*	Type	lthd	2	10	30	SELECT=1,LITERAL;3,LINE;4,DASHED LINE;5,RECTANGLE;6,IMAGE-JPEG;7,IMAGE-PNG;0,ORIGIN;	10		1956	2001-10-19 12:28:19	source	A
2	lthd_x_coord	integer	0		=	X Co-ordinate	lthd	3	10	50	10	0		1957	2001-10-19 12:28:19	source	A
2	lthd_y_coord	integer	0		=	Y Co-ordinate	lthd	3	10	60	10	0		1958	2001-10-19 12:28:19	source	A
2	mdcr_amount	money	0		=	Amount credited	mdcr	30	10	30	10			1990	2001-10-19 12:28:44	source	A
2	mdcr_paym__sequence	integer	0		=	Payment serial number	mdcr	30	10	10	10			1991	2001-10-19 12:28:45	source	A
2	mdcr_svpf__sequence	integer	0		=	Service serial number	mdcr	30	10	20	10			1992	2001-10-19 12:28:45	source	A
2	note_desc	text	0		~*	Description	note	50	10	20	TEXTAREA=3		WRAP=VIRTUAL	1997	2001-10-19 12:28:50	source	A
2	note_patn__sequence	integer	0		=	Patient ID	note	20	10	10	RO	=patn__sequence		1998	2001-10-19 12:28:51	source	A
31	eftv_tdtp_location	text	30		~*	Tdtp Location	eftv	30	110	110	10			2699	2002-02-09 08:01:42	source	A
31	cnrt_start_date	timestamp	47		~*	Start Date	cnrt	10	50	50	10			1773	2001-10-19 12:25:14	source	A
31	gstv_bkdp_date_created	timestamp	47		~*	Bank Date	gstv	10	150	150	SYSTEM			2456	2001-10-23 15:35:05	source	A
31	labl_attribute_name	text	1		~*	Attribute	labl	30	50	50	10			1937	2001-10-19 12:28:08	source	A
31	labl_class_name	text	1		~*	Class	labl	10	40	40	10			1938	2001-10-19 12:28:08	source	A
31	labl_column	int4	1		~*	Column	labl	3	70	70	10			1939	2001-10-19 12:28:09	source	A
31	labl_id	text	1		~*	ID	labl	30	10	10	10			1940	2001-10-19 12:28:09	source	A
31	labl_row	int4	1		~*	row	labl	3	60	60	10			1941	2001-10-19 12:28:09	source	A
31	labl_subtype	text	1		~*	Fee Type	labl	10	20	20	10			1942	2001-10-19 12:28:10	source	A
31	labl_text_label	text	1		~*	Text	labl	30	30	30	10			1943	2001-10-19 12:28:10	source	A
2	lthd_align	char(1)	0		~*	Alignment (L/R/C)	lthd	2	10	100	SELECT=R,RIGHT;C,CENTRE;L,LEFT	10		1948	2001-10-19 12:28:15	source	A
2	lthd_data	text	0		~*	Content	lthd	30	10	40	10			1949	2001-10-19 12:28:16	source	A
2	lthd_font	text	0		~*	Font Name	lthd	2	10	80	SELECT=Courier,Courier;Courier-BoldOblique,Courier-BoldOblique;Courier-Oblique,Courier-Oblique;Helvetica,Helvetica;Helvetica-Bold,Helvetica-Bold;Helvetica-BoldOblique,Helvetica-BoldOblique;Helvetica-Oblique,Helvetica-Oblique;Symbol,Symbol;Times-Roman,Times-Roman;Times-Bold,Times-Bold;Times-BoldItalic,Times-BoldItalic;Times-Italic,Times-Italic;ZapfDingbats,ZapfDingbats;	10		1950	2001-10-19 12:28:16	source	A
2	lthd_order	integer	0		=	Display Order	lthd	5	10	20	10	100		1951	2001-10-19 12:28:16	source	A
2	lthd_prov_code	text	0		~*	Letterhead Code	lthd	10	10	10	FSL=20	=prov_code		1952	2001-10-19 12:28:17	source	A
2	lthd_scale	float	0		~*	Scale	lthd	2	10	70	10	1		1953	2001-10-19 12:28:17	source	A
2	lthd_size	float	0		~*	Font Size (points)	lthd	4	10	90	10	12		1954	2001-10-19 12:28:18	source	A
31	locn_code	text	30		~*	Code	locn	30	10	10	10			3166	2002-10-24 04:26:11	source	A
31	locn_colour	text	30		~*	Colour	locn	10	15	15	COLOUR			3167	2002-10-24 04:26:11	source	A
31	gstv_bkdp_date_printed	timestamp	47		~*	Bkdp Date Printed	gstv	10	160	160	SYSTEM			2457	2001-10-23 15:35:05	source	A
2	feeb_amount	numeric(12,2)	0		=	Amount	feeb	30	30	30	30			1874	2001-10-19 12:26:32	source	A
2	feeb_feet_code	text	0		~*	Fee level	feeb	30	20	20				1875	2001-10-19 12:26:32	source	A
2	feeb_serv_code	text	0		~*	Service code	feeb	30	10	10				1876	2001-10-19 12:26:33	source	A
2	feet_code	text	0		~*	Code	feet	30	10	20	40			1881	2001-10-19 12:26:39	source	A
2	feet_desc	text	0		~*	Description	feet	30	10	30	40			1882	2001-10-19 12:26:39	source	A
2	hlfd_code	text	0		~*	Code	hlfd	30	10	20	40			1887	2001-10-19 12:27:00	source	A
2	hlfd_desc	text	0		~*	Description	hlfd	30	20	40	40			1888	2001-10-19 12:27:01	source	A
2	icd9_age_edit	char	0		~*	Age limit	icd9	30	30	50	30			1893	2001-10-19 12:27:21	source	A
2	icd9_area_edit	char	0		~*	Area Edit	icd9	30	30	100	30			1894	2001-10-19 12:27:22	source	A
2	icd9_code	text	0		~*	ICD9 code	icd9	30	30	40	30			1895	2001-10-19 12:27:22	source	A
2	icd9_code_edit	char	0		~*	Code edit	icd9	30	30	90	30			1896	2001-10-19 12:27:22	source	A
2	icd9_codetype	char	0		~*	Code type	icd9	30	30	30	30			1897	2001-10-19 12:27:23	source	A
2	icd9_desc	text	0		~*	Description	icd9	30	30	120	30			1898	2001-10-19 12:27:23	source	A
2	icd9_digit_5	text	0		~*	Fifth digit edit	icd9	30	30	110	30			1899	2001-10-19 12:27:24	source	A
2	icd9_high_age	smallint	0		=	High Age	icd9	30	30	70	30			1900	2001-10-19 12:27:27	source	A
2	icd9_low_age	smallint	0		=	Low age	icd9	30	30	60	30			1901	2001-10-19 12:27:27	source	A
2	icd9_sex_edit	char	0		~*	Gender limit	icd9	30	30	80	30			1902	2001-10-19 12:27:34	source	A
2	inst_addr	text	0		~*	Street	inst	30	30	50	30			1907	2001-10-19 12:27:40	source	A
2	inst_code	text	0		~*	Code	inst	30	30	30	30			1908	2001-10-19 12:27:41	source	A
2	inst_cont	text	0		~*	Contact name	inst	30	30	80	30			1909	2001-10-19 12:27:41	source	A
2	inst_desc	text	0		~*	Description	inst	30	30	40	30			1910	2001-10-19 12:27:42	source	A
2	diag_icd9	text	0		~*	ICD9 code number	diag	30	30	30	30			1818	2001-10-19 12:25:51	source	A
2	diag_type	text	0		~*	Code type	diag	30	20	20	20			1819	2001-10-19 12:25:51	source	A
31	docs_patn__sequence	int4	10		~*	Patient ID	docs	10	10	10	RO			1824	2001-10-19 12:25:56	source	A
31	docs_title	text	30		~*	Title	docs	30	30	30	10			1825	2001-10-19 12:25:56	source	A
31	docs_url	text	30		~*	Location	docs	30	20	20	RO			1826	2001-10-19 12:25:57	source	A
2	empl_address	text	0		~*	Street	empl	30	10	30	10			1831	2001-10-19 12:26:03	source	A
2	empl_code	text	0		~*	Code	empl	30	12	10	10			1832	2001-10-19 12:26:03	source	A
2	empl_name	text	0		~*	Name	empl	30	10	20	10			1833	2001-10-19 12:26:03	source	A
2	empl_state	text	0		~*	State	empl	20	10	60	10			1835	2001-10-19 12:26:04	source	A
2	epsd_admit_criteria	char	0		~*	Admission criteria	epsd	30	30	40	30			1841	2001-10-19 12:26:11	source	A
2	epsd_admit_source	text	0		~*	Admission source	epsd	30	30	60	30			1843	2001-10-19 12:26:12	source	A
2	epsd_admit_type	text	0		~*	Admission type	epsd	30	30	50	30			1844	2001-10-19 12:26:13	source	A
2	epsd_healthfund	text	0		~*	Healthfund	epsd	30	30	90	30			1845	2001-10-19 12:26:13	source	A
2	epsd_ins_level	text	0		~*	Insurance level	epsd	30	30	100	30			1846	2001-10-19 12:26:13	source	A
2	epsd_lvday_finyr	smallint	0		=	Leave days YTD	epsd	30	30	130	30			1847	2001-10-19 12:26:14	source	A
2	epsd_lvday_month	smallint	0		=	Leave days MTD	epsd	30	30	120	30			1848	2001-10-19 12:26:14	source	A
2	epsd_lvday_total	smallint	0		=	Leave days total	epsd	30	30	140	30			1849	2001-10-19 12:26:15	source	A
2	epsd_neonate_weight	smallint	0		=	Neonate weight	epsd	30	30	70	30			1850	2001-10-19 12:26:15	source	A
2	epsd_patn__sequence	integer	0		=	Patient OID	epsd	30	30	220	30			1851	2001-10-19 12:26:15	source	A
2	epsd_re_admit	text	0		~*	Intention to readmit	epsd	30	30	180	30			1852	2001-10-19 12:26:16	source	A
2	epsd_sepn_transfer	text	0		~*	Separation transfer	epsd	30	30	170	30			1854	2001-10-19 12:26:17	source	A
2	epsd_sepn_type	text	0		~*	Separation type	epsd	30	30	160	30			1855	2001-10-19 12:26:17	source	A
2	epsd_speciality	text	0		~*	Clinical speciality	epsd	30	30	110	30			1856	2001-10-19 12:26:17	source	A
2	epsd_study	text	0		~*	Study ID	epsd	30	30	200	30			1857	2001-10-19 12:26:18	source	A
2	epsd_trans_source	text	0		~*	Transfer source	epsd	30	30	80	30			1858	2001-10-19 12:26:18	source	A
2	epsd_user_flag_diag	text	0		~*	Diagnosis flag	epsd	30	30	210	30			1859	2001-10-19 12:26:19	source	A
2	epsd_user_flag_sepn	text	0		~*	Separation flag	epsd	30	30	190	30			1860	2001-10-19 12:26:19	source	A
31	locn_desc	text	30		~*	Description	locn	30	20	20	10			3168	2002-10-24 04:26:11	source	A
31	cnrt_serv_code	text	30		~*	Service code	cnrt	30	60	60	10			1772	2001-10-19 12:25:14	source	A
31	cnrt_end_date	timestamp	47		~*	Final payment date	cnrt	10	110	110	RO			1767	2001-10-19 12:25:12	source	A
31	ctrt_period	interval	47		~*	Interval	cnrt	47	30	30	10			1774	2001-10-19 12:25:15	source	A
2	cnty_code	text	0		~*	Code	cnty	30	10	10	10			1779	2001-10-19 12:25:20	source	A
2	cnty_desc	text	0		~*	Description	cnty	30	20	20	20			1780	2001-10-19 12:25:21	source	A
2	conf_access	integer	0		=	Access	conf	2	10	30	SELECT=0,Guest;1,User;10,Administrator;	10		1785	2001-10-19 12:25:26	source	A
2	conf_code	text	0		~*	Attribute Name	conf	30	10	40	10			1786	2001-10-19 12:25:26	source	A
2	conf_desc	text	0		~*	Description	conf	30	10	50	10			1787	2001-10-19 12:25:26	source	A
2	conf_scope	integer	0		=	Scope	conf	2	10	20	SELECT=1,Global;2,Database;3,User;4,Session;	10		1788	2001-10-19 12:25:27	source	A
2	conf_type	integer	0		=	Type	conf	2	10	10	SELECT=1,Variable;2,Constant;	10		1789	2001-10-19 12:25:27	source	A
2	conf_value	text	0		~*	Value	conf	30	10	60	10	0		1790	2001-10-19 12:25:28	source	A
2	cred_amount	numeric(12,2)	0		=	Credit Amount	cred	10	30	30	30			1795	2001-10-19 12:25:32	source	A
2	cred_gst_amount	numeric(12,2)	1		~*	GST credit amount	cred	10	32	32		0.0		1796	2001-10-19 12:25:33	source	A
2	cred_invc__sequence	integer	0		=	Invoice Serial Number	cred	30	10	20	RO	=invc__sequence		1797	2001-10-19 12:25:33	source	A
2	cred_paym__sequence	integer	0		=	Payment Serial Number	cred	30	10	10	RO	=paym__sequence		1798	2001-10-19 12:25:34	source	A
2	dbtr_address	text	0		~*	Street	dbtr	60	10	40	40			1803	2001-10-19 12:25:40	source	A
2	dbtr_code	text	0		~*	Code	dbtr	12	10	20	40			1804	2001-10-19 12:25:40	source	A
2	dbtr_name	text	0		~*	Name	dbtr	60	10	30	40			1805	2001-10-19 12:25:40	source	A
2	dbtr_phone	text	0		~*	Phone	dbtr	60	10	80	40			1806	2001-10-19 12:25:41	source	A
2	dbtr_state	text	0		~*	State	dbtr	60	10	70	40			1808	2001-10-19 12:25:41	source	A
2	diag_desc	text	0		~*	Description	diag	30	30	60	30			1816	2001-10-19 12:25:50	source	A
31	mtfn_title	text	0	not null	~*	Title	mtfn	30	10	10	10	New Foreign Relationship		162	2001-10-10 12:25:18	source	A
31	mtrl_join	text	0		~*	Child Class Key	mtrl	20	50	50	10			168	2001-10-10 12:25:25	source	A
31	mtrl_key	text	0		~*	Master Class Key	mtrl	30	30	30	10			169	2001-10-10 12:25:25	source	A
31	mtrl_title	text	0		~*	Relation Title	mtrl	30	10	10	10			172	2001-10-10 12:25:27	source	A
31	mtsv_name	text	30	\N	~*	Name	mtsv	30	10	10	10			110	2001-10-10 12:24:25	source	A
31	mtsv_master_class	text	30	\N	~*	Master Class	mtsv	30	20	20	10			111	2001-10-10 12:24:25	source	A
31	mtsv_key	text	30	\N	~*	Key	mtsv	30	30	30	10			112	2001-10-10 12:24:25	source	A
31	mtsv_other_class	text	30	\N	~*	Other Class	mtsv	30	40	40	10			113	2001-10-10 12:24:25	source	A
31	mtsv_join	text	30	\N	~*	Join	mtsv	30	50	50	10			114	2001-10-10 12:24:25	source	A
31	mtcl_extras	text	0		~*	Extra Code	mtcl	30	110	110	10			124	2001-10-10 12:24:51	source	A
2	accl_code	text	0		~*	Code	accl	30	10	10	10			1712	2001-10-19 12:24:28	source	A
2	accl_desc	text	0		~*	Description	accl	20	20	20				1713	2001-10-19 12:24:28	source	A
31	bank_account	text	1		~*	Account	bank	30	10	100	10			1718	2001-10-19 12:24:33	source	A
31	bank_address	text	1		~*	Business - Address	bank	30	10	30	10			1719	2001-10-19 12:24:34	source	A
31	bank_bank	text	1		~*	Bank	bank	30	10	110	10			1720	2001-10-19 12:24:34	source	A
31	bank_branch	text	1		~*	Branch	bank	30	10	120	10			1721	2001-10-19 12:24:35	source	A
31	bank_code	text	1		~*	Code	bank	10	10	10	10			1722	2001-10-19 12:24:35	source	A
31	bank_name	text	1		~*	Business - Name	bank	30	10	20	10			1723	2001-10-19 12:24:36	source	A
31	bank_phone	text	1		~*	Phone	bank	30	10	70	10			1724	2001-10-19 12:24:36	source	A
31	mtat_browse_order	int4	0		~*	Browse Order	mtat	5	100	100	100	900		142	2001-10-10 12:25:04	source	A
31	mtat_default	text	0		~*	Default	mtat	30	130	130	10			144	2001-10-10 12:25:05	source	A
31	mtat_displen	int4	0		~*	Display Length	mtat	5	90	90	5	10		145	2001-10-10 12:25:06	source	A
31	mtat_htmltagatt	text	0		~*	HTML Tag	mtat	30	140	140	10			146	2001-10-10 12:25:07	source	A
31	mtat_input_method	text	0		~*	Input Method	mtat	30	120	120	10			147	2001-10-10 12:25:07	source	A
31	mtat_view_order	int4	0		~*	View Order	mtat	5	110	110	10	900		153	2001-10-10 12:25:10	source	A
2	diag_epsdserl	integer	0		=	Episode Serial Number	diag	30	10	10				1817	2001-10-19 12:25:51	source	A
31	bank_state	text	1		~*	State	bank	30	10	60	10			1726	2001-10-19 12:24:37	source	A
2	bkdp_amount	numeric(12,2)	1		~*	Total amount	bkdp	10	18	18	RO			1732	2001-10-19 12:24:43	source	A
2	bkdp_bank_code	text	1		~*	Bank Account	bkdp	10	22	22		-		1733	2001-10-19 12:24:44	source	A
2	bkdp_date_created	text	0		~*	Date Created	bkdp	30	10	10	RO			1734	2001-10-19 12:24:44	source	A
2	bkdp_desc	text	1		~*	Annotation	bkdp	10	16	16		New Bank List		1736	2001-10-19 12:24:45	source	A
2	bkdp_user_printed	text	0		~*	Printed by user	bkdp	30	30	30	RO			1737	2001-10-19 12:24:45	source	A
31	gstv_bkdp_amount	numeric	786434		~*	Bkdp Amount	gstv	786434	200	200	SYSTEM			2454	2001-10-23 15:35:04	source	A
31	gstv_bkdp_bank_code	text	30		~*	Bkdp Bank Code	gstv	30	180	180	SYSTEM			2455	2001-10-23 15:35:04	source	A
31	cnrt_last_date	timestamp	47		~*	Last paid date	cnrt	10	90	90	10			1769	2001-10-19 12:25:13	source	A
31	gstv_invc_date_created	timestamp	47		~*	Invc Date Created	gstv	10	300	300	SYSTEM			2474	2001-10-23 15:35:10	source	A
31	gstv_bkdp_desc	text	30		~*	Bkdp Desc	gstv	30	190	190	SYSTEM			2458	2001-10-23 15:35:05	source	A
31	gstv_bkdp_user_printed	text	30		~*	Bkdp User Printed	gstv	30	170	170	SYSTEM			2459	2001-10-23 15:35:05	source	A
31	gstv_cred_amount	numeric	786434		~*	Credit Amount	gstv	786434	30	180	RO			2460	2001-10-23 15:35:06	source	A
31	gstv_cred_gst_amount	numeric	786434		~*	GST Amount	gstv	786434	40	15	RO			2461	2001-10-23 15:35:06	source	A
31	gstv_cred_invc__sequence	int4	10		~*	Invoice Number	gstv	10	20	60	RO			2462	2001-10-23 15:35:06	source	A
31	gstv_cred_paym__sequence	int4	10		~*	Payment Number	gstv	10	10	70	RO			2463	2001-10-23 15:35:07	source	A
31	gstv_day_date	text	30		~*	Bank Date	gstv	30	50	10	RO			2464	2001-10-23 15:35:07	source	A
31	gstv_dbtr_address	text	30		~*	Dbtr Address	gstv	30	490	490	SYSTEM			2465	2001-10-23 15:35:07	source	A
2	cash_amount	numeric(12,2)	0		=	Amount	cash	30	40	40	40			1742	2001-10-19 12:24:51	source	A
2	cash_creditor	text	0		~*	Creditor	cash	30	20	20				1743	2001-10-19 12:24:52	source	A
2	cash_date	date	0		=	Date of assignment	cash	30	30	30				1744	2001-10-19 12:24:52	source	A
2	cash_paym__sequence	integer	0		=	Payment ID	cash	30	10	10				1745	2001-10-19 12:24:52	source	A
2	cash_text	text	0		~*	Annotation	cash	30	50	50	50			1746	2001-10-19 12:24:53	source	A
2	clsp_code	text	0		~*	Code	clsp	30	10	10	10			1751	2001-10-19 12:24:58	source	A
2	clsp_desc	text	0		~*	Description	clsp	30	20	20	20			1752	2001-10-19 12:24:58	source	A
2	clst_feet_code	text	0		~*	Fee level	clst	30	20	20	20			1757	2001-10-19 12:25:03	source	A
2	clst_serv_code_child	text	0		~*	Service code	clst	30	10	10	10			1758	2001-10-19 12:25:04	source	A
2	clst_serv_code_parent	text	0		~*	Cluster Code	clst	30	5	5	5			1759	2001-10-19 12:25:04	source	A
31	cnrt_amount	numeric	786434		~*	Total Amount	cnrt	786434	20	20	10			1764	2001-10-19 12:25:11	source	A
31	cnrt_balance	numeric	786434		~*	Balance	cnrt	786434	100	100	RO			1765	2001-10-19 12:25:11	source	A
31	cnrt_count	int4	10		~*	# Payments	cnrt	10	40	40	10			1766	2001-10-19 12:25:12	source	A
31	gstv_invc_date_printed	timestamp	47		~*	Invc Date Printed	gstv	10	310	310	SYSTEM			2475	2001-10-23 15:35:10	source	A
31	cnrt_first_installment	numeric	786434		~*	First amount	cnrt	786434	70	70	10			1768	2001-10-19 12:25:12	source	A
31	gstv_invc_date_reprint	timestamp	47		~*	Invc Date Reprint	gstv	10	320	320	SYSTEM			2476	2001-10-23 15:35:10	source	A
31	cnrt_other_installment	numeric	786434		~*	Other amounts	cnrt	786434	80	80	10			1770	2001-10-19 12:25:13	source	A
31	cnrt_patn__sequence	int4	10		~*	Patient ID	cnrt	10	10	115	RO			1771	2001-10-19 12:25:14	source	A
31	gstv_dbtr_code	text	30		~*	Dbtr Code	gstv	30	470	470	SYSTEM			2466	2001-10-23 15:35:07	source	A
31	gstv_dbtr_name	text	30		~*	Debtor Name	gstv	30	480	50	RO			2467	2001-10-23 15:35:08	source	A
31	gstv_dbtr_phone	text	30		~*	Dbtr Phone	gstv	30	530	530	SYSTEM			2468	2001-10-23 15:35:08	source	A
31	gstv_dbtr_postcode	text	30		~*	Dbtr Postcode	gstv	30	510	510	SYSTEM			2469	2001-10-23 15:35:08	source	A
31	gstv_dbtr_state	text	30		~*	Dbtr State	gstv	30	520	520	SYSTEM			2470	2001-10-23 15:35:08	source	A
31	gstv_dbtr_suburb	text	30		~*	Dbtr Suburb	gstv	30	500	500	SYSTEM			2471	2001-10-23 15:35:09	source	A
31	gstv_invc_amount	numeric	786434		~*	Invoice Amount	gstv	786434	330	330	RO			2472	2001-10-23 15:35:09	source	A
31	gstv_invc_bank_code	text	30		~*	Invc Bank Code	gstv	30	220	220	SYSTEM			2473	2001-10-23 15:35:09	source	A
31	gstv_invc_rfdr_date	timestamp	47		~*	Invc Rfdr Date	gstv	10	280	280	SYSTEM			2486	2001-10-23 15:35:13	source	A
31	gstv_paym_date_entry	timestamp	47		~*	Payment Date	gstv	10	50	150	RO			2502	2001-10-23 15:35:17	source	A
31	eftv_tdtp_subtotal	text	30		~*	Tdtp Subtotal	eftv	30	80	80	10			2700	2002-02-09 08:01:42	source	A
31	gstv_invc_dbtr_code	text	30		~*	Debtor Code	gstv	30	210	40	RO			2477	2001-10-23 15:35:10	source	A
31	gstv_invc_empl_code	text	30		~*	Invc Empl Code	gstv	30	250	250	SYSTEM			2478	2001-10-23 15:35:11	source	A
31	gstv_invc_feet_code	text	30		~*	Invc Feet Code	gstv	30	260	260	SYSTEM			2479	2001-10-23 15:35:11	source	A
31	gstv_invc_gst_amount	numeric	786434		~*	Invoice GST Amount	gstv	786434	350	350	RO			2480	2001-10-23 15:35:11	source	A
31	gstv_invc_paid_amount	numeric	786434		~*	Invoice Paid	gstv	786434	340	340	RO			2481	2001-10-23 15:35:12	source	A
31	gstv_invc_paid_gst_amount	numeric	786434		~*	Invoice Paid GST Amount	gstv	786434	360	360	RO			2482	2001-10-23 15:35:12	source	A
31	gstv_invc_patn__sequence	int4	10		~*	Patient ID	gstv	10	240	20	RO			2483	2001-10-23 15:35:12	source	A
31	gstv_invc_prov_code	text	30		~*	Invc Prov Code	gstv	30	230	230	SYSTEM			2484	2001-10-23 15:35:12	source	A
31	gstv_invc_rfdr_code	text	30		~*	Invc Rfdr Code	gstv	30	270	270	SYSTEM			2485	2001-10-23 15:35:13	source	A
31	eftv_user_entry	text	30		~*	User Entry	eftv	30	30	30	10			2701	2002-02-09 08:01:42	source	A
31	gstv_invc_rfdr_period	text	30		~*	Invc Rfdr Period	gstv	30	290	290	SYSTEM			2487	2001-10-23 15:35:13	source	A
31	gstv_patn_address	text	30		~*	Patn Address	gstv	30	430	430	SYSTEM			2488	2001-10-23 15:35:13	source	A
31	gstv_patn_dob	text	30		~*	Patn Dob	gstv	30	420	420	SYSTEM			2489	2001-10-23 15:35:14	source	A
31	gstv_patn_flno	text	30		~*	Patn Flno	gstv	30	380	380	SYSTEM			2490	2001-10-23 15:35:14	source	A
31	gstv_patn_fsnam	text	30		~*	Patient Firstname	gstv	30	400	400	RO			2491	2001-10-23 15:35:14	source	A
31	gstv_patn_phone	text	30		~*	Patn Phone	gstv	30	470	470	SYSTEM			2492	2001-10-23 15:35:15	source	A
31	gstv_patn_postcode	text	30		~*	Patn Postcode	gstv	30	460	460	SYSTEM			2493	2001-10-23 15:35:15	source	A
31	gstv_patn_psnam	text	30		~*	Surname	gstv	30	390	30	RO			2494	2001-10-23 15:35:15	source	A
31	gstv_patn_state	text	30		~*	Patn State	gstv	30	450	450	SYSTEM			2495	2001-10-23 15:35:15	source	A
31	gstv_patn_suburb	text	30		~*	Patn Suburb	gstv	30	440	440	SYSTEM			2496	2001-10-23 15:35:16	source	A
31	gstv_patn_title	text	30		~*	Patn Title	gstv	30	410	410	SYSTEM			2497	2001-10-23 15:35:16	source	A
31	gstv_paym_amount	numeric	786434		~*	Total Payment Amount	gstv	786434	80	80	RO			2498	2001-10-23 15:35:16	source	A
31	gstv_paym_bank	text	30		~*	Bank	gstv	30	110	110	RO			2499	2001-10-23 15:35:16	source	A
31	gstv_paym_bkdp__sequence	int4	10		~*	Bank Batch ID	gstv	10	130	130	RO			2500	2001-10-23 15:35:17	source	A
31	gstv_paym_branch	text	30		~*	Branch	gstv	30	120	120	RO			2501	2001-10-23 15:35:17	source	A
31	gstv_paym_drawer	text	30		~*	Drawer	gstv	30	100	100	RO			2503	2001-10-23 15:35:18	source	A
31	gstv_paym_site_entry	text	30		~*	Paym Site Entry	gstv	30	70	170	SYSTEM			2504	2001-10-23 15:35:18	source	A
31	gstv_paym_tdtp_code	text	30		~*	Tender	gstv	30	90	90	RO			2505	2001-10-23 15:35:18	source	A
31	gstv_paym_user_entry	text	30		~*	Paym User Entry	gstv	30	60	160	SYSTEM			2506	2001-10-23 15:35:18	source	A
31	gstv_quarter_date	text	30		~*	Quarter Date	gstv	30	140	4	RO			2507	2001-10-23 15:35:19	source	A
2	patv_dob	timestamp	0		=	Date of birth	patv	10	10	60	40			2402	2001-10-19 12:33:32	source	A
31	crep_date_created	timestamp	47		~*	Invoice Created	crep	10	10	200	RO			2246	2001-10-19 12:32:13	source	A
31	crep_date_printed	timestamp	47		~*	Invoice Printed	crep	10	10	210	RO			2247	2001-10-19 12:32:13	source	A
31	patf_code	text	30		~*	Code	patf	30	10	10	10			2706	2002-02-09 08:01:45	source	A
31	patf_desc	text	30		~*	Description	patf	30	20	20	10			2707	2002-02-09 08:01:46	source	A
31	eftr_date_created	timestamp	47		~*	Date Created	eftr	47	10	10	10			2661	2002-02-09 08:01:29	source	A
31	eftr_first__sequence	int4	10		~*	First  Sequence	eftr	10	20	20	10			2662	2002-02-09 08:01:30	source	A
31	eftr_last__sequence	int4	10		~*	Last  Sequence	eftr	10	30	30	10			2663	2002-02-09 08:01:30	source	A
31	eftv_bank	text	30		~*	Bank	eftv	30	130	130	10			2668	2002-02-09 08:01:33	source	A
31	eftv_bank_account	text	30		~*	Bank Account	eftv	30	330	330	10			2669	2002-02-09 08:01:33	source	A
31	eftv_bank_address	text	30		~*	Bank Address	eftv	30	260	260	10			2670	2002-02-09 08:01:34	source	A
31	eftv_bank_bank	text	30		~*	Bank Bank	eftv	30	310	310	10			2671	2002-02-09 08:01:34	source	A
31	eftv_bank_branch	text	30		~*	Bank Branch	eftv	30	320	320	10			2672	2002-02-09 08:01:34	source	A
31	eftv_bank_code	text	30		~*	Bank Code	eftv	30	240	240	10			2673	2002-02-09 08:01:34	source	A
31	eftv_bank_name	text	30		~*	Bank Name	eftv	30	250	250	10			2674	2002-02-09 08:01:35	source	A
31	eftv_bank_phone	text	30		~*	Bank Phone	eftv	30	300	300	10			2675	2002-02-09 08:01:35	source	A
31	eftv_bank_postcode	text	30		~*	Bank Postcode	eftv	30	290	290	10			2676	2002-02-09 08:01:35	source	A
31	eftv_bank_state	text	30		~*	Bank State	eftv	30	280	280	10			2677	2002-02-09 08:01:35	source	A
31	eftv_bank_suburb	text	30		~*	Bank Suburb	eftv	30	270	270	10			2678	2002-02-09 08:01:36	source	A
31	eftv_bkdp__sequence	int4	10		~*	Bkdp  Sequence	eftv	10	10	10	10			2679	2002-02-09 08:01:36	source	A
31	eftv_branch	text	30		~*	Branch	eftv	30	140	140	10			2680	2002-02-09 08:01:36	source	A
31	eftv_cred_amount	numeric	786434		~*	Cred Amount	eftv	786434	170	170	10			2681	2002-02-09 08:01:37	source	A
31	eftv_cred_gst_amount	numeric	786434		~*	Cred Gst Amount	eftv	786434	180	180	10			2682	2002-02-09 08:01:37	source	A
31	eftv_date_entry	text	30		~*	Date Entry	eftv	30	20	20	10			2683	2002-02-09 08:01:37	source	A
31	eftv_dbtr_code	text	30		~*	Dbtr Code	eftv	30	220	220	10			2684	2002-02-09 08:01:37	source	A
31	eftv_dbtr_name	text	30		~*	Dbtr Name	eftv	30	230	230	10			2685	2002-02-09 08:01:38	source	A
31	eftv_drawer	text	30		~*	Drawer	eftv	30	120	120	10			2686	2002-02-09 08:01:38	source	A
31	eftv_eftr__sequence	int4	10		~*	Eftr  Sequence	eftv	10	10	10	10			2687	2002-02-09 08:01:38	source	A
31	eftv_invc__sequence	int4	10		~*	Invc  Sequence	eftv	10	160	160	10			2688	2002-02-09 08:01:39	source	A
31	eftv_patn__sequence	int4	10		~*	Patn  Sequence	eftv	10	190	190	10			2689	2002-02-09 08:01:39	source	A
31	eftv_patn_fsnam	text	30		~*	Patn Fsnam	eftv	30	210	210	10			2690	2002-02-09 08:01:39	source	A
31	eftv_patn_psnam	text	30		~*	Patn Psnam	eftv	30	200	200	10			2691	2002-02-09 08:01:39	source	A
31	eftv_paym__sequence	int4	10		~*	Paym  Sequence	eftv	10	150	150	10			2692	2002-02-09 08:01:40	source	A
31	eftv_paym_amount	numeric	786434		~*	Paym Amount	eftv	786434	50	50	10			2693	2002-02-09 08:01:40	source	A
31	eftv_site_entry	text	30		~*	Site Entry	eftv	30	40	40	10			2694	2002-02-09 08:01:40	source	A
31	eftv_tdtp_code	text	30		~*	Tdtp Code	eftv	30	60	60	10			2695	2002-02-09 08:01:40	source	A
31	dbag_last_statement	text	30	\N	~*	Last Statement	dbag	30	80	80	10			2834	2002-04-18 13:30:20	source	A
31	dbag_delay_statement	interval	47	\N	~*	Delay Statement	dbag	47	90	90	10			2835	2002-04-18 13:30:20	source	A
31	svpv_ts_service	timestamp	47	\N	~*	Ts Service	svpv	47	20	20	10			2917	2002-10-05 13:46:14	source	A
31	svpv_date_printed	date	10	\N	~*	Date Printed	svpv	10	180	180	10			2918	2002-10-05 13:46:14	source	A
31	svpv_date_reprint	date	10	\N	~*	Date Reprint	svpv	10	190	190	10			2919	2002-10-05 13:46:14	source	A
31	dbag_date	date	10	\N	~*	Date	dbag	10	10	10	10			2839	2002-09-29 05:32:22	source	A
31	dbag_patient_key	text	30	\N	~*	Patient Key	dbag	30	90	90	10			2840	2002-09-29 05:32:22	source	A
31	dbst_full_address	text	30	\N	~*	Full Address	dbst	30	20	20	10			2841	2002-09-29 05:35:22	source	A
31	dbst_patient_key	text	30	\N	~*	Patient Key	dbst	30	100	100	10			2842	2002-09-29 05:35:22	source	A
31	dbst_group	text	30	\N	~*	Group	dbst	30	110	110	10			2843	2002-09-29 05:35:22	source	A
31	dbst_last_statement	timestamp	47	\N	~*	Last Statement	dbst	47	120	120	10			2844	2002-09-29 05:35:22	source	A
31	dbst_last_invoice	date	10	\N	~*	Last Invoice	dbst	10	130	130	10			2845	2002-09-29 05:35:22	source	A
31	dbst_delay_statement	interval	47	\N	~*	Delay Statement	dbst	47	140	140	10			2846	2002-09-29 05:35:22	source	A
31	svpv_rfdr_period	text	30	\N	~*	Rfdr Period	svpv	30	210	210	10			2920	2002-10-05 13:46:14	source	A
2	prov_address	text	0		~*	Street	prov	50	10	40	10			3220	2002-10-25 09:57:38	source	A
2	prov_bank_code	text	1		~*	Bank Account	prov	10	100	100		-		3221	2002-10-25 09:57:38	source	A
2	prov_code	text	0		~*	Provider Code	prov	20	10	10	10			3222	2002-10-25 09:57:39	source	A
31	prov_colour	text	30		~*	Colour	prov	10	10	15	COLOUR			3223	2002-10-25 09:57:39	source	A
2	prov_name	text	0		~*	Name	prov	50	10	30	10			3224	2002-10-25 09:57:39	source	A
2	prov_phone	text	0		~*	Phone	prov	50	10	90	10			3225	2002-10-25 09:57:40	source	A
31	apst_code	text	30		~*	Code	apst	30	10	10	10			3197	2002-10-24 04:26:41	source	A
31	apst_colour	text	30		~*	Colour	apst	10	15	15	COLOUR			3198	2002-10-24 04:26:42	source	A
31	apst_desc	text	30		~*	Desc	apst	30	20	20	10			3199	2002-10-24 04:26:42	source	A
2	prov_provider_num	text	0		~*	Provider number	prov	10	10	20	10			3227	2002-10-25 09:57:40	source	A
31	svpv_dbtr_full_address	text	30	\N	~*	Dbtr Full Address	svpv	30	340	340	10			2921	2002-10-05 13:46:14	source	A
31	evnt_apst_code	text	30		~*	Apst Code	evnt	30	90	90	10			3098	2002-10-24 04:23:30	source	A
31	evnt_aptp_code	text	30		~*	Aptp Code	evnt	30	50	50	10			3099	2002-10-24 04:23:31	source	A
31	evnt_desc	text	30		~*	Notes	evnt	30	40	40	10			3100	2002-10-24 04:23:31	source	A
31	evnt_duration	interval	47		~*	Duration	evnt	47	30	30	10			3101	2002-10-24 04:23:31	source	A
31	evnt_locn_code	text	30		~*	Locn Code	evnt	30	30	30	10			3102	2002-10-24 04:23:31	source	A
31	evnt_patn__sequence	int4	10		~*	Patient ID	evnt	10	10	10	10			3103	2002-10-24 04:23:32	source	A
31	evnt_prov_code	text	1		~*	Provider Code	evnt	10	15	15	10			3104	2002-10-24 04:23:32	source	A
31	evnt_rfdr_code	text	30		~*	Rfdr Code	evnt	30	30	30	10			3105	2002-10-24 04:23:32	source	A
31	evnt_starttime	timestamp	47		~*	Start	evnt	47	20	20	10			3106	2002-10-24 04:23:32	source	A
2	prov_salutation	text	0		~*	Salutation	prov	50	10	80	10			3228	2002-10-25 09:57:40	source	A
2	prov_state	text	0		~*	State	prov	50	10	60	10			3229	2002-10-25 09:57:41	source	A
31	mtcl_group	text	0		~*	Group	mtcl	15	40	40	10			125	2001-10-10 12:24:52	source	A
31	mtcl_name	text	0		~*	Name	mtcl	5	20	10	10			128	2001-10-10 12:24:53	source	A
31	mtcl_access	text	0		~*	Access	mtcl	4	10	30	10	user		123	2001-10-10 12:24:51	source	A
31	mtcl_title	text	0		~*	Title	mtcl	15	30	20	10	New Class		133	2001-10-10 12:24:55	source	A
31	mtat_type	text	0		~*	Data Type	mtat	10	10	20	10			152	2001-10-10 12:25:09	source	A
31	mtat_attributes	text	0		~*	Attributes	mtat	4	50	50	10			141	2001-10-10 12:25:03	source	A
31	mtat_operator	text	0		~*	Query Operator	mtat	4	60	60	10	~*		150	2001-10-10 12:25:08	source	A
31	mtat_title	text	0	not null	~*	Title	mtat	15	70	70	10	New Attribute		151	2001-10-10 12:25:09	source	A
31	mtat_class_name	text	0		~*	Parent Class	mtat	6	80	80				143	2001-10-10 12:25:04	source	A
31	mtat_name	text	0		~*	Name	mtat	15	20	10	10			149	2001-10-10 12:25:08	source	A
31	mtat_access	text	0		~*	Access	mtat	4	4	30	10	user		140	2001-10-10 12:25:03	source	A
31	mtat_length	int4	0		~*	Char Length	mtat	4	3	40	10			148	2001-10-10 12:25:08	source	A
31	notv_desc	text	30		~*	Note Details	notv	40	30	30	10			3235	2003-03-13 15:31:02.523837	source	A
31	notv_patn__sequence	int4	10		~*	Patient ID	notv	10	10	10	SYSTEM			3236	2003-03-13 15:31:02.528221	source	A
31	notv_patn_aboriginality	bpchar	1		~*	Aboriginality	notv	1	160	160	SYSTEM			3237	2003-03-13 15:31:02.53161	source	A
31	notv_patn_accl_code	text	30		~*	Account Code	notv	30	190	190	SYSTEM			3238	2003-03-13 15:31:02.535664	source	A
31	notv_patn_accommodation	bpchar	1		~*	Accomodation	notv	1	200	200	SYSTEM			3239	2003-03-13 15:31:02.5396	source	A
31	notv_patn_address	text	30		~*	Street	notv	30	100	100	SYSTEM			3240	2003-03-13 15:31:02.544325	source	A
31	notv_patn_care	bpchar	1		~*	Care Type	notv	1	210	210	SYSTEM			3241	2003-03-13 15:31:02.63771	source	A
31	notv_patn_country	text	30		~*	County of Birth	notv	30	150	150	SYSTEM			3242	2003-03-13 15:31:02.641492	source	A
31	notv_patn_desc	text	30		~*	Patn Desc	notv	30	50	50	SYSTEM			3243	2003-03-13 15:31:02.646125	source	A
31	notv_patn_dob	text	30		~*	DOB	notv	30	90	90	SYSTEM			3244	2003-03-13 15:31:02.652149	source	A
31	notv_patn_flno	text	30		~*	FileNo.	notv	30	40	40	SYSTEM			3245	2003-03-13 15:31:02.656071	source	A
31	notv_patn_fsnam	text	30		~*	Firstname	notv	30	70	70	SYSTEM			3246	2003-03-13 15:31:02.659844	source	A
31	notv_patn_marital	bpchar	1		~*	Marital Status	notv	1	180	180	SYSTEM			3247	2003-03-13 15:31:02.663552	source	A
31	notv_patn_phone	text	30		~*	Phone	notv	30	140	140	SYSTEM			3248	2003-03-13 15:31:02.667396	source	A
31	notv_patn_postcode	text	30		~*	Postcode	notv	30	130	130	SYSTEM			3249	2003-03-13 15:31:02.671158	source	A
31	notv_patn_psnam	text	30		~*	Surname	notv	30	60	60	SYSTEM			3250	2003-03-13 15:31:02.674958	source	A
31	notv_patn_sex	bpchar	1		~*	Sex	notv	1	170	170	SYSTEM			3251	2003-03-13 15:31:02.678688	source	A
31	notv_patn_state	text	30		~*	State	notv	30	120	120	SYSTEM			3252	2003-03-13 15:31:02.682361	source	A
31	notv_patn_suburb	text	30		~*	Suburb	notv	30	110	110	SYSTEM			3253	2003-03-13 15:31:02.686878	source	A
31	notv_patn_title	text	30		~*	Title	notv	30	80	80	SYSTEM			3254	2003-03-13 15:31:02.690563	source	A
31	notv_time	text	30		~*	Time	notv	20	20	20	RO			3255	2003-03-13 15:31:02.697066	source	A
31	mtop_code	text	30	\N	~*	Code	mtop	30	10	10	10			3257	2004-03-28 13:55:18.536541	source	A
31	mtop_desc	text	30	\N	~*	Description	mtop	30	20	20	10			3258	2004-03-28 13:55:18.536541	source	A
31	mtal_mtat_name	text	30	\N	~*	Attribute	mtal	10	10	10	10			3263	2004-03-28 13:55:21.243797	source	A
31	mtal_value	text	30	\N	~*	Value	mtal	30	30	30	10			3265	2004-03-28 13:55:21.243797	source	A
31	mtal_priority	int4	30	\N	~*	Priority	mtal	30	50	50	10			3267	2004-03-28 13:55:21.243797	source	A
31	mtal_colour	text	30	\N	~*	Colour	mtal	30	40	40	COLOUR			3266	2004-03-28 13:55:21.243797	source	A
31	mtal_mtop_code	text	30	\N	~*	Operator	mtal	30	20	20	FSL=100			3264	2004-03-28 13:55:21.243797	source	A
31	mtag_name	text	30	\N	~*	Name	mtag	10	10	10	10			3272	2004-03-28 13:55:24.233441	source	A
31	mtag_title	text	30	\N	~*	Title	mtag	20	20	20	10			3273	2004-03-28 13:55:24.233441	source	A
31	mtag_parent	text	30	\N	~*	Parent Menu	mtag	10	30	30	10			3274	2004-03-28 13:55:24.233441	source	A
31	mtag_access	int4	30	\N	~*	Access	mtag	5	40	40	10			3275	2004-03-28 13:55:24.233441	source	A
31	mtag_list_order	text	30	\N	~*	List Order	mtag	10	50	50	10			3276	2004-03-28 13:55:24.233441	source	A
31	mtad_title	text	30	\N	~*	Title	mtad	20	10	10	10			3281	2004-03-28 13:55:25.626852	source	A
31	mtad_icon	text	30	\N	~*	Icon	mtad	10	20	20	10			3282	2004-03-28 13:55:25.626852	source	A
31	mtad_parent	text	30	\N	~*	Parent	mtad	10	30	30	10			3283	2004-03-28 13:55:25.626852	source	A
31	mtad_class	text	30	\N	~*	Class	mtad	10	40	40	10			3284	2004-03-28 13:55:25.626852	source	A
31	mtad_access	int4	30	\N	~*	Access	mtad	10	50	50	10			3285	2004-03-28 13:55:25.626852	source	A
31	mtad_list_order	text	30	\N	~*	List Order	mtad	10	60	60	10			3286	2004-03-28 13:55:25.626852	source	A
31	mttk_code	text	30	\N	~*	Code	mttk	30	10	10	10			3291	2004-03-28 13:55:27.545702	source	A
31	mttk_expires	timestamp	30	\N	~*	Expires	mttk	30	20	20	10			3292	2004-03-28 13:55:27.545702	source	A
31	mtau_table_name	text	30	\N	~*	Table Name	mtau	30	10	10	10			3297	2004-03-28 13:55:28.658454	source	A
31	mtau_row_sequence	int4	30	\N	~*	Row Sequence	mtau	30	20	20	10			3298	2004-03-28 13:55:28.658454	source	A
31	mtau_operation	text	30	\N	~*	Operation	mtau	30	30	30	10			3299	2004-03-28 13:55:28.658454	source	A
31	mtau_attributes	text	30	\N	~*	Attributes	mtau	30	40	40	10			3300	2004-03-28 13:55:28.658454	source	A
31	mtau_before	text	30	\N	~*	Before	mtau	30	50	50	10			3301	2004-03-28 13:55:28.658454	source	A
31	mtau_after	text	30	\N	~*	After	mtau	30	60	60	10			3302	2004-03-28 13:55:28.658454	source	A
31	pcde_postcode	text	30	\N	~*	Postcode	pcde	6	10	10	10			3307	2004-03-28 13:55:29.841367	source	A
31	pcde_locality	text	30	\N	~*	Locality	pcde	20	20	20	10			3308	2004-03-28 13:55:29.841367	source	A
31	pcde_state	text	30	\N	~*	State	pcde	5	30	30	10			3309	2004-03-28 13:55:29.841367	source	A
31	pcde_comments	text	30	\N	~*	Comments	pcde	20	40	40	10			3310	2004-03-28 13:55:29.841367	source	A
31	pcde_delivery_office	text	30	\N	~*	Delivery Office	pcde	20	50	50	10			3311	2004-03-28 13:55:29.841367	source	A
31	pcde_presort_indicator	text	30	\N	~*	Presort Indicator	pcde	5	60	60	10			3312	2004-03-28 13:55:29.841367	source	A
31	pcde_parcelzone	text	30	\N	~*	Parcelzone	pcde	5	70	70	10			3313	2004-03-28 13:55:29.841367	source	A
31	pcde_bsp_number	text	30	\N	~*	Bsp Number	pcde	5	80	80	10			3314	2004-03-28 13:55:29.841367	source	A
31	pcde_bsp_name	text	30	\N	~*	Bsp Name	pcde	20	90	90	10			3315	2004-03-28 13:55:29.841367	source	A
31	pcde_category	text	30	\N	~*	Category	pcde	20	100	100	10			3316	2004-03-28 13:55:29.841367	source	A
31	ptts_count	int8	30	\N	~*	Count	ptss	30	50	50	RO			3325	2004-03-28 13:55:44.534516	source	A
31	ptss_year_service	text	30	\N	~*	Year	ptss	8	10	10	RO			3321	2004-03-28 13:55:44.534516	source	A
31	ptss_serv_code	text	30	\N	~*	Item	ptss	8	20	20	RO			3322	2004-03-28 13:55:44.534516	source	A
31	ptss_feet_code	text	30	\N	~*	Fee-type	ptss	8	30	30	RO			3323	2004-03-28 13:55:44.534516	source	A
31	ptss_hlfd_code	text	30	\N	~*	HealthFund	ptss	10	40	40	RO			3324	2004-03-28 13:55:44.534516	source	A
31	addr_name	text	30	\N	~*	Name	addr	12	10	10	10			3330	2004-03-28 13:55:45.84484	source	A
31	addr_contact	text	30	\N	~*	Contact	addr	12	20	20	10			3331	2004-03-28 13:55:45.84484	source	A
31	addr_organisation	text	30	\N	~*	Work Organisation	addr	12	30	30	10			3332	2004-03-28 13:55:45.84484	source	A
31	addr_work_phone	text	30	\N	~*	Work Phone	addr	12	40	40	10			3333	2004-03-28 13:55:45.84484	source	A
31	addr_work_fax	text	30	\N	~*	Work Fax	addr	12	50	50	10			3334	2004-03-28 13:55:45.84484	source	A
31	addr_mobile_phone	text	30	\N	~*	Mobile Phone	addr	12	60	60	10			3335	2004-03-28 13:55:45.84484	source	A
31	addr_work_email	text	30	\N	~*	Work Email	addr	12	70	70	10			3336	2004-03-28 13:55:45.84484	source	A
31	addr_work_www	text	30	\N	~*	Work WWW	addr	12	80	80	10			3337	2004-03-28 13:55:45.84484	source	A
31	addr_work_im	text	30	\N	~*	Work IM	addr	12	90	90	10			3338	2004-03-28 13:55:45.84484	source	A
31	addr_work_street	text	30	\N	~*	Work Street	addr	12	100	100	10			3339	2004-03-28 13:55:45.84484	source	A
31	addr_work_suburb	text	30	\N	~*	Work Suburb	addr	12	110	110	10			3340	2004-03-28 13:55:45.84484	source	A
31	addr_work_postcode	text	30	\N	~*	Work Postcode	addr	12	120	120	10			3341	2004-03-28 13:55:45.84484	source	A
31	addr_home_email	text	30	\N	~*	Home Email	addr	12	130	130	10			3342	2004-03-28 13:55:45.84484	source	A
31	addr_home_www	text	30	\N	~*	Home WWW	addr	12	140	140	10			3343	2004-03-28 13:55:45.84484	source	A
31	addr_home_im	text	30	\N	~*	Home IM	addr	12	150	150	10			3344	2004-03-28 13:55:45.84484	source	A
31	addr_home_street	text	30	\N	~*	Home Street	addr	12	160	160	10			3345	2004-03-28 13:55:45.84484	source	A
31	addr_home_suburb	text	30	\N	~*	Home Suburb	addr	12	170	170	10			3346	2004-03-28 13:55:45.84484	source	A
31	addr_home_postcode	text	30	\N	~*	Home Postcode	addr	12	180	180	10			3347	2004-03-28 13:55:45.84484	source	A
31	addr_home_phone	text	30	\N	~*	Home Phone	addr	12	190	190	10			3348	2004-03-28 13:55:45.84484	source	A
31	addr_home_fax	text	30	\N	~*	Home Fax	addr	12	200	200	10			3349	2004-03-28 13:55:45.84484	source	A
31	addr_comments	text	30	\N	~*	Comments	addr	12	210	210	10			3350	2004-03-28 13:55:45.84484	source	A
31	svpf_invc_balance	numeric(12,2)	1	\N	=	Invoice Balance	svpf	8	120	120	VIRTUAL=invc_balance(svpf_invc__sequence)	\N	\N	3362	2004-03-28 13:55:51.599622	source	A
31	dbtr_amount_outstanding	numeric	786434	\N	~*	Amount Outstanding	dbtr	786434	150	150	10			3364	2004-03-28 13:55:52.47911	source	A
31	dbtr_first_statement	interval	30	\N	~*	First Statement	dbtr	30	160	160	10			3365	2004-03-28 13:55:52.47911	source	A
31	dbst_first_statement	interval	30	\N	~*	First Statement	dbst	30	130	130	10			3366	2004-03-28 13:55:59.599012	source	A
31	dbst_amount_outstanding	numeric	786434	\N	~*	Amount Outstanding	dbst	786434	170	170	10			3367	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_name	text	30	\N	~*	Patn Name	dbst	30	320	320	10			3368	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_address	text	30	\N	~*	Patn Address	dbst	30	330	330	10			3369	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_suburb	text	30	\N	~*	Patn Suburb	dbst	30	340	340	10			3370	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_state	text	30	\N	~*	Patn State	dbst	30	350	350	10			3371	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_postcode	text	30	\N	~*	Patn Postcode	dbst	30	360	360	10			3372	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_dob	text	30	\N	~*	Patn Dob	dbst	30	370	370	10			3373	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_hlfd_code	text	30	\N	~*	Patn Hlfd Code	dbst	30	380	380	10			3374	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_ins_level	bpchar	1	\N	~*	Patn Ins Level	dbst	1	390	390	10			3375	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_healthnumb	text	30	\N	~*	Patn Healthnumb	dbst	30	400	400	10			3376	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_medicare	text	30	\N	~*	Patn Medicare	dbst	30	410	410	10			3377	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_healthcard	text	30	\N	~*	Patn Healthcard	dbst	30	420	420	10			3378	2004-03-28 13:55:59.599012	source	A
31	dbst_patn_patf_code	text	30	\N	~*	Patn Patf Code	dbst	30	430	430	10			3379	2004-03-28 13:55:59.599012	source	A
31	dbst_patn__sequence	int4	30	\N	~*	Patn  Sequence	dbst	30	440	440	10			3380	2004-03-28 13:55:59.599012	source	A
31	svlt_date_service	date	30	\N	~*	Date Service	svlt	30	10	10	10			3381	2004-03-28 13:56:01.656419	source	A
31	svlt_ts_service	timestamp	30	\N	~*	Ts Service	svlt	30	20	20	10			3382	2004-03-28 13:56:01.656419	source	A
31	svlt_serv_code	text	30	\N	~*	Serv Code	svlt	30	30	30	10			3383	2004-03-28 13:56:01.656419	source	A
31	svlt_percentage	int4	30	\N	~*	Percentage	svlt	30	40	40	10			3384	2004-03-28 13:56:01.656419	source	A
31	svlt_desc	text	30	\N	~*	Desc	svlt	30	50	50	10			3385	2004-03-28 13:56:01.656419	source	A
31	svlt_amount	numeric	786434	\N	~*	Amount	svlt	786434	60	60	10			3386	2004-03-28 13:56:01.656419	source	A
31	svlt_gst_amount	numeric	786434	\N	~*	Gst Amount	svlt	786434	70	70	10			3387	2004-03-28 13:56:01.656419	source	A
31	svlt_total_amount	numeric	30	\N	~*	Total Amount	svlt	30	80	80	10			3388	2004-03-28 13:56:01.656419	source	A
31	svlt_patn__sequence	int4	30	\N	~*	Patn  Sequence	svlt	30	90	90	10			3389	2004-03-28 13:56:01.656419	source	A
31	svlt_invc__sequence	int4	30	\N	~*	Invc  Sequence	svlt	30	100	100	10			3390	2004-03-28 13:56:01.656419	source	A
31	svlt_invc_date_printed	timestamp	30	\N	~*	Invc Date Printed	svlt	30	110	110	10			3391	2004-03-28 13:56:01.656419	source	A
31	svlt_invc_date_reprint	timestamp	30	\N	~*	Invc Date Reprint	svlt	30	120	120	10			3392	2004-03-28 13:56:01.656419	source	A
31	svlt_invc_amount	numeric	786434	\N	~*	Invc Amount	svlt	786434	130	130	10			3393	2004-03-28 13:56:01.656419	source	A
31	svlt_invc_gst_amount	numeric	786434	\N	~*	Invc Gst Amount	svlt	786434	140	140	10			3394	2004-03-28 13:56:01.656419	source	A
31	svlt_invc_credits	numeric	30	\N	~*	Invc Credits	svlt	30	150	150	10			3395	2004-03-28 13:56:01.656419	source	A
31	svlt_cred_summary	text	30	\N	~*	Cred Summary	svlt	30	160	160	10			3396	2004-03-28 13:56:01.656419	source	A
31	svlt_invc_balance	numeric	30	\N	~*	Invc Balance	svlt	30	170	170	10			3397	2004-03-28 13:56:01.656419	source	A
31	svlt_date_printed	date	30	\N	~*	Date Printed	svlt	30	180	180	10			3398	2004-03-28 13:56:01.656419	source	A
31	svlt_date_reprint	date	30	\N	~*	Date Reprint	svlt	30	190	190	10			3399	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_date	date	30	\N	~*	Rfdr Date	svlt	30	200	200	10			3400	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_period	text	30	\N	~*	Rfdr Period	svlt	30	210	210	10			3401	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_name	text	30	\N	~*	Patn Name	svlt	30	220	220	10			3402	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_address	text	30	\N	~*	Patn Address	svlt	30	230	230	10			3403	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_suburb	text	30	\N	~*	Patn Suburb	svlt	30	240	240	10			3404	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_state	text	30	\N	~*	Patn State	svlt	30	250	250	10			3405	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_postcode	text	30	\N	~*	Patn Postcode	svlt	30	260	260	10			3406	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_dob	text	30	\N	~*	Patn Dob	svlt	30	270	270	10			3407	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_hlfd_code	text	30	\N	~*	Patn Hlfd Code	svlt	30	280	280	10			3408	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_ins_level	bpchar	1	\N	~*	Patn Ins Level	svlt	1	290	290	10			3409	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_healthnumb	text	30	\N	~*	Patn Healthnumb	svlt	30	300	300	10			3410	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_medicare	text	30	\N	~*	Patn Medicare	svlt	30	310	310	10			3411	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_healthcard	text	30	\N	~*	Patn Healthcard	svlt	30	320	320	10			3412	2004-03-28 13:56:01.656419	source	A
31	svlt_patn_patf_code	text	30	\N	~*	Patn Patf Code	svlt	30	330	330	10			3413	2004-03-28 13:56:01.656419	source	A
31	svlt_dbtr_full_address	text	30	\N	~*	Dbtr Full Address	svlt	30	340	340	10			3414	2004-03-28 13:56:01.656419	source	A
31	svlt_dbtr_name	text	30	\N	~*	Dbtr Name	svlt	30	350	350	10			3415	2004-03-28 13:56:01.656419	source	A
31	svlt_dbtr_address	text	30	\N	~*	Dbtr Address	svlt	30	360	360	10			3416	2004-03-28 13:56:01.656419	source	A
31	svlt_dbtr_suburb	text	30	\N	~*	Dbtr Suburb	svlt	30	370	370	10			3417	2004-03-28 13:56:01.656419	source	A
31	svlt_dbtr_state	text	30	\N	~*	Dbtr State	svlt	30	380	380	10			3418	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_code	text	30	\N	~*	Rfdr Code	svlt	30	390	390	10			3419	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_name	text	30	\N	~*	Rfdr Name	svlt	30	400	400	10			3420	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_street	text	30	\N	~*	Rfdr Street	svlt	30	410	410	10			3421	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_suburb	text	30	\N	~*	Rfdr Suburb	svlt	30	420	420	10			3422	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_postcode	text	30	\N	~*	Rfdr Postcode	svlt	30	430	430	10			3423	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_state	text	30	\N	~*	Rfdr State	svlt	30	440	440	10			3424	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_provider	text	30	\N	~*	Rfdr Provider	svlt	30	450	450	10			3425	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_phone	text	30	\N	~*	Rfdr Phone	svlt	30	460	460	10			3426	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_salutation	text	30	\N	~*	Rfdr Salutation	svlt	30	470	470	10			3427	2004-03-28 13:56:01.656419	source	A
31	svlt_rfdr_index	text	30	\N	~*	Rfdr Index	svlt	30	480	480	10			3428	2004-03-28 13:56:01.656419	source	A
31	svlt_empl_code	text	30	\N	~*	Empl Code	svlt	30	490	490	10			3429	2004-03-28 13:56:01.656419	source	A
31	svlt_empl_name	text	30	\N	~*	Empl Name	svlt	30	500	500	10			3430	2004-03-28 13:56:01.656419	source	A
31	svlt_empl_address	text	30	\N	~*	Empl Address	svlt	30	510	510	10			3431	2004-03-28 13:56:01.656419	source	A
31	svlt_empl_suburb	text	30	\N	~*	Empl Suburb	svlt	30	520	520	10			3432	2004-03-28 13:56:01.656419	source	A
31	svlt_empl_postcode	text	30	\N	~*	Empl Postcode	svlt	30	530	530	10			3433	2004-03-28 13:56:01.656419	source	A
31	svlt_empl_state	text	30	\N	~*	Empl State	svlt	30	540	540	10			3434	2004-03-28 13:56:01.656419	source	A
31	svlt_feet_code	text	30	\N	~*	Feet Code	svlt	30	550	550	10			3435	2004-03-28 13:56:01.656419	source	A
31	svlt_feet_desc	text	30	\N	~*	Feet Desc	svlt	30	560	560	10			3436	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_code	text	30	\N	~*	Prov Code	svlt	30	570	570	10			3437	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_provider_num	text	30	\N	~*	Prov Provider Num	svlt	30	580	580	10			3438	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_name	text	30	\N	~*	Prov Name	svlt	30	590	590	10			3439	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_address	text	30	\N	~*	Prov Address	svlt	30	600	600	10			3440	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_suburb	text	30	\N	~*	Prov Suburb	svlt	30	610	610	10			3441	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_state	text	30	\N	~*	Prov State	svlt	30	620	620	10			3442	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_postcode	text	30	\N	~*	Prov Postcode	svlt	30	630	630	10			3443	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_salutation	text	30	\N	~*	Prov Salutation	svlt	30	640	640	10			3444	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_phone	text	30	\N	~*	Prov Phone	svlt	30	650	650	10			3445	2004-03-28 13:56:01.656419	source	A
31	svlt_prov_bank_code	text	30	\N	~*	Prov Bank Code	svlt	30	660	660	10			3446	2004-03-28 13:56:01.656419	source	A
31	pate_patn__sequence	int4	30	\N	~*	Patn  Sequence	pate	30	10	10	10			3487	2004-09-19 09:52:54.475249	source	A
2	epsd_admit_date	timestamp	0		=	Admission date	epsd	30	30	30	30			1842	2001-10-19 12:26:12	source	A
2	epsd_sepn_date	timestamp	0		=	Separation date	epsd	30	30	150	30			1853	2001-10-19 12:26:16	source	A
2	diag_date_end	timestamp	0		=	End date	diag	30	30	50	30			1814	2001-10-19 12:25:49	source	A
2	diag_date_start	timestamp	0		=	Start date	diag	30	30	40	30			1815	2001-10-19 12:25:50	source	A
31	crlt_date_credit	date	30	\N	~*	Date Credit	crlt	30	10	10	10			3495	2004-09-21 11:15:25.495252	source	A
31	crlt_paym__sequence	int4	30	\N	~*	Paym  Sequence	crlt	30	20	20	10			3496	2004-09-21 11:15:25.495252	source	A
31	crlt_cred_amount	numeric	786434	\N	~*	Cred Amount	crlt	786434	30	30	10			3497	2004-09-21 11:15:25.495252	source	A
31	crlt_cred_gst_amount	numeric	786434	\N	~*	Cred Gst Amount	crlt	786434	40	40	10			3498	2004-09-21 11:15:25.495252	source	A
31	crlt_total_amount	numeric	30	\N	~*	Total Amount	crlt	30	50	50	10			3499	2004-09-21 11:15:25.495252	source	A
31	crlt_notes	text	30	\N	~*	Notes	crlt	30	60	60	10			3500	2004-09-21 11:15:25.495252	source	A
31	crlt_date_payment	date	30	\N	~*	Date Payment	crlt	30	70	70	10			3501	2004-09-21 11:15:25.495252	source	A
31	crlt_ts_payment	timestamp	30	\N	~*	Ts Payment	crlt	30	80	80	10			3502	2004-09-21 11:15:25.495252	source	A
31	crlt_user_entry	text	30	\N	~*	User Entry	crlt	30	90	90	10			3503	2004-09-21 11:15:25.495252	source	A
31	crlt_site_entry	text	30	\N	~*	Site Entry	crlt	30	100	100	10			3504	2004-09-21 11:15:25.495252	source	A
31	crlt_paym_amount	numeric	786434	\N	~*	Paym Amount	crlt	786434	110	110	10			3505	2004-09-21 11:15:25.495252	source	A
31	crlt_tdtp_code	text	30	\N	~*	Tdtp Code	crlt	30	120	120	10			3506	2004-09-21 11:15:25.495252	source	A
31	crlt_drawer	text	30	\N	~*	Drawer	crlt	30	130	130	10			3507	2004-09-21 11:15:25.495252	source	A
31	crlt_bank	text	30	\N	~*	Bank	crlt	30	140	140	10			3508	2004-09-21 11:15:25.495252	source	A
31	crlt_branch	text	30	\N	~*	Branch	crlt	30	150	150	10			3509	2004-09-21 11:15:25.495252	source	A
31	crlt_bkdp__sequence	int4	30	\N	~*	Bkdp  Sequence	crlt	30	160	160	10			3510	2004-09-21 11:15:25.495252	source	A
31	crlt_invc__sequence	int4	30	\N	~*	Invc  Sequence	crlt	30	170	170	10			3511	2004-09-21 11:15:25.495252	source	A
31	crlt_invc_date_printed	timestamp	30	\N	~*	Invc Date Printed	crlt	30	180	180	10			3512	2004-09-21 11:15:25.495252	source	A
31	crlt_invc_date_reprint	timestamp	30	\N	~*	Invc Date Reprint	crlt	30	190	190	10			3513	2004-09-21 11:15:25.495252	source	A
31	crlt_invc_amount	numeric	786434	\N	~*	Invc Amount	crlt	786434	200	200	10			3514	2004-09-21 11:15:25.495252	source	A
31	crlt_invc_gst_amount	numeric	786434	\N	~*	Invc Gst Amount	crlt	786434	210	210	10			3515	2004-09-21 11:15:25.495252	source	A
31	crlt_invc_credits	numeric	30	\N	~*	Invc Credits	crlt	30	220	220	10			3516	2004-09-21 11:15:25.495252	source	A
31	crlt_cred_summary	text	30	\N	~*	Cred Summary	crlt	30	230	230	10			3517	2004-09-21 11:15:25.495252	source	A
31	crlt_invc_balance	numeric	30	\N	~*	Invc Balance	crlt	30	240	240	10			3518	2004-09-21 11:15:25.495252	source	A
31	crlt_date_printed	date	30	\N	~*	Date Printed	crlt	30	250	250	10			3519	2004-09-21 11:15:25.495252	source	A
31	crlt_date_reprint	date	30	\N	~*	Date Reprint	crlt	30	260	260	10			3520	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_date	date	30	\N	~*	Rfdr Date	crlt	30	270	270	10			3521	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_period	text	30	\N	~*	Rfdr Period	crlt	30	280	280	10			3522	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_name	text	30	\N	~*	Patn Name	crlt	30	290	290	10			3523	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_address	text	30	\N	~*	Patn Address	crlt	30	300	300	10			3524	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_suburb	text	30	\N	~*	Patn Suburb	crlt	30	310	310	10			3525	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_state	text	30	\N	~*	Patn State	crlt	30	320	320	10			3526	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_postcode	text	30	\N	~*	Patn Postcode	crlt	30	330	330	10			3527	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_dob	text	30	\N	~*	Patn Dob	crlt	30	340	340	10			3528	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_hlfd_code	text	30	\N	~*	Patn Hlfd Code	crlt	30	350	350	10			3529	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_ins_level	bpchar	1	\N	~*	Patn Ins Level	crlt	1	360	360	10			3530	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_healthnumb	text	30	\N	~*	Patn Healthnumb	crlt	30	370	370	10			3531	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_medicare	text	30	\N	~*	Patn Medicare	crlt	30	380	380	10			3532	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_healthcard	text	30	\N	~*	Patn Healthcard	crlt	30	390	390	10			3533	2004-09-21 11:15:25.495252	source	A
31	crlt_patn_patf_code	text	30	\N	~*	Patn Patf Code	crlt	30	400	400	10			3534	2004-09-21 11:15:25.495252	source	A
31	crlt_dbtr_full_address	text	30	\N	~*	Dbtr Full Address	crlt	30	410	410	10			3535	2004-09-21 11:15:25.495252	source	A
31	crlt_dbtr_name	text	30	\N	~*	Dbtr Name	crlt	30	420	420	10			3536	2004-09-21 11:15:25.495252	source	A
31	crlt_dbtr_address	text	30	\N	~*	Dbtr Address	crlt	30	430	430	10			3537	2004-09-21 11:15:25.495252	source	A
31	crlt_dbtr_suburb	text	30	\N	~*	Dbtr Suburb	crlt	30	440	440	10			3538	2004-09-21 11:15:25.495252	source	A
31	crlt_dbtr_state	text	30	\N	~*	Dbtr State	crlt	30	450	450	10			3539	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_code	text	30	\N	~*	Rfdr Code	crlt	30	460	460	10			3540	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_name	text	30	\N	~*	Rfdr Name	crlt	30	470	470	10			3541	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_street	text	30	\N	~*	Rfdr Street	crlt	30	480	480	10			3542	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_suburb	text	30	\N	~*	Rfdr Suburb	crlt	30	490	490	10			3543	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_postcode	text	30	\N	~*	Rfdr Postcode	crlt	30	500	500	10			3544	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_state	text	30	\N	~*	Rfdr State	crlt	30	510	510	10			3545	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_provider	text	30	\N	~*	Rfdr Provider	crlt	30	520	520	10			3546	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_phone	text	30	\N	~*	Rfdr Phone	crlt	30	530	530	10			3547	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_salutation	text	30	\N	~*	Rfdr Salutation	crlt	30	540	540	10			3548	2004-09-21 11:15:25.495252	source	A
31	crlt_rfdr_index	text	30	\N	~*	Rfdr Index	crlt	30	550	550	10			3549	2004-09-21 11:15:25.495252	source	A
31	crlt_empl_code	text	30	\N	~*	Empl Code	crlt	30	560	560	10			3550	2004-09-21 11:15:25.495252	source	A
31	crlt_empl_name	text	30	\N	~*	Empl Name	crlt	30	570	570	10			3551	2004-09-21 11:15:25.495252	source	A
31	crlt_empl_address	text	30	\N	~*	Empl Address	crlt	30	580	580	10			3552	2004-09-21 11:15:25.495252	source	A
31	crlt_empl_suburb	text	30	\N	~*	Empl Suburb	crlt	30	590	590	10			3553	2004-09-21 11:15:25.495252	source	A
31	crlt_empl_postcode	text	30	\N	~*	Empl Postcode	crlt	30	600	600	10			3554	2004-09-21 11:15:25.495252	source	A
31	crlt_empl_state	text	30	\N	~*	Empl State	crlt	30	610	610	10			3555	2004-09-21 11:15:25.495252	source	A
31	crlt_feet_code	text	30	\N	~*	Feet Code	crlt	30	620	620	10			3556	2004-09-21 11:15:25.495252	source	A
31	crlt_feet_desc	text	30	\N	~*	Feet Desc	crlt	30	630	630	10			3557	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_code	text	30	\N	~*	Prov Code	crlt	30	640	640	10			3558	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_provider_num	text	30	\N	~*	Prov Provider Num	crlt	30	650	650	10			3559	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_name	text	30	\N	~*	Prov Name	crlt	30	660	660	10			3560	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_address	text	30	\N	~*	Prov Address	crlt	30	670	670	10			3561	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_suburb	text	30	\N	~*	Prov Suburb	crlt	30	680	680	10			3562	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_state	text	30	\N	~*	Prov State	crlt	30	690	690	10			3563	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_postcode	text	30	\N	~*	Prov Postcode	crlt	30	700	700	10			3564	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_salutation	text	30	\N	~*	Prov Salutation	crlt	30	710	710	10			3565	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_phone	text	30	\N	~*	Prov Phone	crlt	30	720	720	10			3566	2004-09-21 11:15:25.495252	source	A
31	crlt_prov_bank_code	text	30	\N	~*	Prov Bank Code	crlt	30	730	730	10			3567	2004-09-21 11:15:25.495252	source	A
31	sclt_date	date	30	\N	~*	Date	sclt	30	10	10	10			3572	2004-09-21 11:16:10.027454	source	A
31	sclt_patn_name	text	30	\N	~*	Patn Name	sclt	30	20	20	10			3573	2004-09-21 11:16:10.027454	source	A
31	sclt_dc	text	30	\N	~*	Dc	sclt	30	30	30	10			3574	2004-09-21 11:16:10.027454	source	A
31	sclt_prov_code	text	30	\N	~*	Prov Code	sclt	30	40	40	10			3575	2004-09-21 11:16:10.027454	source	A
31	sclt_prov_name	text	30	\N	~*	Prov Name	sclt	30	50	50	10			3576	2004-09-21 11:16:10.027454	source	A
31	sclt_type	text	30	\N	~*	Type	sclt	30	60	60	10			3577	2004-09-21 11:16:10.027454	source	A
31	sclt_desc	text	30	\N	~*	Desc	sclt	30	70	70	10			3578	2004-09-21 11:16:10.027454	source	A
31	sclt_invc__sequence	int4	30	\N	~*	Invc  Sequence	sclt	30	80	80	10			3579	2004-09-21 11:16:10.027454	source	A
31	sclt_debit	numeric	786434	\N	~*	Debit	sclt	786434	90	90	10			3580	2004-09-21 11:16:10.027454	source	A
31	sclt_gst_debit	numeric	786434	\N	~*	Gst Debit	sclt	786434	100	100	10			3581	2004-09-21 11:16:10.027454	source	A
31	sclt_credit	numeric	786434	\N	~*	Credit	sclt	786434	110	110	10			3582	2004-09-21 11:16:10.027454	source	A
31	sclt_gst_credit	numeric	786434	\N	~*	Gst Credit	sclt	786434	120	120	10			3583	2004-09-21 11:16:10.027454	source	A
31	sclt_total_amount	numeric	786434	\N	~*	Total Amount	sclt	786434	130	130	10			3584	2004-09-21 11:16:10.027454	source	A
31	pemd_export	text	30	\N	~*	Export	pemd	30	10	10	RO			3589	2004-09-21 12:42:31.891074	source	A
2	patn_aboriginality	char	0		~*	Aboriginality	patn	1	0	0	SYSTEM			2712	2002-02-09 08:01:49	source	A
2	patn_accl_code	text	0		~*	Account type	patn	3	0	0	SYSTEM			2713	2002-02-09 08:01:49	source	A
2	patn_accommodation	char	0		~*	Accommodation type	patn	1	0	0	SYSTEM			2714	2002-02-09 08:01:50	source	A
2	patn_care	char	0		~*	Care type	patn	1	0	0	SYSTEM			2716	2002-02-09 08:01:50	source	A
2	patn_country	text	0		~*	Country of birth	patn	4	0	0	SYSTEM			2717	2002-02-09 08:01:50	source	A
2	patn_marital	char	0		~*	Marital Status	patn	1	0	0	SYSTEM			2728	2002-02-09 08:01:53	source	A
2	patn_sex	char	0		~*	Gender	patn	1	0	0	SYSTEM			2738	2002-02-09 08:01:56	source	A
2	patn_psnam	text	0		~*	Surname	patn	15	11	30	20			2734	2002-02-09 08:01:55	source	A
2	patn_fsnam	text	0		~*	Firstname	patn	10	12	40	20			2723	2002-02-09 08:01:52	source	A
2	patn_feet_code	text	0		~*	Fee level	patn	5	10	45	40	-		2721	2002-02-09 08:01:52	source	A
31	patn_patf_code	text	30		~*	Flag	patn	5	300	47	10			2730	2002-02-09 08:01:54	source	A
2	patn_title	text	0		~*	Title	patn	6	10	50	20			2741	2002-02-09 08:01:57	source	A
2	patn_dob	timestamp	0		=	Date of birth	patn	10	10	60	40			2719	2002-02-09 08:01:51	source	A
2	patn_address	text	0		~*	Street	patn	15	10	70	40			2715	2002-02-09 08:01:50	source	A
2	patn_state	text	0		~*	State	patn	3	10	90	10	Victoria		2739	2002-02-09 08:01:57	source	A
2	patn_phone	text	0		~*	Phone	patn	15	10	110	40			2731	2002-02-09 08:01:54	source	A
2	patn_flno	text	0		~*	File number	patn	10	10	150	40			2722	2002-02-09 08:01:52	source	A
2	patn_medicare	text	0		~*	Medicare Number	patn	15	10	160	40			2729	2002-02-09 08:01:54	source	A
2	patn_healthcard	text	0		~*	HealthCard/Ref/VX	patn	15	10	170	20			2724	2002-02-09 08:01:52	source	A
2	patn_hlfd_code	text	0		~*	Health Fund	patn	10	172	172	40			2726	2002-02-09 08:01:53	source	A
2	patn_ins_level	char	0		~*	Fund Level	patn	3	173	173	40			2727	2002-02-09 08:01:53	source	A
2	patn_healthnumb	text	0		~*	Membership Number	patn	15	174	174	40			2725	2002-02-09 08:01:53	source	A
2	patn_dbtr_code	text	0		~*	Usual Debtor (code)	patn	12	10	180	40			2718	2002-02-09 08:01:51	source	A
2	patn_rfdr_code	text	0		~*	Usual Referrer (code)	patn	12	10	200	40			2737	2002-02-09 08:01:56	source	A
2	patn_ref_date	timestamp	0		=	Referral date	patn	10	10	210	40	today		2735	2002-02-09 08:01:55	source	A
2	patn_ref_period	integer	0		=	Referral period	patn	5	10	220	40	12		2736	2002-02-09 08:01:56	source	A
2	patn_prov_code	text	0		~*	Usual   provider (code)	patn	5	10	230	40	-		2733	2002-02-09 08:01:55	source	A
2	patn_empl_code	text	0		~*	Usual Employer (code)	patn	12	10	240	40	-		2720	2002-02-09 08:01:51	source	A
2	svpf_mdaf__sequence	integer	0		=	Medicare form number	svpf	12	0	0	SYSTEM			2115	2001-10-19 12:30:23	source	A
2	svpf_date_service	timestamp	0		=	Date of service	svpf	10	10	10	10	now		2111	2001-10-19 12:30:22	source	A
2	svpf_serv_code	text	0		~*	Service code	svpf	8	10	40			onchange="svpf_js_check()"	2118	2001-10-19 12:30:24	source	A
2	svpf_percentage	float	0		~*	%	svpf	3	0	50		100	onblur="chk_svpf_amounts()"	2117	2001-10-19 12:30:24	source	A
2	svpf_desc	text	0		~*	Description	svpf	30	10	60	TEXTAREA=3	~serv_desc(serv_code)	WRAP=VIRTUAL	2112	2001-10-19 12:30:22	source	A
2	svpf_amount	numeric(12,2)	0		=	Amount	svpf	8	10	70	30	~feeb_amount(feeb_serv_code,feeb_feet_code)	onblur="chk_svpf_amounts()"	2110	2001-10-19 12:30:21	source	A
2	svpf_gst_amount	numeric(12,2)	0		=	GST	svpf	8	10	80	RO		onblur="chk_svpf_amounts()"	2113	2001-10-19 12:30:22	source	A
2	svpf_invc__sequence	integer	0		=	Invoice-#	svpf	12	10	100	RO			2114	2001-10-19 12:30:23	source	A
2	svpf_patn__sequence	integer	0		=	Patient ID	svpf	12	0	150	RO	=patn__sequence		2116	2001-10-19 12:30:24	source	A
2	invc_amount	numeric(12,2)	0		=	Amount	invc	10	50	5	RO			1917	2001-10-19 12:27:49	source	A
2	invc_gst_amount	numeric(12,2)	0		=	GST Amount	invc	8	60	6	RO	0.00		1925	2001-10-19 12:27:52	source	A
2	invc_paid_amount	numeric(12,2)	0		=	Amount Paid	invc	10	55	7	RO			1926	2001-10-19 12:27:53	source	A
2	invc_paid_gst_amount	numeric(12,2)	0		=	GST Paid	invc	8	65	8	RO			1927	2001-10-19 12:27:53	source	A
2	invc_dbtr_code	text	0		~*	Debtor ID code	invc	12	10	10	10			1922	2001-10-19 12:27:51	source	A
2	invc_bank_code	text	1		~*	Bank Account	invc	4	12	12	RO	-		1918	2001-10-19 12:27:49	source	A
2	invc_prov_code	text	1		~*	Provider	invc	8	14	14	RO	-		1929	2001-10-19 12:27:54	source	A
2	invc_patn__sequence	integer	1		=	Patient	invc	8	16	16	RO			1928	2001-10-19 12:27:54	source	A
2	invc_empl_code	text	1		~*	Employer	invc	8	20	20	10	-		1923	2001-10-19 12:27:52	source	A
2	invc_feet_code	text	1		~*	Fee type	invc	8	22	22	10	-		1924	2001-10-19 12:27:52	source	A
2	invc_rfdr_code	text	1		~*	Referrer	invc	8	24	24	10	-		1930	2001-10-19 12:27:55	source	A
2	invc_rfdr_date	timestamp	1		=	Referral Date	invc	10	26	26	10			1931	2001-10-19 12:27:55	source	A
2	invc_rfdr_period	text	1		~*	Referral Period	invc	4	28	28	10			1932	2001-10-19 12:27:55	source	A
2	invc_date_created	timestamp	0		=	Date created	invc	10	40	40	RO			1919	2001-10-19 12:27:50	source	A
2	invc_date_printed	timestamp	0		=	Date printed	invc	10	42	42	10			1920	2001-10-19 12:27:50	source	A
2	invc_date_reprint	timestamp	0		=	Date re-printed	invc	10	44	44	10			1921	2001-10-19 12:27:51	source	A
31	crev_invc__sequence	int4	10		~*	Invoice Number	crev	10	10	122	RO			2222	2001-10-19 12:31:55	source	A
31	crev_site_entry	text	30		~*	Site Entered	crev	10	10	124	10			2225	2001-10-19 12:31:57	source	A
31	crev_paym__sequence	int4	30	\N	~*	Payment ID	crev	10	90	126	10			3493	2004-09-21 11:15:21.032187	source	A
2	rfdr_code	text	0		~*	Code	rfdr	10	10	10	10			2079	2001-10-19 12:29:55	source	A
2	rfdr_state	text	0		~*	State	rfdr	10	60	60	10			2086	2001-10-19 12:29:57	source	A
2	rfdr_provider	text	0		~*	Provider number	rfdr	10	70	70	10			2084	2001-10-19 12:29:57	source	A
2	rfdr_salutation	text	0		~*	Salutation	rfdr	10	80	80	10			2085	2001-10-19 12:29:57	source	A
2	rfdr_index	text	0		~*	Sort order	rfdr	5	90	90	10			2080	2001-10-19 12:29:55	source	A
2	paym_user_entry	text	0		~*	Received by	paym	10	10	20	RO			2044	2001-10-19 12:29:24	source	A
2	paym_tdtp_code	text	0		~*	Tender type	paym	10	10	50	FSL=100		onchange="paym_js_check()"	2043	2001-10-19 12:29:24	source	A
2	paym_bank	text	0		~*	Bank	paym	10	10	70	10	=tdtp_entity		2037	2001-10-19 12:29:21	source	A
2	paym_bkdp__sequence	integer	0		=	Deposit-batch code	paym	10	10	90	RO			2038	2001-10-19 12:29:22	source	A
2	paym_amount	numeric(12,2)	0		=	Amount	paym	10	10	40	10			2036	2001-10-19 12:29:21	source	A
2	paym_date_entry	timestamp	0		=	Date received	paym	10	10	10		now		2040	2001-10-19 12:29:23	source	A
2	paym_site_entry	text	0		~*	Reception site	paym	5	0	95	RO			2042	2001-10-19 12:29:23	source	A
2	bkdp_date_printed	date	0		=	Date Printed	bkdp	10	20	20	RO			1735	2001-10-19 12:24:45	source	A
31	form_classname	text	1		=	Base Class	form	5	22	22	10			177	2001-10-10 12:25:33	source	A
31	form_dt_height	int4	10		~*	Detail Height	form	5	170	170	10			180	2001-10-10 12:25:34	source	A
31	form_mg_bottom	int4	10		~*	Bottom Margin	form	5	60	60	10			182	2001-10-10 12:25:35	source	A
31	form_mg_left	int4	10		~*	Left Margin	form	5	70	70	10			183	2001-10-10 12:25:35	source	A
31	form_mg_right	int4	10		~*	Right Maring	form	5	80	80	10			184	2001-10-10 12:25:35	source	A
31	form_mg_top	int4	10		~*	Top Margin	form	5	50	50	10			185	2001-10-10 12:25:36	source	A
31	form_orientation	int4	10		~*	Orientation	form	5	40	40	10			186	2001-10-10 12:25:36	source	A
31	form_pagesize	int4	10		~*	Pagesize	form	5	30	30	10			188	2001-10-10 12:25:37	source	A
31	form_pf_frequency	int4	10		~*	Page Footer Frequency	form	5	160	160	10			189	2001-10-10 12:25:37	source	A
31	form_pf_height	int4	10		~*	Page Footer Height	form	5	150	150	10			190	2001-10-10 12:25:38	source	A
31	form_ph_frequency	int4	10		~*	Page Header Frequency	form	5	140	140	10			191	2001-10-10 12:25:38	source	A
31	form_ph_height	int4	10		~*	Page Header Height	form	5	130	130	10			192	2001-10-10 12:25:38	source	A
31	form_rf_frequency	int4	10		~*	Report Footer Frequency	form	5	120	120	10			193	2001-10-10 12:25:39	source	A
31	form_rf_height	int4	10		~*	Report Footer Height	form	5	110	110	10			194	2001-10-10 12:25:39	source	A
31	form_rh_frequency	int4	10		~*	Report Header Frequency	form	5	100	100	10			195	2001-10-10 12:25:40	source	A
31	form_rh_height	int4	10		~*	Report Header Height	form	5	90	90	10			196	2001-10-10 12:25:40	source	A
31	form_code	text	30		~*	Code	form	10	10	10	10			178	2001-10-10 12:25:33	source	A
31	form_desc	text	30		~*	Description	form	10	20	20	10			179	2001-10-10 12:25:33	source	A
31	form_page_attribute	text	1		=	Page by	form	10	24	24	10			187	2001-10-10 12:25:36	source	A
31	form_includes	text	30		~*	Include	form	10	26	26	10			181	2001-10-10 12:25:34	source	A
31	fmdt_text	text	30		~*	Text	fmdt	15	50	50	10			222	2001-10-10 12:25:53	source	A
31	fmdt_form_code	text	30		~*	Form Code	fmdt	10	10	10	10			212	2001-10-10 12:25:50	source	A
31	fmdt_desc	text	30		~*	Desc	fmdt	10	20	20	10			209	2001-10-10 12:25:48	source	A
31	fmdt_ft_family	text	30		~*	Ft Family	fmdt	10	150	150	10			213	2001-10-10 12:25:50	source	A
31	fmdt_field_type	int4	10		~*	Field Type	fmdt	5	30	30	10			211	2001-10-10 12:25:49	source	A
31	fmdt_section	int4	10		~*	Section	fmdt	5	40	40	10			221	2001-10-10 12:25:53	source	A
31	fmdt_x_coord	int4	10		~*	X Coord	fmdt	5	60	60	10			226	2001-10-10 12:25:55	source	A
31	fmdt_y_coord	int4	10		~*	Y Coord	fmdt	5	70	70	10			227	2001-10-10 12:25:55	source	A
31	fmdt_width	int4	10		~*	Width	fmdt	5	80	80	10			224	2001-10-10 12:25:54	source	A
31	fmdt_height	int4	10		~*	Height	fmdt	5	90	90	10			217	2001-10-10 12:25:51	source	A
31	fmdt_ft_italic	int4	10		~*	Ft Italic	fmdt	5	180	180	10			214	2001-10-10 12:25:50	source	A
31	fmdt_date_format	int4	10		~*	Date Format	fmdt	5	230	230	10			208	2001-10-10 12:25:48	source	A
31	fmdt_precision	int4	10		~*	Precision	fmdt	5	240	240	10			220	2001-10-10 12:25:53	source	A
31	fmdt_data_type	int4	10		~*	Data Type	fmdt	5	220	220	10			207	2001-10-10 12:25:48	source	A
31	fmdt_currency	int4	10		~*	Currency	fmdt	5	250	250	10			206	2001-10-10 12:25:47	source	A
31	fmdt_comma_sep	int4	10		~*	Comma Sep	fmdt	5	270	270	10			205	2001-10-10 12:25:47	source	A
31	fmdt_word_wrap	int4	10		~*	Word Wrap	fmdt	5	210	210	10			225	2001-10-10 12:25:55	source	A
31	fmdt_bd_width	int4	10		~*	Bd Width	fmdt	5	130	130	10			203	2001-10-10 12:25:46	source	A
31	fmdt_bd_style	int4	10		~*	Bd Style	fmdt	5	140	140	10			202	2001-10-10 12:25:46	source	A
31	fmdt_bd_colour	text	30		~*	Bd Colour	fmdt	10	120	120	COLOUR			201	2001-10-10 12:25:45	source	A
31	fmdt_bg_colour	text	30		~*	Bg Colour	fmdt	10	100	100	COLOUR			204	2001-10-10 12:25:46	source	A
31	fmdt_fg_colour	text	30		~*	Fg Colour	fmdt	10	110	110	COLOUR			210	2001-10-10 12:25:49	source	A
31	fmdt_neg_colour	text	30		~*	Neg Colour	fmdt	10	260	260	COLOUR			219	2001-10-10 12:25:52	source	A
31	fmdt_ft_size	int4	10		~*	Ft Size	fmdt	5	160	91	10			215	2001-10-10 12:25:51	source	A
31	fmdt_ft_weight	int4	10		~*	Ft Weight	fmdt	5	170	92	10			216	2001-10-10 12:25:51	source	A
31	fmdt_hz_align	int4	10		~*	Hz Align	fmdt	5	190	93	10			218	2001-10-10 12:25:52	source	A
31	fmdt_vt_align	int4	10		~*	Vt Align	fmdt	5	200	94	10			223	2001-10-10 12:25:54	source	A
31	tdtp_code	text	1		~*	Code	tdtp	5	5	5	10			2123	2001-10-19 12:30:33	source	A
2	tdtp_entity	text	1		~*	Entity	tdtp	5	30	30	10			2125	2001-10-19 12:30:34	source	A
2	tdtp_location	text	1		~*	Location	tdtp	5	40	40	10			2127	2001-10-19 12:30:34	source	A
31	svsm_date_start	timestamp	30	\N	~*	Date Start	svsm	30	10	10	10			3594	2004-09-21 13:08:45.650712	source	A
31	svsm_date_end	timestamp	30	\N	~*	Date End	svsm	30	20	20	10			3595	2004-09-21 13:08:45.650712	source	A
31	svsm_type	text	30	\N	~*	Type	svsm	30	30	30	10			3596	2004-09-21 13:08:45.650712	source	A
31	svsm_prov_code	text	30	\N	~*	Prov Code	svsm	30	40	40	10			3597	2004-09-21 13:08:45.650712	source	A
31	svsm_prov_name	text	30	\N	~*	Prov Name	svsm	30	50	50	10			3598	2004-09-21 13:08:45.650712	source	A
31	svsm_count	int4	30	\N	~*	Count	svsm	30	60	60	10			3599	2004-09-21 13:08:45.650712	source	A
31	svsm_serv_code	text	30	\N	~*	Serv Code	svsm	30	70	70	10			3600	2004-09-21 13:08:45.650712	source	A
31	svsm_desc	text	30	\N	~*	Desc	svsm	30	80	80	10			3601	2004-09-21 13:08:45.650712	source	A
31	svsm_amount	numeric	786434	\N	~*	Amount	svsm	786434	90	90	10			3602	2004-09-21 13:08:45.650712	source	A
31	svsm_gst_amount	numeric	786434	\N	~*	Gst Amount	svsm	786434	100	100	10			3603	2004-09-21 13:08:45.650712	source	A
31	crsm_date_start	timestamp	30	\N	~*	Date Start	crsm	30	10	10	10			3608	2004-09-21 13:34:37.289103	source	A
31	crsm_date_end	timestamp	30	\N	~*	Date End	crsm	30	20	20	10			3609	2004-09-21 13:34:37.289103	source	A
31	crsm_type	text	30	\N	~*	Type	crsm	30	30	30	10			3610	2004-09-21 13:34:37.289103	source	A
31	crsm_prov_code	text	30	\N	~*	Prov Code	crsm	30	40	40	10			3611	2004-09-21 13:34:37.289103	source	A
31	crsm_prov_name	text	30	\N	~*	Prov Name	crsm	30	50	50	10			3612	2004-09-21 13:34:37.289103	source	A
31	crsm_count	int4	30	\N	~*	Count	crsm	30	60	60	10			3613	2004-09-21 13:34:37.289103	source	A
31	crsm_tdtp_code	text	30	\N	~*	Tdtp Code	crsm	30	70	70	10			3614	2004-09-21 13:34:37.289103	source	A
31	crsm_desc	text	30	\N	~*	Desc	crsm	30	80	80	10			3615	2004-09-21 13:34:37.289103	source	A
31	crsm_amount	numeric	786434	\N	~*	Amount	crsm	786434	90	90	10			3616	2004-09-21 13:34:37.289103	source	A
31	crsm_gst_amount	numeric	786434	\N	~*	Gst Amount	crsm	786434	100	100	10			3617	2004-09-21 13:34:37.289103	source	A
31	feel_db_desc	text	30	\N	~*	Db Desc	feel	12	10	10	10			3635	2005-01-13 11:08:20.560366	source	A
31	feel_serv_code	text	30	\N	~*	Serv Code	feel	12	20	20	10			3636	2005-01-13 11:08:20.560366	source	A
31	feel_serv_desc	text	30	\N	~*	Serv Desc	feel	12	30	30	10			3637	2005-01-13 11:08:20.560366	source	A
31	feel_fee0_code	text	30	\N	~*	Fee0 Code	feel	12	40	40	10			3638	2005-01-13 11:08:20.560366	source	A
31	feel_fee0_amount	numeric	30	\N	~*	Fee0 Amount	feel	12	50	50	10			3639	2005-01-13 11:08:20.560366	source	A
31	feel_fee1_code	text	30	\N	~*	Fee1 Code	feel	12	60	60	10			3640	2005-01-13 11:08:20.560366	source	A
31	feel_fee1_amount	numeric	30	\N	~*	Fee1 Amount	feel	12	70	70	10			3641	2005-01-13 11:08:20.560366	source	A
31	feel_fee2_code	text	30	\N	~*	Fee2 Code	feel	12	80	80	10			3642	2005-01-13 11:08:20.560366	source	A
31	feel_fee2_amount	numeric	30	\N	~*	Fee2 Amount	feel	12	90	90	10			3643	2005-01-13 11:08:20.560366	source	A
31	feel_fee3_code	text	30	\N	~*	Fee3 Code	feel	12	100	100	10			3644	2005-01-13 11:08:20.560366	source	A
31	feel_fee3_amount	numeric	30	\N	~*	Fee3 Amount	feel	12	110	110	10			3645	2005-01-13 11:08:20.560366	source	A
31	feel_fee4_code	text	30	\N	~*	Fee4 Code	feel	12	120	120	10			3646	2005-01-13 11:08:20.560366	source	A
31	feel_fee4_amount	numeric	30	\N	~*	Fee4 Amount	feel	12	130	130	10			3647	2005-01-13 11:08:20.560366	source	A
31	feel_fee5_code	text	30	\N	~*	Fee5 Code	feel	12	140	140	10			3648	2005-01-13 11:08:20.560366	source	A
31	feel_fee5_amount	numeric	30	\N	~*	Fee5 Amount	feel	12	150	150	10			3649	2005-01-13 11:08:20.560366	source	A
31	feel_fee6_code	text	30	\N	~*	Fee6 Code	feel	12	160	160	10			3650	2005-01-13 11:08:20.560366	source	A
31	feel_fee6_amount	numeric	30	\N	~*	Fee6 Amount	feel	12	170	170	10			3651	2005-01-13 11:08:20.560366	source	A
31	feel_fee7_code	text	30	\N	~*	Fee7 Code	feel	12	180	180	10			3652	2005-01-13 11:08:20.560366	source	A
31	feel_fee7_amount	numeric	30	\N	~*	Fee7 Amount	feel	12	190	190	10			3653	2005-01-13 11:08:20.560366	source	A
31	feel_fee8_code	text	30	\N	~*	Fee8 Code	feel	12	200	200	10			3654	2005-01-13 11:08:20.560366	source	A
31	feel_fee8_amount	numeric	30	\N	~*	Fee8 Amount	feel	12	210	210	10			3655	2005-01-13 11:08:20.560366	source	A
31	gsti_invc__sequence	int4	30	\N	~*	Invc  Sequence	gsti	30	10	10	10			3660	2005-01-13 11:08:20.741506	source	A
31	gsti_day_date	text	30	\N	~*	Day Date	gsti	30	20	20	10			3661	2005-01-13 11:08:20.741506	source	A
31	gsti_quarter_date	text	30	\N	~*	Quarter Date	gsti	30	30	30	10			3662	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_dbtr_code	text	30	\N	~*	Invc Dbtr Code	gsti	30	40	40	10			3663	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_bank_code	text	30	\N	~*	Invc Bank Code	gsti	30	50	50	10			3664	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_prov_code	text	30	\N	~*	Invc Prov Code	gsti	30	60	60	10			3665	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_patn__sequence	int4	30	\N	~*	Invc Patn  Sequence	gsti	30	70	70	10			3666	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_empl_code	text	30	\N	~*	Invc Empl Code	gsti	30	80	80	10			3667	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_feet_code	text	30	\N	~*	Invc Feet Code	gsti	30	90	90	10			3668	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_rfdr_code	text	30	\N	~*	Invc Rfdr Code	gsti	30	100	100	10			3669	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_rfdr_date	timestamp	30	\N	~*	Invc Rfdr Date	gsti	30	110	110	10			3670	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_rfdr_period	text	30	\N	~*	Invc Rfdr Period	gsti	30	120	120	10			3671	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_date_created	timestamp	30	\N	~*	Invc Date Created	gsti	30	130	130	10			3672	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_date_printed	timestamp	30	\N	~*	Invc Date Printed	gsti	30	140	140	10			3673	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_date_reprint	timestamp	30	\N	~*	Invc Date Reprint	gsti	30	150	150	10			3674	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_amount	numeric	786434	\N	~*	Invc Amount	gsti	786434	160	160	10			3675	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_paid_amount	numeric	786434	\N	~*	Invc Paid Amount	gsti	786434	170	170	10			3676	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_gst_amount	numeric	786434	\N	~*	Invc Gst Amount	gsti	786434	180	180	10			3677	2005-01-13 11:08:20.741506	source	A
31	gsti_invc_paid_gst_amount	numeric	786434	\N	~*	Invc Paid Gst Amount	gsti	786434	190	190	10			3678	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_flno	text	30	\N	~*	Patn Flno	gsti	30	200	200	10			3679	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_psnam	text	30	\N	~*	Patn Psnam	gsti	30	210	210	10			3680	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_fsnam	text	30	\N	~*	Patn Fsnam	gsti	30	220	220	10			3681	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_title	text	30	\N	~*	Patn Title	gsti	30	230	230	10			3682	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_dob	text	30	\N	~*	Patn Dob	gsti	30	240	240	10			3683	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_address	text	30	\N	~*	Patn Address	gsti	30	250	250	10			3684	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_suburb	text	30	\N	~*	Patn Suburb	gsti	30	260	260	10			3685	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_state	text	30	\N	~*	Patn State	gsti	30	270	270	10			3686	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_postcode	text	30	\N	~*	Patn Postcode	gsti	30	280	280	10			3687	2005-01-13 11:08:20.741506	source	A
31	gsti_patn_phone	text	30	\N	~*	Patn Phone	gsti	30	290	290	10			3688	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_code	text	30	\N	~*	Dbtr Code	gsti	30	300	300	10			3689	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_name	text	30	\N	~*	Dbtr Name	gsti	30	310	310	10			3690	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_address	text	30	\N	~*	Dbtr Address	gsti	30	320	320	10			3691	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_suburb	text	30	\N	~*	Dbtr Suburb	gsti	30	330	330	10			3692	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_postcode	text	30	\N	~*	Dbtr Postcode	gsti	30	340	340	10			3693	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_state	text	30	\N	~*	Dbtr State	gsti	30	350	350	10			3694	2005-01-13 11:08:20.741506	source	A
31	gsti_dbtr_phone	text	30	\N	~*	Dbtr Phone	gsti	30	360	360	10			3695	2005-01-13 11:08:20.741506	source	A
31	mtsv_type	text	30	\N	~*	Type	mtsv	30	60	60	10			3731	2005-01-16 12:38:46.331033	source	A
31	evwl_prov_code	text	30	\N	~*	Prov	evwl	5	5	10				3633	2005-01-13 11:08:20.119089	source	A
31	evwl_aptp_code	text	30	\N	~*	Type	evwl	5	10	10				3467	2004-08-04 09:26:24.604655	source	A
31	evwl_apst_code	text	30	\N	~*	Status	evwl	5	20	20				3468	2004-08-04 09:26:24.604655	source	A
31	evwl_patf_code	text	30	\N	~*	Flag	evwl	10	20	20	SYSTEM			3634	2005-01-13 11:08:20.119089	source	A
31	evwl_desc	text	30	\N	~*	Notes	evwl	30	30	30				3469	2004-08-04 09:26:24.604655	source	A
31	evwl_ev_time	text	30	\N	~*	Time	evwl	5	40	40				3470	2004-08-04 09:26:24.604655	source	A
31	evwl_ev_date	text	30	\N	~*	Date	evwl	12	50	50				3471	2004-08-04 09:26:24.604655	source	A
31	evwl_ev_minutes	float8	30	\N	~*	Duration	evwl	5	60	60				3472	2004-08-04 09:26:24.604655	source	A
31	evwl_patn_flno	text	30	\N	~*	UR	evwl	12	70	70	SYSTEM			3473	2004-08-04 09:26:24.604655	source	A
31	evwl_patn__sequence	int4	30	\N	~*	ID	evwl	12	80	80	RO			3484	2004-08-26 14:04:30.014136	source	A
31	evwl_patn_desc	text	30	\N	~*	Name	evwl	20	90	90	RO			3474	2004-08-04 09:26:24.604655	source	A
31	evwl_patn_dob	text	30	\N	~*	DOB	evwl	12	110	110	RO			3475	2004-08-04 09:26:24.604655	source	A
31	evwl_patn_last_visit	timestamp	30	\N	~*	Last Visit	evwl	12	120	120	SYSTEM			3476	2004-08-04 09:26:24.604655	source	A
31	evwl_patn_amount_outstanding	numeric	786434	\N	~*	Owing	evwl	10	130	130	SYSTEM			3477	2004-08-04 09:26:24.604655	source	A
31	evwl_rfdr_name	text	30	\N	~*	Referrer	evwl	5	140	140	SYSTEM			3478	2004-08-04 09:26:24.604655	source	A
31	evwl_starttime	timestamp	30	\N	~*	Time	evwl	30	150	150	SYSTEM			3483	2004-08-04 09:54:28.308003	source	A
31	patn_accident_date	timestamp	30	\N	~*	Accident Date	patn	10	390	224	10			3735	2005-01-21 09:11:34.245198	source	A
31	patn_claim_number	text	30	\N	~*	Claim Number	patn	15	380	222	10			3734	2005-01-21 09:11:34.245198	source	A
31	svpv_patn_claim_number	text	30	\N	~*	Patn Claim Number	svpv	30	340	340	10			3736	2005-01-23 15:26:07.976771	source	A
31	svpv_patn_accident_date	date	30	\N	~*	Patn Accident Date	svpv	30	350	350	10			3737	2005-01-23 15:26:07.976771	source	A
31	surg_patn__sequence	int4	10		~*	Patient ID	surg	10	10	10	SYSTEM			2752	2002-02-09 08:02:07	source	A
31	surg_symptoms	text	30	\N	~*	Symptoms	surg	15	20	10	10			3738	2005-01-25 07:22:21.041701	source	A
31	surg_class	text	30	\N	~*	Class	surg	15	30	20	10			3739	2005-01-25 07:22:21.041701	source	A
31	surg_diag_codes	text	30		~*	Diagnosis Codes	surg	15	20	30	10			2746	2002-02-09 08:02:06	source	A
31	surg_diagnosis	text	30		~*	Diagnosis	surg	15	30	40	10			2747	2002-02-09 08:02:06	source	A
31	surg_treatment	text	30	\N	~*	Treatment	surg	15	60	50	10			3740	2005-01-25 07:22:21.041701	source	A
31	surg_oprn_codes	text	30		~*	Operation Codes	surg	15	40	60	10			2749	2002-02-09 08:02:07	source	A
31	surg_operation	text	30		~*	Operation	surg	15	50	70	10			2748	2002-02-09 08:02:06	source	A
31	surg_oprn_date	timestamp	47		~*	Op Date	surg	15	60	80	10			2750	2002-02-09 08:02:07	source	A
31	surg_oprn_place	text	30		~*	Op Place	surg	15	70	90	10			2751	2002-02-09 08:02:07	source	A
31	surg_photo_code	text	30	\N	~*	Photo	surg	15	110	100	10			3741	2005-01-25 07:22:21.041701	source	A
31	surv_dob	text	30		~*	Dob	surv	15	50	50	10			2759	2002-02-09 08:02:11	source	A
31	surv_psnam	text	30		~*	Surname	surv	15	20	2	10			2765	2002-02-09 08:02:13	source	A
31	surv_fsnam	text	30		~*	Firstname	surv	15	30	4	10			2760	2002-02-09 08:02:12	source	A
31	surv_symptoms	text	30	\N	~*	Symptoms	surv	15	40	10	10			3742	2005-01-25 07:22:33.521556	source	A
31	surv_class	text	30	\N	~*	Class	surv	15	50	20	10			3743	2005-01-25 07:22:33.521556	source	A
31	surv_diag_codes	text	30		~*	Diagnosis Codes	surv	15	120	30	10			2757	2002-02-09 08:02:11	source	A
31	surv_diagnosis	text	30		~*	Diagnosis	surv	15	130	40	10			2758	2002-02-09 08:02:11	source	A
31	surv_oprn_place	text	30		~*	Op Place	surv	15	170	90	10			2764	2002-02-09 08:02:13	source	A
31	surv_treatment	text	30	\N	~*	Treatment	surv	15	80	50	10			3744	2005-01-25 07:22:33.521556	source	A
31	surv_oprn_codes	text	30		~*	Operation Codes	surv	15	140	60	10			2762	2002-02-09 08:02:12	source	A
31	surv_operation	text	30		~*	Operation	surv	15	150	70	10			2761	2002-02-09 08:02:12	source	A
31	surv_oprn_date	timestamp	47		~*	Op Date	surv	15	160	80	10			2763	2002-02-09 08:02:13	source	A
31	surv_photo_code	text	30	\N	~*	Photo	surv	15	130	100	10			3745	2005-01-25 07:22:33.521556	source	A
31	svrv_ts_service	timestamp	30	\N	~*	Ts Service	svrv	30	20	20	RO			3747	2005-01-25 13:46:55.847793	source	A
31	svrv_percentage	int4	30	\N	~*	Percentage	svrv	30	40	40	RO			3749	2005-01-25 13:46:55.847793	source	A
31	svrv_patn__sequence	int4	30	\N	~*	Patn  Sequence	svrv	30	90	90	RO			3754	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_address	text	30	\N	~*	Patn Address	svrv	30	110	110	RO			3756	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_state	text	30	\N	~*	Patn State	svrv	30	130	130	RO			3758	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_postcode	text	30	\N	~*	Patn Postcode	svrv	30	140	140	RO			3759	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_hlfd_code	text	30	\N	~*	Patn Hlfd Code	svrv	30	160	160	RO			3761	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_ins_level	bpchar	1	\N	~*	Patn Ins Level	svrv	1	170	170	RO			3762	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_healthnumb	text	30	\N	~*	Patn Healthnumb	svrv	30	180	180	RO			3763	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_medicare	text	30	\N	~*	Patn Medicare	svrv	30	190	190	RO			3764	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_healthcard	text	30	\N	~*	Patn Healthcard	svrv	30	200	200	RO			3765	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_patf_code	text	30	\N	~*	Patn Patf Code	svrv	30	210	210	RO			3766	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_claim_number	text	30	\N	~*	Patn Claim Number	svrv	30	220	220	RO			3767	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_accident_date	date	30	\N	~*	Patn Accident Date	svrv	30	230	230	RO			3768	2005-01-25 13:46:55.847793	source	A
31	svrv_serv_code	text	30	\N	~*	Item	svrv	8	30	1	RO			3748	2005-01-25 13:46:55.847793	source	A
31	svrv_date_service	date	30	\N	~*	Date	svrv	10	10	2	RO			3746	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_name	text	30	\N	~*	Patient	svrv	12	100	3	RO			3755	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_suburb	text	30	\N	~*	Suburb	svrv	12	120	4	RO			3757	2005-01-25 13:46:55.847793	source	A
31	svrv_patn_dob	text	30	\N	~*	DOB	svrv	10	150	5	RO			3760	2005-01-25 13:46:55.847793	source	A
31	svrv_desc	text	30	\N	~*	Description	svrv	15	50	6	RO			3750	2005-01-25 13:46:55.847793	source	A
31	svrv_amount	numeric	786434	\N	~*	Amount	svrv	10	60	7	RO			3751	2005-01-25 13:46:55.847793	source	A
31	svrv_gst_amount	numeric	786434	\N	~*	GST	svrv	6	70	8	RO			3752	2005-01-25 13:46:55.847793	source	A
31	svrv_total_amount	numeric	30	\N	~*	Total	svrv	10	80	9	RO			3753	2005-01-25 13:46:55.847793	source	A
31	svpv_invc_healthcard	text	30	\N	~*	Invc Healthcard	svpv	30	220	220	10			3779	2005-01-25 22:09:42.292935	source	A
31	svpv_invc_claim_number	text	30	\N	~*	Invc Claim Number	svpv	30	230	230	10			3780	2005-01-25 22:09:42.292935	source	A
31	svpv_invc_accident_date	timestamp	30	\N	~*	Invc Accident Date	svpv	30	240	240	10			3781	2005-01-25 22:09:42.292935	source	A
31	svpv_invc_reference_1	text	30	\N	~*	Invc Reference 1	svpv	30	250	250	10			3785	2005-01-25 22:23:02.241252	source	A
31	svpv_invc_reference_2	text	30	\N	~*	Invc Reference 2	svpv	30	260	260	10			3786	2005-01-25 22:23:02.241252	source	A
31	svpv_invc_reference_3	text	30	\N	~*	Invc Reference 3	svpv	30	270	270	10			3787	2005-01-25 22:23:02.241252	source	A
31	svpv_hlfd_desc	text	30	\N	~*	Hlfd Desc	svpv	30	220	220	10			3791	2005-01-26 16:14:50.257573	source	A
31	svpv_invc_ins_level	text	30	\N	~*	Invc Ins Level	svpv	30	230	230	10			3792	2005-01-26 16:14:50.257573	source	A
31	svpv_invc_healthnumb	text	30	\N	~*	Invc Healthnumb	svpv	30	240	240	10			3793	2005-01-26 16:14:50.257573	source	A
31	mtvs_schema_name	text	30	\N	~*	Schema Name	mtvs	30	10	10	10			3795	2005-01-30 09:25:48.66161	source	A
31	mtvs_schema_version	text	30	\N	~*	Schema Version	mtvs	30	20	20	10			3796	2005-01-30 09:25:48.66161	source	A
31	mtvs_product_name	text	30	\N	~*	Product Name	mtvs	30	30	30	10			3797	2005-01-30 09:25:48.66161	source	A
31	mtvs_product_version	text	30	\N	~*	Product Version	mtvs	30	40	40	10			3798	2005-01-30 09:25:48.66161	source	A
31	mtvs_desc	text	30	\N	~*	Desc	mtvs	30	50	50	10			3799	2005-01-30 09:25:48.66161	source	A
31	-	text	1	\N	=	TITLE	-	10	500	500	\N	\N	\N	3897	2005-01-31 13:52:37.519789	source	A
31	hicv_accountpaidind	text	30	\N	~*	Accountpaidind	hicv	30	10	10	10			3910	2005-02-05 17:37:22.922276	source	A
31	hicv_accountreferencenum	text	30	\N	~*	Accountreferencenum	hicv	30	20	20	10			3911	2005-02-05 17:37:22.922276	source	A
31	hicv_admissiondate	text	30	\N	~*	Admissiondate	hicv	30	30	30	10			3912	2005-02-05 17:37:22.922276	source	A
31	hicv_aftercareoverrideind	text	30	\N	~*	Aftercareoverrideind	hicv	30	40	40	10			3913	2005-02-05 17:37:22.922276	source	A
31	hicv_approvalnum	text	30	\N	~*	Approvalnum	hicv	30	50	50	10			3914	2005-02-05 17:37:22.922276	source	A
31	hicv_associatename	text	30	\N	~*	Associatename	hicv	30	60	60	10			3915	2005-02-05 17:37:22.922276	source	A
31	hicv_atsiindicator	text	30	\N	~*	Atsiindicator	hicv	30	70	70	10			3916	2005-02-05 17:37:22.922276	source	A
31	hicv_authproxyname	text	30	\N	~*	Authproxyname	hicv	30	80	80	10			3917	2005-02-05 17:37:22.922276	source	A
31	hicv_authproxypasswd	text	30	\N	~*	Authproxypasswd	hicv	30	90	90	10			3918	2005-02-05 17:37:22.922276	source	A
31	hicv_authproxypasswd_proxyname	text	30	\N	~*	Authproxypasswd Proxyname	hicv	30	100	100	10			3919	2005-02-05 17:37:22.922276	source	A
31	hicv_authproxyuserid	text	30	\N	~*	Authproxyuserid	hicv	30	110	110	10			3920	2005-02-05 17:37:22.922276	source	A
31	hicv_authproxyuserid_proxyname	text	30	\N	~*	Authproxyuserid Proxyname	hicv	30	120	120	10			3921	2005-02-05 17:37:22.922276	source	A
31	hicv_authorityapprovalnum	text	30	\N	~*	Authorityapprovalnum	hicv	30	130	130	10			3922	2005-02-05 17:37:22.922276	source	A
31	hicv_authorityprescriptionnum	text	30	\N	~*	Authorityprescriptionnum	hicv	30	140	140	10			3923	2005-02-05 17:37:22.922276	source	A
31	hicv_bankaccountname	text	30	\N	~*	Bankaccountname	hicv	30	150	150	10			3924	2005-02-05 17:37:22.922276	source	A
31	hicv_bankaccountnum	text	30	\N	~*	Bankaccountnum	hicv	30	160	160	10			3925	2005-02-05 17:37:22.922276	source	A
31	hicv_benefitassignmentauthorised	text	30	\N	~*	Benefitassignmentauthorised	hicv	30	170	170	10			3926	2005-02-05 17:37:22.922276	source	A
31	hicv_billingagentid	text	30	\N	~*	Billingagentid	hicv	30	180	180	10			3927	2005-02-05 17:37:22.922276	source	A
31	hicv_buffersize	text	30	\N	~*	Buffersize	hicv	30	190	190	10			3928	2005-02-05 17:37:22.922276	source	A
31	hicv_chargeamount	text	30	\N	~*	Chargeamount	hicv	30	200	200	10			3929	2005-02-05 17:37:22.922276	source	A
31	hicv_claimid	text	30	\N	~*	Claimid	hicv	30	210	210	10			3930	2005-02-05 17:37:22.922276	source	A
31	hicv_claimperiodnum	text	30	\N	~*	Claimperiodnum	hicv	30	220	220	10			3931	2005-02-05 17:37:22.922276	source	A
31	hicv_claimreference	text	30	\N	~*	Claimreference	hicv	30	230	230	10			3932	2005-02-05 17:37:22.922276	source	A
31	hicv_claimsubmissionauthorised	text	30	\N	~*	Claimsubmissionauthorised	hicv	30	240	240	10			3933	2005-02-05 17:37:22.922276	source	A
31	hicv_claimtypecde	text	30	\N	~*	Claimtypecde	hicv	30	250	250	10			3934	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantaddressline1	text	30	\N	~*	Claimantaddressline1	hicv	30	260	260	10			3935	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantaddressline2	text	30	\N	~*	Claimantaddressline2	hicv	30	270	270	10			3936	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantaddresslocality	text	30	\N	~*	Claimantaddresslocality	hicv	30	280	280	10			3937	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantaddresspostcode	text	30	\N	~*	Claimantaddresspostcode	hicv	30	290	290	10			3938	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantdateofbirth	text	30	\N	~*	Claimantdateofbirth	hicv	30	300	300	10			3939	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantfamilyname	text	30	\N	~*	Claimantfamilyname	hicv	30	310	310	10			3940	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantfirstname	text	30	\N	~*	Claimantfirstname	hicv	30	320	320	10			3941	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantmedicarecardnum	text	30	\N	~*	Claimantmedicarecardnum	hicv	30	330	330	10			3942	2005-02-05 17:37:22.922276	source	A
31	hicv_claimantreferencenum	text	30	\N	~*	Claimantreferencenum	hicv	30	340	340	10			3943	2005-02-05 17:37:22.922276	source	A
31	hicv_cliniccode	text	30	\N	~*	Cliniccode	hicv	30	350	350	10			3944	2005-02-05 17:37:22.922276	source	A
31	hicv_communitycode	text	30	\N	~*	Communitycode	hicv	30	360	360	10			3945	2005-02-05 17:37:22.922276	source	A
31	hicv_compensationclaimind	text	30	\N	~*	Compensationclaimind	hicv	30	370	370	10			3946	2005-02-05 17:37:22.922276	source	A
31	hicv_contactphonenum	text	30	\N	~*	Contactphonenum	hicv	30	380	380	10			3947	2005-02-05 17:37:22.922276	source	A
31	hicv_contenttype	text	30	\N	~*	Contenttype	hicv	30	390	390	10			3948	2005-02-05 17:37:22.922276	source	A
31	hicv_dateofdispensing	text	30	\N	~*	Dateofdispensing	hicv	30	400	400	10			3949	2005-02-05 17:37:22.922276	source	A
31	hicv_dateofimmunisation	text	30	\N	~*	Dateofimmunisation	hicv	30	410	410	10			3950	2005-02-05 17:37:22.922276	source	A
31	hicv_dateoflodgement	text	30	\N	~*	Dateoflodgement	hicv	30	420	420	10			3951	2005-02-05 17:37:22.922276	source	A
31	hicv_dateofprescribing	text	30	\N	~*	Dateofprescribing	hicv	30	430	430	10			3952	2005-02-05 17:37:22.922276	source	A
31	hicv_dateofservice	text	30	\N	~*	Dateofservice	hicv	30	440	440	10			3953	2005-02-05 17:37:22.922276	source	A
31	hicv_dateofsupply	text	30	\N	~*	Dateofsupply	hicv	30	450	450	10			3954	2005-02-05 17:37:22.922276	source	A
31	hicv_dateoftransmission	text	30	\N	~*	Dateoftransmission	hicv	30	460	460	10			3955	2005-02-05 17:37:22.922276	source	A
31	hicv_dischargedate	text	30	\N	~*	Dischargedate	hicv	30	470	470	10			3956	2005-02-05 17:37:22.922276	source	A
31	hicv_distancekms	text	30	\N	~*	Distancekms	hicv	30	480	480	10			3957	2005-02-05 17:37:22.922276	source	A
31	hicv_duplicateserviceoverrideind	text	30	\N	~*	Duplicateserviceoverrideind	hicv	30	490	490	10			3958	2005-02-05 17:37:22.922276	source	A
31	hicv_entitlementid	text	30	\N	~*	Entitlementid	hicv	30	500	500	10			3959	2005-02-05 17:37:22.922276	source	A
31	hicv_equipmentid	text	30	\N	~*	Equipmentid	hicv	30	510	510	10			3960	2005-02-05 17:37:22.922276	source	A
31	hicv_facilityid	text	30	\N	~*	Facilityid	hicv	30	520	520	10			3961	2005-02-05 17:37:22.922276	source	A
31	hicv_familyname	text	30	\N	~*	Familyname	hicv	30	530	530	10			3962	2005-02-05 17:37:22.922276	source	A
31	hicv_fieldquantity	text	30	\N	~*	Fieldquantity	hicv	30	540	540	10			3963	2005-02-05 17:37:22.922276	source	A
31	hicv_filepath	text	30	\N	~*	Filepath	hicv	30	550	550	10			3964	2005-02-05 17:37:22.922276	source	A
31	hicv_financialinterestdisclosureind	text	30	\N	~*	Financialinterestdisclosureind	hicv	30	560	560	10			3965	2005-02-05 17:37:22.922276	source	A
31	hicv_formcategory	text	30	\N	~*	Formcategory	hicv	30	570	570	10			3966	2005-02-05 17:37:22.922276	source	A
31	hicv_fundbrandid	text	30	\N	~*	Fundbrandid	hicv	30	580	580	10			3967	2005-02-05 17:37:22.922276	source	A
31	hicv_fundpayeeid	text	30	\N	~*	Fundpayeeid	hicv	30	590	590	10			3968	2005-02-05 17:37:22.922276	source	A
31	hicv_givenname	text	30	\N	~*	Givenname	hicv	30	600	600	10			3969	2005-02-05 17:37:22.922276	source	A
31	hicv_glassbottleind	text	30	\N	~*	Glassbottleind	hicv	30	610	610	10			3970	2005-02-05 17:37:22.922276	source	A
31	hicv_hclpassphrase	text	30	\N	~*	Hclpassphrase	hicv	30	620	620	10			3971	2005-02-05 17:37:22.922276	source	A
31	hicv_hepbbirthdosedate	text	30	\N	~*	Hepbbirthdosedate	hicv	30	630	630	10			3972	2005-02-05 17:37:22.922276	source	A
31	hicv_hepbbirthdoseind	text	30	\N	~*	Hepbbirthdoseind	hicv	30	640	640	10			3973	2005-02-05 17:37:22.922276	source	A
31	hicv_hospitalind	text	30	\N	~*	Hospitalind	hicv	30	650	650	10			3974	2005-02-05 17:37:22.922276	source	A
31	hicv_hospitalprovidernum	text	30	\N	~*	Hospitalprovidernum	hicv	30	660	660	10			3975	2005-02-05 17:37:22.922276	source	A
31	hicv_ifcissuecde	text	30	\N	~*	Ifcissuecde	hicv	30	670	670	10			3976	2005-02-05 17:37:22.922276	source	A
31	hicv_immediatesupplynecessaryind	text	30	\N	~*	Immediatesupplynecessaryind	hicv	30	680	680	10			3977	2005-02-05 17:37:22.922276	source	A
31	hicv_immunisingprovidernum	text	30	\N	~*	Immunisingprovidernum	hicv	30	690	690	10			3978	2005-02-05 17:37:22.922276	source	A
31	hicv_informationprovidernum	text	30	\N	~*	Informationprovidernum	hicv	30	700	700	10			3979	2005-02-05 17:37:22.922276	source	A
31	hicv_itemnum	text	30	\N	~*	Itemnum	hicv	30	710	710	10			3980	2005-02-05 17:37:22.922276	source	A
31	hicv_locationid	text	30	\N	~*	Locationid	hicv	30	720	720	10			3981	2005-02-05 17:37:22.922276	source	A
31	hicv_logicpackdir	text	30	\N	~*	Logicpackdir	hicv	30	730	730	10			3982	2005-02-05 17:37:22.922276	source	A
31	hicv_medicarenum	text	30	\N	~*	Medicarenum	hicv	30	740	740	10			3983	2005-02-05 17:37:22.922276	source	A
31	hicv_multipleprocedureoverrideind	text	30	\N	~*	Multipleprocedureoverrideind	hicv	30	750	750	10			3984	2005-02-05 17:37:22.922276	source	A
31	hicv_nextduedate	text	30	\N	~*	Nextduedate	hicv	30	760	760	10			3985	2005-02-05 17:37:22.922276	source	A
31	hicv_noofpatientsseen	text	30	\N	~*	Noofpatientsseen	hicv	30	770	770	10			3986	2005-02-05 17:37:22.922276	source	A
31	hicv_numberofrepeats	text	30	\N	~*	Numberofrepeats	hicv	30	780	780	10			3987	2005-02-05 17:37:22.922276	source	A
31	hicv_numberofservices	text	30	\N	~*	Numberofservices	hicv	30	790	790	10			3988	2005-02-05 17:37:22.922276	source	A
31	hicv_opvtypecde	text	30	\N	~*	Opvtypecde	hicv	30	800	800	10			3989	2005-02-05 17:37:22.922276	source	A
31	hicv_pbsitemcode	text	30	\N	~*	Pbsitemcode	hicv	30	810	810	10			3990	2005-02-05 17:37:22.922276	source	A
31	hicv_pbsreferencenum	text	30	\N	~*	Pbsreferencenum	hicv	30	820	820	10			3991	2005-02-05 17:37:22.922276	source	A
31	hicv_participanttype	text	30	\N	~*	Participanttype	hicv	30	830	830	10			3992	2005-02-05 17:37:22.922276	source	A
31	hicv_patientaddressline1	text	30	\N	~*	Patientaddressline1	hicv	30	840	840	10			3993	2005-02-05 17:37:22.922276	source	A
31	hicv_patientaddressline2	text	30	\N	~*	Patientaddressline2	hicv	30	850	850	10			3994	2005-02-05 17:37:22.922276	source	A
31	hicv_patientaddresslocality	text	30	\N	~*	Patientaddresslocality	hicv	30	860	860	10			3995	2005-02-05 17:37:22.922276	source	A
31	hicv_patientaddresspostcode	text	30	\N	~*	Patientaddresspostcode	hicv	30	870	870	10			3996	2005-02-05 17:37:22.922276	source	A
31	hicv_patientaliasfamilyname	text	30	\N	~*	Patientaliasfamilyname	hicv	30	880	880	10			3997	2005-02-05 17:37:22.922276	source	A
31	hicv_patientaliasfirstname	text	30	\N	~*	Patientaliasfirstname	hicv	30	890	890	10			3998	2005-02-05 17:37:22.922276	source	A
31	hicv_patientcategory	text	30	\N	~*	Patientcategory	hicv	30	900	900	10			3999	2005-02-05 17:37:22.922276	source	A
31	hicv_patientcontribamt	text	30	\N	~*	Patientcontribamt	hicv	30	910	910	10			4000	2005-02-05 17:37:22.922276	source	A
31	hicv_patientdateofbirth	text	30	\N	~*	Patientdateofbirth	hicv	30	920	920	10			4001	2005-02-05 17:37:22.922276	source	A
31	hicv_patientfamilyname	text	30	\N	~*	Patientfamilyname	hicv	30	930	930	10			4002	2005-02-05 17:37:22.922276	source	A
31	hicv_patientfirstname	text	30	\N	~*	Patientfirstname	hicv	30	940	940	10			4003	2005-02-05 17:37:22.922276	source	A
31	hicv_patientfundmembershipnum	text	30	\N	~*	Patientfundmembershipnum	hicv	30	950	950	10			4004	2005-02-05 17:37:22.922276	source	A
31	hicv_patientfundupi	text	30	\N	~*	Patientfundupi	hicv	30	960	960	10			4005	2005-02-05 17:37:22.922276	source	A
31	hicv_patientgender	text	30	\N	~*	Patientgender	hicv	30	970	970	10			4006	2005-02-05 17:37:22.922276	source	A
31	hicv_patientmedicarecardnum	text	30	\N	~*	Patientmedicarecardnum	hicv	30	980	980	10			4007	2005-02-05 17:37:22.922276	source	A
31	hicv_patientproviderchildid	text	30	\N	~*	Patientproviderchildid	hicv	30	990	990	10			4008	2005-02-05 17:37:22.922276	source	A
31	hicv_patientreferencenum	text	30	\N	~*	Patientreferencenum	hicv	30	1000	1000	10			4009	2005-02-05 17:37:22.922276	source	A
31	hicv_patientsecondinitial	text	30	\N	~*	Patientsecondinitial	hicv	30	1010	1010	10			4010	2005-02-05 17:37:22.922276	source	A
31	hicv_payeeprovidernum	text	30	\N	~*	Payeeprovidernum	hicv	30	1020	1020	10			4011	2005-02-05 17:37:22.922276	source	A
31	hicv_paymentcategory	text	30	\N	~*	Paymentcategory	hicv	30	1030	1030	10			4012	2005-02-05 17:37:22.922276	source	A
31	hicv_periodtypeind	text	30	\N	~*	Periodtypeind	hicv	30	1040	1040	10			4013	2005-02-05 17:37:22.922276	source	A
31	hicv_pharmacyprocessingcode	text	30	\N	~*	Pharmacyprocessingcode	hicv	30	1050	1050	10			4014	2005-02-05 17:37:22.922276	source	A
31	hicv_pmsclaimid	text	30	\N	~*	Pmsclaimid	hicv	30	1060	1060	10			4015	2005-02-05 17:37:22.922276	source	A
31	hicv_pmsproduct	text	30	\N	~*	Pmsproduct	hicv	30	1070	1070	10			4016	2005-02-05 17:37:22.922276	source	A
31	hicv_pmsversion	text	30	\N	~*	Pmsversion	hicv	30	1080	1080	10			4017	2005-02-05 17:37:22.922276	source	A
31	hicv_prescriberid	text	30	\N	~*	Prescriberid	hicv	30	1090	1090	10			4018	2005-02-05 17:37:22.922276	source	A
31	hicv_previoussupplies	text	30	\N	~*	Previoussupplies	hicv	30	1100	1100	10			4019	2005-02-05 17:37:22.922276	source	A
31	hicv_principalprovidernum	text	30	\N	~*	Principalprovidernum	hicv	30	1110	1110	10			4020	2005-02-05 17:37:22.922276	source	A
31	hicv_referraldatefrom	text	30	\N	~*	Referraldatefrom	hicv	30	1120	1120	10			4021	2005-02-05 17:37:22.922276	source	A
31	hicv_referraldateto	text	30	\N	~*	Referraldateto	hicv	30	1130	1130	10			4022	2005-02-05 17:37:22.922276	source	A
31	hicv_referralissuedate	text	30	\N	~*	Referralissuedate	hicv	30	1140	1140	10			4023	2005-02-05 17:37:22.922276	source	A
31	hicv_referraloverridetype	text	30	\N	~*	Referraloverridetype	hicv	30	1150	1150	10			4024	2005-02-05 17:37:22.922276	source	A
31	hicv_referraloverridetypecde	text	30	\N	~*	Referraloverridetypecde	hicv	30	1160	1160	10			4025	2005-02-05 17:37:22.922276	source	A
31	hicv_referralperiod	text	30	\N	~*	Referralperiod	hicv	30	1170	1170	10			4026	2005-02-05 17:37:22.922276	source	A
31	hicv_referralperiodtypecde	text	30	\N	~*	Referralperiodtypecde	hicv	30	1180	1180	10			4027	2005-02-05 17:37:22.922276	source	A
31	hicv_referringprovidernum	text	30	\N	~*	Referringprovidernum	hicv	30	1190	1190	10			4028	2005-02-05 17:37:22.922276	source	A
31	hicv_reportstatuscde	text	30	\N	~*	Reportstatuscde	hicv	30	1200	1200	10			4029	2005-02-05 17:37:22.922276	source	A
31	hicv_requestcontenttype	text	30	\N	~*	Requestcontenttype	hicv	30	1210	1210	10			4030	2005-02-05 17:37:22.922276	source	A
31	hicv_requestissuedate	text	30	\N	~*	Requestissuedate	hicv	30	1220	1220	10			4031	2005-02-05 17:37:22.922276	source	A
31	hicv_requesttypecde	text	30	\N	~*	Requesttypecde	hicv	30	1230	1230	10			4032	2005-02-05 17:37:22.922276	source	A
31	hicv_requesttypeind	text	30	\N	~*	Requesttypeind	hicv	30	1240	1240	10			4033	2005-02-05 17:37:22.922276	source	A
31	hicv_requestingprovidernum	text	30	\N	~*	Requestingprovidernum	hicv	30	1250	1250	10			4034	2005-02-05 17:37:22.922276	source	A
31	hicv_resubmissionind	text	30	\N	~*	Resubmissionind	hicv	30	1260	1260	10			4035	2005-02-05 17:37:22.922276	source	A
31	hicv_rule3exemptind	text	30	\N	~*	Rule3exemptind	hicv	30	1270	1270	10			4036	2005-02-05 17:37:22.922276	source	A
31	hicv_sddreasoncode	text	30	\N	~*	Sddreasoncode	hicv	30	1280	1280	10			4037	2005-02-05 17:37:22.922276	source	A
31	hicv_selfdeemedcde	text	30	\N	~*	Selfdeemedcde	hicv	30	1290	1290	10			4038	2005-02-05 17:37:22.922276	source	A
31	hicv_selfdeemedind	text	30	\N	~*	Selfdeemedind	hicv	30	1300	1300	10			4039	2005-02-05 17:37:22.922276	source	A
31	hicv_sender	text	30	\N	~*	Sender	hicv	30	1310	1310	10			4040	2005-02-05 17:37:22.922276	source	A
31	hicv_sendercontactpersonname	text	30	\N	~*	Sendercontactpersonname	hicv	30	1320	1320	10			4041	2005-02-05 17:37:22.922276	source	A
31	hicv_sendercontactpersonphone	text	30	\N	~*	Sendercontactpersonphone	hicv	30	1330	1330	10			4042	2005-02-05 17:37:22.922276	source	A
31	hicv_serialnum	text	30	\N	~*	Serialnum	hicv	30	1340	1340	10			4043	2005-02-05 17:37:22.922276	source	A
31	hicv_server	text	30	\N	~*	Server	hicv	30	1350	1350	10			4044	2005-02-05 17:37:22.922276	source	A
31	hicv_servicetext	text	30	\N	~*	Servicetext	hicv	30	1360	1360	10			4045	2005-02-05 17:37:22.922276	source	A
31	hicv_servicetype	text	30	\N	~*	Servicetype	hicv	30	1370	1370	10			4046	2005-02-05 17:37:22.922276	source	A
31	hicv_servicetypecde	text	30	\N	~*	Servicetypecde	hicv	30	1380	1380	10			4047	2005-02-05 17:37:22.922276	source	A
31	hicv_servicingprovidernum	text	30	\N	~*	Servicingprovidernum	hicv	30	1390	1390	10			4048	2005-02-05 17:37:22.922276	source	A
31	hicv_sessionid	text	30	\N	~*	Sessionid	hicv	30	1400	1400	10			4049	2005-02-05 17:37:22.922276	source	A
31	hicv_timeduration	text	30	\N	~*	Timeduration	hicv	30	1410	1410	10			4050	2005-02-05 17:37:22.922276	source	A
31	hicv_timeoflodgement	text	30	\N	~*	Timeoflodgement	hicv	30	1420	1420	10			4051	2005-02-05 17:37:22.922276	source	A
31	hicv_timeofservice	text	30	\N	~*	Timeofservice	hicv	30	1430	1430	10			4052	2005-02-05 17:37:22.922276	source	A
31	hicv_timeoftransmission	text	30	\N	~*	Timeoftransmission	hicv	30	1440	1440	10			4053	2005-02-05 17:37:22.922276	source	A
31	hicv_transactionid	text	30	\N	~*	Transactionid	hicv	30	1450	1450	10			4054	2005-02-05 17:37:22.922276	source	A
31	hicv_transmissionid	text	30	\N	~*	Transmissionid	hicv	30	1460	1460	10			4055	2005-02-05 17:37:22.922276	source	A
31	hicv_transmissiontype	text	30	\N	~*	Transmissiontype	hicv	30	1470	1470	10			4056	2005-02-05 17:37:22.922276	source	A
31	hicv_treatmentlocation	text	30	\N	~*	Treatmentlocation	hicv	30	1480	1480	10			4057	2005-02-05 17:37:22.922276	source	A
31	hicv_uniquepharmacyprescriptionnum	text	30	\N	~*	Uniquepharmacyprescriptionnum	hicv	30	1490	1490	10			4058	2005-02-05 17:37:22.922276	source	A
31	hicv_vaccinebatchnum	text	30	\N	~*	Vaccinebatchnum	hicv	30	1500	1500	10			4059	2005-02-05 17:37:22.922276	source	A
31	hicv_vaccinecode	text	30	\N	~*	Vaccinecode	hicv	30	1510	1510	10			4060	2005-02-05 17:37:22.922276	source	A
31	hicv_vaccinedose	text	30	\N	~*	Vaccinedose	hicv	30	1520	1520	10			4061	2005-02-05 17:37:22.922276	source	A
31	hicv_veteranfilenum	text	30	\N	~*	Veteranfilenum	hicv	30	1530	1530	10			4062	2005-02-05 17:37:22.922276	source	A
31	hice_name	text	15	\N	~*	Name	hice	20	10	10	10			3898	2005-02-05 16:07:20.979279	source	A
31	hice_input	bpchar	5	\N	~*	Input	hice	5	20	20	10			3899	2005-02-05 16:07:20.979279	source	A
31	hice_output	bpchar	5	\N	~*	Output	hice	5	30	30	10			3900	2005-02-05 16:07:20.979279	source	A
31	hice_session	bpchar	5	\N	~*	Session	hice	5	40	40	10			3901	2005-02-05 16:07:20.979279	source	A
31	hice_transmission	bpchar	5	\N	~*	Transmission	hice	5	50	50	10			3902	2005-02-05 16:07:20.979279	source	A
31	hice_length	text	5	\N	~*	Length	hice	5	60	60	10			3903	2005-02-05 16:07:20.979279	source	A
31	hice_type	text	5	\N	~*	Type	hice	5	70	70	10			3904	2005-02-05 16:07:20.979279	source	A
31	hice_desc	text	30	\N	~*	Description	hice	30	80	80	10			3905	2005-02-05 16:07:20.979279	source	A
31	mdbt_location_id	text	30	\N	~*	Location Id	mdbt	30	50	50	10			4063	2005-02-05 19:49:19.182888	source	A
31	mdbt_product	text	30	\N	~*	Product	mdbt	30	60	60	10			4064	2005-02-05 19:49:19.182888	source	A
31	mdbt_version	text	30	\N	~*	Version	mdbt	30	70	70	10			4065	2005-02-05 19:49:19.182888	source	A
31	mdbt_accpaid_ind	text	30	\N	~*	Accpaid Ind	mdbt	30	80	80	10			4066	2005-02-05 19:49:19.182888	source	A
31	mdbt_claimsubauth	text	30	\N	~*	Claimsubauth	mdbt	30	90	90	10			4067	2005-02-05 19:49:19.182888	source	A
31	mdbt_accunpaid	text	30	\N	~*	Accunpaid	mdbt	30	100	100	10			4068	2005-02-05 19:49:19.182888	source	A
31	mdbt_recipient	text	30	\N	~*	Recipient	mdbt	30	140	140	10			4069	2005-02-05 19:49:19.182888	source	A
31	mdbt_server	text	30	\N	~*	Server	mdbt	30	150	150	10			4070	2005-02-05 19:49:19.182888	source	A
31	mdbt_prov_code	text	30	\N	~*	Provider	mdbt	5	10	10	10			3857	2005-01-31 13:28:47.865107	source	A
31	mdbt_first_voucher	text	30	\N	~*	First Voucher	mdbt	5	20	20	10			3858	2005-01-31 13:28:47.865107	source	A
31	mdbt_last_voucher	text	30	\N	~*	Last Voucher	mdbt	5	30	30	10			3859	2005-01-31 13:28:47.865107	source	A
31	mdbt_batch_code	text	30	\N	~*	External Code	mdbt	10	40	40	10			3860	2005-01-31 13:28:47.865107	source	A
31	mdbt_voucher_count	int4	30	\N	~*	Voucher Count	mdbt	4	50	50	10			3861	2005-01-31 13:28:47.865107	source	A
31	mdbt_total_amount	numeric	786434	\N	~*	Total Amount	mdbt	10	60	60	10			3862	2005-01-31 13:28:47.865107	source	A
31	mdbt_claim_date	timestamp	30	\N	~*	Claim Date	mdbt	17	70	70	10			3863	2005-01-31 13:28:47.865107	source	A
31	mdbt_claim_status	text	30	\N	~*	Claim Status	mdbt	5	80	80	10			3864	2005-01-31 13:28:47.865107	source	A
31	hicv_recipient	text	30	\N	~*	Recipient	hicv	30	1120	1120	10			4071	2005-02-05 21:14:41.500324	source	A
31	mbst_item	int4	30	\N	~*	Item	mbst	30	10	10	10			4072	2005-02-06 13:35:20.80535	source	A
31	mbst_desc	text	30	\N	~*	Desc	mbst	30	20	20	10			4073	2005-02-06 13:35:20.80535	source	A
31	mbst_sch100	numeric	786434	\N	~*	Sch100	mbst	786434	30	30	10			4074	2005-02-06 13:35:20.80535	source	A
31	mbst_sch75	numeric	786434	\N	~*	Sch75	mbst	786434	40	40	10			4075	2005-02-06 13:35:20.80535	source	A
31	mbst_sch85	numeric	786434	\N	~*	Sch85	mbst	786434	50	50	10			4076	2005-02-06 13:35:20.80535	source	A
31	mdaf_voucher	text	30	\N	~*	Voucher	mdaf	30	40	40	10			3834	2005-01-31 12:06:23.210725	source	A
2	mdaf_patn__sequence	integer	0		=	Patient ID	mdaf	15	10	10	RO			1967	2001-10-19 12:28:27	source	A
2	mdaf_prov_code	text	0		~*	Provider	mdaf	15	20	20	RO			1968	2001-10-19 12:28:27	source	A
2	mdaf_rfdr_code	text	0		~*	Referrer	mdaf	15	30	30	RO			1969	2001-10-19 12:28:28	source	A
2	mdaf_date_printed	timestamp	0		=	Claimed	mdaf	20	70	70	RO			1965	2001-10-19 12:28:26	source	A
2	mdaf_mdbt__sequence	integer	0		=	Claim ID	mdaf	10	80	80	RO			1966	2001-10-19 12:28:26	source	A
31	hicv_mdbt__sequence	int4	30	\N	~*	Mdbt  Sequence	hicv	30	1550	1550	10			4081	2005-02-11 12:29:47.373542	source	A
31	hicv_mdaf__sequence	int4	30	\N	~*	Mdaf  Sequence	hicv	30	1560	1560	10			4082	2005-02-11 12:29:47.373542	source	A
31	cred_notes	text	30	\N	~*	Notes	cred	20	40	40	10			3492	2004-09-21 11:15:17.929002	source	A
31	crev_cred_notes	text	30	\N	~*	Notes	crev	20	40	40	10			3494	2004-09-21 11:15:21.032187	source	A
2	patn_postcode	text	0		~*	Postcode	patn	4	10	100	COPYTEXT=pcde;pcde_postcode;pcde_locality;patn_suburb			2732	2002-02-09 08:01:55	source	A
2	patn_suburb	text	0		~*	Suburb	patn	15	10	80	COPYTEXT=pcde;pcde_locality;pcde_postcode;patn_postcode			2740	2002-02-09 08:01:57	source	A
2	rfdr_postcode	text	0		~*	Postcode	rfdr	10	50	50	COPYTEXT=pcde;pcde_postcode;pcde_locality;rfdr_suburb			2083	2001-10-19 12:29:56	source	A
2	rfdr_suburb	text	0		~*	Suburb	rfdr	30	40	40	COPYTEXT=pcde;pcde_locality;pcde_postcode;rfdr_postcode			2088	2001-10-19 12:29:58	source	A
31	bank_postcode	text	1		~*	Business - Postcode	bank	10	10	50	COPYTEXT=pcde;pcde_postcode;pcde_locality;bank_suburb			1725	2001-10-19 12:24:36	source	A
31	bank_suburb	text	1		~*	Business -  Suburb	bank	30	10	40	COPYTEXT=pcde;pcde_locality;pcde_postcode;bank_postcode			1727	2001-10-19 12:24:37	source	A
2	dbtr_postcode	text	0		~*	Postcode	dbtr	4	10	60	COPYTEXT=pcde;pcde_postcode;pcde_locality;dbtr_suburb			1807	2001-10-19 12:25:41	source	A
2	dbtr_suburb	text	0		~*	Suburb	dbtr	60	10	50	COPYTEXT=pcde;pcde_locality;pcde_postcode;dbtr_postcode			1809	2001-10-19 12:25:42	source	A
2	empl_postcode	text	0		~*	Postcode	empl	4	10	50	COPYTEXT=pcde;pcde_postcode;pcde_locality;empl_suburb			1834	2001-10-19 12:26:04	source	A
2	empl_suburb	text	0		~*	Suburb	empl	30	10	40	COPYTEXT=pcde;pcde_locality;pcde_postcode;empl_postcode			1836	2001-10-19 12:26:05	source	A
2	inst_postc	text	0		~*	Postcode	inst	30	30	70	COPYTEXT=pcde;pcde_postcode;pcde_locality;inst_suburb			1911	2001-10-19 12:27:42	source	A
2	inst_suburb	text	0		~*	Suburb	inst	30	30	60	COPYTEXT=pcde;pcde_locality;pcde_postcode;inst_postc			1912	2001-10-19 12:27:43	source	A
2	prov_postcode	text	0		~*	Postcode	prov	4	10	70	COPYTEXT=pcde;pcde_postcode;pcde_locality;prov_suburb			3226	2002-10-25 09:57:40	source	A
2	prov_suburb	text	0		~*	Suburb	prov	50	10	50	COPYTEXT=pcde;pcde_locality;pcde_postcode;prov_postcode			3230	2002-10-25 09:57:41	source	A
31	aptd_aptp_code	text	30		~*	Type	aptd	5	10	10	RO			3204	2002-10-25 09:52:17	source	A
31	aptd_dayofmonth	int4	10		~*	Month Day	aptd	3	70	70	10			3206	2002-10-25 09:52:18	source	A
31	aptd_dayofweek	int4	10		~*	Week Day	aptd	3	60	60	SELECT= 0,Sunday;1,Monday;2,Tuesday;3,Wednesday;4,Thursday;5,Friday;6,Saturday;			3207	2002-10-25 09:52:18	source	A
31	aptd_desc	text	30		~*	Description	aptd	15	20	20	10			3208	2002-10-25 09:52:19	source	A
31	aptd_ending	time	10		~*	Ending	aptd	5	120	120	10			3209	2002-10-25 09:52:19	source	A
31	aptd_locn_code	text	30		~*	Location	aptd	5	50	50	FSL=30			3210	2002-10-25 09:52:19	source	A
31	aptd_monthofyear	int4	10		~*	Month	aptd	3	80	80	SELECT=1,January;2,February;3,March;4,April;5,May;6,June;7,July;8,August;9,September;10,October;11,November;12,December;			3211	2002-10-25 09:52:19	source	A
31	aptd_parallel	int4	30	\N	~*	Double	aptd	5	110	110	10			3623	2005-01-13 11:08:19.390164	source	A
31	aptd_prov_code	text	30		~*	Provider	aptd	5	40	40	FSL=30			3212	2002-10-25 09:52:20	source	A
31	aptd_skip	int4	30	\N	~*	Skip	aptd	5	120	120	10			3624	2005-01-13 11:08:19.390164	source	A
31	aptd_start_date	date	30	\N	~*	Start Date	aptd	10	130	130	10			3625	2005-01-13 11:08:19.390164	source	A
31	aptd_end_date	date	30	\N	~*	End Date	aptd	10	140	140	10			3626	2005-01-13 11:08:19.390164	source	A
31	aptd_recurrence	text	30	\N	~*	Recurrence	aptd	5	150	150	10			3627	2005-01-13 11:08:19.390164	source	A
31	aptd_starting	time	10		~*	Starting	aptd	5	110	110	10			3213	2002-10-25 09:52:20	source	A
31	aptd_weekofyear	text	30		~*	Week of year	aptd	5	70	70	SELECT=1,Odd Weeks;0,Even Weeks;			3214	2002-10-25 09:52:20	source	A
31	aptd_year	int4	10		~*	Year	aptd	5	90	90	SELECT=2002,2002;2003,2003;2004,2004;2005,2005;2006,2006;2007,2007;2008,2008;2009,2009;2010,2010;			3215	2002-10-25 09:52:21	source	A
31	aptd_colour	text	30		~*	Colour	aptd	5	30	30	SYSTEM			3205	2002-10-25 09:52:18	source	A
31	aptp_desc	text	30		~*	Description	aptp	15	20	20	10			3175	2002-10-24 04:26:21	source	A
31	aptp_code	text	30		~*	Code	aptp	8	10	10	10			3173	2002-10-24 04:26:20	source	A
31	aptp_colour	text	30		~*	Colour	aptp	8	15	15	COLOUR			3174	2002-10-24 04:26:20	source	A
31	aptp_duration	int4	10		~*	Duration	aptp	8	30	30	10			3176	2002-10-24 04:26:21	source	A
31	aptp_disable	int4	30	\N	~*	Block	aptp	8	50	50	SELECT=0,No;1,Yes			3622	2005-01-13 11:08:19.197858	source	A
31	invc_hlfd_code	text	30	\N	~*	Health Fund	invc	10	270	31	10			3788	2005-01-26 16:14:09.798076	source	A
31	invc_ins_level	text	30	\N	~*	Ins Level	invc	10	280	32	10			3789	2005-01-26 16:14:09.798076	source	A
31	invc_healthnumb	text	30	\N	~*	Insurance No	invc	10	290	33	10			3790	2005-01-26 16:14:09.798076	source	A
31	invc_healthcard	text	30	\N	~*	Healthcard	invc	10	210	34	10			3773	2005-01-25 22:08:49.21177	source	A
31	invc_medicare	text	30	\N	~*	Medicare No	invc	10	300	34	10			4083	2005-09-14 11:33:05.93557	source	A
31	invc_claim_number	text	30	\N	~*	Claim No	invc	10	220	35	10			3774	2005-01-25 22:08:49.21177	source	A
31	invc_accident_date	timestamp	30	\N	~*	Accident Date	invc	10	230	36	10			3775	2005-01-25 22:08:49.21177	source	A
31	invc_reference_1	text	30	\N	~*	Ref 1	invc	10	240	37	10			3776	2005-01-25 22:08:49.21177	source	A
31	invc_reference_2	text	30	\N	~*	Ref 2	invc	10	250	38	10			3777	2005-01-25 22:08:49.21177	source	A
31	invc_reference_3	text	30	\N	~*	Ref 3	invc	10	260	39	10			3778	2005-01-25 22:08:49.21177	source	A
31	svpv_invc_medicare	text	30	\N	~*	Invc Medicare	svpv	30	260	260	10			4084	2005-09-14 11:33:07.058789	source	A
31	svpv_form_code	text	30	\N	~*	Form Code	svpv	30	790	790	10			4085	2005-09-14 11:33:07.058789	source	A
31	patn_amount_outstanding	numeric(12,2)	1	\N	=	Amount Outstanding	patn	30	370	370	RO	\N	\N	4086	2005-09-14 11:33:09.435788	source	A
31	patn_last_service	timestamp	1	\N	=	Last Service	patn	30	360	360	RO	\N	\N	4087	2005-09-14 11:33:09.941865	source	A
31	patn_last_visit	timestamp	1	\N	=	Last Visit	patn	30	350	350	RO	\N	\N	4088	2005-09-14 11:33:10.161473	source	A
31	evnv_starttime	timestamp	47		~*	Start	evnv	16	40	10	10			3161	2002-10-24 04:23:54	source	A
31	evnv_duration	interval	47		~*	Duration	evnv	47	50	20	10			3116	2002-10-24 04:23:41	source	A
31	evnv_desc	text	30		~*	Note	evnv	30	60	30	10			3115	2002-10-24 04:23:41	source	A
31	evnv_note_1	text	30	\N	~*	Note 1	evnv	30	100	40	10			4089	2005-09-14 11:49:07.4437	source	A
31	evnv_note_2	text	30	\N	~*	Note 2	evnv	30	110	50	10			4090	2005-09-14 11:49:07.4437	source	A
31	evnv_locn_code	text	30		~*	Location	evnv	30	64	60	FSL=30			3120	2002-10-24 04:23:42	source	A
31	evnv_aptp_code	text	30		~*	Type	evnv	30	55	70	FSL=20			3113	2002-10-24 04:23:40	source	A
31	evnv_apst_code	text	30		~*	Status	evnv	30	60	80	FSL=20			3111	2002-10-24 04:23:40	source	A
31	evnv_patn__sequence	int4	10		~*	Patient ID	evnv	12	75	110	RO			3122	2002-10-24 04:23:43	source	A
31	evnv_patn_psnam	text	30		~*	Surname	evnv	30	80	120	10			3136	2002-10-24 04:23:47	source	A
31	evnv_patn_fsnam	text	30		~*	Firstname	evnv	30	90	130	10			3132	2002-10-24 04:23:46	source	A
31	evnv_patn_title	text	30		~*	Title	evnv	30	100	140	10			3140	2002-10-24 04:23:48	source	A
31	evnv_patn_dob	text	30		~*	DOB	evnv	30	110	150	10			3130	2002-10-24 04:23:45	source	A
31	evnv_patn_address	text	30		~*	Address	evnv	30	120	160	10			3126	2002-10-24 04:23:44	source	A
31	evnv_patn_suburb	text	30		~*	Suburb	evnv	30	130	170	COPYTEXT=pcde;pcde_locality;pcde_postcode;evnv_patn_postcode			3139	2002-10-24 04:23:48	source	A
31	evnv_patn_postcode	text	30		~*	Postcode	evnv	30	150	180	COPYTEXT=pcde;pcde_postcode;pcde_locality;evnv_patn_suburb			3135	2002-10-24 04:23:47	source	A
31	evnv_patn_phone	text	30		~*	Phone	evnv	30	160	180	10			3134	2002-10-24 04:23:46	source	A
31	evnv_patn_flno	text	30		~*	Patient UR	evnv	30	70	200	10			3131	2002-10-24 04:23:46	source	A
31	evnv_patn_ref_date	timestamp	30	\N	~*	Referral Date	evnv	30	240	210	10			3358	2004-03-28 13:55:51.141465	source	A
31	evnv_patn_ref_period	int4	30	\N	~*	Referral Period	evnv	30	250	220	10			3359	2004-03-28 13:55:51.141465	source	A
31	evnv_patn_last_visit	timestamp	30	\N	~*	Last Visit	evnv	30	260	230	RO			3360	2004-03-28 13:55:51.141465	source	A
31	evnv_patn_amount_outstanding	numeric	786434	\N	~*	Amount Owing	evnv	786434	270	240	RO			3361	2004-03-28 13:55:51.141465	source	A
31	evnv_prov_code	text	30		~*	Provider	evnv	30	62	250	FSL=20			3143	2002-10-24 04:23:49	source	A
31	evnv_rfdr_code	text	30		~*	Referrer Code	evnv	30	290	260	10			3151	2002-10-24 04:23:51	source	A
31	evnv_ev_time	text	30		~*	Ev Time	evnv	30	70	1000	SYSTEM			3119	2002-10-24 04:23:42	source	A
31	evnv_ev_date	text	30		~*	Ev Date	evnv	30	80	1010	SYSTEM			3117	2002-10-24 04:23:42	source	A
31	evnv_ev_minutes	float8	24		~*	Ev Minutes	evnv	24	90	1020	SYSTEM			3118	2002-10-24 04:23:42	source	A
31	evnv_patn_desc	text	30		~*	Patn Desc	evnv	30	100	1030	SYSTEM			3129	2002-10-24 04:23:45	source	A
31	evnv_patn_state	text	30		~*	Patn State	evnv	30	140	1040	SYSTEM			3138	2002-10-24 04:23:48	source	A
31	evnv_patn_desc_comp	text	30	\N	~*	Patn Desc Comp	evnv	30	170	1050	SYSTEM			4091	2005-09-14 11:49:07.4437	source	A
31	evnv_locn_desc	text	30		~*	Location Name	evnv	30	180	1080	SYSTEM			3121	2002-10-24 04:23:43	source	A
31	evnv_prov_provider_num	text	30		~*	Provider Number	evnv	30	200	1090	SYSTEM			3147	2002-10-24 04:23:50	source	A
31	evnv_prov_name	text	30		~*	Provider Name	evnv	30	210	1100	SYSTEM			3144	2002-10-24 04:23:49	source	A
31	evnv_prov_address	text	30		~*	Provider Address	evnv	30	220	1120	SYSTEM			3141	2002-10-24 04:23:48	source	A
31	evnv_prov_suburb	text	30		~*	Provider Suburb	evnv	30	230	1130	SYSTEM			3150	2002-10-24 04:23:51	source	A
31	evnv_prov_state	text	30		~*	Provider State	evnv	30	240	1140	SYSTEM			3149	2002-10-24 04:23:51	source	A
31	evnv_aptp_desc	text	30		~*	Aptp Desc	evnv	30	240	1150	SYSTEM			3114	2002-10-24 04:23:41	source	A
31	evnv_prov_postcode	text	30		~*	Provider PC	evnv	30	250	1160	SYSTEM			3146	2002-10-24 04:23:50	source	A
31	evnv_apst_desc	text	30		~*	Apst Desc	evnv	30	250	1170	SYSTEM			3112	2002-10-24 04:23:40	source	A
31	evnv_prov_salutation	text	30		~*	Provider Salutation	evnv	30	260	1180	SYSTEM			3148	2002-10-24 04:23:51	source	A
31	evnv_prov_phone	text	30		~*	Prov Phone	evnv	30	270	1190	SYSTEM			3145	2002-10-24 04:23:50	source	A
31	evnv_prov_bank_code	text	30		~*	Prov Bank Code	evnv	30	280	1200	SYSTEM			3142	2002-10-24 04:23:49	source	A
31	evnv_rfdr_name	text	30		~*	Referrer Name	evnv	30	300	1210	SYSTEM			3153	2002-10-24 04:23:52	source	A
31	evnv_rfdr_street	text	30		~*	Referrer Street	evnv	30	310	1220	SYSTEM			3159	2002-10-24 04:23:54	source	A
31	evnv_rfdr_suburb	text	30		~*	Referrer Suburb	evnv	30	320	1230	SYSTEM			3160	2002-10-24 04:23:54	source	A
31	evnv_rfdr_postcode	text	30		~*	Referrer Postcode	evnv	30	330	1240	SYSTEM			3155	2002-10-24 04:23:53	source	A
31	evnv_rfdr_state	text	30		~*	Referrer State	evnv	30	340	1250	SYSTEM			3158	2002-10-24 04:23:53	source	A
31	evnv_rfdr_provider	text	30		~*	Referrer Provider Number	evnv	30	350	1260	SYSTEM			3156	2002-10-24 04:23:53	source	A
31	evnv_rfdr_phone	text	30		~*	Referrer Phone	evnv	30	360	1270	SYSTEM			3154	2002-10-24 04:23:52	source	A
31	evnv_rfdr_salutation	text	30		~*	Referrer Salutation	evnv	30	370	1280	SYSTEM			3157	2002-10-24 04:23:53	source	A
31	evnv_rfdr_index	text	30		~*	Referrer Index	evnv	30	380	1290	SYSTEM			3152	2002-10-24 04:23:52	source	A
31	evnv_patn_country	text	30		~*	Country	evnv	30	390	1300	SYSTEM			3128	2002-10-24 04:23:45	source	A
31	evnv_patn_aboriginality	bpchar	1		~*	Aboriginality	evnv	1	400	1310	SYSTEM			3123	2002-10-24 04:23:43	source	A
31	evnv_patn_sex	bpchar	1		~*	Sex	evnv	1	410	1320	SYSTEM			3137	2002-10-24 04:23:47	source	A
31	evnv_patn_marital	bpchar	1		~*	Marital	evnv	1	420	1330	SYSTEM			3133	2002-10-24 04:23:46	source	A
31	evnv_patn_accl_code	text	30		~*	Account Class	evnv	30	430	1340	SYSTEM			3124	2002-10-24 04:23:44	source	A
31	evnv_patn_accommodation	bpchar	1		~*	Accommodation	evnv	1	440	1350	SYSTEM			3125	2002-10-24 04:23:44	source	A
31	evnv_patn_care	bpchar	1		~*	Care	evnv	1	450	1360	SYSTEM			3127	2002-10-24 04:23:44	source	A
31	evnv_patn_hlfd_code	text	30	\N	~*	Patn Hlfd Code	evnv	30	490	1380	SYSTEM			3628	2005-01-13 11:08:19.950556	source	A
31	evnv_patn_ins_level	bpchar	1	\N	~*	Patn Ins Level	evnv	1	500	1400	SYSTEM			3629	2005-01-13 11:08:19.950556	source	A
31	evnv_patn_healthnumb	text	30	\N	~*	Patn Healthnumb	evnv	30	510	1420	SYSTEM			3630	2005-01-13 11:08:19.950556	source	A
31	evnv_patn_medicare	text	30	\N	~*	Patn Medicare	evnv	30	520	1440	SYSTEM			3631	2005-01-13 11:08:19.950556	source	A
31	evnv_patn_feet_code	text	30	\N	~*	Patn Feet Code	evnv	30	520	1450	SYSTEM			4092	2005-09-14 11:49:07.4437	source	A
31	evnv_patn_healthcard	text	30	\N	~*	Patn Healthcard	evnv	30	530	1460	SYSTEM			3632	2005-01-13 11:08:19.950556	source	A
31	ptss__status	text	30	\N	~*	Status	ptss	30	90	90	SYSTEM			3329	2004-03-28 13:55:44.534516	source	A
31	feel__sequence	int4	30	\N	~*	Sequence	feel	12	220	220	SYSTEM			3656	2005-01-13 11:08:20.560366	source	A
31	evwl__sequence	int4	30	\N	~*	ID	evwl	10	160	160	SYSTEM			3479	2004-08-04 09:26:24.604655	source	A
31	sclt__sequence	int4	30	\N	~*	Sequence	sclt	30	140	140	SYSTEM			3585	2004-09-21 11:16:10.027454	source	A
31	sclt__timestamp	timestamp	30	\N	~*	Timestamp	sclt	30	150	150	SYSTEM			3586	2004-09-21 11:16:10.027454	source	A
31	sclt__user_entry	text	30	\N	~*	User Entry	sclt	30	160	160	SYSTEM			3587	2004-09-21 11:16:10.027454	source	A
31	sclt__status	bpchar	1	\N	~*	Status	sclt	1	170	170	SYSTEM			3588	2004-09-21 11:16:10.027454	source	A
31	pemd__sequence	int4	30	\N	~*	Sequence	pemd	30	20	20	SYSTEM			3590	2004-09-21 12:42:31.891074	source	A
31	pemd__timestamp	timestamp	30	\N	~*	Timestamp	pemd	30	30	30	SYSTEM			3591	2004-09-21 12:42:31.891074	source	A
31	pemd__user_entry	text	30	\N	~*	User Entry	pemd	30	40	40	SYSTEM			3592	2004-09-21 12:42:31.891074	source	A
31	pemd__status	bpchar	1	\N	~*	Status	pemd	1	50	50	SYSTEM			3593	2004-09-21 12:42:31.891074	source	A
31	svsm__sequence	int4	30	\N	~*	Sequence	svsm	30	110	110	SYSTEM			3604	2004-09-21 13:08:45.650712	source	A
31	svsm__timestamp	timestamp	30	\N	~*	Timestamp	svsm	30	120	120	SYSTEM			3605	2004-09-21 13:08:45.650712	source	A
31	svsm__user_entry	text	30	\N	~*	User Entry	svsm	30	130	130	SYSTEM			3606	2004-09-21 13:08:45.650712	source	A
31	svsm__status	bpchar	1	\N	~*	Status	svsm	1	140	140	SYSTEM			3607	2004-09-21 13:08:45.650712	source	A
31	crsm__sequence	int4	30	\N	~*	Sequence	crsm	30	110	110	SYSTEM			3618	2004-09-21 13:34:37.289103	source	A
31	crsm__timestamp	timestamp	30	\N	~*	Timestamp	crsm	30	120	120	SYSTEM			3619	2004-09-21 13:34:37.289103	source	A
31	crsm__user_entry	text	30	\N	~*	User Entry	crsm	30	130	130	SYSTEM			3620	2004-09-21 13:34:37.289103	source	A
31	crsm__status	bpchar	1	\N	~*	Status	crsm	1	140	140	SYSTEM			3621	2004-09-21 13:34:37.289103	source	A
31	feel__timestamp	timestamp	30	\N	~*	Timestamp	feel	12	230	230	SYSTEM			3657	2005-01-13 11:08:20.560366	source	A
31	feel__user_entry	text	30	\N	~*	User Entry	feel	12	240	240	SYSTEM			3658	2005-01-13 11:08:20.560366	source	A
31	feel__status	bpchar	1	\N	~*	Status	feel	12	250	250	SYSTEM			3659	2005-01-13 11:08:20.560366	source	A
31	gsti__sequence	int4	30	\N	~*	Sequence	gsti	30	370	370	SYSTEM			3696	2005-01-13 11:08:20.741506	source	A
31	gsti__timestamp	timestamp	30	\N	~*	Timestamp	gsti	30	380	380	SYSTEM			3697	2005-01-13 11:08:20.741506	source	A
31	gsti__user_entry	text	30	\N	~*	User Entry	gsti	30	390	390	SYSTEM			3698	2005-01-13 11:08:20.741506	source	A
31	gsti__status	bpchar	1	\N	~*	Status	gsti	1	400	400	SYSTEM			3699	2005-01-13 11:08:20.741506	source	A
31	svlt__sequence	int4	30	\N	~*	Sequence	svlt	30	670	670	SYSTEM			3447	2004-03-28 13:56:01.656419	source	A
31	svlt__timestamp	timestamp	30	\N	~*	Timestamp	svlt	30	680	680	SYSTEM			3448	2004-03-28 13:56:01.656419	source	A
31	ssmp__user_entry	name	1		~*	Entered by	ssmp	10	10	0	SYSTEM			2196	2001-10-19 12:31:36	source	A
31	ssmc__sequence	int4	1		~*	Sequence	ssmc	10	10	0	SYSTEM			2202	2001-10-19 12:31:43	source	A
31	ssmc__status	text	1		~*	Status	ssmc	10	10	0	SYSTEM			2203	2001-10-19 12:31:43	source	A
31	ssmc__timestamp	timestamp	1		~*	Timestamp	ssmc	10	10	0	SYSTEM			2204	2001-10-19 12:31:44	source	A
2	stts__timestamp	timestamp	0		=	Timestamp	stts	30	0	210	SYSTEM			2099	2001-10-19 12:30:14	source	A
31	pmsc__sequence	int4	1		~*	Sequence	pmsc	10	10	0	SYSTEM			2164	2001-10-19 12:31:11	source	A
31	pmsc__status	text	1		~*	Status	pmsc	10	10	0	SYSTEM			2165	2001-10-19 12:31:12	source	A
31	pmsc__timestamp	timestamp	1		~*	Date	pmsc	10	10	10	SYSTEM			2166	2001-10-19 12:31:12	source	A
31	pmsc__user_entry	name	1		~*	Entered by	pmsc	10	10	0	SYSTEM			2167	2001-10-19 12:31:13	source	A
31	pmsp__sequence	int4	1		~*	Sequence	pmsp	10	10	0	SYSTEM			2174	2001-10-19 12:31:20	source	A
31	pmsp__status	text	1		~*	Status	pmsp	10	10	0	SYSTEM			2175	2001-10-19 12:31:20	source	A
31	tdtp__sequence	int4	1		~*	tdtp__sequence	tdtp	10	0	0	SYSTEM			2119	2001-10-19 12:30:31	source	A
31	svlt__user_entry	text	30	\N	~*	User Entry	svlt	30	690	690	SYSTEM			3449	2004-03-28 13:56:01.656419	source	A
31	svlt__status	bpchar	1	\N	~*	Status	svlt	1	700	700	SYSTEM			3450	2004-03-28 13:56:01.656419	source	A
31	agdd__sequence	int4	1		~*	Row-ID	agdd	10	50	50	SYSTEM			2142	2001-10-19 12:30:50	source	A
31	agdd__status	bpchar	1		~*	Status	agdd	1	80	80	SYSTEM			2143	2001-10-19 12:30:51	source	A
31	agdd__timestamp	timestamp	1		~*	Timestamp	agdd	30	60	60	SYSTEM			2144	2001-10-19 12:30:51	source	A
31	agdd__user_entry	text	1		~*	Created by	agdd	10	70	70	SYSTEM			2145	2001-10-19 12:30:51	source	A
31	agdp__sequence	int4	1		~*	Row-ID	agdp	10	40	40	SYSTEM			2150	2001-10-19 12:30:58	source	A
31	agdp__status	bpchar	1		~*	Status	agdp	1	70	70	SYSTEM			2151	2001-10-19 12:30:58	source	A
31	agdp__timestamp	timestamp	1		~*	Timestamp	agdp	30	50	50	SYSTEM			2152	2001-10-19 12:30:59	source	A
31	agdp__user_entry	text	1		~*	Created by	agdp	10	60	60	SYSTEM			2153	2001-10-19 12:30:59	source	A
31	agdi__sequence	int4	1		~*	Row-ID	agdi	10	100	100	SYSTEM			2129	2001-10-19 12:30:39	source	A
31	agdi__status	bpchar	1		~*	Status	agdi	1	130	130	SYSTEM			2130	2001-10-19 12:30:40	source	A
31	agdi__timestamp	timestamp	1		~*	Timestamp	agdi	30	110	110	SYSTEM			2131	2001-10-19 12:30:40	source	A
31	agdi__user_entry	text	1		~*	Created by	agdi	10	120	120	SYSTEM			2132	2001-10-19 12:30:41	source	A
31	agdt__status	bpchar	1		~*	Status	agdt	1	70	70	SYSTEM			2158	2001-10-19 12:31:05	source	A
2	patv__sequence	integer	0		=	Row-ID	patv	12	0	310	SYSTEM			2385	2001-10-19 12:33:25	source	A
2	patv__status	char	0		~*	Record status	patv	12	0	340	SYSTEM			2386	2001-10-19 12:33:26	source	A
2	patv__user_entry	text	0		~*	Entered by	patv	12	0	330	SYSTEM			2388	2001-10-19 12:33:27	source	A
31	dbag__sequence	int4	10		~*	Sequence	dbag	10	140	140	SYSTEM			2290	2001-10-19 12:32:37	source	A
31	dbag__status	bpchar	1		~*	Status	dbag	1	170	170	SYSTEM			2291	2001-10-19 12:32:37	source	A
31	dbag__timestamp	timestamp	47		~*	Timestamp	dbag	47	150	150	SYSTEM			2292	2001-10-19 12:32:38	source	A
31	dbag__user_entry	text	30		~*	User Entry	dbag	30	160	160	SYSTEM			2293	2001-10-19 12:32:38	source	A
31	cnrv__sequence	int4	10		~*	Sequence	cnrv	10	130	130	SYSTEM			2307	2001-10-19 12:32:47	source	A
31	cnrv__status	bpchar	1		~*	Status	cnrv	1	160	160	SYSTEM			2308	2001-10-19 12:32:47	source	A
31	cnrv__timestamp	timestamp	47		~*	Timestamp	cnrv	47	140	140	SYSTEM			2309	2001-10-19 12:32:48	source	A
31	cnrv__user_entry	text	30		~*	User Entry	cnrv	30	150	150	SYSTEM			2310	2001-10-19 12:32:48	source	A
31	crep__sequence	int4	10		~*	Credit ID	crep	10	10	1000	SYSTEM			2238	2001-10-19 12:32:09	source	A
31	crep__status	bpchar	1		~*	Status	crep	10	10	1010	SYSTEM			2239	2001-10-19 12:32:10	source	A
31	crep__timestamp	timestamp	47		~*	Timestamp	crep	10	10	1020	SYSTEM			2240	2001-10-19 12:32:10	source	A
31	crep__user_entry	text	30		~*	User Entry	crep	10	10	1030	SYSTEM			2241	2001-10-19 12:32:11	source	A
31	dbst__sequence	int4	10		~*	Sequence	dbst	10	230	230	SYSTEM			2263	2001-10-19 12:32:23	source	A
31	dbst__status	bpchar	1		~*	Status	dbst	1	260	260	SYSTEM			2264	2001-10-19 12:32:24	source	A
31	dbst__timestamp	timestamp	47		~*	Timestamp	dbst	47	240	240	SYSTEM			2265	2001-10-19 12:32:24	source	A
31	dbst__user_entry	text	30		~*	User Entry	dbst	30	250	250	SYSTEM			2266	2001-10-19 12:32:24	source	A
31	ssms__timestamp	timestamp	1		~*	Timestamp	ssms	30	10	0	SYSTEM			2185	2001-10-19 12:31:28	source	A
31	ssms__user_entry	name	1		~*	Entered by	ssms	10	10	0	SYSTEM			2186	2001-10-19 12:31:28	source	A
31	ssmp__sequence	int4	1		~*	Sequence	ssmp	10	10	0	SYSTEM			2193	2001-10-19 12:31:35	source	A
31	ssmp__status	text	1		~*	Status	ssmp	10	10	0	SYSTEM			2194	2001-10-19 12:31:36	source	A
31	ssmp__timestamp	timestamp	1		~*	Timestamp	ssmp	10	10	0	SYSTEM			2195	2001-10-19 12:31:36	source	A
31	ssmc__user_entry	name	1		~*	Entered By	ssmc	10	10	0	SYSTEM			2205	2001-10-19 12:31:44	source	A
31	crev__sequence	int4	10		~*	Sequence	crev	10	10	1010	SYSTEM			2212	2001-10-19 12:31:51	source	A
31	crev__status	bpchar	1		~*	Status	crev	10	10	1020	SYSTEM			2213	2001-10-19 12:31:52	source	A
31	crev__timestamp	timestamp	47		~*	Timestamp	crev	10	10	1030	SYSTEM			2214	2001-10-19 12:31:52	source	A
31	crev__user_entry	text	30		~*	User Entry	crev	10	10	1040	SYSTEM			2215	2001-10-19 12:31:53	source	A
31	fept__sequence	int4	10		~*	Sequence	fept	10	70	70	SYSTEM			2228	2001-10-19 12:32:02	source	A
31	fept__status	text	30		~*	Status	fept	30	100	100	SYSTEM			2229	2001-10-19 12:32:02	source	A
31	fept__timestamp	timestamp	47		~*	Timestamp	fept	47	80	80	SYSTEM			2230	2001-10-19 12:32:03	source	A
31	fept__user_entry	name	32		~*	User Entry	fept	32	90	90	SYSTEM			2231	2001-10-19 12:32:03	source	A
31	pmsp__timestamp	timestamp	1		~*	Timestamp	pmsp	10	10	0	SYSTEM			2176	2001-10-19 12:31:20	source	A
31	pmsp__user_entry	name	1		~*	Entered by	pmsp	10	10	0	SYSTEM			2177	2001-10-19 12:31:21	source	A
31	ssms__sequence	int4	1		~*	Sequence	ssms	10	10	0	SYSTEM			2183	2001-10-19 12:31:27	source	A
31	ssms__status	text	1		~*	Status	ssms	1	10	0	SYSTEM			2184	2001-10-19 12:31:27	source	A
2	stts__sequence	integer	0		=	Row-ID	stts	30	0	200	SYSTEM			2097	2001-10-19 12:30:13	source	A
2	stts__status	char	0		~*	Record status	stts	30	0	230	SYSTEM			2098	2001-10-19 12:30:13	source	A
2	stts__user_entry	text	0		~*	Entered by	stts	30	0	220	SYSTEM			2100	2001-10-19 12:30:14	source	A
31	tdtp__status	bpchar	1		~*	tdtp__status	tdtp	10	0	0	SYSTEM			2120	2001-10-19 12:30:32	source	A
31	tdtp__user_entry	text	1		~*	tdtp__user_entry	tdtp	10	0	0	SYSTEM			2122	2001-10-19 12:30:32	source	A
31	tdtp__timestamp	timestamp	1		~*	tdtp__timestamp	tdtp	10	0	0	SYSTEM			2121	2001-10-19 12:30:32	source	A
31	prnt__timestamp	timestamp	1		~*	prnt__timestamp	prnt	0	0	0	SYSTEM			2047	2001-10-19 12:29:31	source	A
2	pyas__timestamp	timestamp	0		=	Timestamp	pyas	30	0	210	SYSTEM			2070	2001-10-19 12:29:48	source	A
31	prnt__status	bpchar	1		~*	prnt__status	prnt	0	0	0	SYSTEM			2046	2001-10-19 12:29:31	source	A
31	prnt__user_entry	text	1		~*	prnt__user_entry	prnt	0	0	0	SYSTEM			2048	2001-10-19 12:29:31	source	A
2	pyas__sequence	integer	0		=	Row-ID	pyas	30	0	200	SYSTEM			2068	2001-10-19 12:29:47	source	A
2	pyas__status	char	0		~*	Record status	pyas	30	0	230	SYSTEM			2069	2001-10-19 12:29:48	source	A
2	pyas__user_entry	text	0		~*	Entered by	pyas	30	0	220	SYSTEM			2071	2001-10-19 12:29:49	source	A
2	rfdr__sequence	integer	0		=	Row-ID	rfdr	30	0	200	SYSTEM			2075	2001-10-19 12:29:53	source	A
2	rfdr__status	char	0		~*	Record status	rfdr	30	0	230	SYSTEM			2076	2001-10-19 12:29:54	source	A
2	rfdr__user_entry	text	0		~*	Entered by	rfdr	30	0	220	SYSTEM			2078	2001-10-19 12:29:54	source	A
2	serv__sequence	integer	0		=	Row-ID	serv	30	0	200	SYSTEM			2089	2001-10-19 12:30:04	source	A
2	serv__status	char	0		~*	Record status	serv	30	0	230	SYSTEM			2090	2001-10-19 12:30:04	source	A
2	serv__user_entry	text	0		~*	Entered by	serv	30	0	220	SYSTEM			2092	2001-10-19 12:30:05	source	A
31	svpv__sequence	int4	10		~*	Sequence	svpv	10	270	270	SYSTEM			2766	2002-02-09 08:02:15	source	A
31	svpv__status	bpchar	1		~*	Status	svpv	1	300	300	SYSTEM			2767	2002-02-09 08:02:15	source	A
31	svpv__timestamp	timestamp	47		~*	Timestamp	svpv	47	280	280	SYSTEM			2768	2002-02-09 08:02:16	source	A
31	svpv__user_entry	text	30		~*	User Entry	svpv	30	290	290	SYSTEM			2769	2002-02-09 08:02:16	source	A
31	mtat__sequence	int4	0		~*	attribute__sequence	mtat	10	0	200	SYSTEM			136	2001-10-10 12:25:01	source	A
31	mtat__status	bpchar	0		~*	attribute__status	mtat	10	0	200	SYSTEM	N		137	2001-10-10 12:25:02	source	A
31	mtat__user_entry	text	0		~*	attribute__user_entry	mtat	10	0	200	SYSTEM	CURRENT_USER		139	2001-10-10 12:25:03	source	A
31	prnt__sequence	int4	1		=	prnt__sequence	prnt	10	0	0	SYSTEM			2045	2001-10-19 12:29:30	source	A
2	mdcr__sequence	integer	0		=	Row-ID	mdcr	30	0	200	SYSTEM			1986	2001-10-19 12:28:43	source	A
2	mdcr__status	char	0		~*	Record status	mdcr	30	0	230	SYSTEM			1987	2001-10-19 12:28:43	source	A
2	mdcr__user_entry	text	0		~*	Entered by	mdcr	30	0	220	SYSTEM			1989	2001-10-19 12:28:44	source	A
2	note__sequence	integer	0		=	Row-ID	note	30	0	200	SYSTEM			1993	2001-10-19 12:28:49	source	A
2	note__status	char	0		~*	Record status	note	30	0	230	SYSTEM			1994	2001-10-19 12:28:49	source	A
2	note__user_entry	text	0		~*	Entered by	note	30	0	220	SYSTEM			1996	2001-10-19 12:28:50	source	A
31	locn__sequence	int4	10		~*	Sequence	locn	10	30	30	SYSTEM			3162	2002-10-24 04:26:09	source	A
31	labl__sequence	int4	1		~*	labl__sequence	labl	10	1000	1000	SYSTEM			1933	2001-10-19 12:28:06	source	A
31	labl__status	bpchar	1		~*	labl__status	labl	1	1000	1000	SYSTEM			1934	2001-10-19 12:28:07	source	A
31	labl__timestamp	timestamp	1		~*	labl__timestamp	labl	20	1000	1000	SYSTEM			1935	2001-10-19 12:28:07	source	A
31	labl__user_entry	text	1		~*	labl__user_entry	labl	10	1000	1000	SYSTEM			1936	2001-10-19 12:28:07	source	A
2	lthd__sequence	integer	0		=	Row-ID	lthd	30	0	200	SYSTEM			1944	2001-10-19 12:28:14	source	A
2	lthd__status	char	0		~*	Record status	lthd	30	0	230	SYSTEM			1945	2001-10-19 12:28:14	source	A
2	lthd__user_entry	text	0		~*	Entered by	lthd	30	0	220	SYSTEM			1947	2001-10-19 12:28:15	source	A
31	locn__status	bpchar	1		~*	Status	locn	1	60	60	SYSTEM			3163	2002-10-24 04:26:10	source	A
31	locn__timestamp	timestamp	47		~*	Timestamp	locn	47	40	40	SYSTEM			3164	2002-10-24 04:26:10	source	A
31	locn__user_entry	text	30		~*	User Entry	locn	30	50	50	SYSTEM			3165	2002-10-24 04:26:10	source	A
2	feeb__sequence	integer	0		=	Row-ID	feeb	30	0	200	SYSTEM			1870	2001-10-19 12:26:30	source	A
2	feeb__status	char	0		~*	Record status	feeb	30	0	230	SYSTEM			1871	2001-10-19 12:26:31	source	A
2	feeb__user_entry	text	0		~*	Entered by	feeb	30	0	220	SYSTEM			1873	2001-10-19 12:26:32	source	A
2	feet__sequence	integer	0		=	Row-ID	feet	30	0	200	SYSTEM			1877	2001-10-19 12:26:37	source	A
2	feet__status	char	0		~*	Record status	feet	30	0	230	SYSTEM			1878	2001-10-19 12:26:38	source	A
2	feet__user_entry	text	0		~*	Entered by	feet	30	0	220	SYSTEM			1880	2001-10-19 12:26:38	source	A
2	hlfd__sequence	integer	0		=	Row-ID	hlfd	30	0	200	SYSTEM			1883	2001-10-19 12:26:55	source	A
2	hlfd__status	char	0		~*	Record status	hlfd	30	0	230	SYSTEM			1884	2001-10-19 12:26:59	source	A
2	hlfd__user_entry	text	0		~*	Entered by	hlfd	30	0	220	SYSTEM			1886	2001-10-19 12:27:00	source	A
2	icd9__sequence	integer	0		=	Row-ID	icd9	30	200	200	SYSTEM			1889	2001-10-19 12:27:15	source	A
2	icd9__status	char	0		~*	Record status	icd9	30	200	230	SYSTEM			1890	2001-10-19 12:27:15	source	A
2	icd9__user_entry	text	0		~*	Entered by	icd9	30	200	220	SYSTEM			1892	2001-10-19 12:27:21	source	A
2	inst__sequence	integer	0		=	Row-ID	inst	30	0	200	SYSTEM			1903	2001-10-19 12:27:38	source	A
2	inst__status	char	0		~*	Record status	inst	30	0	230	SYSTEM			1904	2001-10-19 12:27:39	source	A
2	inst__user_entry	text	0		~*	Entered by	inst	30	0	220	SYSTEM			1906	2001-10-19 12:27:40	source	A
31	docs__sequence	int4	10		~*	Document ID	docs	10	40	40	SYSTEM			1820	2001-10-19 12:25:54	source	A
31	docs__status	bpchar	1		~*	Status	docs	1	70	70	SYSTEM			1821	2001-10-19 12:25:55	source	A
31	docs__user_entry	text	30		~*	Created by	docs	30	60	60	SYSTEM			1823	2001-10-19 12:25:56	source	A
2	empl__sequence	integer	0		=	Row-ID	empl	30	0	200	SYSTEM			1827	2001-10-19 12:26:01	source	A
2	empl__status	char	0		~*	Record status	empl	30	0	230	SYSTEM			1828	2001-10-19 12:26:01	source	A
2	empl__user_entry	text	0		~*	Entered by	empl	30	0	220	SYSTEM			1830	2001-10-19 12:26:02	source	A
2	epsd__sequence	integer	0		=	Row-ID	epsd	30	0	230	SYSTEM			1837	2001-10-19 12:26:10	source	A
2	epsd__status	char	0		~*	Record status	epsd	30	0	260	SYSTEM			1838	2001-10-19 12:26:10	source	A
2	epsd__user_entry	text	0		~*	Entered by	epsd	30	0	250	SYSTEM			1840	2001-10-19 12:26:11	source	A
2	cnty__sequence	integer	0		=	Row-ID	cnty	30	0	200	SYSTEM			1775	2001-10-19 12:25:19	source	A
2	cnty__status	char	0		~*	Record status	cnty	30	0	230	SYSTEM			1776	2001-10-19 12:25:19	source	A
2	cnty__user_entry	text	0		~*	Entered by	cnty	30	0	220	SYSTEM			1778	2001-10-19 12:25:20	source	A
2	conf__sequence	integer	0		=	Row-ID	conf	30	0	200	SYSTEM			1781	2001-10-19 12:25:24	source	A
2	conf__status	char	0		~*	Record status	conf	30	0	230	SYSTEM			1782	2001-10-19 12:25:24	source	A
2	conf__user_entry	text	0		~*	Entered by	conf	30	0	220	SYSTEM			1784	2001-10-19 12:25:25	source	A
2	cred__sequence	integer	0		=	Row-ID	cred	30	0	200	SYSTEM			1791	2001-10-19 12:25:31	source	A
2	cred__status	char	0		~*	Record status	cred	30	0	230	SYSTEM			1792	2001-10-19 12:25:31	source	A
2	cred__user_entry	text	0		~*	Entered by	cred	30	0	220	SYSTEM			1794	2001-10-19 12:25:32	source	A
31	fmdt__user_entry	text	30		~*	User Entry	fmdt	30	300	300	SYSTEM			200	2001-10-10 12:25:45	source	A
2	dbtr__sequence	integer	0		=	Row-ID	dbtr	30	0	200	SYSTEM			1799	2001-10-19 12:25:38	source	A
2	dbtr__status	char	0		~*	Record status	dbtr	30	0	230	SYSTEM			1800	2001-10-19 12:25:38	source	A
2	dbtr__user_entry	text	0		~*	Entered by	dbtr	30	0	220	SYSTEM			1802	2001-10-19 12:25:39	source	A
2	diag__sequence	integer	0		=	Row-ID	diag	30	0	200	SYSTEM			1810	2001-10-19 12:25:48	source	A
2	diag__status	char	0		~*	Record status	diag	30	0	230	SYSTEM			1811	2001-10-19 12:25:48	source	A
2	diag__user_entry	text	0		~*	Entered by	diag	30	0	220	SYSTEM			1813	2001-10-19 12:25:49	source	A
31	mtfn__status	bpchar	0		~*	foreign__status	mtfn	10	0	200	SYSTEM	N		155	2001-10-10 12:25:15	source	A
31	mtfn__user_entry	text	0		~*	foreign__user_entry	mtfn	10	0	200	SYSTEM	CURRENT_USER		157	2001-10-10 12:25:16	source	A
31	mtrl__sequence	int4	0		~*	relation__sequence	mtrl	10	0	200	SYSTEM			164	2001-10-10 12:25:23	source	A
31	mtrl__status	bpchar	0		~*	relation__status	mtrl	10	0	200	SYSTEM	N		165	2001-10-10 12:25:24	source	A
31	mtrl__user_entry	text	0		~*	relation__user_entry	mtrl	10	0	200	SYSTEM	CURRENT_USER		167	2001-10-10 12:25:25	source	A
31	fmdt__sequence	int4	10		~*	Sequence	fmdt	10	280	280	SYSTEM			197	2001-10-10 12:25:44	source	A
31	fmdt__status	bpchar	1		~*	Status	fmdt	1	310	310	SYSTEM			198	2001-10-10 12:25:44	source	A
31	fmdt__timestamp	timestamp	47		~*	Timestamp	fmdt	47	290	290	SYSTEM			199	2001-10-10 12:25:45	source	A
31	mtsv__sequence	oid	10	\N	~*	Sequence	mtsv	10	60	60	SYSTEM			115	2001-10-10 12:24:25	source	A
31	mtsv__timestamp	timestamp	47	\N	~*	Timestamp	mtsv	47	70	70	SYSTEM			116	2001-10-10 12:24:25	source	A
31	mtsv__user_entry	name	32	\N	~*	User Entry	mtsv	32	80	80	SYSTEM			117	2001-10-10 12:24:25	source	A
31	mtsv__status	bpchar	1	\N	~*	Status	mtsv	1	90	90	SYSTEM			118	2001-10-10 12:24:25	source	A
31	mtcl__sequence	int4	0		~*	class__sequence	mtcl	10	0	200	SYSTEM			119	2001-10-10 12:24:49	source	A
31	mtcl__status	bpchar	0		~*	class__status	mtcl	10	0	200	SYSTEM	N		120	2001-10-10 12:24:50	source	A
31	mtcl__user_entry	text	0		~*	class__user_entry	mtcl	10	0	200	SYSTEM	CURRENT_USER		122	2001-10-10 12:24:50	source	A
2	accl__sequence	integer	0		=	Row-ID	accl	30	0	200	SYSTEM			1708	2001-10-19 12:24:26	source	A
2	accl__status	char	0		~*	Record status	accl	30	0	230	SYSTEM			1709	2001-10-19 12:24:27	source	A
2	accl__user_entry	text	0		~*	Entered by	accl	30	0	220	SYSTEM			1711	2001-10-19 12:24:28	source	A
31	bank__sequence	int4	1		~*	Row-ID	bank	10	10	1000	SYSTEM			1714	2001-10-19 12:24:32	source	A
31	bank__status	bpchar	1		~*	Status	bank	1	10	1000	SYSTEM			1715	2001-10-19 12:24:32	source	A
31	bank__timestamp	timestamp	1		~*	Timestamp	bank	10	10	1000	SYSTEM			1716	2001-10-19 12:24:33	source	A
31	bank__user_entry	text	1		~*	Entered By	bank	10	10	1000	SYSTEM			1717	2001-10-19 12:24:33	source	A
31	mtfn__sequence	int4	0		~*	foreign__sequence	mtfn	10	0	200	SYSTEM			154	2001-10-10 12:25:15	source	A
2	bkdp__status	char	0		~*	Record status	bkdp	30	0	230	SYSTEM			1729	2001-10-19 12:24:42	source	A
2	bkdp__user_entry	text	0		~*	Entered by	bkdp	30	0	220	SYSTEM			1731	2001-10-19 12:24:43	source	A
2	cash__sequence	integer	0		=	Row-ID	cash	30	0	200	SYSTEM			1738	2001-10-19 12:24:49	source	A
2	cash__status	char	0		~*	Record status	cash	30	0	230	SYSTEM			1739	2001-10-19 12:24:50	source	A
2	cash__user_entry	text	0		~*	Entered by	cash	30	0	220	SYSTEM			1741	2001-10-19 12:24:51	source	A
31	gstv__sequence	int4	10		~*	Sequence	gstv	10	540	540	SYSTEM			2450	2001-10-23 15:35:03	source	A
31	gstv__status	bpchar	1		~*	Status	gstv	1	570	570	SYSTEM			2451	2001-10-23 15:35:03	source	A
31	gstv__timestamp	timestamp	47		~*	Timestamp	gstv	47	550	550	SYSTEM			2452	2001-10-23 15:35:03	source	A
31	gstv__user_entry	text	30		~*	User Entry	gstv	30	560	560	SYSTEM			2453	2001-10-23 15:35:04	source	A
2	clsp__sequence	integer	0		=	Row-ID	clsp	30	0	200	SYSTEM			1747	2001-10-19 12:24:56	source	A
2	clsp__status	char	0		~*	Record status	clsp	30	0	230	SYSTEM			1748	2001-10-19 12:24:57	source	A
2	clsp__user_entry	text	0		~*	Entered by	clsp	30	0	220	SYSTEM			1750	2001-10-19 12:24:58	source	A
2	clst__sequence	integer	0		=	Row-ID	clst	30	0	200	SYSTEM			1753	2001-10-19 12:25:02	source	A
2	clst__status	char	0		~*	Record status	clst	30	0	230	SYSTEM			1754	2001-10-19 12:25:02	source	A
2	clst__user_entry	text	0		~*	Entered by	clst	30	0	220	SYSTEM			1756	2001-10-19 12:25:03	source	A
31	cnrt__sequence	int4	10		~*	Sequence	cnrt	10	120	120	SYSTEM			1760	2001-10-19 12:25:09	source	A
31	cnrt__status	bpchar	1		~*	Status	cnrt	1	150	150	SYSTEM			1761	2001-10-19 12:25:10	source	A
31	cnrt__timestamp	timestamp	47		~*	Timestamp	cnrt	47	130	130	SYSTEM			1762	2001-10-19 12:25:10	source	A
31	cnrt__user_entry	text	30		~*	User Entry	cnrt	30	140	140	SYSTEM			1763	2001-10-19 12:25:10	source	A
31	patf__sequence	int4	10		~*	Sequence	patf	10	30	30	SYSTEM			2702	2002-02-09 08:01:44	source	A
31	patf__status	bpchar	1		~*	Status	patf	1	60	60	SYSTEM			2703	2002-02-09 08:01:44	source	A
31	patf__timestamp	timestamp	47		~*	Timestamp	patf	47	40	40	SYSTEM			2704	2002-02-09 08:01:45	source	A
31	patf__user_entry	text	30		~*	User Entry	patf	30	50	50	SYSTEM			2705	2002-02-09 08:01:45	source	A
31	eftr__sequence	int4	10		~*	Sequence	eftr	10	40	40	SYSTEM			2657	2002-02-09 08:01:28	source	A
31	eftr__status	bpchar	1		~*	Status	eftr	1	70	70	SYSTEM			2658	2002-02-09 08:01:29	source	A
31	eftr__timestamp	timestamp	47		~*	Timestamp	eftr	47	50	50	SYSTEM			2659	2002-02-09 08:01:29	source	A
31	eftr__user_entry	text	30		~*	User Entry	eftr	30	60	60	SYSTEM			2660	2002-02-09 08:01:29	source	A
31	eftv__sequence	int4	10		~*	Sequence	eftv	10	340	340	SYSTEM			2664	2002-02-09 08:01:32	source	A
31	eftv__status	bpchar	1		~*	Status	eftv	1	370	370	SYSTEM			2665	2002-02-09 08:01:32	source	A
31	eftv__timestamp	timestamp	47		~*	Timestamp	eftv	47	350	350	SYSTEM			2666	2002-02-09 08:01:32	source	A
31	eftv__user_entry	text	30		~*	User Entry	eftv	30	360	360	SYSTEM			2667	2002-02-09 08:01:33	source	A
2	prov__sequence	integer	0		=	Row-ID	prov	30	0	200	SYSTEM			3216	2002-10-25 09:57:37	source	A
2	prov__status	char	0		~*	Record status	prov	30	0	230	SYSTEM			3217	2002-10-25 09:57:37	source	A
2	prov__user_entry	text	0		~*	Entered by	prov	30	0	220	SYSTEM			3219	2002-10-25 09:57:38	source	A
31	apst__sequence	int4	10		~*	Sequence	apst	10	30	30	SYSTEM			3193	2002-10-24 04:26:40	source	A
31	apst__status	bpchar	1		~*	Status	apst	1	60	60	SYSTEM			3194	2002-10-24 04:26:41	source	A
31	apst__timestamp	timestamp	47		~*	Timestamp	apst	47	40	40	SYSTEM			3195	2002-10-24 04:26:41	source	A
31	apst__user_entry	text	30		~*	User Entry	apst	30	50	50	SYSTEM			3196	2002-10-24 04:26:41	source	A
31	evnt__sequence	int4	10		~*	Sequence	evnt	10	50	50	SYSTEM			3094	2002-10-24 04:23:29	source	A
31	evnt__status	bpchar	1		~*	Status	evnt	1	80	80	SYSTEM			3095	2002-10-24 04:23:29	source	A
31	evnt__timestamp	timestamp	47		~*	Creation time	evnt	47	60	60	SYSTEM			3096	2002-10-24 04:23:30	source	A
31	evnt__user_entry	text	30		~*	Created by	evnt	30	70	70	SYSTEM			3097	2002-10-24 04:23:30	source	A
31	notv__sequence	int4	10		~*	Note ID	notv	10	220	220	SYSTEM			3231	2003-03-13 15:31:02.238633	source	A
31	notv__status	bpchar	1		~*	Status	notv	1	250	250	SYSTEM			3232	2003-03-13 15:31:02.512671	source	A
31	notv__timestamp	timestamp	47		~*	Timestamp	notv	47	230	230	SYSTEM			3233	2003-03-13 15:31:02.516433	source	A
31	notv__user_entry	text	30		~*	User Entry	notv	30	240	240	SYSTEM			3234	2003-03-13 15:31:02.520141	source	A
31	mtop__sequence	int4	30	\N	~*	Sequence	mtop	30	30	30	SYSTEM			3259	2004-03-28 13:55:18.536541	source	A
31	mtop__timestamp	timestamp	30	\N	~*	Timestamp	mtop	30	40	40	SYSTEM			3260	2004-03-28 13:55:18.536541	source	A
31	mtop__user_entry	text	30	\N	~*	User Entry	mtop	30	50	50	SYSTEM			3261	2004-03-28 13:55:18.536541	source	A
31	mtop__status	bpchar	1	\N	~*	Status	mtop	1	60	60	SYSTEM			3262	2004-03-28 13:55:18.536541	source	A
31	mtal__sequence	int4	30	\N	~*	Sequence	mtal	30	60	60	SYSTEM			3268	2004-03-28 13:55:21.243797	source	A
31	mtal__timestamp	timestamp	30	\N	~*	Timestamp	mtal	30	70	70	SYSTEM			3269	2004-03-28 13:55:21.243797	source	A
31	mtal__user_entry	text	30	\N	~*	User Entry	mtal	30	80	80	SYSTEM			3270	2004-03-28 13:55:21.243797	source	A
31	mtal__status	bpchar	1	\N	~*	Status	mtal	1	90	90	SYSTEM			3271	2004-03-28 13:55:21.243797	source	A
31	mtag__sequence	int4	30	\N	~*	Sequence	mtag	30	60	60	SYSTEM			3277	2004-03-28 13:55:24.233441	source	A
31	mtag__timestamp	timestamp	30	\N	~*	Timestamp	mtag	30	70	70	SYSTEM			3278	2004-03-28 13:55:24.233441	source	A
31	mtag__user_entry	text	30	\N	~*	User Entry	mtag	30	80	80	SYSTEM			3279	2004-03-28 13:55:24.233441	source	A
31	mtag__status	bpchar	1	\N	~*	Status	mtag	1	90	90	SYSTEM			3280	2004-03-28 13:55:24.233441	source	A
31	mtad__sequence	int4	30	\N	~*	Sequence	mtad	30	70	70	SYSTEM			3287	2004-03-28 13:55:25.626852	source	A
31	mtad__timestamp	timestamp	30	\N	~*	Timestamp	mtad	30	80	80	SYSTEM			3288	2004-03-28 13:55:25.626852	source	A
31	mtad__user_entry	text	30	\N	~*	User Entry	mtad	30	90	90	SYSTEM			3289	2004-03-28 13:55:25.626852	source	A
31	mtad__status	bpchar	1	\N	~*	Status	mtad	1	100	100	SYSTEM			3290	2004-03-28 13:55:25.626852	source	A
31	mttk__sequence	int4	30	\N	~*	Sequence	mttk	30	30	30	SYSTEM			3293	2004-03-28 13:55:27.545702	source	A
31	mttk__timestamp	timestamp	30	\N	~*	Timestamp	mttk	30	40	40	SYSTEM			3294	2004-03-28 13:55:27.545702	source	A
31	mttk__user_entry	text	30	\N	~*	User Entry	mttk	30	50	50	SYSTEM			3295	2004-03-28 13:55:27.545702	source	A
31	mttk__status	bpchar	1	\N	~*	Status	mttk	1	60	60	SYSTEM			3296	2004-03-28 13:55:27.545702	source	A
31	mtau__sequence	int4	30	\N	~*	Sequence	mtau	30	70	70	SYSTEM			3303	2004-03-28 13:55:28.658454	source	A
31	mtau__timestamp	timestamp	30	\N	~*	Timestamp	mtau	30	80	80	SYSTEM			3304	2004-03-28 13:55:28.658454	source	A
31	mtau__user_entry	text	30	\N	~*	User Entry	mtau	30	90	90	SYSTEM			3305	2004-03-28 13:55:28.658454	source	A
31	mtau__status	bpchar	1	\N	~*	Status	mtau	1	100	100	SYSTEM			3306	2004-03-28 13:55:28.658454	source	A
31	pcde__sequence	int4	30	\N	~*	Sequence	pcde	30	110	110	SYSTEM			3317	2004-03-28 13:55:29.841367	source	A
31	pcde__status	bpchar	1	\N	~*	Status	pcde	1	140	140	SYSTEM			3320	2004-03-28 13:55:29.841367	source	A
31	pcde__timestamp	timestamp	30	\N	~*	Timestamp	pcde	30	120	120	SYSTEM			3318	2004-03-28 13:55:29.841367	source	A
31	pcde__user_entry	text	30	\N	~*	User Entry	pcde	30	130	130	SYSTEM			3319	2004-03-28 13:55:29.841367	source	A
31	ptss__sequence	int4	30	\N	~*	Sequence	ptss	30	60	60	SYSTEM			3326	2004-03-28 13:55:44.534516	source	A
31	ptss__timestamp	timestamptz	30	\N	~*	Timestamp	ptss	30	70	70	SYSTEM			3327	2004-03-28 13:55:44.534516	source	A
31	ptss__user_entry	name	30	\N	~*	User Entry	ptss	30	80	80	SYSTEM			3328	2004-03-28 13:55:44.534516	source	A
31	addr__sequence	int4	30	\N	~*	Sequence	addr	30	220	220	SYSTEM			3351	2004-03-28 13:55:45.84484	source	A
31	addr__timestamp	timestamp	30	\N	~*	Timestamp	addr	30	230	230	SYSTEM			3352	2004-03-28 13:55:45.84484	source	A
31	addr__user_entry	text	30	\N	~*	User Entry	addr	30	240	240	SYSTEM			3353	2004-03-28 13:55:45.84484	source	A
31	addr__status	bpchar	1	\N	~*	Status	addr	1	250	250	SYSTEM			3354	2004-03-28 13:55:45.84484	source	A
31	agdt__sequence	int4	1		~*	Row-ID	agdt	10	40	40	SYSTEM			2157	2001-10-19 12:31:04	source	A
31	agdt__timestamp	timestamp	1		~*	Timestamp	agdt	30	50	50	SYSTEM			2159	2001-10-19 12:31:05	source	A
31	agdt__user_entry	text	1		~*	Created by	agdt	10	60	60	SYSTEM			2160	2001-10-19 12:31:06	source	A
31	pate__sequence	int4	30	\N	~*	Sequence	pate	30	20	20	SYSTEM			3488	2004-09-19 09:52:54.475249	source	A
31	pate__timestamp	timestamp	30	\N	~*	Timestamp	pate	30	30	30	SYSTEM			3489	2004-09-19 09:52:54.475249	source	A
31	pate__user_entry	text	30	\N	~*	User Entry	pate	30	40	40	SYSTEM			3490	2004-09-19 09:52:54.475249	source	A
31	pate__status	bpchar	1	\N	~*	Status	pate	1	50	50	SYSTEM			3491	2004-09-19 09:52:54.475249	source	A
2	patv__timestamp	timestamp	0		=	Timestamp	patv	12	0	320	SYSTEM			2387	2001-10-19 12:33:26	source	A
2	rfdr__timestamp	timestamp	0		=	Timestamp	rfdr	30	0	210	SYSTEM			2077	2001-10-19 12:29:54	source	A
2	serv__timestamp	timestamp	0		=	Timestamp	serv	30	0	210	SYSTEM			2091	2001-10-19 12:30:05	source	A
31	mtat__timestamp	timestamp	0		~*	attribute__timestamp	mtat	10	0	200	SYSTEM	now		138	2001-10-10 12:25:02	source	A
2	paym__timestamp	timestamp	0		=	Timestamp	paym	30	0	210	SYSTEM			2034	2001-10-19 12:29:20	source	A
2	mdcr__timestamp	timestamp	0		=	Timestamp	mdcr	30	0	210	SYSTEM			1988	2001-10-19 12:28:44	source	A
2	lthd__timestamp	timestamp	0		=	Timestamp	lthd	30	0	210	SYSTEM			1946	2001-10-19 12:28:14	source	A
2	feeb__timestamp	timestamp	0		=	Timestamp	feeb	30	0	210	SYSTEM			1872	2001-10-19 12:26:31	source	A
2	feet__timestamp	timestamp	0		=	Timestamp	feet	30	0	210	SYSTEM			1879	2001-10-19 12:26:38	source	A
2	hlfd__timestamp	timestamp	0		=	Timestamp	hlfd	30	0	210	SYSTEM			1885	2001-10-19 12:26:59	source	A
2	icd9__timestamp	timestamp	0		=	Timestamp	icd9	30	200	210	SYSTEM			1891	2001-10-19 12:27:20	source	A
2	inst__timestamp	timestamp	0		=	Timestamp	inst	30	0	210	SYSTEM			1905	2001-10-19 12:27:40	source	A
2	empl__timestamp	timestamp	0		=	Timestamp	empl	30	0	210	SYSTEM			1829	2001-10-19 12:26:02	source	A
2	epsd__timestamp	timestamp	0		=	Timestamp	epsd	30	0	240	SYSTEM			1839	2001-10-19 12:26:11	source	A
2	cnty__timestamp	timestamp	0		=	Timestamp	cnty	30	0	210	SYSTEM			1777	2001-10-19 12:25:20	source	A
2	conf__timestamp	timestamp	0		=	Timestamp	conf	30	0	210	SYSTEM			1783	2001-10-19 12:25:25	source	A
2	cred__timestamp	timestamp	0		=	Timestamp	cred	30	0	210	SYSTEM			1793	2001-10-19 12:25:32	source	A
2	dbtr__timestamp	timestamp	0		=	Timestamp	dbtr	30	0	210	SYSTEM			1801	2001-10-19 12:25:39	source	A
2	diag__timestamp	timestamp	0		=	Timestamp	diag	30	0	210	SYSTEM			1812	2001-10-19 12:25:49	source	A
31	mtfn__timestamp	timestamp	0		~*	foreign__timestamp	mtfn	10	0	200	SYSTEM	now		156	2001-10-10 12:25:16	source	A
31	mtrl__timestamp	timestamp	0		~*	relation__timestamp	mtrl	10	0	200	SYSTEM	now		166	2001-10-10 12:25:24	source	A
2	accl__timestamp	timestamp	0		=	Timestamp	accl	30	0	210	SYSTEM			1710	2001-10-19 12:24:27	source	A
2	bkdp__timestamp	timestamp	0		=	Timestamp	bkdp	30	0	210	SYSTEM			1730	2001-10-19 12:24:43	source	A
2	cash__timestamp	timestamp	0		=	Timestamp	cash	30	0	210	SYSTEM			1740	2001-10-19 12:24:50	source	A
2	clsp__timestamp	timestamp	0		=	Timestamp	clsp	30	0	210	SYSTEM			1749	2001-10-19 12:24:57	source	A
2	clst__timestamp	timestamp	0		=	Timestamp	clst	30	0	210	SYSTEM			1755	2001-10-19 12:25:02	source	A
2	prov__timestamp	timestamp	0		=	Timestamp	prov	30	0	210	SYSTEM			3218	2002-10-25 09:57:38	source	A
31	mtcl__timestamp	timestamp	0		~*	class__timestamp	mtcl	20	0	200	SYSTEM	now		121	2001-10-10 12:24:50	source	A
31	crlt__sequence	int4	30	\N	~*	Sequence	crlt	30	740	740	SYSTEM			3568	2004-09-21 11:15:25.495252	source	A
31	crlt__timestamp	timestamp	30	\N	~*	Timestamp	crlt	30	750	750	SYSTEM			3569	2004-09-21 11:15:25.495252	source	A
31	crlt__user_entry	text	30	\N	~*	User Entry	crlt	30	760	760	SYSTEM			3570	2004-09-21 11:15:25.495252	source	A
31	crlt__status	bpchar	1	\N	~*	Status	crlt	1	770	770	SYSTEM			3571	2004-09-21 11:15:25.495252	source	A
2	patn__user_entry	text	0		~*	Entered by	patn	8	0	330	SYSTEM			2711	2002-02-09 08:01:49	source	A
2	patn__status	char	0		~*	Record status	patn	1	0	340	SYSTEM			2709	2002-02-09 08:01:48	source	A
2	svpf__sequence	integer	0		=	Row-ID	svpf	12	0	200	SYSTEM			2106	2001-10-19 12:30:20	source	A
2	svpf__timestamp	timestamp	0		=	Timestamp	svpf	12	0	210	SYSTEM			2108	2001-10-19 12:30:20	source	A
2	svpf__user_entry	text	0		~*	Entered by	svpf	12	0	220	SYSTEM			2109	2001-10-19 12:30:21	source	A
2	svpf__status	char	0		~*	Record status	svpf	1	0	230	SYSTEM			2107	2001-10-19 12:30:20	source	A
2	invc__timestamp	timestamp	0		=	Timestamp	invc	15	0	210	SYSTEM			1915	2001-10-19 12:27:48	source	A
2	invc__user_entry	text	0		~*	Entered by	invc	8	0	220	SYSTEM			1916	2001-10-19 12:27:49	source	A
2	invc__status	char	0		~*	Record status	invc	1	0	230	SYSTEM			1914	2001-10-19 12:27:47	source	A
2	paym__user_entry	text	0		~*	Entered by	paym	10	0	100	SYSTEM			2035	2001-10-19 12:29:21	source	A
2	paym__status	char	0		~*	Record status	paym	1	0	230	SYSTEM			2033	2001-10-19 12:29:20	source	A
2	paym__sequence	integer	0		=	Payment ID	paym	10	0	200	SYSTEM			2032	2001-10-19 12:29:19	source	A
2	bkdp__sequence	integer	0		=	List-ID	bkdp	10	0	5	SYSTEM			1728	2001-10-19 12:24:42	source	A
31	form__sequence	int4	10		~*	ID Sequence #	form	5	180	180	SYSTEM			173	2001-10-10 12:25:31	source	A
31	form__status	bpchar	1		~*	Status	form	5	210	210	SYSTEM			174	2001-10-10 12:25:31	source	A
31	form__timestamp	timestamp	47		~*	Timestamp	form	5	190	190	SYSTEM			175	2001-10-10 12:25:32	source	A
31	form__user_entry	text	30		~*	User Entry	form	5	200	200	SYSTEM			176	2001-10-10 12:25:32	source	A
31	evwl__timestamp	timestamp	30	\N	~*	Created	evwl	20	170	170	SYSTEM			3480	2004-08-04 09:26:24.604655	source	A
31	evwl__user_entry	text	30	\N	~*	Creator	evwl	10	180	180	SYSTEM			3481	2004-08-04 09:26:24.604655	source	A
31	evwl__status	bpchar	1	\N	~*	Internal	evwl	1	190	190	SYSTEM			3482	2004-08-04 09:26:24.604655	source	A
31	surg__sequence	int4	10		~*	Sequence	surg	10	80	80	SYSTEM			2742	2002-02-09 08:02:05	source	A
31	surg__status	bpchar	1		~*	Status	surg	1	110	110	SYSTEM			2743	2002-02-09 08:02:05	source	A
31	surg__user_entry	text	30		~*	User Entry	surg	30	100	100	SYSTEM			2745	2002-02-09 08:02:05	source	A
31	surv__sequence	int4	10		~*	Sequence	surv	10	180	180	SYSTEM			2753	2002-02-09 08:02:10	source	A
31	surv__status	bpchar	1		~*	Status	surv	1	210	210	SYSTEM			2754	2002-02-09 08:02:10	source	A
31	surv__user_entry	text	30		~*	User Entry	surv	30	200	200	SYSTEM			2756	2002-02-09 08:02:11	source	A
31	svrv__timestamp	timestamp	30	\N	~*	Timestamp	svrv	30	250	250	SYSTEM			3770	2005-01-25 13:46:55.847793	source	A
31	svrv__user_entry	text	30	\N	~*	User Entry	svrv	30	260	260	SYSTEM			3771	2005-01-25 13:46:55.847793	source	A
31	svrv__status	bpchar	1	\N	~*	Status	svrv	1	270	270	SYSTEM			3772	2005-01-25 13:46:55.847793	source	A
31	mtvs__sequence	int4	30	\N	~*	Sequence	mtvs	30	60	60	SYSTEM			3800	2005-01-30 09:25:48.66161	source	A
31	mtvs__timestamp	timestamp	30	\N	~*	Timestamp	mtvs	30	70	70	SYSTEM			3801	2005-01-30 09:25:48.66161	source	A
31	svrv__sequence	int4	30	\N	~*	Sequence	svrv	30	240	240	RO			3769	2005-01-25 13:46:55.847793	source	A
31	mtvs__user_entry	text	30	\N	~*	User Entry	mtvs	30	80	80	SYSTEM			3802	2005-01-30 09:25:48.66161	source	A
31	mtvs__status	bpchar	1	\N	~*	Status	mtvs	1	90	90	SYSTEM			3803	2005-01-30 09:25:48.66161	source	A
31	hicv__sequence	int4	30	\N	~*	Sequence	hicv	30	250	250	SYSTEM			3893	2005-01-31 13:32:23.54422	source	A
31	hicv__timestamp	timestamp	30	\N	~*	Timestamp	hicv	30	260	260	SYSTEM			3894	2005-01-31 13:32:23.54422	source	A
31	hicv__user_entry	text	30	\N	~*	User Entry	hicv	30	270	270	SYSTEM			3895	2005-01-31 13:32:23.54422	source	A
31	hicv__status	bpchar	1	\N	~*	Status	hicv	1	280	280	SYSTEM			3896	2005-01-31 13:32:23.54422	source	A
31	hice__sequence	int4	30	\N	~*	Sequence	hice	30	90	90	SYSTEM			3906	2005-02-05 16:07:20.979279	source	A
31	hice__timestamp	timestamp	30	\N	~*	Timestamp	hice	30	100	100	SYSTEM			3907	2005-02-05 16:07:20.979279	source	A
31	hice__user_entry	text	30	\N	~*	User Entry	hice	30	110	110	SYSTEM			3908	2005-02-05 16:07:20.979279	source	A
31	hice__status	bpchar	1	\N	~*	Status	hice	1	120	120	SYSTEM			3909	2005-02-05 16:07:20.979279	source	A
31	mdbt__sequence	int4	30	\N	~*	Internal ID	mdbt	5	90	90	SYSTEM			3865	2005-01-31 13:28:47.865107	source	A
31	mdbt__status	bpchar	1	\N	~*	Status	mdbt	20	120	120	SYSTEM			3868	2005-01-31 13:28:47.865107	source	A
31	mdbt__timestamp	timestamp	30	\N	~*	Created	mdbt	5	100	100	SYSTEM			3866	2005-01-31 13:28:47.865107	source	A
31	mdbt__user_entry	text	30	\N	~*	User	mdbt	20	110	110	SYSTEM			3867	2005-01-31 13:28:47.865107	source	A
31	mbst__sequence	int4	30	\N	~*	Sequence	mbst	30	60	60	SYSTEM			4077	2005-02-06 13:35:20.80535	source	A
31	mbst__timestamp	timestamp	30	\N	~*	Timestamp	mbst	30	70	70	SYSTEM			4078	2005-02-06 13:35:20.80535	source	A
31	mbst__user_entry	text	30	\N	~*	User Entry	mbst	30	80	80	SYSTEM			4079	2005-02-06 13:35:20.80535	source	A
31	mbst__status	bpchar	1	\N	~*	Status	mbst	1	90	90	SYSTEM			4080	2005-02-06 13:35:20.80535	source	A
2	mdaf__sequence	integer	0		=	Row-ID	mdaf	30	0	200	SYSTEM			1959	2001-10-19 12:28:23	source	A
2	mdaf__status	char	0		~*	Record status	mdaf	30	0	230	SYSTEM			1960	2001-10-19 12:28:24	source	A
2	mdaf__user_entry	text	0		~*	Entered by	mdaf	30	0	220	SYSTEM			1962	2001-10-19 12:28:25	source	A
2	mdaf__timestamp	timestamp	0		=	Timestamp	mdaf	30	0	210	SYSTEM			1961	2001-10-19 12:28:24	source	A
31	aptd__sequence	int4	10		~*	Sequence	aptd	5	130	130	SYSTEM			3200	2002-10-25 09:52:16	source	A
31	aptd__status	bpchar	1		~*	Status	aptd	5	160	160	SYSTEM			3201	2002-10-25 09:52:16	source	A
31	aptd__timestamp	timestamp	47		~*	Timestamp	aptd	5	140	140	SYSTEM			3202	2002-10-25 09:52:17	source	A
31	aptd__user_entry	text	30		~*	User Entry	aptd	5	150	150	SYSTEM			3203	2002-10-25 09:52:17	source	A
31	aptp__sequence	int4	10		~*	Sequence	aptp	10	40	40	SYSTEM			3169	2002-10-24 04:26:19	source	A
31	aptp__status	bpchar	1		~*	Status	aptp	1	70	70	SYSTEM			3170	2002-10-24 04:26:19	source	A
31	aptp__timestamp	timestamp	47		~*	Timestamp	aptp	47	50	50	SYSTEM			3171	2002-10-24 04:26:19	source	A
31	aptp__user_entry	text	30		~*	User Entry	aptp	30	60	60	SYSTEM			3172	2002-10-24 04:26:20	source	A
31	evnv__sequence	int4	10		~*	Sequence	evnv	10	480	1370	SYSTEM			3107	2002-10-24 04:23:39	source	A
31	evnv__timestamp	timestamp	47		~*	Timestamp	evnv	47	490	1390	SYSTEM			3109	2002-10-24 04:23:39	source	A
31	evnv__user_entry	text	30		~*	User Entry	evnv	30	500	1410	SYSTEM			3110	2002-10-24 04:23:40	source	A
31	evnv__status	bpchar	1		~*	Status	evnv	1	510	1430	SYSTEM			3108	2002-10-24 04:23:39	source	A
2	note__timestamp	timestamp	0		=	Timestamp	note	30	0	5	RO			1995	2001-10-19 12:28:49	source	A
31	docs__timestamp	timestamp	47		~*	Creattion time	docs	47	50	50	RO			1822	2001-10-19 12:25:55	source	A
31	surv__timestamp	timestamp	47		~*	Timestamp	surv	10	190	190	RO			2755	2002-02-09 08:02:10	source	A
31	surg__timestamp	timestamp	47		~*	Timestamp	surg	10	90	90	RO			2744	2002-02-09 08:02:05	source	A
31	patn_ref_expired	char(1)	1	\N	=	Referral Expired	patn	3	10	182	VIRTUAL=isreferralexpired( patn_ref_date, patn_ref_period)	\N	\N	4093	2005-09-17 19:11:18.24598	source	A
2	invc__sequence	integer	0		=	Invoice Number	invc	12	0	4	RO			1913	2001-10-19 12:27:47	source	A
2	patn__sequence	integer	0		=	Row-ID	patn	12	0	310	RO			2708	2002-02-09 08:01:48	source	A
2	patn__timestamp	timestamp	0		=	Timestamp	patn	15	0	320	SYSTEM			2710	2002-02-09 08:01:48	source	A
31	dbst_reference	text	30	\N	~*	Reference	dbst	30	320	320	10			4094	2005-09-17 19:20:21.83194	source	A
\.


--
-- Data for Name: mtau; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtau (mtau_table_name, mtau_row_sequence, mtau_operation, mtau_attributes, mtau_before, mtau_after, mtau__sequence, mtau__timestamp, mtau__user_entry, mtau__status) FROM stdin;
\.


--
-- Data for Name: mtcl; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtcl (mtcl_access, mtcl_name, mtcl_title, mtcl_group, mtcl_matrix_order, mtcl_order_by, mtcl_group_by, mtcl_primary, mtcl_userkey, mtcl_userlabel, mtcl_query_limit, mtcl_query_offset, mtcl_extras, mtcl__sequence, mtcl__timestamp, mtcl__user_entry, mtcl__status) FROM stdin;
2	hlfd	Health Funds 	\N	100			hlfd__sequence	hlfd_code	hlfd_desc	200	0		142	2001-10-19 12:26:54	source	A
2	icd9	ICD-9 Codes 	\N	1000			icd9__sequence			200	0		143	2001-10-19 12:27:12	source	A
2	inst	Institutions 	\N	1000			inst__sequence			200	0		144	2001-10-19 12:27:37	source	A
31	labl	Class labl	\N	10000	order by labl_id,labl_subtype,labl_row		labl__sequence			200	0		146	2001-10-19 12:28:06	source	A
2	lthd	Letterheads 	\N	100	order by lthd_order asc		lthd__sequence			200	0		147	2001-10-19 12:28:13	source	A
2	mdcr	Medicare Credits 	\N	10000			mdcr__sequence			200	0		150	2001-10-19 12:28:42	source	A
31	prnt	Printers	\N	10000	order by prnt_desc		prnt_name			20	0		154	2001-10-19 12:29:30	source	A
31	gstv	GST Receipts	\N	10000	order by gstv_bkdp_date_created,gstv_paym_date_entry		gstv__sequence	gstv_invc_sequence	gstv_quarter_date	200	0		179	2001-10-23 15:35:02	source	A
2	pyas	Payment assignments to services 	\N	10000			pyas__sequence			200	0		156	2001-10-19 12:29:47	source	A
2	stts	Episode status 	\N	100000			stts__sequence			200	0		159	2001-10-19 12:30:13	source	A
31	form	Forms	\N	10000			form_code	form_code	form_desc	200	0		12	2001-10-10 12:25:30	source	A
31	fmdt	Class fmdt	\N	10000	order by fmdt_section, fmdt_field_type,fmdt_y_coord,fmdt_x_coord		fmdt__sequence			200	0		13	2001-10-10 12:25:43	source	A
31	pmsc	Payment Summary	\N	10000	order by pmsc__timestamp		pmsc__sequence			200	0		166	2001-10-19 12:31:11	source	A
31	pmsp	Credits by Periods	\N	10000	order by pmsp_month desc		pmsp_month			200	0		167	2001-10-19 12:31:19	source	A
31	ssms	Services in Summary	\N	10000	order by ssms_date_service		ssms__sequence			200	0		168	2001-10-19 12:31:27	source	A
31	ssmp	Service Summary by Period	\N	10000	order by ssmp_month		ssmp_month			200	0		169	2001-10-19 12:31:35	source	A
31	ssmc	Service Summary by Code	\N	10000	order by ssmc_serv_code		ssmc__sequence			200	0		170	2001-10-19 12:31:43	source	A
31	crev	Credits to Invoices(V)	\N	10000			crev__sequence	crev_invc__sequence	crev_cred_amount	200	0		171	2001-10-19 12:31:51	source	A
31	crep	Credits to Invoices	\N	10000	order by crep_paym__sequence,crep_invc__sequence		crep__sequence	crep__sequence	crep_invc__sequence	200	0		173	2001-10-19 12:32:09	source	A
31	bank	Bank Accounts	\N	10000	order by bank_code		bank_code	bank__sequence	bank_name	200	0	paym_extras.inc	125	2001-10-19 12:24:31	source	A
31	dbst	Debtor Statements	\N	10000	order by dbst__sequence		dbst__sequence	dbst__sequence	dbst__sequence	200	0		174	2001-10-19 12:32:23	source	A
31	dbag	Aged Debtors	\N	10000	order by dbag__sequence		dbag__sequence	dbag__sequence	dbag__sequence	200	0		175	2001-10-19 12:32:37	source	A
31	cnrv	Contracts	\N	10000	order by cnrv_start_date desc		cnrv__sequence	cnrv__sequence	cnrv_start_date	200	0		176	2001-10-19 12:32:46	source	A
2	patv	Patient Demographics View	\N	10	order by patv_psnam asc, patv_fsnam asc	patv_psnam	patv__sequence	patv_fileno	patv_psnam	200	0	patv_extras.inc	178	2001-10-19 12:33:25	source	A
31	surg	Surgical Notes	\N	10000	order by surg_patn__sequence, surg__sequence desc		surg__sequence	surg__sequence	surg_patn__sequence	200	0		192	2002-02-09 08:02:04	source	A
2	cash	Cash Assignments 	\N	1000000			cash__sequence			200	0		127	2001-10-19 12:24:49	source	A
2	clsp	Clinical Speciality 	\N	1000000			clsp__sequence			200	0		128	2001-10-19 12:24:56	source	A
2	clst	Service Clusters 	\N	100			clst__sequence			200	0		129	2001-10-19 12:25:01	source	A
31	cnrt	Contracts	\N	10000	order by cnrt_start_date desc		cnrt__sequence	cnrt__sequence	cnrt_start_date	200	0		130	2001-10-19 12:25:09	source	A
2	cnty	Country of Birth 	\N	100000			cnty__sequence			200	0		131	2001-10-19 12:25:18	source	A
2	conf	Configuration 	\N	100	order by conf_type asc,conf_code asc		conf__sequence			200	0		132	2001-10-19 12:25:24	source	A
2	cred	Credits to Invoices 	\N	100000			cred__sequence	cred_invc__sequence	cred_amount	100	0		133	2001-10-19 12:25:30	source	A
2	diag	Diagnosis 	\N	1000			diag__sequence			200	0		135	2001-10-19 12:25:47	source	A
31	docs	Documents	\N	10000	order by docs_patn__sequence, docs__sequence,docs__timestamp desc		docs__sequence	docs__sequence	docs_title	200	0		136	2001-10-19 12:25:54	source	A
2	epsd	Treatment Episodes 	\N	1000			epsd__sequence			200	0		138	2001-10-19 12:26:09	source	A
31	mtop	Comparison Operators	METADATA	10000	order by mtop__sequence	\N	mtop_code	mtop_code	mtop_desc	0	0	\N	222	2004-03-28 13:55:18.536541	source	A
31	locn	Location	\N	10000	order by locn_code		locn_code	locn_code	locn_desc	0	0		214	2002-10-24 04:26:09	source	A
31	surv	Surgical Report	\N	10000	order by surv_psnam,surv_fsnam,surv_oprn_date		surv__sequence	surv__sequence	surv_psnam	200	0		193	2002-02-09 08:02:09	source	A
31	evnt	Schedule	\N	10000	order by evnt__sequence,evnt_starttime desc		evnt__sequence	evnt__sequence	evnt_starttime	200	0		212	2002-10-24 04:23:29	source	A
31	patf	Patient Flags	\N	10000	order by patf_code		patf_code	patf_code	patf_desc	0	0		190	2002-02-09 08:01:44	source	A
2	prov	Service Providers 	\N	100	order by prov_code		prov__sequence	prov_code	prov_name	0	0		219	2002-10-25 09:57:37	source	A
31	eftr	EFT - base	\N	10000	order by eftr__sequence		eftr__sequence	eftr__sequence	eftr__sequence	200	0		188	2002-02-09 08:01:28	source	A
31	eftv	EFT-reports	\N	10000	order by eftv_paym__sequence,eftv__sequence		eftv__sequence	eftv__sequence	eftv_patn_psnam	200	0		189	2002-02-09 08:01:32	source	A
31	notv	Patient Note Pad	\N	10000	order by notv_patn__sequence,notv__timestamp		notv__sequence	notv__sequence	notv__sequence	200	0		220	2003-03-13 15:31:02.128425	source	A
31	mtal	Alerts	METADATA	10000	order by mtal__sequence	\N	mtal__sequence	mtal__sequence	mtal__sequence	0	0	\N	223	2004-03-28 13:55:21.243797	source	A
31	mtag	Application Groups	METADATA	10000	order by mtag_list_order asc	\N	mtag_name	mtag_name	mtag_name	200	0	\N	224	2004-03-28 13:55:24.233441	source	A
31	mtad	Application Detail	METADATA	10000	order by mtad_list_order asc	\N	mtad__sequence	mtad__sequence	mtad__sequence	200	0	\N	225	2004-03-28 13:55:25.626852	source	A
31	pcde	Postcodes	\N	10000	order by pcde__sequence	\N	pcde__sequence	pcde__sequence	pcde__sequence	200	0	\N	228	2004-03-28 13:55:29.841367	source	A
31	ptss	Patient Services Summary	\N	10000	ptss_year_service,ptss_serv_code,ptss_feet_code,ptss_hlfd_code	\N	ptss__sequence	ptss__sequence	ptss_year_service,ptss_serv_code,ptss_feet_code,ptss_hlfd_code	400	0	\N	229	2004-03-28 13:55:44.534516	source	A
31	addr	Address Book	\N	10000	order by addr__sequence	\N	addr__sequence	addr__sequence	addr__sequence	200	0	\N	230	2004-03-28 13:55:45.84484	source	A
2	svpf	Services performed 	\N	10	order by svpf_invc__sequence desc, svpf_date_service asc, svpf_amount desc	svpf_invc__sequence	svpf__sequence	svpf_date_service	<b>%1 %2 </b> %3 %4: Invoice #%5, svpf_date_service, svpf_serv_code,svpf_amount,svpf_desc,svpf_invc__sequence	200	0	svpf_extras.inc	160	2001-10-19 12:30:19	source	A
2	invc	Invoices 	\N	10	order by invc__sequence		invc__sequence		Invoice <b>%1</b> : $%2 + $%3 Paid $%4 + $%5 Debtor Code: %6  Patient ID %7,invc__sequence,invc_amount,invc_gst_amount,invc_paid_amount,invc_paid_gst_amount,invc_dbtr_code,invc_patn__sequence	200	0	invc_extras.inc	145	2001-10-19 12:27:46	source	A
31	mtfn	Foreign Meta Data	METADATA	10030			mtfn__sequence		mtfn_title	200	0		10	2001-10-10 12:25:14	source	A
2	dbtr	Debtors 	\N	100	order by dbtr_code		dbtr__sequence	dbtr_code	<b>%1</b>: %2 %3 %4, dbtr_code,dbtr_name,dbtr_address,dbtr_suburb	200	0		134	2001-10-19 12:25:38	source	A
2	rfdr	Referrers 	\N	100	order by rfdr_code asc		rfdr__sequence	rfdr_code	<b>%1</b>: %2 %3 %4, rfdr_code,rfdr_name,rfdr_street,rfdr_suburb	200	0		157	2001-10-19 12:29:53	source	A
2	paym	Payments Received 	\N	10	order by paym_date_entry		paym__sequence	paym__sequence	<b>%1</b>: %2 %3 $%4 %5 %6 %7,paym__sequence,paym_date_entry,paym_tdtp_code,paym_amount,paym_drawer,paym_bank,paym_branch	200	0	paym_extras.inc	153	2001-10-19 12:29:19	source	A
2	patn	Patient Demographics 	\N	10	order by patn_psnam asc, patn_fsnam asc	patn_psnam	patn__sequence	patn_fileno	<b>%1 %2 (%3)</b><br><i>%4 %5 %6</i><br>Ref: %7(%8)<br>Ph: %9<br> Last Visit: %+1<br> Owing: %+2<br>, patn_fsnam,patn_psnam, patn_dob,patn_address, patn_suburb, patn_postcode, patn_ref_date,patn_ref_period, patn_phone, patn_last_visit, patn_amount_outstanding	200	0	patn_extras.inc	191	2002-02-09 08:01:48	source	A
2	accl	Account Class 	\N	100			accl__sequence		accl_desc	200	0		124	2001-10-19 12:24:26	source	A
31	mtcl	Class Meta Data	METADATA	10010	order by mtcl_name	class_group	mtcl_name	mtcl_name	%1: %2, mtcl_name, mtcl_title	200	0		8	2001-10-10 12:24:49	source	A
2	agdd	Aged Debt by Debtor	\N	10000	order by agdd_dbtr_code		agdd_dbtr_code		%1: %2, agdd_dbtr_name, agdd_amount	200	0		163	2001-10-19 12:30:50	source	A
2	agdp	Aged Debt by Period	\N	10000	order by agdp_period		agdp_period		%1: %2, agdp_period, agdp_amount	200	0		164	2001-10-19 12:30:57	source	A
31	agdi	Aged Debt by Invoice	\N	10000	order by agdi_dbtr_code,agdi_period		agdi__sequence	agdi__sequence	%1/%2: %3, agdi_dbtr_code, agdi_invc__sequence, agdi_amount	200	0	aged_extras.inc	162	2001-10-19 12:30:39	source	A
2	agdt	Aged Debt by FeeType	\N	10000	order by agdt_feet_code		agdt_feet_code		%1: %2, agdt_feet_code, agdt_amount	200	0		165	2001-10-19 12:31:04	source	A
2	bkdp	Bank Deposit Reports 	\N	1000	order by bkdp__sequence desc		bkdp__sequence	bkdp__sequence	%1 (%2), bkdp_date_created, bkdp__sequence	200	0	bkdp_extras.inc	126	2001-10-19 12:24:41	source	A
2	empl	Employers 	\N	100	order by empl_code		empl__sequence		%1: %2, empl_code, empl_name	200	0		137	2001-10-19 12:26:01	source	A
2	feeb	Fees for services 	\N	100	order by feeb_serv_code,feeb_feet_code	feeb_serv_code	feeb__sequence		%1/%2: %3, feeb_serv_code, feeb_feet_code, feeb_amount	800	0		140	2001-10-19 12:26:30	source	A
31	fept	Fee List	\N	10000	order by fept_serv_code,fept_feet_code		fept__sequence	fept_serv_code	%1/%2: %3, fept_serv_code, fept_feet_code, fept_desc	200	0		172	2001-10-19 12:32:02	source	A
31	mtat	Attribute Meta Data	METADATA	10020	order by mtat_view_order,mtat_name		mtat_name		mtat_title	200	0		9	2001-10-10 12:25:01	source	A
31	mtrl	Relation Meta Data	METADATA	10040			mtrl__sequence		mtrl_title	200	0		11	2001-10-10 12:25:23	source	A
2	note	Patient Note pad 	\N	20	order by note_patn__sequence,note__timestamp		note__sequence		note__timestamp	200	0		151	2001-10-19 12:28:48	source	A
31	pemd	Pending Exports - MD2	\N	10000	order by pemd__sequence	\N	pemd__sequence	pemd__sequence	pemd__sequence	200	0	\N	237	2004-09-21 12:42:31.891074	source	A
31	apst	Appointment Status	\N	10000	order by apst__sequence		apst_code	apst_code	%1: %2, apst_code, apst_desc	0	0		217	2002-10-24 04:26:40	source	A
31	aptp	Appointment Types	\N	10000	order by aptp__sequence		aptp_code	aptp_code	%1: %2, aptp_code, aptp_desc	0	0		215	2002-10-24 04:26:19	source	A
2	feet	Fee Levels 	\N	100			feet__sequence		%1: %2, feet_code, feet_desc	0	0		141	2001-10-19 12:26:37	source	A
2	serv	Service Items 	\N	100	order by serv_code		serv__sequence		%1: %2, serv_code, serv_desc	0	0		158	2001-10-19 12:30:04	source	A
31	tdtp	Tender Types	\N	10000	order by tdtp_desc		tdtp_code	tdtp_code	%1: %2, tdtp_code, tdtp_desc	0	0		161	2001-10-19 12:30:31	source	A
31	svrv	Service Report	\N	10000	order by svrv_ts_service	\N	svrv__sequence	svrv__sequence	svrv__sequence	200	0	\N	243	2005-01-25 13:46:55.847793	source	A
31	feel	Fee Report	\N	10000	order by feel__sequence	\N	feel__sequence	feel__sequence	feel__sequence	0	0	\N	240	2005-01-13 11:08:20.560366	source	A
31	evwl	Waiting List	\N	10000	order by evwl_starttime	\N	evwl__sequence	evwl__sequence	evwl__sequence	200	0	\N	233	2004-08-04 09:26:24.604655	source	A
2	-	TITLE	\N	\N	\N	\N	\N	\N	\N	200	0	\N	252	2005-01-31 13:52:37.519789	source	A
31	hice	HIC Data Elements	\N	10000	order by hice_name	\N	hice__sequence	hice__sequence	<b>%1:</b><br>%2,hice_name,hice_desc	200	0	\N	253	2005-02-05 16:07:20.979279	source	A
31	mdbt	HIC Claims	\N	10000	order by mdbt__sequence	\N	mdbt__sequence	mdbt__sequence	mdbt__sequence	200	0	\N	250	2005-01-31 13:28:47.865107	source	A
31	mttk	Ticket Management	\N	10000	order by mttk__sequence	\N	mttk_code	mttk_code	mttk_code	200	0	\N	226	2004-03-28 13:55:27.545702	source	A
31	mtau	Audit Log	\N	10000	order by mtau__sequence	\N	mtau__sequence	mtau__sequence	mtau__sequence	200	0	\N	227	2004-03-28 13:55:28.658454	source	A
31	mtvs	Metadata Version History	\N	10000	order by mtvs__sequence	\N	mtvs__sequence	mtvs__sequence	mtvs__sequence	200	0	\N	244	2005-01-30 09:25:48.66161	source	A
31	mtsv	PRAC Trigger View	METADATA	10000	order by mtsv_master_class, mtsv_key	\N	mtsv__sequence	mtsv__sequence	mtsv__sequence	200	0	\N	7	2001-10-10 12:24:25	source	A
31	svsm	Service Summary	\N	10000	order by svsm__sequence	\N	svsm__sequence	svsm__sequence	svsm__sequence	200	0	\N	238	2004-09-21 13:08:45.650712	source	A
31	crsm	Credit Summary	\N	10000	order by crsm__sequence	\N	crsm__sequence	crsm__sequence	crsm__sequence	200	0	\N	239	2004-09-21 13:34:37.289103	source	A
31	gsti	GST Invoicing (View)	\N	10000	order by gsti__sequence	\N	gsti__sequence	gsti__sequence	gsti__sequence	200	0	\N	241	2005-01-13 11:08:20.741506	source	A
31	mbst	MBS Table of Fees	\N	10000	order by mbst__sequence	\N	mbst__sequence	mbst__sequence	mbst__sequence	200	0	\N	254	2005-02-06 13:35:20.80535	source	A
2	mdaf	Medicare Voucher	\N	10000	order by mdaf__timestamp desc		mdaf__sequence			200	0		148	2001-10-19 12:28:23	source	A
31	hicv	HIC Claims (View)	\N	10000	order by hicv__sequence	\N	hicv__sequence	hicv__sequence	hicv__sequence	200	0	\N	251	2005-01-31 13:32:23.54422	source	A
31	crlt	Credit List	\N	10000	order by crlt__sequence	\N	crlt__sequence	crlt__sequence	crlt__sequence	200	0	\N	235	2004-09-21 11:15:25.495252	source	A
31	sclt	Debit and Credit List	\N	10000	order by sclt__timestamp	\N	sclt__sequence	sclt__sequence	sclt__sequence	200	0	\N	236	2004-09-21 11:16:10.027454	source	A
31	aptd	Type Details	\N	10000	order by aptd__timestamp desc		aptd__sequence	aptd__sequence	aptd_desc	200	0		218	2002-10-25 09:52:16	source	A
31	svpv	Services - View	\N	10000	order by svpv_form_code, svpv_invc__sequence desc, svpv_ts_service asc, svpv_amount desc		svpv__sequence	svpv__sequence	svpv_desc	200	0		194	2002-02-09 08:02:15	source	A
31	svlt	Services Reporting (View)	\N	10000	order by svlt__sequence	\N	svlt__sequence	svlt__sequence	svlt__sequence	200	0	\N	231	2004-03-28 13:56:01.656419	source	A
31	pate	Patients Edited	\N	10000	order by pate__sequence	\N	pate__sequence	pate__sequence	pate__sequence	200	0	\N	234	2004-09-19 09:52:54.475249	source	A
31	evnv	Appointments View	\N	10000	order by evnv_patn__sequence,evnv_starttime		evnv__sequence	evnv__sequence	<b>%1 %2 (%3)</b><br><i>%4</i>, evnv_patn_fsnam,evnv_patn_psnam, evnv_patn_dob,,evnv_desc	200	0		213	2002-10-24 04:23:38	source	A
\.


--
-- Data for Name: mtfn; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtfn (mtfn_title, mtfn_master_class, mtfn_key, mtfn_other_class, mtfn_join, mtfn_view, mtfn__sequence, mtfn__timestamp, mtfn__user_entry, mtfn__status) FROM stdin;
Debtor	agdd	agdd_dbtr_code	dbtr	dbtr_code	dbtr_name	378	2001-10-19 12:30:54	source	A
Debtor	agdi	agdi_dbtr_code	agdd	agdd_dbtr_code	agdd_dbtr_code	379	2001-10-19 12:30:54	source	A
Aged Period	agdi	agdi_period	agdp	agdp_period	agdp_period	380	2001-10-19 12:31:01	source	A
Fee Type	agdi	agdi_feet_code	agdt	agdt_feet_code	agdt_feet_code	381	2001-10-19 12:31:08	source	A
Fee type	agdt	agdt_feet_code	feet	feet_code	feet_desc	382	2001-10-19 12:31:08	source	A
Invoice	pmsc	pmsc_invc__sequence	invc	invc__sequence	invc_dbtr_code	383	2001-10-19 12:31:16	source	A
Payment	pmsc	pmsc_paym__sequence	paym	paym__sequence	paym_drawer	385	2001-10-19 12:31:16	source	A
Period	pmsc	pmsc_month	pmsp	pmsp_month	pmsp_month	386	2001-10-19 12:31:24	source	A
Summary	ssms	ssms_month	ssmp	ssmp_month	ssmp_month	390	2001-10-19 12:31:40	source	A
Summary	ssmc	ssmc_month	ssmp	ssmp_month	ssmp_month	391	2001-10-19 12:31:47	source	A
Service	ssmc	ssmc_serv_code	serv	serv_code	serv_desc	392	2001-10-19 12:31:48	source	A
Code total	ssms	ssms_serv_code	ssmc	ssmc_serv_code	ssmc_serv_code	393	2001-10-19 12:31:48	source	A
Parent Class	mtat	mtat_class_name	mtcl	mtcl_name	mtcl_title	22	2001-10-10 12:25:11	source	A
New Foreign Relationship	mtfn	mtfn_join	mtat	mtat_name	mtat_title	26	2001-10-10 12:25:19	source	A
Foreign Key	mtfn	mtfn_key	mtat	mtat_name	mtat_title	27	2001-10-10 12:25:19	source	A
Local Class	mtfn	mtfn_master_class	mtcl	mtcl_name	mtcl_title	28	2001-10-10 12:25:20	source	A
Foreign Class	mtfn	mtfn_other_class	mtcl	mtcl_name	mtcl_title	29	2001-10-10 12:25:20	source	A
Tender Type	crev	crev_tdtp_code	tdtp	tdtp_code	tdtp_desc	394	2001-10-19 12:31:58	source	A
patv	cnrt	cnrt_patn__sequence	patv	patv__sequence	patv__sequence	395	2001-10-19 12:33:54	source	A
Patient	invc	invc_patn__sequence	patv	patv__sequence	patv_psnam	396	2001-10-19 12:33:55	source	A
Patient Demographics	mdaf	mdaf_patn__sequence	patv	patv__sequence	patv__sequence	397	2001-10-19 12:33:55	source	A
Debtor	patv	patv_dbtr_code	dbtr	dbtr_code	dbtr_name	399	2001-10-19 12:33:56	source	A
View Attribute	mtfn	mtfn_view	mtat	mtat_name	mtat_title	30	2001-10-10 12:25:20	source	A
Employer	patv	patv_empl_code	empl	empl_code	empl_name	400	2001-10-19 12:33:56	source	A
Fee Type	patv	patv_feet_code	feet	feet_code	feet_desc	401	2001-10-19 12:33:56	source	A
Parent Class	mtrl	mtrl_master_class	mtcl	mtcl_name	mtcl_title	31	2001-10-10 12:25:27	source	A
Healthfund	patv	patv_hlfd_code	hlfd	hlfd_code	hlfd_desc	402	2001-10-19 12:33:57	source	A
Type	aptd	aptd_aptp_code	aptp	aptp_code	aptp_desc	492	2002-10-25 09:52:21	source	A
Referrer	patv	patv_rfdr_code	rfdr	rfdr_code	rfdr_name	404	2001-10-19 12:33:57	source	A
Patient	svpf	svpf_patn__sequence	patv	patv__sequence	patv_psnam	405	2001-10-19 12:33:58	source	A
Cluster Parent	clst	clst_serv_code_parent	serv	serv_code	serv_code	363	2001-10-19 12:30:09	source	A
Child Class	mtrl	mtrl_other_class	mtcl	mtcl_name	mtcl_title	32	2001-10-10 12:25:28	source	A
Service	feeb	feeb_serv_code	serv	serv_code	serv_desc	364	2001-10-19 12:30:09	source	A
Invoice	svpf	svpf_invc__sequence	invc	invc__sequence	invc_date_created	367	2001-10-19 12:30:26	source	A
Service	svpf	svpf_serv_code	serv	serv_code	serv_desc	371	2001-10-19 12:30:28	source	A
Tender Type	paym	paym_tdtp_code	tdtp	tdtp_code	tdtp_desc	373	2001-10-19 12:30:36	source	A
Invoice	agdi	agdi_invc__sequence	invc	invc__sequence	invc__sequence	376	2001-10-19 12:30:46	source	A
Fee Type	clst	clst_feet_code	feet	feet_code	feet_code	308	2001-10-19 12:26:41	source	A
Fee Level	feeb	feeb_feet_code	feet	feet_code	feet_desc	309	2001-10-19 12:26:41	source	A
Invoice credited	cred	cred_invc__sequence	invc	invc__sequence	invc_amount	316	2001-10-19 12:27:59	source	A
Payment	cash	cash_paym__sequence	paym	paym__sequence	paym__sequence	348	2001-10-19 12:29:25	source	A
Payment Source	cred	cred_paym__sequence	paym	paym__sequence	paym_drawer	349	2001-10-19 12:29:26	source	A
Bank Deposit Reports	paym	paym_bkdp__sequence	bkdp	bkdp__sequence	bkdp_desc	350	2001-10-19 12:29:26	source	A
Location	aptd	aptd_locn_code	locn	locn_code	locn_desc	493	2002-10-25 09:52:23	source	A
Provider	aptd	aptd_prov_code	prov	prov_code	prov_name	495	2002-10-25 09:57:42	source	A
prov	evnt	evnt_prov_code	prov	prov_code	prov_name	496	2002-10-25 09:57:42	source	A
Bank	invc	invc_bank_code	bank	bank_code	bank_name	317	2001-10-19 12:28:00	source	A
Referrer	invc	invc_rfdr_code	rfdr	rfdr_code	rfdr_name	358	2001-10-19 12:30:00	source	A
Referring Doctor	mdaf	mdaf_rfdr_code	rfdr	rfdr_code	rfdr_code	359	2001-10-19 12:30:00	source	A
Debtor	invc	invc_dbtr_code	dbtr	dbtr_code	dbtr_name	318	2001-10-19 12:28:00	source	A
Component	clst	clst_serv_code_child	serv	serv_code	serv_code	362	2001-10-19 12:30:08	source	A
Provider	invc	invc_prov_code	prov	prov_code	prov_name	498	2002-10-25 09:57:42	source	A
Provider	lthd	lthd_prov_code	prov	prov_code	prov_name	499	2002-10-25 09:57:43	source	A
patn	evnt	evnt_patn__sequence	patn	patn__sequence	patn_psnam	477	2002-10-24 04:23:33	source	A
Service Provider	mdaf	mdaf_prov_code	prov	prov_code	prov_code	500	2002-10-25 09:57:43	source	A
Provider	patn	patn_prov_code	prov	prov_code	prov_name	501	2002-10-25 09:57:43	source	A
Provider	patv	patv_prov_code	prov	prov_code	prov_name	502	2002-10-25 09:57:43	source	A
Employer	invc	invc_empl_code	empl	empl_code	empl_name	319	2001-10-19 12:28:00	source	A
Fee Type	invc	invc_feet_code	feet	feet_code	feet_desc	320	2001-10-19 12:28:01	source	A
locn	evnt	evnt_locn_code	locn	locn_code	locn_desc	484	2002-10-24 04:26:12	source	A
patn	cnrt	cnrt_patn__sequence	patn	patn__sequence	patn__sequence	424	2002-02-09 08:02:00	source	A
patn	docs	docs_patn__sequence	patn	patn__sequence	patn__sequence	425	2002-02-09 08:02:00	source	A
Patient	invc	invc_patn__sequence	patn	patn__sequence	patn_psnam	427	2002-02-09 08:02:00	source	A
Patient Demographics	mdaf	mdaf_patn__sequence	patn	patn__sequence	patn__sequence	428	2002-02-09 08:02:00	source	A
Debtor	patn	patn_dbtr_code	dbtr	dbtr_code	dbtr_name	430	2002-02-09 08:02:01	source	A
Employer	patn	patn_empl_code	empl	empl_code	empl_name	431	2002-02-09 08:02:01	source	A
Fee Type	patn	patn_feet_code	feet	feet_code	feet_desc	432	2002-02-09 08:02:01	source	A
Healthfund	patn	patn_hlfd_code	hlfd	hlfd_code	hlfd_desc	433	2002-02-09 08:02:02	source	A
patf	patn	patn_patf_code	patf	patf_code	patf_code	434	2002-02-09 08:02:02	source	A
Referrer	patn	patn_rfdr_code	rfdr	rfdr_code	rfdr_name	436	2002-02-09 08:02:02	source	A
Patient	svpf	svpf_patn__sequence	patn	patn__sequence	patn_psnam	438	2002-02-09 08:02:03	source	A
Patient	surg	surg_patn__sequence	patn	patn__sequence	patn__sequence	439	2002-02-09 08:02:08	source	A
Patient	notv	notv_patn__sequence	patn	patn__sequence	patn_psnam	504	2003-03-13 15:31:02.857347	source	A
Patient	notv	notv_patn__sequence	patv	patv__sequence	patv_psnam	398	2001-10-19 12:33:55	source	A
mtat	mtal	mtal_mtat_name	mtat	mtat_name	mtat_title	506	2004-03-28 13:55:21.619298	source	A
mtcl	mtad	mtad_class	mtcl	mtcl_name	mtcl_name	509	2004-03-28 13:55:26.294814	source	A
Menus	mtad	mtad_parent	mtag	mtag_name	mtag_name	508	2004-03-28 13:55:26.294814	source	A
Menus	mtag	mtag_parent	mtag	mtag_name	mtag_name	510	2004-03-28 13:55:26.413169	source	A
mtop	mtal	mtal_mtop_code	mtop	mtop_code	mtop_desc	507	2004-03-28 13:55:21.619298	source	A
Provider	evnv	evnv_prov_code	prov	prov_code	prov_name	531	2005-09-14 11:49:08.716627	source	A
Patient	evnv	evnv_patn__sequence	patn	patn__sequence	patn_psnam	532	2005-09-14 11:49:08.745515	source	A
Referror	evnv	evnv_rfdr_code	rfdr	rfdr_code	rfdr_name	533	2005-09-14 11:49:08.759781	source	A
Location	evnv	evnv_locn_code	locn	locn_code	locn_desc	534	2005-09-14 11:49:08.774715	source	A
Type	evnv	evnv_aptp_code	aptp	aptp_code	aptp_desc	535	2005-09-14 11:49:08.790525	source	A
Status	evnv	evnv_apst_code	apst	apst_code	apst_desc	536	2005-09-14 11:49:08.80585	source	A
Bank	evnv	evnv_prov_bank_code	bank	bank_code	bank_name	537	2005-09-14 11:49:08.816554	source	A
ACCL	evnv	evnv_patn_accl_code	accl	accl_code	accl_desc	538	2005-09-14 11:49:08.831685	source	A
Fund	evnv	evnv_patn_hlfd_code	hlfd	hlfd_code	hlfd_desc	539	2005-09-14 11:49:08.846859	source	A
Fee Level	evnv	evnv_patn_feet_code	feet	feet_code	feet_desc	540	2005-09-14 11:49:08.862466	source	A
\.


--
-- Data for Name: mtop; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtop (mtop_code, mtop_desc, mtop__sequence, mtop__timestamp, mtop__user_entry, mtop__status) FROM stdin;
0	Matches	1	2004-03-28 13:55:19.870058	source	N
1	Like	2	2004-03-28 13:55:19.942665	source	N
2	Contains	3	2004-03-28 13:55:20.000102	source	N
3	Equals	4	2004-03-28 13:55:20.057829	source	N
4	GreaterThan	5	2004-03-28 13:55:20.115249	source	N
5	LessThan	6	2004-03-28 13:55:20.172945	source	N
6	GreaterThanOrEqual	7	2004-03-28 13:55:20.230517	source	N
7	LessThanOrEqual	8	2004-03-28 13:55:20.288047	source	N
8	NotEqual	9	2004-03-28 13:55:20.345686	source	N
9	All	10	2004-03-28 13:55:20.403157	source	N
\.


--
-- Data for Name: mtpt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtpt (mtpt_name, mtpt_rcs_header, mtpt__sequence, mtpt__timestamp, mtpt__user_entry, mtpt__status) FROM stdin;
\.


--
-- Data for Name: mtrl; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtrl (mtrl_title, mtrl_master_class, mtrl_key, mtrl_other_class, mtrl_join, mtrl__sequence, mtrl__timestamp, mtrl__user_entry, mtrl__status) FROM stdin;
Patients covered	dbtr	dbtr_code	patv	patv_dbtr_code	265	2001-10-19 12:33:52	source	A
Patients	hlfd	hlfd_code	patv	patv_hlfd_code	266	2001-10-19 12:33:52	source	A
Attributes	mtcl	mtcl_name	mtat	mtat_class_name	12	2001-10-10 12:25:10	source	A
Foreigns	mtcl	mtcl_name	mtfn	mtfn_master_class	13	2001-10-10 12:25:19	source	A
Relations	mtcl	mtcl_name	mtrl	mtrl_master_class	14	2001-10-10 12:25:27	source	A
Details	form	form_code	fmdt	fmdt_form_code	16	2001-10-10 12:25:56	source	A
Contracts	patv	patv__sequence	cnrv	cnrv_patn__sequence	267	2001-10-19 12:33:52	source	A
Care Episodes	patv	patv__sequence	epsd	epsd_patn__sequence	268	2001-10-19 12:33:53	source	A
Invoices	patv	patv__sequence	invc	invc_patn__sequence	269	2001-10-19 12:33:53	source	A
Services Performed	patv	patv__sequence	svpf	svpf_patn__sequence	271	2001-10-19 12:33:54	source	A
Patients referred	rfdr	rfdr_code	patv	patv_rfdr_code	272	2001-10-19 12:33:54	source	A
TITLE	bank	bank_code	invc	invc_bank_code	209	2001-10-19 12:27:56	source	A
Invoices	dbtr	dbtr_code	invc	invc_dbtr_code	210	2001-10-19 12:27:56	source	A
TITLE	empl	empl_code	invc	invc_empl_code	211	2001-10-19 12:27:56	source	A
TITLE	feet	feet_code	invc	invc_feet_code	212	2001-10-19 12:27:57	source	A
Conditions	aptp	aptp_code	aptd	aptd_aptp_code	315	2002-10-25 09:52:21	source	A
Invoices	patn	patn__sequence	invc	invc_patn__sequence	292	2002-02-09 08:01:58	source	A
Services Performed	patn	patn__sequence	svpf	svpf_patn__sequence	295	2002-02-09 08:01:59	source	A
Patients referred	rfdr	rfdr_code	patn	patn_rfdr_code	296	2002-02-09 08:01:59	source	A
Surgical Note	patn	patn__sequence	surg	surg_patn__sequence	297	2002-02-09 08:02:08	source	A
Payments Deposited	bkdp	bkdp__sequence	paym	paym_bkdp__sequence	233	2001-10-19 12:29:25	source	A
Invoices referred	rfdr	rfdr_code	invc	invc_rfdr_code	237	2001-10-19 12:29:58	source	A
TITLE	prov	prov_code	invc	invc_prov_code	316	2002-10-25 09:57:41	source	A
Components	serv	serv_code	clst	clst_serv_code_parent	240	2001-10-19 12:30:07	source	A
Fees	serv	serv_code	feeb	feeb_serv_code	241	2001-10-19 12:30:08	source	A
Services Invoiced	invc	invc__sequence	svpf	svpf_invc__sequence	242	2001-10-19 12:30:25	source	A
Services Performed	mdaf	mdaf__sequence	svpf	svpf_mdaf__sequence	243	2001-10-19 12:30:25	source	A
Letterhead	prov	prov_code	lthd	lthd_prov_code	317	2002-10-25 09:57:42	source	A
Aged Invoices	agdd	agdd_dbtr_code	agdi	agdi_dbtr_code	250	2001-10-19 12:30:53	source	A
Aged Debt	dbtr	dbtr_code	agdd	agdd_dbtr_code	251	2001-10-19 12:30:54	source	A
Aged Invoices	agdp	agdp_period	agdi	agdi_period	252	2001-10-19 12:31:00	source	A
Aged Invoices	agdt	agdt_feet_code	agdi	agdi_feet_code	253	2001-10-19 12:31:07	source	A
Credits in period	pmsp	pmsp_month	pmsc	pmsc_month	255	2001-10-19 12:31:23	source	A
Services	ssmp	ssmp_month	ssms	ssms_month	258	2001-10-19 12:31:39	source	A
Service Codes	ssmp	ssmp_month	ssmc	ssmc_month	259	2001-10-19 12:31:47	source	A
Credits to Invoice	invc	invc__sequence	crev	crev_invc__sequence	260	2001-10-19 12:31:58	source	A
Credits	svpf	svpf_invc__sequence	crev	crev_invc__sequence	261	2001-10-19 12:31:58	source	A
Payment Distribution	paym	paym__sequence	crep	crep_paym__sequence	262	2001-10-19 12:32:19	source	A
Fees	feet	feet_code	feeb	feeb_feet_code	205	2001-10-19 12:26:40	source	A
Appointments	patn	patn__sequence	evnv	evnv_patn__sequence	311	2002-10-24 04:23:55	source	A
evnt	locn	locn_code	evnt	evnt_locn_code	312	2002-10-24 04:26:11	source	A
Patients covered	dbtr	dbtr_code	patn	patn_dbtr_code	287	2002-02-09 08:01:57	source	A
Patients	hlfd	hlfd_code	patn	patn_hlfd_code	288	2002-02-09 08:01:58	source	A
patn	patf	patf_code	patn	patn_patf_code	289	2002-02-09 08:01:58	source	A
Documents	patn	patn__sequence	docs	docs_patn__sequence	290	2002-02-09 08:01:58	source	A
Patient Notes	patn	patn__sequence	notv	notv_patn__sequence	318	2003-03-13 15:31:02.700905	source	A
Patient Notes	patv	patv__sequence	notv	notv_patn__sequence	270	2001-10-19 12:33:53	source	A
Menu Items	mtag	mtag_name	mtad	mtad_parent	320	2004-03-28 13:55:26.490576	source	A
Menus	mtag	mtag_name	mtag	mtag_parent	321	2004-03-28 13:55:26.490576	source	A
Classes	mtag	mtag_name	mtcl	mtcl_group	322	2004-03-28 13:55:26.490576	source	A
Vouchers	patn	patn__sequence	mdaf	mdaf_patn__sequence	323	2005-01-31 13:52:37.519789	source	A
\.


--
-- Data for Name: mttb; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mttb (mttb_name, mttb_rcs_header, mttb_notes, mttb__sequence, mttb__timestamp, mttb__user_entry, mttb__status) FROM stdin;
\.


--
-- Data for Name: mttk; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mttk (mttk_code, mttk_expires, mttk__sequence, mttk__timestamp, mttk__user_entry, mttk__status) FROM stdin;
\.


--
-- Data for Name: mtvs; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mtvs (mtvs_schema_name, mtvs_schema_version, mtvs_product_name, mtvs_product_version, mtvs_desc, mtvs__sequence, mtvs__timestamp, mtvs__user_entry, mtvs__status) FROM stdin;
\.


--
-- Data for Name: mvac_database; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mvac_database (db_name, db_desc, db_host, db_port, db_options, db_tty, db_login, db_pwd, perms) FROM stdin;
prac	Prac Database		5432					2
\.


--
-- Data for Name: mvac_label; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mvac_label (perms, label) FROM stdin;
1	guest
2	user
4	supervisor
8	medical
16	office
32	office-admin
64	local-admin
127	support-admin
\.


--
-- Data for Name: mvac_sessions; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mvac_sessions (sid, name, val, changed) FROM stdin;
\.


--
-- Data for Name: mvac_user; Type: TABLE DATA; Schema: public; Owner: source
--

COPY mvac_user (uid, username, userdesc, "password", perms, email) FROM stdin;
c14cbf141af555b607ab	admin	Office Admin	guest	3	admin
c14cbf141af555b607ac	guest	Guest account	guest	3	guest
c14cbf141af555b607dc	source	Administrator	admin	127	source@localhost
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: source
--

COPY note (note_patn__sequence, note_desc, note__sequence, note__timestamp, note__user_entry, note__status) FROM stdin;
\.


--
-- Data for Name: pate; Type: TABLE DATA; Schema: public; Owner: source
--

COPY pate (pate_patn__sequence, pate__sequence, pate__timestamp, pate__user_entry, pate__status) FROM stdin;
\.


--
-- Data for Name: patf; Type: TABLE DATA; Schema: public; Owner: source
--

COPY patf (patf_code, patf_desc, patf__sequence, patf__timestamp, patf__user_entry, patf__status) FROM stdin;
-	\N	0	2003-04-18 16:06:08.612207	source	N
HOLD	HOLD INVOICES	4	2005-01-10 09:45:09.672109	source	N
\.


--
-- Data for Name: patn; Type: TABLE DATA; Schema: public; Owner: source
--

COPY patn (patn_flno, patn_psnam, patn_fsnam, patn_title, patn_dob, patn_address, patn_suburb, patn_state, patn_postcode, patn_phone, patn_hlfd_code, patn_ins_level, patn_healthnumb, patn_feet_code, patn_medicare, patn_healthcard, patn_dbtr_code, patn_empl_code, patn_rfdr_code, patn_ref_date, patn_ref_period, patn_prov_code, patn_country, patn_aboriginality, patn_sex, patn_marital, patn_accl_code, patn_accommodation, patn_care, patn_patf_code, patn__sequence, patn__timestamp, patn__user_entry, patn__status, patn_last_visit, patn_last_service, patn_amount_outstanding, patn_claim_number, patn_accident_date) FROM stdin;
\.


--
-- Data for Name: paym; Type: TABLE DATA; Schema: public; Owner: source
--

COPY paym (paym_date_entry, paym_user_entry, paym_site_entry, paym_amount, paym_tdtp_code, paym_drawer, paym_bank, paym_branch, paym_bkdp__sequence, paym__sequence, paym__timestamp, paym__user_entry, paym__status) FROM stdin;
\.


--
-- Data for Name: pcde; Type: TABLE DATA; Schema: public; Owner: source
--

COPY pcde (pcde_postcode, pcde_locality, pcde_state, pcde_comments, pcde_delivery_office, pcde_presort_indicator, pcde_parcelzone, pcde_bsp_number, pcde_bsp_name, pcde_category, pcde__sequence, pcde__timestamp, pcde__user_entry, pcde__status) FROM stdin;
\.


--
-- Data for Name: prnt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY prnt (prnt_type, prnt_access, prnt_name, prnt_desc, prnt_command, prnt__sequence, prnt__timestamp, prnt__user_entry, prnt__status) FROM stdin;
\.


--
-- Data for Name: prov; Type: TABLE DATA; Schema: public; Owner: source
--

COPY prov (prov_code, prov_provider_num, prov_name, prov_address, prov_suburb, prov_state, prov_postcode, prov_salutation, prov_phone, prov_bank_code, prov__sequence, prov__timestamp, prov__user_entry, prov__status, prov_colour) FROM stdin;
-	XXXX	Default - Null Referror	\N	\N	\N	\N	\N	\N	-	36	2005-01-30 11:54:40.705191	source	N	#ffaaaaff
\.


--
-- Data for Name: pyas; Type: TABLE DATA; Schema: public; Owner: source
--

COPY pyas (pyas_paym__sequence, pyas_svpf__sequence, pyas_amount, pyas__sequence, pyas__timestamp, pyas__user_entry, pyas__status) FROM stdin;
\.


--
-- Data for Name: rfdr; Type: TABLE DATA; Schema: public; Owner: source
--

COPY rfdr (rfdr_code, rfdr_name, rfdr_street, rfdr_suburb, rfdr_postcode, rfdr_state, rfdr_provider, rfdr_phone, rfdr_salutation, rfdr_index, rfdr__sequence, rfdr__timestamp, rfdr__user_entry, rfdr__status) FROM stdin;
-	\N	\N	\N	\N	\N	\N	\N	\N	\N	28802	2005-01-30 12:06:33.13467	source	N
\.


--
-- Data for Name: sclt; Type: TABLE DATA; Schema: public; Owner: source
--

COPY sclt (sclt_date, sclt_patn_name, sclt_dc, sclt_prov_code, sclt_prov_name, sclt_type, sclt_desc, sclt_invc__sequence, sclt_debit, sclt_gst_debit, sclt_credit, sclt_gst_credit, sclt_total_amount, sclt__sequence, sclt__timestamp, sclt__user_entry, sclt__status) FROM stdin;
\.


--
-- Data for Name: serv; Type: TABLE DATA; Schema: public; Owner: source
--

COPY serv (serv_code, serv_value, serv_gst_percentage, serv_desc, serv__sequence, serv__timestamp, serv__user_entry, serv__status) FROM stdin;
-	1	0	\N	6092	2005-01-30 12:06:33.381204	source	N
104	1	0	Consultation	6093	2005-01-31 13:57:54.703261	source	N
105	1	0	Subsequent Consultation	6106	2005-02-08 20:14:08.029748	source	N
\.


--
-- Data for Name: stts; Type: TABLE DATA; Schema: public; Owner: source
--

COPY stts (stts_epsdserl, stts_start_date, stts_account_class, stts_accom_type, stts_care_type, stts__sequence, stts__timestamp, stts__user_entry, stts__status) FROM stdin;
\.


--
-- Data for Name: surg; Type: TABLE DATA; Schema: public; Owner: source
--

COPY surg (surg_patn__sequence, surg_symptoms, surg_class, surg_diag_codes, surg_diagnosis, surg_treatment, surg_oprn_codes, surg_operation, surg_oprn_date, surg_oprn_place, surg_photo_code, surg__sequence, surg__timestamp, surg__user_entry, surg__status) FROM stdin;
\.


--
-- Data for Name: svpf; Type: TABLE DATA; Schema: public; Owner: source
--

COPY svpf (svpf_date_service, svpf_serv_code, svpf_percentage, svpf_desc, svpf_amount, svpf_gst_amount, svpf_invc__sequence, svpf_mdaf__sequence, svpf_patn__sequence, svpf__sequence, svpf__timestamp, svpf__user_entry, svpf__status) FROM stdin;
\.


--
-- Data for Name: svsm; Type: TABLE DATA; Schema: public; Owner: source
--

COPY svsm (svsm_date_start, svsm_date_end, svsm_type, svsm_prov_code, svsm_prov_name, svsm_count, svsm_serv_code, svsm_desc, svsm_amount, svsm_gst_amount, svsm__sequence, svsm__timestamp, svsm__user_entry, svsm__status) FROM stdin;
\.


--
-- Data for Name: tdtp; Type: TABLE DATA; Schema: public; Owner: source
--

COPY tdtp (tdtp_code, tdtp_list, tdtp_subtotal, tdtp_desc, tdtp_entity, tdtp_location, tdtp__sequence, tdtp__timestamp, tdtp__user_entry, tdtp__status) FROM stdin;
W	Adjustments	Write Off	Write off	\N	\N	12	2001-10-13 08:15:57	source	N
-	Unknown	Unknown	\N	\N	\N	2	2001-10-13 08:15:57	source	N
B	EFTPOS	Credit Cards	BankCard	\N	\N	3	2001-10-13 08:15:57	source	N
E	EFTPOS	EFTPOS	Eftpos	\N	\N	5	2001-10-13 08:15:57	source	N
M	EFTPOS	Credit Cards	Mastercard	\N	\N	7	2001-10-13 08:15:57	source	N
O	EFTPOS	Credit Cards	Other	\N	\N	8	2001-10-13 08:15:57	source	N
V	EFTPOS	Credit Cards	Visa	\N	\N	11	2001-10-13 08:15:57	source	N
R	Adjustments	Rebates	Rebate	\N	\N	10	2001-10-13 08:15:57	source	N
C	CASH	Cash	Cash	\N	\N	4	2001-10-13 08:15:57	source	N
Q	CHEQUES	Cheques	Cheque	\N	\N	9	2001-10-13 08:15:57	source	N
F	DIRECT ENTRY	Directed Payment	Directed	\N	\N	6	2001-10-13 08:15:57	source	N
\.


--
-- Name: accl_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY accl
    ADD CONSTRAINT accl_pkey PRIMARY KEY (accl__sequence);


ALTER INDEX public.accl_pkey OWNER TO source;

--
-- Name: addr_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY addr
    ADD CONSTRAINT addr_pkey PRIMARY KEY (addr__sequence);


ALTER INDEX public.addr_pkey OWNER TO source;

--
-- Name: apst_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY apst
    ADD CONSTRAINT apst_pkey PRIMARY KEY (apst_code);


ALTER INDEX public.apst_pkey OWNER TO source;

--
-- Name: aptd_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY aptd
    ADD CONSTRAINT aptd_pkey PRIMARY KEY (aptd__sequence);


ALTER INDEX public.aptd_pkey OWNER TO source;

--
-- Name: aptp_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY aptp
    ADD CONSTRAINT aptp_pkey PRIMARY KEY (aptp_code);


ALTER INDEX public.aptp_pkey OWNER TO source;

--
-- Name: bank_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY bank
    ADD CONSTRAINT bank_pkey PRIMARY KEY (bank_code);


ALTER INDEX public.bank_pkey OWNER TO source;

--
-- Name: bkdp_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY bkdp
    ADD CONSTRAINT bkdp_pkey PRIMARY KEY (bkdp__sequence);


ALTER INDEX public.bkdp_pkey OWNER TO source;

--
-- Name: cash_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY cash
    ADD CONSTRAINT cash_pkey PRIMARY KEY (cash__sequence);


ALTER INDEX public.cash_pkey OWNER TO source;

--
-- Name: clsp_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY clsp
    ADD CONSTRAINT clsp_pkey PRIMARY KEY (clsp__sequence);


ALTER INDEX public.clsp_pkey OWNER TO source;

--
-- Name: clst_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY clst
    ADD CONSTRAINT clst_pkey PRIMARY KEY (clst__sequence);


ALTER INDEX public.clst_pkey OWNER TO source;

--
-- Name: cnrt_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY cnrt
    ADD CONSTRAINT cnrt_pkey PRIMARY KEY (cnrt__sequence);


ALTER INDEX public.cnrt_pkey OWNER TO source;

--
-- Name: cnty_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY cnty
    ADD CONSTRAINT cnty_pkey PRIMARY KEY (cnty__sequence);


ALTER INDEX public.cnty_pkey OWNER TO source;

--
-- Name: conf_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY conf
    ADD CONSTRAINT conf_pkey PRIMARY KEY (conf_code);


ALTER INDEX public.conf_pkey OWNER TO source;

--
-- Name: cred_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY cred
    ADD CONSTRAINT cred_pkey PRIMARY KEY (cred__sequence);


ALTER INDEX public.cred_pkey OWNER TO source;

--
-- Name: crsm_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY crsm
    ADD CONSTRAINT crsm_pkey PRIMARY KEY (crsm__sequence);


ALTER INDEX public.crsm_pkey OWNER TO source;

--
-- Name: dbtr_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY dbtr
    ADD CONSTRAINT dbtr_pkey PRIMARY KEY (dbtr_code);


ALTER INDEX public.dbtr_pkey OWNER TO source;

--
-- Name: diag_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY diag
    ADD CONSTRAINT diag_pkey PRIMARY KEY (diag__sequence);


ALTER INDEX public.diag_pkey OWNER TO source;

--
-- Name: docs_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY docs
    ADD CONSTRAINT docs_pkey PRIMARY KEY (docs__sequence);


ALTER INDEX public.docs_pkey OWNER TO source;

--
-- Name: eftr_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY eftr
    ADD CONSTRAINT eftr_pkey PRIMARY KEY (eftr__sequence);


ALTER INDEX public.eftr_pkey OWNER TO source;

--
-- Name: empl_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY empl
    ADD CONSTRAINT empl_pkey PRIMARY KEY (empl_code);


ALTER INDEX public.empl_pkey OWNER TO source;

--
-- Name: epsd_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY epsd
    ADD CONSTRAINT epsd_pkey PRIMARY KEY (epsd__sequence);


ALTER INDEX public.epsd_pkey OWNER TO source;

--
-- Name: evnt_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_pkey PRIMARY KEY (evnt__sequence);


ALTER INDEX public.evnt_pkey OWNER TO source;

--
-- Name: feeb_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY feeb
    ADD CONSTRAINT feeb_pkey PRIMARY KEY (feeb__sequence);


ALTER INDEX public.feeb_pkey OWNER TO source;

--
-- Name: feet_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY feet
    ADD CONSTRAINT feet_pkey PRIMARY KEY (feet_code);


ALTER INDEX public.feet_pkey OWNER TO source;

--
-- Name: fmdt_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY fmdt
    ADD CONSTRAINT fmdt_pkey PRIMARY KEY (fmdt__sequence);


ALTER INDEX public.fmdt_pkey OWNER TO source;

--
-- Name: form_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY form
    ADD CONSTRAINT form_pkey PRIMARY KEY (form_code);


ALTER INDEX public.form_pkey OWNER TO source;

--
-- Name: hice_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY hice
    ADD CONSTRAINT hice_pkey PRIMARY KEY (hice__sequence);


ALTER INDEX public.hice_pkey OWNER TO source;

--
-- Name: hlfd_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY hlfd
    ADD CONSTRAINT hlfd_pkey PRIMARY KEY (hlfd_code);


ALTER INDEX public.hlfd_pkey OWNER TO source;

--
-- Name: icd9_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY icd9
    ADD CONSTRAINT icd9_pkey PRIMARY KEY (icd9__sequence);


ALTER INDEX public.icd9_pkey OWNER TO source;

--
-- Name: inst_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY inst
    ADD CONSTRAINT inst_pkey PRIMARY KEY (inst__sequence);


ALTER INDEX public.inst_pkey OWNER TO source;

--
-- Name: invc_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_pkey PRIMARY KEY (invc__sequence);


ALTER INDEX public.invc_pkey OWNER TO source;

--
-- Name: labl_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY labl
    ADD CONSTRAINT labl_pkey PRIMARY KEY (labl__sequence);


ALTER INDEX public.labl_pkey OWNER TO source;

--
-- Name: locn_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY locn
    ADD CONSTRAINT locn_pkey PRIMARY KEY (locn_code);


ALTER INDEX public.locn_pkey OWNER TO source;

--
-- Name: lthd_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY lthd
    ADD CONSTRAINT lthd_pkey PRIMARY KEY (lthd__sequence);


ALTER INDEX public.lthd_pkey OWNER TO source;

--
-- Name: mbst_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mbst
    ADD CONSTRAINT mbst_pkey PRIMARY KEY (mbst__sequence);


ALTER INDEX public.mbst_pkey OWNER TO source;

--
-- Name: mdaf_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mdaf
    ADD CONSTRAINT mdaf_pkey PRIMARY KEY (mdaf__sequence);


ALTER INDEX public.mdaf_pkey OWNER TO source;

--
-- Name: mdbt_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mdbt
    ADD CONSTRAINT mdbt_pkey PRIMARY KEY (mdbt__sequence);


ALTER INDEX public.mdbt_pkey OWNER TO source;

--
-- Name: mdcr_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mdcr
    ADD CONSTRAINT mdcr_pkey PRIMARY KEY (mdcr__sequence);


ALTER INDEX public.mdcr_pkey OWNER TO source;

--
-- Name: mtad_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtad
    ADD CONSTRAINT mtad_pkey PRIMARY KEY (mtad__sequence);


ALTER INDEX public.mtad_pkey OWNER TO source;

--
-- Name: mtag_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtag
    ADD CONSTRAINT mtag_pkey PRIMARY KEY (mtag_name);


ALTER INDEX public.mtag_pkey OWNER TO source;

--
-- Name: mtal_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtal
    ADD CONSTRAINT mtal_pkey PRIMARY KEY (mtal__sequence);


ALTER INDEX public.mtal_pkey OWNER TO source;

--
-- Name: mtat_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtat
    ADD CONSTRAINT mtat_pkey PRIMARY KEY (mtat_name);


ALTER INDEX public.mtat_pkey OWNER TO source;

--
-- Name: mtau_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtau
    ADD CONSTRAINT mtau_pkey PRIMARY KEY (mtau__sequence);


ALTER INDEX public.mtau_pkey OWNER TO source;

--
-- Name: mtcl_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtcl
    ADD CONSTRAINT mtcl_pkey PRIMARY KEY (mtcl_name);


ALTER INDEX public.mtcl_pkey OWNER TO source;

--
-- Name: mtfn_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtfn
    ADD CONSTRAINT mtfn_pkey PRIMARY KEY (mtfn__sequence);


ALTER INDEX public.mtfn_pkey OWNER TO source;

--
-- Name: mtop_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtop
    ADD CONSTRAINT mtop_pkey PRIMARY KEY (mtop_code);


ALTER INDEX public.mtop_pkey OWNER TO source;

--
-- Name: mtpt_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtpt
    ADD CONSTRAINT mtpt_pkey PRIMARY KEY (mtpt__sequence);


ALTER INDEX public.mtpt_pkey OWNER TO source;

--
-- Name: mtrl_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtrl
    ADD CONSTRAINT mtrl_pkey PRIMARY KEY (mtrl__sequence);


ALTER INDEX public.mtrl_pkey OWNER TO source;

--
-- Name: mttb_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mttb
    ADD CONSTRAINT mttb_pkey PRIMARY KEY (mttb__sequence);


ALTER INDEX public.mttb_pkey OWNER TO source;

--
-- Name: mttk_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mttk
    ADD CONSTRAINT mttk_pkey PRIMARY KEY (mttk_code);


ALTER INDEX public.mttk_pkey OWNER TO source;

--
-- Name: mtvs_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mtvs
    ADD CONSTRAINT mtvs_pkey PRIMARY KEY (mtvs__sequence);


ALTER INDEX public.mtvs_pkey OWNER TO source;

--
-- Name: mvac_database_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mvac_database
    ADD CONSTRAINT mvac_database_pkey PRIMARY KEY (db_name);


ALTER INDEX public.mvac_database_pkey OWNER TO source;

--
-- Name: mvac_label_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mvac_label
    ADD CONSTRAINT mvac_label_pkey PRIMARY KEY (perms);


ALTER INDEX public.mvac_label_pkey OWNER TO source;

--
-- Name: mvac_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mvac_sessions
    ADD CONSTRAINT mvac_sessions_pkey PRIMARY KEY (sid, name);


ALTER INDEX public.mvac_sessions_pkey OWNER TO source;

--
-- Name: mvac_user_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY mvac_user
    ADD CONSTRAINT mvac_user_pkey PRIMARY KEY (uid);


ALTER INDEX public.mvac_user_pkey OWNER TO source;

--
-- Name: note_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY note
    ADD CONSTRAINT note_pkey PRIMARY KEY (note__sequence);


ALTER INDEX public.note_pkey OWNER TO source;

--
-- Name: pate_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY pate
    ADD CONSTRAINT pate_pkey PRIMARY KEY (pate__sequence);


ALTER INDEX public.pate_pkey OWNER TO source;

--
-- Name: patf_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY patf
    ADD CONSTRAINT patf_pkey PRIMARY KEY (patf_code);


ALTER INDEX public.patf_pkey OWNER TO source;

--
-- Name: patn_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_pkey PRIMARY KEY (patn__sequence);


ALTER INDEX public.patn_pkey OWNER TO source;

--
-- Name: paym_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY paym
    ADD CONSTRAINT paym_pkey PRIMARY KEY (paym__sequence);


ALTER INDEX public.paym_pkey OWNER TO source;

--
-- Name: pcde_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY pcde
    ADD CONSTRAINT pcde_pkey PRIMARY KEY (pcde__sequence);


ALTER INDEX public.pcde_pkey OWNER TO source;

--
-- Name: prnt_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY prnt
    ADD CONSTRAINT prnt_pkey PRIMARY KEY (prnt_name);


ALTER INDEX public.prnt_pkey OWNER TO source;

--
-- Name: prov_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY prov
    ADD CONSTRAINT prov_pkey PRIMARY KEY (prov_code);


ALTER INDEX public.prov_pkey OWNER TO source;

--
-- Name: pyas_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY pyas
    ADD CONSTRAINT pyas_pkey PRIMARY KEY (pyas__sequence);


ALTER INDEX public.pyas_pkey OWNER TO source;

--
-- Name: rfdr_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY rfdr
    ADD CONSTRAINT rfdr_pkey PRIMARY KEY (rfdr_code);


ALTER INDEX public.rfdr_pkey OWNER TO source;

--
-- Name: serv_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY serv
    ADD CONSTRAINT serv_pkey PRIMARY KEY (serv_code);


ALTER INDEX public.serv_pkey OWNER TO source;

--
-- Name: stts_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY stts
    ADD CONSTRAINT stts_pkey PRIMARY KEY (stts__sequence);


ALTER INDEX public.stts_pkey OWNER TO source;

--
-- Name: surg_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY surg
    ADD CONSTRAINT surg_pkey PRIMARY KEY (surg__sequence);


ALTER INDEX public.surg_pkey OWNER TO source;

--
-- Name: svpf_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY svpf
    ADD CONSTRAINT svpf_pkey PRIMARY KEY (svpf__sequence);


ALTER INDEX public.svpf_pkey OWNER TO source;

--
-- Name: svsm_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY svsm
    ADD CONSTRAINT svsm_pkey PRIMARY KEY (svsm__sequence);


ALTER INDEX public.svsm_pkey OWNER TO source;

--
-- Name: tdtp_pkey; Type: CONSTRAINT; Schema: public; Owner: source; Tablespace: 
--

ALTER TABLE ONLY tdtp
    ADD CONSTRAINT tdtp_pkey PRIMARY KEY (tdtp_code);


ALTER INDEX public.tdtp_pkey OWNER TO source;

--
-- Name: apst_apst__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX apst_apst__sequence_key ON apst USING btree (apst__sequence);


ALTER INDEX public.apst_apst__sequence_key OWNER TO source;

--
-- Name: bank_bank__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX bank_bank__sequence_key ON bank USING btree (bank__sequence);


ALTER INDEX public.bank_bank__sequence_key OWNER TO source;

--
-- Name: conf_conf__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX conf_conf__sequence_key ON conf USING btree (conf__sequence);


ALTER INDEX public.conf_conf__sequence_key OWNER TO source;

--
-- Name: dbtr_dbtr__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX dbtr_dbtr__sequence_key ON dbtr USING btree (dbtr__sequence);


ALTER INDEX public.dbtr_dbtr__sequence_key OWNER TO source;

--
-- Name: empl_empl__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX empl_empl__sequence_key ON empl USING btree (empl__sequence);


ALTER INDEX public.empl_empl__sequence_key OWNER TO source;

--
-- Name: feet_feet__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX feet_feet__sequence_key ON feet USING btree (feet__sequence);


ALTER INDEX public.feet_feet__sequence_key OWNER TO source;

--
-- Name: form_form__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX form_form__sequence_key ON form USING btree (form__sequence);


ALTER INDEX public.form_form__sequence_key OWNER TO source;

--
-- Name: hlfd_hlfd__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX hlfd_hlfd__sequence_key ON hlfd USING btree (hlfd__sequence);


ALTER INDEX public.hlfd_hlfd__sequence_key OWNER TO source;

--
-- Name: ix_clst_1; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_clst_1 ON clst USING btree (clst_serv_code_parent);


ALTER INDEX public.ix_clst_1 OWNER TO source;

--
-- Name: ix_cnrt_patn; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_cnrt_patn ON cnrt USING btree (cnrt_patn__sequence);


ALTER INDEX public.ix_cnrt_patn OWNER TO source;

--
-- Name: ix_cnrt_serv; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_cnrt_serv ON cnrt USING btree (cnrt_serv_code);


ALTER INDEX public.ix_cnrt_serv OWNER TO source;

--
-- Name: ix_cred_invc; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_cred_invc ON cred USING btree (cred_invc__sequence);


ALTER INDEX public.ix_cred_invc OWNER TO source;

--
-- Name: ix_cred_paym; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_cred_paym ON cred USING btree (cred_paym__sequence);


ALTER INDEX public.ix_cred_paym OWNER TO source;

--
-- Name: ix_evnt_starttime; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_evnt_starttime ON evnt USING btree (evnt_starttime);


ALTER INDEX public.ix_evnt_starttime OWNER TO source;

--
-- Name: ix_feeb_1; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX ix_feeb_1 ON feeb USING btree (feeb_serv_code, feeb_feet_code);


ALTER INDEX public.ix_feeb_1 OWNER TO source;

--
-- Name: ix_invc_dbtr; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_invc_dbtr ON invc USING btree (invc_dbtr_code);


ALTER INDEX public.ix_invc_dbtr OWNER TO source;

--
-- Name: ix_invc_patn; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_invc_patn ON invc USING btree (invc_patn__sequence);


ALTER INDEX public.ix_invc_patn OWNER TO source;

--
-- Name: ix_locality__sequence; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX ix_locality__sequence ON pcde USING btree (pcde_locality, pcde__sequence);


ALTER INDEX public.ix_locality__sequence OWNER TO source;

--
-- Name: ix_patn__sequence; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX ix_patn__sequence ON pate USING btree (pate_patn__sequence);


ALTER INDEX public.ix_patn__sequence OWNER TO source;

--
-- Name: ix_patn_dbtr; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_patn_dbtr ON patn USING btree (patn_dbtr_code);


ALTER INDEX public.ix_patn_dbtr OWNER TO source;

--
-- Name: ix_patn_psnam; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_patn_psnam ON patn USING btree (patn_psnam);


ALTER INDEX public.ix_patn_psnam OWNER TO source;

--
-- Name: ix_patn_rfdr; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_patn_rfdr ON patn USING btree (patn_rfdr_code);


ALTER INDEX public.ix_patn_rfdr OWNER TO source;

--
-- Name: ix_paym_1; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_paym_1 ON paym USING btree (paym_bkdp__sequence);


ALTER INDEX public.ix_paym_1 OWNER TO source;

--
-- Name: ix_paym_2; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_paym_2 ON paym USING btree (paym_date_entry);


ALTER INDEX public.ix_paym_2 OWNER TO source;

--
-- Name: ix_pcde_locality; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_pcde_locality ON pcde USING btree (pcde_locality);


ALTER INDEX public.ix_pcde_locality OWNER TO source;

--
-- Name: ix_pcde_postcode; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_pcde_postcode ON pcde USING btree (pcde_postcode);


ALTER INDEX public.ix_pcde_postcode OWNER TO source;

--
-- Name: ix_postcode__sequence; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX ix_postcode__sequence ON pcde USING btree (pcde_postcode, pcde__sequence);


ALTER INDEX public.ix_postcode__sequence OWNER TO source;

--
-- Name: ix_pyas_paym; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_pyas_paym ON pyas USING btree (pyas_paym__sequence);


ALTER INDEX public.ix_pyas_paym OWNER TO source;

--
-- Name: ix_pyas_svpf; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_pyas_svpf ON pyas USING btree (pyas_svpf__sequence);


ALTER INDEX public.ix_pyas_svpf OWNER TO source;

--
-- Name: ix_rfdr_code; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX ix_rfdr_code ON rfdr USING btree (rfdr_code);


ALTER INDEX public.ix_rfdr_code OWNER TO source;

--
-- Name: ix_surg_patn; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_surg_patn ON surg USING btree (surg_patn__sequence);


ALTER INDEX public.ix_surg_patn OWNER TO source;

--
-- Name: ix_svpf_invc; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_svpf_invc ON svpf USING btree (svpf_invc__sequence);


ALTER INDEX public.ix_svpf_invc OWNER TO source;

--
-- Name: ix_svpf_patn; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_svpf_patn ON svpf USING btree (svpf_patn__sequence);


ALTER INDEX public.ix_svpf_patn OWNER TO source;

--
-- Name: ix_svpf_serv; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE INDEX ix_svpf_serv ON svpf USING btree (svpf_serv_code);


ALTER INDEX public.ix_svpf_serv OWNER TO source;

--
-- Name: k_database; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX k_database ON mvac_database USING btree (db_name);


ALTER INDEX public.k_database OWNER TO source;

--
-- Name: k_username; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX k_username ON mvac_user USING btree (username);


ALTER INDEX public.k_username OWNER TO source;

--
-- Name: locn_locn__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX locn_locn__sequence_key ON locn USING btree (locn__sequence);


ALTER INDEX public.locn_locn__sequence_key OWNER TO source;

--
-- Name: mtat_mtat__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX mtat_mtat__sequence_key ON mtat USING btree (mtat__sequence);


ALTER INDEX public.mtat_mtat__sequence_key OWNER TO source;

--
-- Name: mtcl_mtcl__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX mtcl_mtcl__sequence_key ON mtcl USING btree (mtcl__sequence);


ALTER INDEX public.mtcl_mtcl__sequence_key OWNER TO source;

--
-- Name: patf_patf__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX patf_patf__sequence_key ON patf USING btree (patf__sequence);


ALTER INDEX public.patf_patf__sequence_key OWNER TO source;

--
-- Name: prnt_prnt__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX prnt_prnt__sequence_key ON prnt USING btree (prnt__sequence);


ALTER INDEX public.prnt_prnt__sequence_key OWNER TO source;

--
-- Name: prov_prov__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX prov_prov__sequence_key ON prov USING btree (prov__sequence);


ALTER INDEX public.prov_prov__sequence_key OWNER TO source;

--
-- Name: rfdr_rfdr__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX rfdr_rfdr__sequence_key ON rfdr USING btree (rfdr__sequence);


ALTER INDEX public.rfdr_rfdr__sequence_key OWNER TO source;

--
-- Name: serv_serv__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX serv_serv__sequence_key ON serv USING btree (serv__sequence);


ALTER INDEX public.serv_serv__sequence_key OWNER TO source;

--
-- Name: tdtp_tdtp__sequence_key; Type: INDEX; Schema: public; Owner: source; Tablespace: 
--

CREATE UNIQUE INDEX tdtp_tdtp__sequence_key ON tdtp USING btree (tdtp__sequence);


ALTER INDEX public.tdtp_tdtp__sequence_key OWNER TO source;

--
-- Name: rl_cnrv_delete; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_cnrv_delete AS ON DELETE TO cnrv DO INSTEAD DELETE FROM cnrt WHERE (cnrt.cnrt__sequence = old.cnrv__sequence);


--
-- Name: rl_cnrv_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_cnrv_update AS ON UPDATE TO cnrv DO INSTEAD UPDATE cnrt SET cnrt_patn__sequence = new.cnrv_patn__sequence, cnrt_amount = new.cnrv_amount, ctrt_period = new.ctrv_period, cnrt_count = new.cnrv_count, cnrt_start_date = (new.cnrv_start_date)::timestamp without time zone, cnrt_serv_code = new.cnrv_serv_code, cnrt_first_installment = new.cnrv_first_installment, cnrt_other_installment = new.cnrv_other_installment, cnrt_last_date = (new.cnrv_last_date)::timestamp without time zone, cnrt_balance = new.cnrv_balance, cnrt_end_date = (new.cnrv_end_date)::timestamp without time zone, cnrt__sequence = new.cnrv__sequence, cnrt__timestamp = new.cnrv__timestamp, cnrt__user_entry = new.cnrv__user_entry, cnrt__status = new.cnrv__status WHERE (cnrt.cnrt__sequence = new.cnrv__sequence);


--
-- Name: rl_crep_delete; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_crep_delete AS ON DELETE TO crep DO INSTEAD DELETE FROM cred WHERE (cred.cred__sequence = old.crep__sequence);


--
-- Name: rl_crep_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_crep_update AS ON UPDATE TO crep DO INSTEAD UPDATE cred SET cred_invc__sequence = new.crep_invc__sequence, cred_paym__sequence = new.crep_paym__sequence, cred_amount = new.crep_cred_amount, cred_gst_amount = new.crep_cred_gst_amount WHERE (cred.cred__sequence = new.crep__sequence);


--
-- Name: rl_crev_delete; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_crev_delete AS ON DELETE TO crev DO INSTEAD DELETE FROM cred WHERE (cred.cred__sequence = old.crev__sequence);


--
-- Name: rl_crev_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_crev_update AS ON UPDATE TO crev DO INSTEAD (UPDATE cred SET cred_invc__sequence = new.crev_invc__sequence, cred_amount = new.crev_cred_amount, cred_gst_amount = new.crev_cred_gst_amount, cred_notes = new.crev_cred_notes WHERE (cred.cred__sequence = new.crev__sequence); UPDATE paym SET paym_user_entry = new.crev_user_entry, paym_site_entry = new.crev_site_entry, paym_date_entry = new.crev_date_entry, paym_amount = new.crev_paym_amount, paym_tdtp_code = new.crev_tdtp_code, paym_drawer = new.crev_drawer, paym_bank = new.crev_bank, paym_branch = new.crev_branch WHERE (paym.paym__sequence = new.crev_paym__sequence); UPDATE paym SET paym_amount = (SELECT (sum(cred.cred_amount) + sum(cred.cred_gst_amount)) FROM cred WHERE (cred.cred_paym__sequence = new.crev_paym__sequence)) WHERE (paym.paym__sequence = new.crev_paym__sequence); );


--
-- Name: rl_evnv_delete; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_evnv_delete AS ON DELETE TO evnv DO INSTEAD DELETE FROM evnt WHERE (evnt.evnt__sequence = old.evnv__sequence);


--
-- Name: rl_evnv_insert; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_evnv_insert AS ON INSERT TO evnv DO INSTEAD SELECT evnv_insert_row() AS evnv_insert_row;


--
-- Name: rl_evnv_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_evnv_update AS ON UPDATE TO evnv DO INSTEAD (UPDATE evnt SET evnt_patn__sequence = new.evnv_patn__sequence, evnt_prov_code = new.evnv_prov_code, evnt_rfdr_code = new.evnv_rfdr_code, evnt_locn_code = new.evnv_locn_code, evnt_aptp_code = new.evnv_aptp_code, evnt_apst_code = new.evnv_apst_code, evnt_starttime = new.evnv_starttime, evnt_duration = new.evnv_duration, evnt_desc = new.evnv_desc, evnt_note_1 = new.evnv_note_1, evnt_note_2 = new.evnv_note_2 WHERE (evnt.evnt__sequence = new.evnv__sequence); UPDATE patn SET patn_psnam = new.evnv_patn_psnam, patn_fsnam = new.evnv_patn_fsnam, patn_title = new.evnv_patn_title, patn_dob = (new.evnv_patn_dob)::timestamp without time zone, patn_address = new.evnv_patn_address, patn_suburb = new.evnv_patn_suburb, patn_postcode = new.evnv_patn_postcode, patn_phone = new.evnv_patn_phone, patn_rfdr_code = new.evnv_rfdr_code, patn_ref_date = new.evnv_patn_ref_date, patn_ref_period = new.evnv_patn_ref_period, patn_flno = new.evnv_patn_flno, patn_feet_code = new.evnv_patn_feet_code WHERE ((patn.patn__sequence = new.evnv_patn__sequence) AND (new.evnv_patn__sequence > 0)); );


--
-- Name: rl_evwl_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_evwl_update AS ON UPDATE TO evwl DO INSTEAD UPDATE evnt SET evnt_apst_code = new.evwl_apst_code, evnt_desc = new.evwl_desc WHERE (evnt.evnt__sequence = new.evwl__sequence);


--
-- Name: rl_hicv_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_hicv_update AS ON UPDATE TO hicv DO INSTEAD UPDATE mdbt SET mdbt_claim_date = (new.hicv_timeoflodgement)::timestamp without time zone WHERE (mdbt.mdbt__sequence = new.hicv__sequence);


--
-- Name: rl_notv_delete; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_notv_delete AS ON DELETE TO notv DO INSTEAD DELETE FROM note WHERE (note.note__sequence = old.notv__sequence);


--
-- Name: rl_notv_insert; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_notv_insert AS ON INSERT TO notv DO INSTEAD SELECT notv_insert_row() AS notv_insert_row;


--
-- Name: rl_notv_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_notv_update AS ON UPDATE TO notv DO INSTEAD UPDATE note SET note_patn__sequence = new.notv_patn__sequence, note_desc = new.notv_desc WHERE (note.note__sequence = new.notv__sequence);


--
-- Name: rl_surv_delete; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_surv_delete AS ON DELETE TO surv DO INSTEAD DELETE FROM surg WHERE (surg.surg__sequence = old.surv__sequence);


--
-- Name: rl_surv_update; Type: RULE; Schema: public; Owner: source
--

CREATE RULE rl_surv_update AS ON UPDATE TO surv DO INSTEAD UPDATE surg SET surg_symptoms = new.surv_symptoms, surg_class = new.surv_class, surg_diag_codes = new.surv_diag_codes, surg_diagnosis = new.surv_diagnosis, surg_treatment = new.surv_treatment, surg_oprn_codes = new.surv_oprn_codes, surg_operation = new.surv_operation, surg_oprn_date = new.surv_oprn_date, surg_oprn_place = new.surv_oprn_place, surg_photo_code = new.surv_photo_code WHERE (surg.surg__sequence = new.surv__sequence);


--
-- Name: apst_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER apst_tr_before
    BEFORE INSERT OR UPDATE ON apst
    FOR EACH ROW
    EXECUTE PROCEDURE apst_tr_before();


--
-- Name: aptp_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER aptp_tr_before
    BEFORE INSERT OR DELETE OR UPDATE ON aptp
    FOR EACH ROW
    EXECUTE PROCEDURE aptp_tr_before();


--
-- Name: bank_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER bank_tr_before
    BEFORE INSERT OR UPDATE ON bank
    FOR EACH ROW
    EXECUTE PROCEDURE bank_tr_before();


--
-- Name: bkdp_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER bkdp_tr_before
    BEFORE INSERT OR DELETE OR UPDATE ON bkdp
    FOR EACH ROW
    EXECUTE PROCEDURE bkdp_tr_before();


--
-- Name: cnrt_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER cnrt_tr_before
    BEFORE INSERT OR UPDATE ON cnrt
    FOR EACH ROW
    EXECUTE PROCEDURE cnrt_tr_before();


--
-- Name: cred_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER cred_tr_before
    BEFORE INSERT OR UPDATE ON cred
    FOR EACH ROW
    EXECUTE PROCEDURE cred_tr_before();


--
-- Name: dbtr_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER dbtr_tr_before
    BEFORE INSERT OR DELETE OR UPDATE ON dbtr
    FOR EACH ROW
    EXECUTE PROCEDURE dbtr_tr_before();


--
-- Name: eftr_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER eftr_tr_before
    BEFORE INSERT ON eftr
    FOR EACH ROW
    EXECUTE PROCEDURE eftr_tr_before();


--
-- Name: feeb_tr_after_feet; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER feeb_tr_after_feet
    AFTER INSERT ON feet
    FOR EACH ROW
    EXECUTE PROCEDURE feeb_tr_after();


--
-- Name: feeb_tr_after_serv; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER feeb_tr_after_serv
    AFTER INSERT ON serv
    FOR EACH ROW
    EXECUTE PROCEDURE feeb_tr_after();


--
-- Name: feet_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER feet_tr_before
    BEFORE INSERT OR UPDATE ON feet
    FOR EACH ROW
    EXECUTE PROCEDURE feet_tr_before();


--
-- Name: form_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER form_tr_before
    BEFORE INSERT OR UPDATE ON form
    FOR EACH ROW
    EXECUTE PROCEDURE form_tr_before();


--
-- Name: hlfd_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER hlfd_tr_before
    BEFORE INSERT OR UPDATE ON hlfd
    FOR EACH ROW
    EXECUTE PROCEDURE hlfd_tr_before();


--
-- Name: invc_credit_totals; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER invc_credit_totals
    AFTER INSERT OR DELETE OR UPDATE ON cred
    FOR EACH ROW
    EXECUTE PROCEDURE invc_credit_totals();


--
-- Name: invc_debit_totals; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER invc_debit_totals
    AFTER INSERT OR DELETE OR UPDATE ON svpf
    FOR EACH ROW
    EXECUTE PROCEDURE invc_debit_totals();


--
-- Name: locn_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER locn_tr_before
    BEFORE INSERT OR UPDATE ON locn
    FOR EACH ROW
    EXECUTE PROCEDURE locn_tr_before();


--
-- Name: mtfn_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER mtfn_tr_before
    BEFORE INSERT OR UPDATE ON mtfn
    FOR EACH ROW
    EXECUTE PROCEDURE mtfn_tr_before();


--
-- Name: mtrl_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER mtrl_tr_before
    BEFORE INSERT OR UPDATE ON mtrl
    FOR EACH ROW
    EXECUTE PROCEDURE mtrl_tr_before();


--
-- Name: patf_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER patf_tr_before
    BEFORE INSERT OR UPDATE ON patf
    FOR EACH ROW
    EXECUTE PROCEDURE patf_tr_before();


--
-- Name: rfdr_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER rfdr_tr_before
    BEFORE INSERT OR DELETE OR UPDATE ON rfdr
    FOR EACH ROW
    EXECUTE PROCEDURE rfdr_tr_before();


--
-- Name: serv_tr_before; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER serv_tr_before
    BEFORE INSERT OR UPDATE ON serv
    FOR EACH ROW
    EXECUTE PROCEDURE serv_tr_before();


--
-- Name: tr_after_feeb; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_after_feeb
    BEFORE INSERT OR UPDATE ON feeb
    FOR EACH ROW
    EXECUTE PROCEDURE tr_before_feeb();


--
-- Name: tr_amountoutstanding; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_amountoutstanding
    AFTER INSERT OR DELETE OR UPDATE ON invc
    FOR EACH ROW
    EXECUTE PROCEDURE fn_amountoutstanding();


--
-- Name: tr_copypatndata; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_copypatndata
    BEFORE INSERT OR UPDATE ON evnt
    FOR EACH ROW
    EXECUTE PROCEDURE fn_copypatndata();


--
-- Name: tr_invc_closedinvoice; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_invc_closedinvoice
    BEFORE DELETE OR UPDATE ON invc
    FOR EACH ROW
    EXECUTE PROCEDURE fn_invc_closedinvoice();


--
-- Name: tr_lastservice; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_lastservice
    AFTER INSERT OR DELETE OR UPDATE ON svpf
    FOR EACH ROW
    EXECUTE PROCEDURE fn_lastservice();


--
-- Name: tr_lastvisit; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_lastvisit
    AFTER INSERT OR DELETE OR UPDATE ON evnt
    FOR EACH ROW
    EXECUTE PROCEDURE fn_lastvisit();


--
-- Name: tr_patientexport; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_patientexport
    AFTER INSERT OR UPDATE ON patn
    FOR EACH ROW
    EXECUTE PROCEDURE fn_patientexport();


--
-- Name: tr_patn_dob_check; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_patn_dob_check
    BEFORE INSERT OR UPDATE ON patn
    FOR EACH ROW
    EXECUTE PROCEDURE fn_patn_dob_check();


--
-- Name: tr_patn_null2default; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_patn_null2default
    BEFORE INSERT OR UPDATE ON patn
    FOR EACH ROW
    EXECUTE PROCEDURE fn_patn_null2default();


--
-- Name: tr_paym_closeddeposit; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_paym_closeddeposit
    BEFORE DELETE OR UPDATE ON paym
    FOR EACH ROW
    EXECUTE PROCEDURE fn_paym_closeddeposit();


--
-- Name: tr_paym_null2default; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_paym_null2default
    BEFORE INSERT OR UPDATE ON paym
    FOR EACH ROW
    EXECUTE PROCEDURE fn_paym_null2default();


--
-- Name: tr_serv_ckdel; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_serv_ckdel
    BEFORE DELETE OR UPDATE ON serv
    FOR EACH ROW
    EXECUTE PROCEDURE fn_serv_ckdel();


--
-- Name: tr_setbkdpamount; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_setbkdpamount
    AFTER INSERT OR DELETE OR UPDATE ON paym
    FOR EACH ROW
    EXECUTE PROCEDURE fn_setbkdpamount();


--
-- Name: tr_svpf_closedinvoice; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_svpf_closedinvoice
    BEFORE DELETE OR UPDATE ON svpf
    FOR EACH ROW
    EXECUTE PROCEDURE fn_svpf_closedinvoice();


--
-- Name: tr_svpf_null2default; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_svpf_null2default
    BEFORE INSERT OR UPDATE ON svpf
    FOR EACH ROW
    EXECUTE PROCEDURE fn_svpf_null2default();


--
-- Name: tr_vacuumtickets; Type: TRIGGER; Schema: public; Owner: source
--

CREATE TRIGGER tr_vacuumtickets
    BEFORE INSERT ON mttk
    FOR EACH ROW
    EXECUTE PROCEDURE fn_vacuumtickets();


--
-- Name: $1; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtag
    ADD CONSTRAINT "$1" FOREIGN KEY (mtag_parent) REFERENCES mtag(mtag_name) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: $1; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtad
    ADD CONSTRAINT "$1" FOREIGN KEY (mtad_parent) REFERENCES mtag(mtag_name) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: $2; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtad
    ADD CONSTRAINT "$2" FOREIGN KEY (mtad_class) REFERENCES mtcl(mtcl_name) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: aptd_fk_aptp; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY aptd
    ADD CONSTRAINT aptd_fk_aptp FOREIGN KEY (aptd_aptp_code) REFERENCES aptp(aptp_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aptd_fk_locn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY aptd
    ADD CONSTRAINT aptd_fk_locn FOREIGN KEY (aptd_locn_code) REFERENCES locn(locn_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aptd_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY aptd
    ADD CONSTRAINT aptd_fk_prov FOREIGN KEY (aptd_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cash_fk_bank; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY cash
    ADD CONSTRAINT cash_fk_bank FOREIGN KEY (cash_bank_code) REFERENCES bank(bank_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cash_fk_paym; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY cash
    ADD CONSTRAINT cash_fk_paym FOREIGN KEY (cash_paym__sequence) REFERENCES paym(paym__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cnrt_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY cnrt
    ADD CONSTRAINT cnrt_fk_patn FOREIGN KEY (cnrt_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cnrt_fk_serv; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY cnrt
    ADD CONSTRAINT cnrt_fk_serv FOREIGN KEY (cnrt_serv_code) REFERENCES serv(serv_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cred_fk_invc; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY cred
    ADD CONSTRAINT cred_fk_invc FOREIGN KEY (cred_invc__sequence) REFERENCES invc(invc__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cred_fk_paym; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY cred
    ADD CONSTRAINT cred_fk_paym FOREIGN KEY (cred_paym__sequence) REFERENCES paym(paym__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: crsm_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY crsm
    ADD CONSTRAINT crsm_fk_prov FOREIGN KEY (crsm_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: crsm_fk_tdtp; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY crsm
    ADD CONSTRAINT crsm_fk_tdtp FOREIGN KEY (crsm_tdtp_code) REFERENCES tdtp(tdtp_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: docs_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY docs
    ADD CONSTRAINT docs_fk_patn FOREIGN KEY (docs_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: evnt_fk_apst; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_fk_apst FOREIGN KEY (evnt_apst_code) REFERENCES apst(apst_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: evnt_fk_aptp; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_fk_aptp FOREIGN KEY (evnt_aptp_code) REFERENCES aptp(aptp_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: evnt_fk_locn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_fk_locn FOREIGN KEY (evnt_locn_code) REFERENCES locn(locn_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: evnt_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_fk_patn FOREIGN KEY (evnt_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: evnt_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_fk_prov FOREIGN KEY (evnt_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: evnt_fk_rfdr; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY evnt
    ADD CONSTRAINT evnt_fk_rfdr FOREIGN KEY (evnt_rfdr_code) REFERENCES rfdr(rfdr_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feeb_fk_feet; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY feeb
    ADD CONSTRAINT feeb_fk_feet FOREIGN KEY (feeb_feet_code) REFERENCES feet(feet_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feeb_fk_serv; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY feeb
    ADD CONSTRAINT feeb_fk_serv FOREIGN KEY (feeb_serv_code) REFERENCES serv(serv_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: fmdt_fk_form; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY fmdt
    ADD CONSTRAINT fmdt_fk_form FOREIGN KEY (fmdt_form_code) REFERENCES form(form_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_bank; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_bank FOREIGN KEY (invc_bank_code) REFERENCES bank(bank_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_dbtr; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_dbtr FOREIGN KEY (invc_dbtr_code) REFERENCES dbtr(dbtr_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_empl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_empl FOREIGN KEY (invc_empl_code) REFERENCES empl(empl_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_feet; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_feet FOREIGN KEY (invc_feet_code) REFERENCES feet(feet_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_patn FOREIGN KEY (invc_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_prov FOREIGN KEY (invc_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invc_fk_rfdr; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY invc
    ADD CONSTRAINT invc_fk_rfdr FOREIGN KEY (invc_rfdr_code) REFERENCES rfdr(rfdr_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mdaf_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mdaf
    ADD CONSTRAINT mdaf_fk_patn FOREIGN KEY (mdaf_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mdaf_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mdaf
    ADD CONSTRAINT mdaf_fk_prov FOREIGN KEY (mdaf_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mdaf_fk_rfdr; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mdaf
    ADD CONSTRAINT mdaf_fk_rfdr FOREIGN KEY (mdaf_rfdr_code) REFERENCES rfdr(rfdr_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mdcr_fk_paym; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mdcr
    ADD CONSTRAINT mdcr_fk_paym FOREIGN KEY (mdcr_paym__sequence) REFERENCES paym(paym__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mdcr_fk_svpf; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mdcr
    ADD CONSTRAINT mdcr_fk_svpf FOREIGN KEY (mdcr_svpf__sequence) REFERENCES svpf(svpf__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtal_fk_mtop; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtal
    ADD CONSTRAINT mtal_fk_mtop FOREIGN KEY (mtal_mtop_code) REFERENCES mtop(mtop_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtat_fk_mtcl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtat
    ADD CONSTRAINT mtat_fk_mtcl FOREIGN KEY (mtat_class_name) REFERENCES mtcl(mtcl_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtcl_fk_mtag; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtcl
    ADD CONSTRAINT mtcl_fk_mtag FOREIGN KEY (mtcl_group) REFERENCES mtag(mtag_name) ON UPDATE CASCADE ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtfn_fk_join_mtat; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtfn
    ADD CONSTRAINT mtfn_fk_join_mtat FOREIGN KEY (mtfn_join) REFERENCES mtat(mtat_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtfn_fk_key_mtat; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtfn
    ADD CONSTRAINT mtfn_fk_key_mtat FOREIGN KEY (mtfn_key) REFERENCES mtat(mtat_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtfn_fk_master_mtcl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtfn
    ADD CONSTRAINT mtfn_fk_master_mtcl FOREIGN KEY (mtfn_master_class) REFERENCES mtcl(mtcl_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtfn_fk_other_mtcl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtfn
    ADD CONSTRAINT mtfn_fk_other_mtcl FOREIGN KEY (mtfn_other_class) REFERENCES mtcl(mtcl_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtfn_fk_view_mtat; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtfn
    ADD CONSTRAINT mtfn_fk_view_mtat FOREIGN KEY (mtfn_view) REFERENCES mtat(mtat_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtrl_fk_master_mtcl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtrl
    ADD CONSTRAINT mtrl_fk_master_mtcl FOREIGN KEY (mtrl_master_class) REFERENCES mtcl(mtcl_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mtrl_fk_other_mtcl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY mtrl
    ADD CONSTRAINT mtrl_fk_other_mtcl FOREIGN KEY (mtrl_other_class) REFERENCES mtcl(mtcl_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: note_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY note
    ADD CONSTRAINT note_fk_patn FOREIGN KEY (note_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_dbtr; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_dbtr FOREIGN KEY (patn_dbtr_code) REFERENCES dbtr(dbtr_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_empl; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_empl FOREIGN KEY (patn_empl_code) REFERENCES empl(empl_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_feet; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_feet FOREIGN KEY (patn_feet_code) REFERENCES feet(feet_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_hlfd; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_hlfd FOREIGN KEY (patn_hlfd_code) REFERENCES hlfd(hlfd_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_patf; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_patf FOREIGN KEY (patn_patf_code) REFERENCES patf(patf_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_prov FOREIGN KEY (patn_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patn_fk_rfdr; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY patn
    ADD CONSTRAINT patn_fk_rfdr FOREIGN KEY (patn_rfdr_code) REFERENCES rfdr(rfdr_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: paym_fk_bkdp; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY paym
    ADD CONSTRAINT paym_fk_bkdp FOREIGN KEY (paym_bkdp__sequence) REFERENCES bkdp(bkdp__sequence) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: paym_fk_tdtp; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY paym
    ADD CONSTRAINT paym_fk_tdtp FOREIGN KEY (paym_tdtp_code) REFERENCES tdtp(tdtp_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pyas_fk_paym; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY pyas
    ADD CONSTRAINT pyas_fk_paym FOREIGN KEY (pyas_paym__sequence) REFERENCES paym(paym__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pyas_fk_svpf; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY pyas
    ADD CONSTRAINT pyas_fk_svpf FOREIGN KEY (pyas_svpf__sequence) REFERENCES svpf(svpf__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: surg_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY surg
    ADD CONSTRAINT surg_fk_patn FOREIGN KEY (surg_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: svpf_fk_invc; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY svpf
    ADD CONSTRAINT svpf_fk_invc FOREIGN KEY (svpf_invc__sequence) REFERENCES invc(invc__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: svpf_fk_mdaf; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY svpf
    ADD CONSTRAINT svpf_fk_mdaf FOREIGN KEY (svpf_mdaf__sequence) REFERENCES mdaf(mdaf__sequence) ON UPDATE CASCADE ON DELETE SET DEFAULT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: svpf_fk_patn; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY svpf
    ADD CONSTRAINT svpf_fk_patn FOREIGN KEY (svpf_patn__sequence) REFERENCES patn(patn__sequence) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: svpf_fk_serv; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY svpf
    ADD CONSTRAINT svpf_fk_serv FOREIGN KEY (svpf_serv_code) REFERENCES serv(serv_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: svsm_fk_prov; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY svsm
    ADD CONSTRAINT svsm_fk_prov FOREIGN KEY (svsm_prov_code) REFERENCES prov(prov_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: svsm_fk_serv; Type: FK CONSTRAINT; Schema: public; Owner: source
--

ALTER TABLE ONLY svsm
    ADD CONSTRAINT svsm_fk_serv FOREIGN KEY (svsm_serv_code) REFERENCES serv(serv_code) ON UPDATE CASCADE ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: accl; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE accl FROM PUBLIC;
REVOKE ALL ON TABLE accl FROM source;
GRANT ALL ON TABLE accl TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE accl TO PUBLIC;


--
-- Name: accl_accl__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE accl_accl__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE accl_accl__sequence_seq FROM source;
GRANT ALL ON TABLE accl_accl__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE accl_accl__sequence_seq TO PUBLIC;


--
-- Name: addr; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE addr FROM PUBLIC;
REVOKE ALL ON TABLE addr FROM source;
GRANT ALL ON TABLE addr TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE addr TO PUBLIC;


--
-- Name: addr_addr__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE addr_addr__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE addr_addr__sequence_seq FROM source;
GRANT ALL ON TABLE addr_addr__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE addr_addr__sequence_seq TO PUBLIC;


--
-- Name: dbtr; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE dbtr FROM PUBLIC;
REVOKE ALL ON TABLE dbtr FROM source;
GRANT ALL ON TABLE dbtr TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE dbtr TO PUBLIC;


--
-- Name: invc; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE invc FROM PUBLIC;
REVOKE ALL ON TABLE invc FROM source;
GRANT ALL ON TABLE invc TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE invc TO PUBLIC;


--
-- Name: agdi; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE agdi FROM PUBLIC;
REVOKE ALL ON TABLE agdi FROM source;
GRANT ALL ON TABLE agdi TO source;
GRANT SELECT ON TABLE agdi TO PUBLIC;


--
-- Name: agdd; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE agdd FROM PUBLIC;
REVOKE ALL ON TABLE agdd FROM source;
GRANT ALL ON TABLE agdd TO source;
GRANT SELECT ON TABLE agdd TO PUBLIC;


--
-- Name: agdp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE agdp FROM PUBLIC;
REVOKE ALL ON TABLE agdp FROM source;
GRANT ALL ON TABLE agdp TO source;
GRANT SELECT ON TABLE agdp TO PUBLIC;


--
-- Name: agdt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE agdt FROM PUBLIC;
REVOKE ALL ON TABLE agdt FROM source;
GRANT ALL ON TABLE agdt TO source;
GRANT SELECT ON TABLE agdt TO PUBLIC;


--
-- Name: apst; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE apst FROM PUBLIC;
REVOKE ALL ON TABLE apst FROM source;
GRANT ALL ON TABLE apst TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE apst TO PUBLIC;


--
-- Name: apst_apst__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE apst_apst__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE apst_apst__sequence_seq FROM source;
GRANT ALL ON TABLE apst_apst__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE apst_apst__sequence_seq TO PUBLIC;


--
-- Name: aptd; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE aptd FROM PUBLIC;
REVOKE ALL ON TABLE aptd FROM source;
GRANT ALL ON TABLE aptd TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE aptd TO PUBLIC;


--
-- Name: aptd_aptd__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE aptd_aptd__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE aptd_aptd__sequence_seq FROM source;
GRANT ALL ON TABLE aptd_aptd__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE aptd_aptd__sequence_seq TO PUBLIC;


--
-- Name: aptp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE aptp FROM PUBLIC;
REVOKE ALL ON TABLE aptp FROM source;
GRANT ALL ON TABLE aptp TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE aptp TO PUBLIC;


--
-- Name: aptp_aptp__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE aptp_aptp__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE aptp_aptp__sequence_seq FROM source;
GRANT ALL ON TABLE aptp_aptp__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE aptp_aptp__sequence_seq TO PUBLIC;


--
-- Name: bank; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE bank FROM PUBLIC;
REVOKE ALL ON TABLE bank FROM source;
GRANT ALL ON TABLE bank TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE bank TO PUBLIC;


--
-- Name: bank_bank__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE bank_bank__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE bank_bank__sequence_seq FROM source;
GRANT ALL ON TABLE bank_bank__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE bank_bank__sequence_seq TO PUBLIC;


--
-- Name: bkdp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE bkdp FROM PUBLIC;
REVOKE ALL ON TABLE bkdp FROM source;
GRANT ALL ON TABLE bkdp TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE bkdp TO PUBLIC;


--
-- Name: bkdp_bkdp__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE bkdp_bkdp__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE bkdp_bkdp__sequence_seq FROM source;
GRANT ALL ON TABLE bkdp_bkdp__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE bkdp_bkdp__sequence_seq TO PUBLIC;


--
-- Name: cred; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cred FROM PUBLIC;
REVOKE ALL ON TABLE cred FROM source;
GRANT ALL ON TABLE cred TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE cred TO PUBLIC;


--
-- Name: patn; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE patn FROM PUBLIC;
REVOKE ALL ON TABLE patn FROM source;
GRANT ALL ON TABLE patn TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE patn TO PUBLIC;


--
-- Name: paym; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE paym FROM PUBLIC;
REVOKE ALL ON TABLE paym FROM source;
GRANT ALL ON TABLE paym TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE paym TO PUBLIC;


--
-- Name: tdtp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE tdtp FROM PUBLIC;
REVOKE ALL ON TABLE tdtp FROM source;
GRANT ALL ON TABLE tdtp TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE tdtp TO PUBLIC;


--
-- Name: bkdv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE bkdv FROM PUBLIC;
REVOKE ALL ON TABLE bkdv FROM source;
GRANT ALL ON TABLE bkdv TO source;
GRANT SELECT ON TABLE bkdv TO PUBLIC;


--
-- Name: cash; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cash FROM PUBLIC;
REVOKE ALL ON TABLE cash FROM source;
GRANT ALL ON TABLE cash TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE cash TO PUBLIC;


--
-- Name: cash_cash__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cash_cash__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE cash_cash__sequence_seq FROM source;
GRANT ALL ON TABLE cash_cash__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE cash_cash__sequence_seq TO PUBLIC;


--
-- Name: clsp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE clsp FROM PUBLIC;
REVOKE ALL ON TABLE clsp FROM source;
GRANT ALL ON TABLE clsp TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE clsp TO PUBLIC;


--
-- Name: clsp_clsp__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE clsp_clsp__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE clsp_clsp__sequence_seq FROM source;
GRANT ALL ON TABLE clsp_clsp__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE clsp_clsp__sequence_seq TO PUBLIC;


--
-- Name: clst; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE clst FROM PUBLIC;
REVOKE ALL ON TABLE clst FROM source;
GRANT ALL ON TABLE clst TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE clst TO PUBLIC;


--
-- Name: clst_clst__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE clst_clst__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE clst_clst__sequence_seq FROM source;
GRANT ALL ON TABLE clst_clst__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE clst_clst__sequence_seq TO PUBLIC;


--
-- Name: cnrt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cnrt FROM PUBLIC;
REVOKE ALL ON TABLE cnrt FROM source;
GRANT ALL ON TABLE cnrt TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE cnrt TO PUBLIC;


--
-- Name: cnrt_cnrt__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cnrt_cnrt__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE cnrt_cnrt__sequence_seq FROM source;
GRANT ALL ON TABLE cnrt_cnrt__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE cnrt_cnrt__sequence_seq TO PUBLIC;


--
-- Name: cnrv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cnrv FROM PUBLIC;
REVOKE ALL ON TABLE cnrv FROM source;
GRANT ALL ON TABLE cnrv TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE cnrv TO PUBLIC;


--
-- Name: cnty; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cnty FROM PUBLIC;
REVOKE ALL ON TABLE cnty FROM source;
GRANT ALL ON TABLE cnty TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE cnty TO PUBLIC;


--
-- Name: cnty_cnty__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cnty_cnty__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE cnty_cnty__sequence_seq FROM source;
GRANT ALL ON TABLE cnty_cnty__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE cnty_cnty__sequence_seq TO PUBLIC;


--
-- Name: conf; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE conf FROM PUBLIC;
REVOKE ALL ON TABLE conf FROM source;
GRANT ALL ON TABLE conf TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE conf TO PUBLIC;


--
-- Name: conf_conf__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE conf_conf__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE conf_conf__sequence_seq FROM source;
GRANT ALL ON TABLE conf_conf__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE conf_conf__sequence_seq TO PUBLIC;


--
-- Name: cred_cred__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE cred_cred__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE cred_cred__sequence_seq FROM source;
GRANT ALL ON TABLE cred_cred__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE cred_cred__sequence_seq TO PUBLIC;


--
-- Name: crep; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE crep FROM PUBLIC;
REVOKE ALL ON TABLE crep FROM source;
GRANT ALL ON TABLE crep TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE crep TO PUBLIC;


--
-- Name: crev; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE crev FROM PUBLIC;
REVOKE ALL ON TABLE crev FROM source;
GRANT ALL ON TABLE crev TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE crev TO PUBLIC;


--
-- Name: empl; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE empl FROM PUBLIC;
REVOKE ALL ON TABLE empl FROM source;
GRANT ALL ON TABLE empl TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE empl TO PUBLIC;


--
-- Name: feet; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE feet FROM PUBLIC;
REVOKE ALL ON TABLE feet FROM source;
GRANT ALL ON TABLE feet TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE feet TO PUBLIC;


--
-- Name: prov; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE prov FROM PUBLIC;
REVOKE ALL ON TABLE prov FROM source;
GRANT ALL ON TABLE prov TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE prov TO PUBLIC;


--
-- Name: rfdr; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE rfdr FROM PUBLIC;
REVOKE ALL ON TABLE rfdr FROM source;
GRANT ALL ON TABLE rfdr TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE rfdr TO PUBLIC;


--
-- Name: crlt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE crlt FROM PUBLIC;
REVOKE ALL ON TABLE crlt FROM source;
GRANT ALL ON TABLE crlt TO source;
GRANT SELECT ON TABLE crlt TO PUBLIC;


--
-- Name: crsm; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE crsm FROM PUBLIC;
REVOKE ALL ON TABLE crsm FROM source;
GRANT ALL ON TABLE crsm TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE crsm TO PUBLIC;


--
-- Name: crsm_crsm__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE crsm_crsm__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE crsm_crsm__sequence_seq FROM source;
GRANT ALL ON TABLE crsm_crsm__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE crsm_crsm__sequence_seq TO PUBLIC;


--
-- Name: dbag; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE dbag FROM PUBLIC;
REVOKE ALL ON TABLE dbag FROM source;
GRANT ALL ON TABLE dbag TO source;
GRANT SELECT ON TABLE dbag TO PUBLIC;


--
-- Name: dbst; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE dbst FROM PUBLIC;
REVOKE ALL ON TABLE dbst FROM source;
GRANT ALL ON TABLE dbst TO source;
GRANT SELECT ON TABLE dbst TO PUBLIC;


--
-- Name: dbtr_dbtr__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE dbtr_dbtr__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE dbtr_dbtr__sequence_seq FROM source;
GRANT ALL ON TABLE dbtr_dbtr__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE dbtr_dbtr__sequence_seq TO PUBLIC;


--
-- Name: diag; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE diag FROM PUBLIC;
REVOKE ALL ON TABLE diag FROM source;
GRANT ALL ON TABLE diag TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE diag TO PUBLIC;


--
-- Name: diag_diag__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE diag_diag__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE diag_diag__sequence_seq FROM source;
GRANT ALL ON TABLE diag_diag__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE diag_diag__sequence_seq TO PUBLIC;


--
-- Name: docs; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE docs FROM PUBLIC;
REVOKE ALL ON TABLE docs FROM source;
GRANT ALL ON TABLE docs TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE docs TO PUBLIC;


--
-- Name: docs_docs__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE docs_docs__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE docs_docs__sequence_seq FROM source;
GRANT ALL ON TABLE docs_docs__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE docs_docs__sequence_seq TO PUBLIC;


--
-- Name: eftr; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE eftr FROM PUBLIC;
REVOKE ALL ON TABLE eftr FROM source;
GRANT ALL ON TABLE eftr TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE eftr TO PUBLIC;


--
-- Name: eftr_eftr__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE eftr_eftr__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE eftr_eftr__sequence_seq FROM source;
GRANT ALL ON TABLE eftr_eftr__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE eftr_eftr__sequence_seq TO PUBLIC;


--
-- Name: eftv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE eftv FROM PUBLIC;
REVOKE ALL ON TABLE eftv FROM source;
GRANT ALL ON TABLE eftv TO source;
GRANT SELECT ON TABLE eftv TO PUBLIC;


--
-- Name: empl_empl__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE empl_empl__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE empl_empl__sequence_seq FROM source;
GRANT ALL ON TABLE empl_empl__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE empl_empl__sequence_seq TO PUBLIC;


--
-- Name: epsd; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE epsd FROM PUBLIC;
REVOKE ALL ON TABLE epsd FROM source;
GRANT ALL ON TABLE epsd TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE epsd TO PUBLIC;


--
-- Name: epsd_epsd__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE epsd_epsd__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE epsd_epsd__sequence_seq FROM source;
GRANT ALL ON TABLE epsd_epsd__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE epsd_epsd__sequence_seq TO PUBLIC;


--
-- Name: evnt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE evnt FROM PUBLIC;
REVOKE ALL ON TABLE evnt FROM source;
GRANT ALL ON TABLE evnt TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE evnt TO PUBLIC;


--
-- Name: evnt_evnt__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE evnt_evnt__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE evnt_evnt__sequence_seq FROM source;
GRANT ALL ON TABLE evnt_evnt__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE evnt_evnt__sequence_seq TO PUBLIC;


--
-- Name: locn; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE locn FROM PUBLIC;
REVOKE ALL ON TABLE locn FROM source;
GRANT ALL ON TABLE locn TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE locn TO PUBLIC;


--
-- Name: evnv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE evnv FROM PUBLIC;
REVOKE ALL ON TABLE evnv FROM source;
GRANT ALL ON TABLE evnv TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE evnv TO PUBLIC;


--
-- Name: evwl; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE evwl FROM PUBLIC;
REVOKE ALL ON TABLE evwl FROM source;
GRANT ALL ON TABLE evwl TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE evwl TO PUBLIC;


--
-- Name: feeb; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE feeb FROM PUBLIC;
REVOKE ALL ON TABLE feeb FROM source;
GRANT ALL ON TABLE feeb TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE feeb TO PUBLIC;


--
-- Name: feeb_feeb__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE feeb_feeb__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE feeb_feeb__sequence_seq FROM source;
GRANT ALL ON TABLE feeb_feeb__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE feeb_feeb__sequence_seq TO PUBLIC;


--
-- Name: mvac_database; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mvac_database FROM PUBLIC;
REVOKE ALL ON TABLE mvac_database FROM source;
GRANT ALL ON TABLE mvac_database TO source;
GRANT SELECT ON TABLE mvac_database TO PUBLIC;


--
-- Name: serv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE serv FROM PUBLIC;
REVOKE ALL ON TABLE serv FROM source;
GRANT ALL ON TABLE serv TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE serv TO PUBLIC;


--
-- Name: feel; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE feel FROM PUBLIC;
REVOKE ALL ON TABLE feel FROM source;
GRANT ALL ON TABLE feel TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE feel TO PUBLIC;


--
-- Name: feet_feet__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE feet_feet__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE feet_feet__sequence_seq FROM source;
GRANT ALL ON TABLE feet_feet__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE feet_feet__sequence_seq TO PUBLIC;


--
-- Name: fept; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE fept FROM PUBLIC;
REVOKE ALL ON TABLE fept FROM source;
GRANT ALL ON TABLE fept TO source;
GRANT SELECT ON TABLE fept TO PUBLIC;


--
-- Name: fmdt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE fmdt FROM PUBLIC;
REVOKE ALL ON TABLE fmdt FROM source;
GRANT ALL ON TABLE fmdt TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE fmdt TO PUBLIC;


--
-- Name: form; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE form FROM PUBLIC;
REVOKE ALL ON TABLE form FROM source;
GRANT ALL ON TABLE form TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE form TO PUBLIC;


--
-- Name: gsti; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE gsti FROM PUBLIC;
REVOKE ALL ON TABLE gsti FROM source;
GRANT ALL ON TABLE gsti TO source;
GRANT SELECT ON TABLE gsti TO PUBLIC;


--
-- Name: gstv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE gstv FROM PUBLIC;
REVOKE ALL ON TABLE gstv FROM source;
GRANT ALL ON TABLE gstv TO source;
GRANT SELECT ON TABLE gstv TO PUBLIC;


--
-- Name: hice; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE hice FROM PUBLIC;
REVOKE ALL ON TABLE hice FROM source;
GRANT ALL ON TABLE hice TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE hice TO PUBLIC;


--
-- Name: hice_hice__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE hice_hice__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE hice_hice__sequence_seq FROM source;
GRANT ALL ON TABLE hice_hice__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE hice_hice__sequence_seq TO PUBLIC;


--
-- Name: mdaf; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mdaf FROM PUBLIC;
REVOKE ALL ON TABLE mdaf FROM source;
GRANT ALL ON TABLE mdaf TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mdaf TO PUBLIC;


--
-- Name: mdbt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mdbt FROM PUBLIC;
REVOKE ALL ON TABLE mdbt FROM source;
GRANT ALL ON TABLE mdbt TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mdbt TO PUBLIC;


--
-- Name: svpf; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svpf FROM PUBLIC;
REVOKE ALL ON TABLE svpf FROM source;
GRANT ALL ON TABLE svpf TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE svpf TO PUBLIC;


--
-- Name: hicv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE hicv FROM PUBLIC;
REVOKE ALL ON TABLE hicv FROM source;
GRANT ALL ON TABLE hicv TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE hicv TO PUBLIC;


--
-- Name: hlfd; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE hlfd FROM PUBLIC;
REVOKE ALL ON TABLE hlfd FROM source;
GRANT ALL ON TABLE hlfd TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE hlfd TO PUBLIC;


--
-- Name: hlfd_hlfd__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE hlfd_hlfd__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE hlfd_hlfd__sequence_seq FROM source;
GRANT ALL ON TABLE hlfd_hlfd__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE hlfd_hlfd__sequence_seq TO PUBLIC;


--
-- Name: icd9; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE icd9 FROM PUBLIC;
REVOKE ALL ON TABLE icd9 FROM source;
GRANT ALL ON TABLE icd9 TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE icd9 TO PUBLIC;


--
-- Name: icd9_icd9__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE icd9_icd9__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE icd9_icd9__sequence_seq FROM source;
GRANT ALL ON TABLE icd9_icd9__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE icd9_icd9__sequence_seq TO PUBLIC;


--
-- Name: inst; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE inst FROM PUBLIC;
REVOKE ALL ON TABLE inst FROM source;
GRANT ALL ON TABLE inst TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE inst TO PUBLIC;


--
-- Name: inst_inst__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE inst_inst__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE inst_inst__sequence_seq FROM source;
GRANT ALL ON TABLE inst_inst__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE inst_inst__sequence_seq TO PUBLIC;


--
-- Name: invc_invc__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE invc_invc__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE invc_invc__sequence_seq FROM source;
GRANT ALL ON TABLE invc_invc__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE invc_invc__sequence_seq TO PUBLIC;


--
-- Name: labl; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE labl FROM PUBLIC;
REVOKE ALL ON TABLE labl FROM source;
GRANT ALL ON TABLE labl TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE labl TO PUBLIC;


--
-- Name: labl_labl__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE labl_labl__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE labl_labl__sequence_seq FROM source;
GRANT ALL ON TABLE labl_labl__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE labl_labl__sequence_seq TO PUBLIC;


--
-- Name: locn_locn__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE locn_locn__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE locn_locn__sequence_seq FROM source;
GRANT ALL ON TABLE locn_locn__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE locn_locn__sequence_seq TO PUBLIC;


--
-- Name: lthd; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE lthd FROM PUBLIC;
REVOKE ALL ON TABLE lthd FROM source;
GRANT ALL ON TABLE lthd TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE lthd TO PUBLIC;


--
-- Name: lthd_lthd__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE lthd_lthd__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE lthd_lthd__sequence_seq FROM source;
GRANT ALL ON TABLE lthd_lthd__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE lthd_lthd__sequence_seq TO PUBLIC;


--
-- Name: mbst; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mbst FROM PUBLIC;
REVOKE ALL ON TABLE mbst FROM source;
GRANT ALL ON TABLE mbst TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mbst TO PUBLIC;


--
-- Name: mbst_mbst__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mbst_mbst__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mbst_mbst__sequence_seq FROM source;
GRANT ALL ON TABLE mbst_mbst__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mbst_mbst__sequence_seq TO PUBLIC;


--
-- Name: mdaf_mdaf__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mdaf_mdaf__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mdaf_mdaf__sequence_seq FROM source;
GRANT ALL ON TABLE mdaf_mdaf__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mdaf_mdaf__sequence_seq TO PUBLIC;


--
-- Name: mdbt_mdbt__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mdbt_mdbt__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mdbt_mdbt__sequence_seq FROM source;
GRANT ALL ON TABLE mdbt_mdbt__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mdbt_mdbt__sequence_seq TO PUBLIC;


--
-- Name: mdcr; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mdcr FROM PUBLIC;
REVOKE ALL ON TABLE mdcr FROM source;
GRANT ALL ON TABLE mdcr TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mdcr TO PUBLIC;


--
-- Name: mdcr_mdcr__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mdcr_mdcr__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mdcr_mdcr__sequence_seq FROM source;
GRANT ALL ON TABLE mdcr_mdcr__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mdcr_mdcr__sequence_seq TO PUBLIC;


--
-- Name: mtad; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtad FROM PUBLIC;
REVOKE ALL ON TABLE mtad FROM source;
GRANT ALL ON TABLE mtad TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtad TO PUBLIC;


--
-- Name: mtad_mtad__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtad_mtad__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtad_mtad__sequence_seq FROM source;
GRANT ALL ON TABLE mtad_mtad__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtad_mtad__sequence_seq TO PUBLIC;


--
-- Name: mtag; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtag FROM PUBLIC;
REVOKE ALL ON TABLE mtag FROM source;
GRANT ALL ON TABLE mtag TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtag TO PUBLIC;


--
-- Name: mtag_mtag__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtag_mtag__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtag_mtag__sequence_seq FROM source;
GRANT ALL ON TABLE mtag_mtag__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtag_mtag__sequence_seq TO PUBLIC;


--
-- Name: mtal; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtal FROM PUBLIC;
REVOKE ALL ON TABLE mtal FROM source;
GRANT ALL ON TABLE mtal TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtal TO PUBLIC;


--
-- Name: mtal_mtal__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtal_mtal__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtal_mtal__sequence_seq FROM source;
GRANT ALL ON TABLE mtal_mtal__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtal_mtal__sequence_seq TO PUBLIC;


--
-- Name: mtat; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtat FROM PUBLIC;
REVOKE ALL ON TABLE mtat FROM source;
GRANT ALL ON TABLE mtat TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtat TO PUBLIC;


--
-- Name: mtat_mtat__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtat_mtat__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtat_mtat__sequence_seq FROM source;
GRANT ALL ON TABLE mtat_mtat__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtat_mtat__sequence_seq TO PUBLIC;


--
-- Name: mtau; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtau FROM PUBLIC;
REVOKE ALL ON TABLE mtau FROM source;
GRANT ALL ON TABLE mtau TO source;
GRANT INSERT,SELECT ON TABLE mtau TO PUBLIC;


--
-- Name: mtau_mtau__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtau_mtau__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtau_mtau__sequence_seq FROM source;
GRANT ALL ON TABLE mtau_mtau__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtau_mtau__sequence_seq TO PUBLIC;


--
-- Name: mtcl; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtcl FROM PUBLIC;
REVOKE ALL ON TABLE mtcl FROM source;
GRANT ALL ON TABLE mtcl TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtcl TO PUBLIC;


--
-- Name: mtcl_mtcl__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtcl_mtcl__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtcl_mtcl__sequence_seq FROM source;
GRANT ALL ON TABLE mtcl_mtcl__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtcl_mtcl__sequence_seq TO PUBLIC;


--
-- Name: mtfn; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtfn FROM PUBLIC;
REVOKE ALL ON TABLE mtfn FROM source;
GRANT ALL ON TABLE mtfn TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtfn TO PUBLIC;


--
-- Name: mtfn_mtfn__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtfn_mtfn__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtfn_mtfn__sequence_seq FROM source;
GRANT ALL ON TABLE mtfn_mtfn__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtfn_mtfn__sequence_seq TO PUBLIC;


--
-- Name: mtop; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtop FROM PUBLIC;
REVOKE ALL ON TABLE mtop FROM source;
GRANT ALL ON TABLE mtop TO source;
GRANT SELECT ON TABLE mtop TO PUBLIC;


--
-- Name: mtop_mtop__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtop_mtop__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtop_mtop__sequence_seq FROM source;
GRANT ALL ON TABLE mtop_mtop__sequence_seq TO source;
GRANT SELECT ON TABLE mtop_mtop__sequence_seq TO PUBLIC;


--
-- Name: mtpt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtpt FROM PUBLIC;
REVOKE ALL ON TABLE mtpt FROM source;
GRANT ALL ON TABLE mtpt TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtpt TO PUBLIC;


--
-- Name: mtpt_mtpt__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtpt_mtpt__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtpt_mtpt__sequence_seq FROM source;
GRANT ALL ON TABLE mtpt_mtpt__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtpt_mtpt__sequence_seq TO PUBLIC;


--
-- Name: mtrl; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtrl FROM PUBLIC;
REVOKE ALL ON TABLE mtrl FROM source;
GRANT ALL ON TABLE mtrl TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtrl TO PUBLIC;


--
-- Name: mtrl_mtrl__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtrl_mtrl__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtrl_mtrl__sequence_seq FROM source;
GRANT ALL ON TABLE mtrl_mtrl__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mtrl_mtrl__sequence_seq TO PUBLIC;


--
-- Name: mtsv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtsv FROM PUBLIC;
REVOKE ALL ON TABLE mtsv FROM source;
GRANT ALL ON TABLE mtsv TO source;
GRANT SELECT ON TABLE mtsv TO PUBLIC;


--
-- Name: mttb; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mttb FROM PUBLIC;
REVOKE ALL ON TABLE mttb FROM source;
GRANT ALL ON TABLE mttb TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mttb TO PUBLIC;


--
-- Name: mttb_mttb__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mttb_mttb__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mttb_mttb__sequence_seq FROM source;
GRANT ALL ON TABLE mttb_mttb__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE mttb_mttb__sequence_seq TO PUBLIC;


--
-- Name: mttk; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mttk FROM PUBLIC;
REVOKE ALL ON TABLE mttk FROM source;
GRANT ALL ON TABLE mttk TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mttk TO PUBLIC;


--
-- Name: mttk_mttk__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mttk_mttk__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mttk_mttk__sequence_seq FROM source;
GRANT ALL ON TABLE mttk_mttk__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mttk_mttk__sequence_seq TO PUBLIC;


--
-- Name: mtvs; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtvs FROM PUBLIC;
REVOKE ALL ON TABLE mtvs FROM source;
GRANT ALL ON TABLE mtvs TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtvs TO PUBLIC;


--
-- Name: mtvs_mtvs__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mtvs_mtvs__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE mtvs_mtvs__sequence_seq FROM source;
GRANT ALL ON TABLE mtvs_mtvs__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE mtvs_mtvs__sequence_seq TO PUBLIC;


--
-- Name: mvac_label; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mvac_label FROM PUBLIC;
REVOKE ALL ON TABLE mvac_label FROM source;
GRANT ALL ON TABLE mvac_label TO source;
GRANT SELECT ON TABLE mvac_label TO PUBLIC;


--
-- Name: mvac_user; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE mvac_user FROM PUBLIC;
REVOKE ALL ON TABLE mvac_user FROM source;
GRANT ALL ON TABLE mvac_user TO source;
GRANT SELECT ON TABLE mvac_user TO PUBLIC;


--
-- Name: note; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE note FROM PUBLIC;
REVOKE ALL ON TABLE note FROM source;
GRANT ALL ON TABLE note TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE note TO PUBLIC;


--
-- Name: note_note__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE note_note__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE note_note__sequence_seq FROM source;
GRANT ALL ON TABLE note_note__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE note_note__sequence_seq TO PUBLIC;


--
-- Name: notv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE notv FROM PUBLIC;
REVOKE ALL ON TABLE notv FROM source;
GRANT ALL ON TABLE notv TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE notv TO PUBLIC;


--
-- Name: pate; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pate FROM PUBLIC;
REVOKE ALL ON TABLE pate FROM source;
GRANT ALL ON TABLE pate TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE pate TO PUBLIC;


--
-- Name: pate_pate__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pate_pate__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE pate_pate__sequence_seq FROM source;
GRANT ALL ON TABLE pate_pate__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE pate_pate__sequence_seq TO PUBLIC;


--
-- Name: patf; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE patf FROM PUBLIC;
REVOKE ALL ON TABLE patf FROM source;
GRANT ALL ON TABLE patf TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE patf TO PUBLIC;


--
-- Name: patf_patf__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE patf_patf__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE patf_patf__sequence_seq FROM source;
GRANT ALL ON TABLE patf_patf__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE patf_patf__sequence_seq TO PUBLIC;


--
-- Name: patn_patn__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE patn_patn__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE patn_patn__sequence_seq FROM source;
GRANT ALL ON TABLE patn_patn__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE patn_patn__sequence_seq TO PUBLIC;


--
-- Name: patv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE patv FROM PUBLIC;
REVOKE ALL ON TABLE patv FROM source;
GRANT ALL ON TABLE patv TO source;
GRANT SELECT ON TABLE patv TO PUBLIC;


--
-- Name: paym_paym__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE paym_paym__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE paym_paym__sequence_seq FROM source;
GRANT ALL ON TABLE paym_paym__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE paym_paym__sequence_seq TO PUBLIC;


--
-- Name: pcde; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pcde FROM PUBLIC;
REVOKE ALL ON TABLE pcde FROM source;
GRANT ALL ON TABLE pcde TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE pcde TO PUBLIC;


--
-- Name: pcde_pcde__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pcde_pcde__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE pcde_pcde__sequence_seq FROM source;
GRANT ALL ON TABLE pcde_pcde__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE pcde_pcde__sequence_seq TO PUBLIC;


--
-- Name: pemd; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pemd FROM PUBLIC;
REVOKE ALL ON TABLE pemd FROM source;
GRANT ALL ON TABLE pemd TO source;
GRANT SELECT ON TABLE pemd TO PUBLIC;


--
-- Name: pmsc; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pmsc FROM PUBLIC;
REVOKE ALL ON TABLE pmsc FROM source;
GRANT ALL ON TABLE pmsc TO source;
GRANT SELECT ON TABLE pmsc TO PUBLIC;


--
-- Name: pmsp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pmsp FROM PUBLIC;
REVOKE ALL ON TABLE pmsp FROM source;
GRANT ALL ON TABLE pmsp TO source;
GRANT SELECT ON TABLE pmsp TO PUBLIC;


--
-- Name: prnt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE prnt FROM PUBLIC;
REVOKE ALL ON TABLE prnt FROM source;
GRANT ALL ON TABLE prnt TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE prnt TO PUBLIC;


--
-- Name: prnt_prnt__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE prnt_prnt__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE prnt_prnt__sequence_seq FROM source;
GRANT ALL ON TABLE prnt_prnt__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE prnt_prnt__sequence_seq TO PUBLIC;


--
-- Name: prov_prov__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE prov_prov__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE prov_prov__sequence_seq FROM source;
GRANT ALL ON TABLE prov_prov__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE prov_prov__sequence_seq TO PUBLIC;


--
-- Name: ptss; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE ptss FROM PUBLIC;
REVOKE ALL ON TABLE ptss FROM source;
GRANT ALL ON TABLE ptss TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE ptss TO PUBLIC;


--
-- Name: pyas; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pyas FROM PUBLIC;
REVOKE ALL ON TABLE pyas FROM source;
GRANT ALL ON TABLE pyas TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE pyas TO PUBLIC;


--
-- Name: pyas_pyas__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE pyas_pyas__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE pyas_pyas__sequence_seq FROM source;
GRANT ALL ON TABLE pyas_pyas__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE pyas_pyas__sequence_seq TO PUBLIC;


--
-- Name: rfdr_rfdr__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE rfdr_rfdr__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE rfdr_rfdr__sequence_seq FROM source;
GRANT ALL ON TABLE rfdr_rfdr__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE rfdr_rfdr__sequence_seq TO PUBLIC;


--
-- Name: sclt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE sclt FROM PUBLIC;
REVOKE ALL ON TABLE sclt FROM source;
GRANT ALL ON TABLE sclt TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE sclt TO PUBLIC;


--
-- Name: sclt_sclt__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE sclt_sclt__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE sclt_sclt__sequence_seq FROM source;
GRANT ALL ON TABLE sclt_sclt__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE sclt_sclt__sequence_seq TO PUBLIC;


--
-- Name: serv_serv__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE serv_serv__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE serv_serv__sequence_seq FROM source;
GRANT ALL ON TABLE serv_serv__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE serv_serv__sequence_seq TO PUBLIC;


--
-- Name: ssms; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE ssms FROM PUBLIC;
REVOKE ALL ON TABLE ssms FROM source;
GRANT ALL ON TABLE ssms TO source;
GRANT SELECT ON TABLE ssms TO PUBLIC;


--
-- Name: ssmc; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE ssmc FROM PUBLIC;
REVOKE ALL ON TABLE ssmc FROM source;
GRANT ALL ON TABLE ssmc TO source;
GRANT SELECT ON TABLE ssmc TO PUBLIC;


--
-- Name: ssmp; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE ssmp FROM PUBLIC;
REVOKE ALL ON TABLE ssmp FROM source;
GRANT ALL ON TABLE ssmp TO source;
GRANT SELECT ON TABLE ssmp TO PUBLIC;


--
-- Name: stts; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE stts FROM PUBLIC;
REVOKE ALL ON TABLE stts FROM source;
GRANT ALL ON TABLE stts TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE stts TO PUBLIC;


--
-- Name: stts_stts__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE stts_stts__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE stts_stts__sequence_seq FROM source;
GRANT ALL ON TABLE stts_stts__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE stts_stts__sequence_seq TO PUBLIC;


--
-- Name: surg; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE surg FROM PUBLIC;
REVOKE ALL ON TABLE surg FROM source;
GRANT ALL ON TABLE surg TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE surg TO PUBLIC;


--
-- Name: surg_surg__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE surg_surg__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE surg_surg__sequence_seq FROM source;
GRANT ALL ON TABLE surg_surg__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE surg_surg__sequence_seq TO PUBLIC;


--
-- Name: surv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE surv FROM PUBLIC;
REVOKE ALL ON TABLE surv FROM source;
GRANT ALL ON TABLE surv TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE surv TO PUBLIC;


--
-- Name: svlt; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svlt FROM PUBLIC;
REVOKE ALL ON TABLE svlt FROM source;
GRANT ALL ON TABLE svlt TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE svlt TO PUBLIC;


--
-- Name: svpf_svpf__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svpf_svpf__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE svpf_svpf__sequence_seq FROM source;
GRANT ALL ON TABLE svpf_svpf__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE svpf_svpf__sequence_seq TO PUBLIC;


--
-- Name: svpv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svpv FROM PUBLIC;
REVOKE ALL ON TABLE svpv FROM source;
GRANT ALL ON TABLE svpv TO source;
GRANT SELECT ON TABLE svpv TO PUBLIC;


--
-- Name: svrv; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svrv FROM PUBLIC;
REVOKE ALL ON TABLE svrv FROM source;
GRANT ALL ON TABLE svrv TO source;
GRANT SELECT ON TABLE svrv TO PUBLIC;


--
-- Name: svsm; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svsm FROM PUBLIC;
REVOKE ALL ON TABLE svsm FROM source;
GRANT ALL ON TABLE svsm TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE svsm TO PUBLIC;


--
-- Name: svsm_svsm__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE svsm_svsm__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE svsm_svsm__sequence_seq FROM source;
GRANT ALL ON TABLE svsm_svsm__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE ON TABLE svsm_svsm__sequence_seq TO PUBLIC;


--
-- Name: tdtp_tdtp__sequence_seq; Type: ACL; Schema: public; Owner: source
--

REVOKE ALL ON TABLE tdtp_tdtp__sequence_seq FROM PUBLIC;
REVOKE ALL ON TABLE tdtp_tdtp__sequence_seq FROM source;
GRANT ALL ON TABLE tdtp_tdtp__sequence_seq TO source;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE tdtp_tdtp__sequence_seq TO PUBLIC;


--
-- PostgreSQL database dump complete
--

